-- HF15 CAM-01: follower-only local Mini UI camera preference.
-- This module uses only a saved zoom + camera tracking preference and a small,
-- reversible pitch nudge. It never overwrites the player's saved camera views.
-- Gameplay, party, follow, protected clicks and the Group Leader are untouched.
local HB=HaploBox
local pendingPitchStop=0
local activePitch=nil
local PITCH_DURATION=0.16
local PITCH_SPEED=0.85
local TARGET_ZOOM=20
local TRACKING_KEY="cameraSmoothTrackingStyle"
local function blocked() return InCombatLockdown and InCombatLockdown() end
local function follower()
    return IsInGroup and IsInGroup() and HB.IAmLeader and not HB.IAmLeader()
end
local function cvarGet(k)
    local fn=(C_CVar and C_CVar.GetCVar) or GetCVar
    if not fn then return nil end
    local ok,result=pcall(fn,k)
    if ok and result~=nil then return tostring(result) end
end
local function cvarSet(k,v)
    local fn=(C_CVar and C_CVar.SetCVar) or SetCVar
    if not fn or v==nil then return false end
    return pcall(fn,k,tostring(v))
end
local function zoomValue()
    if not GetCameraZoom then return nil end
    local ok,v=pcall(GetCameraZoom)
    if ok and type(v)=="number" and v>=0 and v<100 then return v end
end
local function adjustZoom(target)
    local actual=zoomValue()
    if not actual or not target or blocked() then return end
    local difference=target-actual
    if difference>0.18 and CameraZoomOut then pcall(CameraZoomOut,difference)
    elseif difference<(-0.18) and CameraZoomIn then pcall(CameraZoomIn,-difference) end
end
local function stopPitch()
    if not activePitch then return 0 end
    local elapsed=GetTime and GetTime()-activePitch.started or PITCH_DURATION
    if type(elapsed)~="number" or elapsed<0 then elapsed=PITCH_DURATION end
    local seconds=math.min(PITCH_DURATION,elapsed)
    local stop=activePitch.direction=="down" and MoveViewDownStop or MoveViewUpStop
    if stop then pcall(stop) end
    activePitch=nil
    return seconds
end
local function pitch(direction,seconds)
    if blocked() or not (C_Timer and C_Timer.After) or not (GetTime and type(seconds)=="number" and seconds>0) then return false end
    local start=direction=="down" and MoveViewDownStart or MoveViewUpStart
    local stop=direction=="down" and MoveViewDownStop or MoveViewUpStop
    if not start or not stop then return false end
    stopPitch()
    pendingPitchStop=pendingPitchStop+1
    local token=pendingPitchStop
    local ok=pcall(start,PITCH_SPEED)
    if not ok then return false end
    activePitch={direction=direction,started=GetTime()}
    C_Timer.After(seconds,function()
        if token~=pendingPitchStop then return end
        stopPitch()
    end)
    return true
end
local function restore()
    if not HB.db then return end
    local snapshot=HB.db.miniCameraSnapshot
    if not snapshot then return end
    if blocked() then return end
    -- A pending down nudge is shortened to the actual elapsed interval.
    if activePitch and activePitch.direction=="down" then
        snapshot.pitchSeconds=stopPitch()
    else stopPitch() end
    if snapshot.tracking~=nil then cvarSet(TRACKING_KEY,snapshot.tracking) end
    if snapshot.zoom then adjustZoom(snapshot.zoom) end
    -- Restore the relative pitch movement, without touching camera view slots.
    if snapshot.pitchSeconds and snapshot.pitchSeconds>0 then
        pitch("up",snapshot.pitchSeconds)
    end
    HB.db.miniCameraSnapshot=nil
end
function HB.ApplyMiniCamera(enabled)
    if not HB.db or blocked() then return end
    if not enabled or not follower() then restore();return end
    local existing=HB.db.miniCameraSnapshot
    if existing then
        -- Reapply only zoom/tracking after reload; do NOT tilt twice.
        cvarSet(TRACKING_KEY,"4")
        local current=zoomValue()
        if current and current<TARGET_ZOOM then adjustZoom(TARGET_ZOOM) end
        return
    end
    local snapshot={zoom=zoomValue(),tracking=cvarGet(TRACKING_KEY)}
    HB.db.miniCameraSnapshot=snapshot
    cvarSet(TRACKING_KEY,"4") -- Blizzard: automatically follow while moving
    local current=zoomValue()
    if current and current<TARGET_ZOOM then adjustZoom(TARGET_ZOOM) end
    if pitch("down",PITCH_DURATION) then snapshot.pitchSeconds=PITCH_DURATION end
end
function HB.RestoreMiniCamera() restore() end
-- On a /reload, the game may keep the camera while Lua is reconstructed.
-- Reconcile only after MiniHeal has applied its on-world mode logic.
local events=CreateFrame("Frame")
events:RegisterEvent("PLAYER_ENTERING_WORLD")
events:RegisterEvent("PLAYER_REGEN_ENABLED")
events:RegisterEvent("GROUP_ROSTER_UPDATE")
events:RegisterEvent("PLAYER_LOGOUT")
events:SetScript("OnEvent",function(_,event)
    if not HB.db then return end
    if event=="PLAYER_LOGOUT" then restore();return end
    if blocked() then return end
    if event=="PLAYER_ENTERING_WORLD" and C_Timer and C_Timer.After then
        C_Timer.After(0,function()
            if HB.db then HB.ApplyMiniCamera(HB.db.miniHealMode) end
        end)
    elseif event=="PLAYER_REGEN_ENABLED" or event=="GROUP_ROSTER_UPDATE" then
        HB.ApplyMiniCamera(HB.db.miniHealMode)
    end
end)

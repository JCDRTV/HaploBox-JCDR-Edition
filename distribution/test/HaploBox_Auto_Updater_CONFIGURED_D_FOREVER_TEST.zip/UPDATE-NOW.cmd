@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%LOCALAPPDATA%\HaploBoxUpdater\HaploBox-Updater.ps1"
if errorlevel 1 (
    echo Update mislukt. Kijk in %%LOCALAPPDATA%%\HaploBoxUpdater\updater.log
)
pause

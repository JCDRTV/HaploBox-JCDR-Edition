# One-time setup, for ONE Interface\AddOns directory shared by all WoW clients.
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
$Base = Join-Path $env:LOCALAPPDATA 'HaploBoxUpdater'
$UpSrc = Join-Path $PSScriptRoot 'HaploBox-Updater.ps1'
$UpDest = Join-Path $Base 'HaploBox-Updater.ps1'
$ConfigPath = Join-Path $Base 'config.json'
$ManifestUrl = 'https://raw.githubusercontent.com/JCDRTV/HaploBox-JCDR-Edition/main/distribution/test/manifest.json'
# Exact WoW folder confirmed by the user. Fall back to the picker only if missing.
$PreferredAddons = 'D:\World of Warcraft\_forever_\Interface\AddOns'

try {
    if (-not (Test-Path -LiteralPath $UpSrc -PathType Leaf)) { throw 'Updaterbestand ontbreekt naast het installatiebestand.' }
    New-Item -ItemType Directory -Path $Base -Force | Out-Null
    $addons = $null
    if (Test-Path -LiteralPath $PreferredAddons -PathType Container) {
        $addons = $PreferredAddons
        Write-Host "Geconfigureerde WoW-map gevonden: $addons" -ForegroundColor Green
    }
    if (-not $addons -and (Test-Path -LiteralPath $ConfigPath -PathType Leaf)) {
        try {
            $previous = Get-Content -LiteralPath $ConfigPath -Raw | ConvertFrom-Json
            if ((Test-Path -LiteralPath $previous.addons_path -PathType Container) -and ((Split-Path $previous.addons_path -Leaf) -ieq 'AddOns')) {
                $addons = [string]$previous.addons_path
                Write-Host "Bestaande WoW-map hergebruiken: $addons"
            }
        } catch { $addons = $null }
    }
    if (-not $addons) {
        Add-Type -AssemblyName System.Windows.Forms
        $dialog = New-Object System.Windows.Forms.FolderBrowserDialog
        $dialog.Description = 'Kies jouw ENIGE WoW-map Interface\AddOns (niet de HaploBox-submap).'
        $dialog.ShowNewFolderButton = $false
        $result = $dialog.ShowDialog()
        if ($result -ne [System.Windows.Forms.DialogResult]::OK) { throw 'Geen map gekozen. Er is niets gewijzigd.' }
        $selected = $dialog.SelectedPath
        if ((Split-Path $selected -Leaf) -ieq 'AddOns') {
            $addons = $selected
        } else {
            $found = @()
            foreach ($rel in @('Interface\AddOns','_classic_era_\Interface\AddOns','_classic_\Interface\AddOns','_retail_\Interface\AddOns')) {
                $p = Join-Path $selected $rel
                if (Test-Path -LiteralPath $p -PathType Container) { $found += $p }
            }
            if ($found.Count -eq 1) { $addons = $found[0] }
            else { throw 'Selecteer de exacte Interface\AddOns-map. Geen of meerdere mogelijke installaties aangetroffen.' }
        }
    }
    $addons = (Resolve-Path -LiteralPath $addons).ProviderPath
    if ((Split-Path $addons -Leaf) -ine 'AddOns') { throw 'Geen geldige Interface\AddOns-map.' }
    Copy-Item -LiteralPath $UpSrc -Destination $UpDest -Force
    [ordered]@{ addons_path=$addons; channel='test'; manifest_url=$ManifestUrl } |
        ConvertTo-Json | Set-Content -LiteralPath $ConfigPath -Encoding UTF8

    Write-Host ''
    Write-Host 'Eerste synchronisatie (testbuild HF26.17) ...'
    $first = Start-Process -FilePath 'powershell.exe' -ArgumentList ('-NoProfile -ExecutionPolicy Bypass -File "' + $UpDest + '"') -Wait -PassThru
    if ($first.ExitCode -ne 0) { throw 'Eerste download/installatie mislukt. Zie updater.log.' }

    $taskName = 'HaploBox Auto Updater TEST'
    $taskCommand = 'powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "' + $UpDest + '" -Quiet'
    & schtasks.exe /Create /F /SC MINUTE /MO 5 /TN $taskName /TR $taskCommand | Out-Host
    if ($LASTEXITCODE -ne 0) { throw 'De addon is bijgewerkt, maar de geplande taak kon niet worden gemaakt. Gebruik UPDATE-NOW.cmd of stel Task Scheduler handmatig in.' }

    Write-Host ''
    Write-Host 'KLAAR! TEST-kanaal actief. Windows controleert elke 5 minuten GitHub.' -ForegroundColor Green
    Write-Host 'Er is EEN AddOns-map. In alle vijf WoW-clients alleen /reload na een nieuwe build.'
    Write-Host ('Geinstalleerd in: ' + $addons)
    Write-Host ('Status/log: ' + $Base)
} catch {
    Write-Host ('INSTALLATIEFOUT: ' + $_.Exception.Message) -ForegroundColor Red
    Write-Host ('Details: ' + (Join-Path $Base 'updater.log'))
    exit 1
}

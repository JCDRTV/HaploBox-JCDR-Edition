HAPLOBOX — AUTO UPDATER — TEST
================================
Voor EEN WoW-installatiemap met vijf clients.
GitHub repository: https://github.com/JCDRTV/HaploBox-JCDR-Edition

EENMALIG:
1. Pak alle bestanden in deze updater-ZIP uit naar een gewone Windows-map.
2. Dubbelklik INSTALL.cmd.
3. De updater herkent automatisch jouw map:
   D:\World of Warcraft\_forever_\Interface\AddOns
   Alleen als die map niet bestaat vraagt hij om de Interface\AddOns-map.
   Selecteer dan NIET de HaploBox-submap.
4. De updater downloadt de actuele TEST-versie van GitHub,
   controleert SHA-256, maakt een back-up en installeert HaploBox.
5. Windows Taakplanner krijgt een taak die elke 5 minuten controleert.

DAARNA:
- Nieuwe TEST-build via GitHub? De updater installeert die automatisch.
- Op elk van de vijf WoW-clients /reload om gewijzigde Lua-bestanden in te laden.
- Let op: sommige .toc- of structuurwijzigingen vereisen een volledige WoW-herstart.
- Het kan maximaal ongeveer 5 minuten duren voordat een gepubliceerde build is opgehaald.
- Je computer moet aan staan; met pc uit gebeurt er niets.
- WoW SavedVariables (WTF) worden NIET aangepast.
- Alleen HaploBox in de ENIGE door jou gekozen AddOns-map wordt gewijzigd.
- Volledige voorafgaande HaploBox-back-ups staan in:
  %LOCALAPPDATA%\HaploBoxUpdater\Backups
- Gebruik STATUS.cmd om de vorige update en fouten te zien.
- Gebruik UPDATE-NOW.cmd voor een directe handmatige controle.

TEST versus STABLE:
- Deze eerste updater is op het TEST-kanaal ingesteld.
- Er wordt NOOIT automatisch naar STABLE gepromoveerd.
- De GitHub manifest-URL is aan de bekende JCDRTV-repository gebonden.
- Download wordt met SHA-256 gecontroleerd VOORDAT iets wordt geïnstalleerd.
- Bij installatieproblemen probeert de updater automatisch te herstellen.

UITSCHAKELEN:
  Windows Taakplanner > HaploBox Auto Updater TEST > Uitschakelen
  of vanaf een opdrachtprompt:
  schtasks /Delete /TN "HaploBox Auto Updater TEST" /F

OPMERKING:
Het downloaden en installeren kan alleen worden gevalideerd op jouw Windows-pc.
Er zijn hier offline controles uitgevoerd maar geen live Windows/Task Scheduler-test.

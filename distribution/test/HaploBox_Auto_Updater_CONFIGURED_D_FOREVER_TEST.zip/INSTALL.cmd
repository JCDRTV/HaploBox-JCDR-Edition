@echo off
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -STA -File "%~dp0HaploBox-Install-Updater.ps1"
if errorlevel 1 (
    echo.
    echo Installatie niet volledig gelukt. Controleer de melding hierboven.
    pause
    exit /b 1
)
echo.
echo Klaar. Sluit dit venster. In WoW: /reload na een nieuwe build.
pause

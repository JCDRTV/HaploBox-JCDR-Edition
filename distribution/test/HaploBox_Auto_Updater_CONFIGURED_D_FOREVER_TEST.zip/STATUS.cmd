@echo off
set "D=%LOCALAPPDATA%\HaploBoxUpdater"
echo === HaploBox TEST Updater ===
if exist "%D%\state.json" type "%D%\state.json"
if not exist "%D%\state.json" echo Nog geen geslaagde installatie.
echo.
echo Recente logregels:
if exist "%D%\updater.log" powershell.exe -NoProfile -Command "Get-Content -LiteralPath '%D%\updater.log' -Tail 12"
echo.
pause

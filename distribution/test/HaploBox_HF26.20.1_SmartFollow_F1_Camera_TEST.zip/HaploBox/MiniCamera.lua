-- HF15 CAM-01: follower-only local Mini UI camera preference.
-- This module uses only a saved zoom + camera tracking preference and a small,
-- reversible pitch nudge. It never overwrites the player's saved camera views.
-- Gameplay, party, follow, protected clicks and the Group Leader are untouched.
local HB=HaploBox
local pendingPitchStop=0
local activePitch=nil
local PITCH_DURATION=0.16
local PITCH_SPEED=0.85
local TARGET_ZOOM=20
local TRACKING_KEY="cameraSmoothTrackingStyle"
local function blocked() return InCombatLockdown and InCombatLockdown() end
local function follower()
    return IsInGroup and IsInGroup() and HB.IAmLeader and not HB.IAmLeader()
end
local function cvarGet(k)
    local fn=(C_CVar and C_CVar.GetCVar) or GetCVar
    if not fn then return nil end
    local ok,result=pcall(fn,k)
    if ok and result~=nil then return tostring(result) end
end
local function cvarSet(k,v)
    local fn=(C_CVar and C_CVar.SetCVar) or SetCVar
    if not fn or v==nil then return false end
    return pcall(fn,k,tostring(v))
end
local function zoomValue()
    if not GetCameraZoom then return nil end
    local ok,v=pcall(GetCameraZoom)
    if ok and type(v)=="number" and v>=0 and v<100 then return v end
end
local function adjustZoom(target)
    local actual=zoomValue()
    if not actual or not target or blocked() then return end
    local difference=target-actual
    if difference>0.18 and CameraZoomOut then pcall(CameraZoomOut,difference)
    elseif difference<(-0.18) and CameraZoomIn then pcall(CameraZoomIn,-difference) end
end
local function stopPitch()
    if not activePitch then return 0 end
    local elapsed=GetTime and GetTime()-activePitch.started or PITCH_DURATION
    if type(elapsed)~="number" or elapsed<0 then elapsed=PITCH_DURATION end
    local seconds=math.min(PITCH_DURATION,elapsed)
    local stop=activePitch.direction=="down" and MoveViewDownStop or MoveViewUpStop
    if stop then pcall(stop) end
    activePitch=nil
    return seconds
end
local function pitch(direction,seconds)
    if blocked() or not (C_Timer and C_Timer.After) or not (GetTime and type(seconds)=="number" and seconds>0) then return false end
    local start=direction=="down" and MoveViewDownStart or MoveViewUpStart
    local stop=direction=="down" and MoveViewDownStop or MoveViewUpStop
    if not start or not stop then return false end
    stopPitch()
    pendingPitchStop=pendingPitchStop+1
    local token=pendingPitchStop
    local ok=pcall(start,PITCH_SPEED)
    if not ok then return false end
    activePitch={direction=direction,started=GetTime()}
    C_Timer.After(seconds,function()
        if token~=pendingPitchStop then return end
        stopPitch()
    end)
    return true
end
local function restore()
    if not HB.db then return end
    local snapshot=HB.db.miniCameraSnapshot
    if not snapshot then return end
    if blocked() then return end
    -- A pending down nudge is shortened to the actual elapsed interval.
    if activePitch and activePitch.direction=="down" then
        snapshot.pitchSeconds=stopPitch()
    else stopPitch() end
    if snapshot.tracking~=nil then cvarSet(TRACKING_KEY,snapshot.tracking) end
    if snapshot.zoom then adjustZoom(snapshot.zoom) end
    -- Restore the relative pitch movement, without touching camera view slots.
    if snapshot.pitchSeconds and snapshot.pitchSeconds>0 then
        pitch("up",snapshot.pitchSeconds)
    end
    HB.db.miniCameraSnapshot=nil
end
function HB.ApplyMiniCamera(enabled)
    if not HB.db or blocked() then return end
    if not enabled or not follower() then restore();return end
    local existing=HB.db.miniCameraSnapshot
    if existing then
        -- Reapply only zoom/tracking after reload; do NOT tilt twice.
        cvarSet(TRACKING_KEY,"4")
        local current=zoomValue()
        if current and current<TARGET_ZOOM then adjustZoom(TARGET_ZOOM) end
        return
    end
    local snapshot={zoom=zoomValue(),tracking=cvarGet(TRACKING_KEY)}
    HB.db.miniCameraSnapshot=snapshot
    cvarSet(TRACKING_KEY,"4") -- Blizzard: automatically follow while moving
    local current=zoomValue()
    if current and current<TARGET_ZOOM then adjustZoom(TARGET_ZOOM) end
    if pitch("down",PITCH_DURATION) then snapshot.pitchSeconds=PITCH_DURATION end
end
function HB.RestoreMiniCamera() restore() end

-- HF26.20.1 / CAM-F1: exact camera recall on the EXISTING F1 Smart Follow.
-- Calibration is explicit: saving overwrites Blizzard camera view slot 5,
-- therefore ONLY /hb followcam save confirm may invoke SaveView(5).
-- A follower can enable this independently; UI sync must not copy it.
local SMART_FOLLOW_VIEW=5
local pendingFollowView=false
local function followCameraReset()
    if not HB.db or not HB.db.smartFollowCameraSaved or not follower() or
       not HB.db.boxMode or not SetView then return false end
    local ok=pcall(SetView,SMART_FOLLOW_VIEW)
    if not ok then
        if blocked() then pendingFollowView=true end
        return false
    end
    pendingFollowView=false
    -- A saved view is an absolute angle. The Mini Camera's older relative
    -- pitch nudge must NOT later reverse that calibrated angle on Main switch.
    local snapshot=HB.db.miniCameraSnapshot
    if snapshot then snapshot.pitchSeconds=0 end
    if HB.db.miniHealMode then cvarSet(TRACKING_KEY,"4") end
    return true
end
function HB.SmartFollowCamera()
    -- Triggered only by the user's own F1 Blizzard macro; NO auto follow.
    return followCameraReset()
end
function HB.SaveSmartFollowCamera(confirm)
    if not follower() then
        if HB.print then HB.print("Follower camera: configure this on a follower in the party, not Mael.") end
        return false
    end
    if blocked() then
        if HB.print then HB.print("Save follower camera after combat.") end
        return false
    end
    if not confirm then
        if HB.print then HB.print("CAUTION: /hb followcam save confirm overwrites Blizzard camera view 5 on THIS follower only.") end
        return false
    end
    if not SaveView then
        if HB.print then HB.print("WoW SaveView API unavailable; nothing changed.") end
        return false
    end
    local ok=pcall(SaveView,SMART_FOLLOW_VIEW)
    if not ok then
        if HB.print then HB.print("Saving follower camera view 5 failed.") end
        return false
    end
    HB.db.smartFollowCameraSaved=true
    if HB.print then HB.print("Follower camera 5 saved. Your existing F1 now restores this view after /follow.") end
    return true
end
function HB.DisableSmartFollowCamera()
    if not HB.db then return false end
    HB.db.smartFollowCameraSaved=false
    pendingFollowView=false
    if HB.print then HB.print("F1 camera recall OFF. Blizzard view slot 5 was not deleted.") end
    return true
end
function HB.SmartFollowCameraStatus()
    local enabled=HB.db and HB.db.smartFollowCameraSaved==true
    if HB.print then HB.print("Smart Follow F1 camera recall: "..(enabled and "ON (saved Blizzard view 5)" or "OFF; set desired view then /hb followcam save confirm")) end
    return enabled
end
-- On a /reload, the game may keep the camera while Lua is reconstructed.
-- Reconcile only after MiniHeal has applied its on-world mode logic.
local events=CreateFrame("Frame")
events:RegisterEvent("PLAYER_ENTERING_WORLD")
events:RegisterEvent("PLAYER_REGEN_ENABLED")
events:RegisterEvent("GROUP_ROSTER_UPDATE")
events:RegisterEvent("PLAYER_LOGOUT")
events:SetScript("OnEvent",function(_,event)
    if not HB.db then return end
    if event=="PLAYER_LOGOUT" then restore();return end
    if blocked() then return end
    if event=="PLAYER_ENTERING_WORLD" and C_Timer and C_Timer.After then
        C_Timer.After(0,function()
            if HB.db then HB.ApplyMiniCamera(HB.db.miniHealMode) end
        end)
    elseif event=="PLAYER_REGEN_ENABLED" or event=="GROUP_ROSTER_UPDATE" then
        HB.ApplyMiniCamera(HB.db.miniHealMode)
        if event=="PLAYER_REGEN_ENABLED" and pendingFollowView then
            -- After MiniCamera's own reconciling, finish a camera API call
            -- refused in combat. The most recent F1 press is enough.
            if C_Timer and C_Timer.After then
                C_Timer.After(0,function()
                    if pendingFollowView then followCameraReset() end
                end)
            else followCameraReset() end
        end
    end
end)

-- HaploBox TB19.1t: follower Mini UI.  Four full-width bottom party frames,
-- SELF and PARTY1 TARGET above.  All unit buttons are genuine secure unit
-- frames: player clicks / Blizzard click-casting are hardware-only.
-- Secure attributes, visibility/layout and Blizzard HUD writes are NEVER
-- performed from insecure Lua during combat.
local HB=HaploBox
local root,selfSlot,targetSlot,exitButton,settingsButton
local slots={}
local pendingLayout=false
local pendingDesired=nil
local hudHidden=false
local suppressed={}
local suppressionHooks={} -- named frames only: never enumerate arbitrary frames
local secret=function(v) return issecretvalue and issecretvalue(v) end
local function plain(v) if secret(v) then return nil end return v end
local function locked() return InCombatLockdown and InCombatLockdown() end
local function usableNumber(v) return type(v)=="number" and not secret(v) end
local ORANGE={1.0,0.49,0.04}
local EMPTY={0.095,0.105,0.115}
local MISSING_TEAM={0.24,0.035,0.045} -- dark red missing health
local MISSING_TARGET={0.13,0.14,0.16} -- dark grey missing health
local TARGET_RED={0.95,0.17,0.13}
local DARK={0.07,0.075,0.08}
local GREEN={0.24,0.78,0.30}
local function makeBorder(frame)
    for edge=1,4 do
        local line=frame:CreateTexture(nil,"OVERLAY")
        line:SetColorTexture(0.45,0.40,0.26,0.90)
        if edge==1 then line:SetPoint("TOPLEFT");line:SetPoint("TOPRIGHT");line:SetHeight(1)
        elseif edge==2 then line:SetPoint("BOTTOMLEFT");line:SetPoint("BOTTOMRIGHT");line:SetHeight(1)
        elseif edge==3 then line:SetPoint("TOPLEFT");line:SetPoint("BOTTOMLEFT");line:SetWidth(1)
        else line:SetPoint("TOPRIGHT");line:SetPoint("BOTTOMRIGHT");line:SetWidth(1) end
    end
end
local function createSlot(index,kind)
    local frame=CreateFrame("Button","HaploBoxMiniHeal"..index,root,"SecureUnitButtonTemplate")
    frame:RegisterForClicks("AnyUp")
    frame:SetAttribute("type1","target")
    frame:SetAttribute("unit",nil)
    frame:SetFrameStrata("LOW")
    frame:SetFrameLevel(root:GetFrameLevel()+2)
    frame.kind=kind
    frame.active=false
    frame.bg=frame:CreateTexture(nil,"BACKGROUND")
    frame.bg:SetAllPoints()
    frame.bg:SetColorTexture(unpack(kind=="target" and MISSING_TARGET or MISSING_TEAM))
    frame.bar=CreateFrame("StatusBar",nil,frame)
    frame.bar:SetPoint("TOPLEFT",frame,"TOPLEFT",2,-2)
    frame.bar:SetPoint("BOTTOMRIGHT",frame,"BOTTOMRIGHT",-2,2)
    frame.bar:SetStatusBarTexture("Interface\\TargetingFrame\\UI-StatusBar")
    frame.bar:SetStatusBarColor(unpack(ORANGE))
    frame.bar:SetMinMaxValues(0,1)
    frame.bar:SetValue(0)
    frame.incomingHeal=HB.AttachIncomingHealBar and HB.AttachIncomingHealBar(frame.bar)
    frame.icon=frame:CreateTexture(nil,"OVERLAY")
    frame.icon:SetPoint("CENTER")
    frame.icon:SetSize(36,36)
    frame.icon:Hide()
    makeBorder(frame)
    frame:EnableMouse(false)
    -- Blizzard's own click-casting support (where available); the player must
    -- deliberately configure and press the click-cast binding.  No auto-cast.
    if type(ClickCastFrames)=="table" then ClickCastFrames[frame]=true end
    return frame
end
local function showState(f,state)
    if state=="empty" then
        f.bg:SetColorTexture(unpack(EMPTY));f.bar:SetValue(0)
        f.bar:SetStatusBarColor(unpack(DARK));f.bar:SetAlpha(1)
        if f.incomingHeal then f.incomingHeal:Hide() end
        f.icon:Hide()
    elseif state=="dead" then
        f.bg:SetColorTexture(unpack(DARK));f.bar:SetValue(0)
        f.bar:SetStatusBarColor(unpack(DARK));f.bar:SetAlpha(1)
        if f.incomingHeal then f.incomingHeal:Hide() end
        f.icon:SetTexture("Interface\\TargetingFrame\\UI-TargetingFrame-Skull")
        f.icon:SetVertexColor(1,0.18,0.17,1);f.icon:Show()
    elseif state=="offline" then
        f.bg:SetColorTexture(unpack(DARK));f.bar:SetValue(0)
        f.bar:SetStatusBarColor(unpack(DARK));f.bar:SetAlpha(1)
        if f.incomingHeal then f.incomingHeal:Hide() end
        f.icon:SetTexture("Interface\\AddOns\\HaploBox\\Media\\link-broken.tga")
        f.icon:SetVertexColor(0.63,0.67,0.71,1);f.icon:Show()
    elseif state=="out-of-range" then
        -- Crucially retain the last known fill.  No misleading green heal.
        f.bar:SetAlpha(0.37)
        if f.incomingHeal then f.incomingHeal:Hide() end
        f.icon:Hide()
    else
        f.bg:SetColorTexture(unpack(f.kind=="target" and MISSING_TARGET or MISSING_TEAM));f.bar:SetAlpha(1);f.icon:Hide()
    end
end
local function targetColor(unit)
    if UnitIsPlayer then
        local ok,isPlayer=pcall(UnitIsPlayer,unit)
        if ok and plain(isPlayer)==true and UnitClass then
            local ok2,_,class=pcall(UnitClass,unit)
            class=ok2 and plain(class) or nil
            local colors=CUSTOM_CLASS_COLORS or RAID_CLASS_COLORS
            local c=class and colors and colors[class]
            if c then return c.r,c.g,c.b end
        end
    end
    if UnitReaction then
        local ok,r=pcall(UnitReaction,"player",unit)
        r=ok and plain(r) or nil
        if type(r)=="number" then
            if r<=3 then return 0.95,0.17,0.13 end
            if r==4 then return 1,0.85,0.14 end
            return GREEN[1],GREEN[2],GREEN[3]
        end
    end
    return ORANGE[1],ORANGE[2],ORANGE[3]
end
local function teamColor(unit)
    if UnitClass then
        local ok,_,class=pcall(UnitClass,unit)
        class=ok and plain(class) or nil
        local colors=CUSTOM_CLASS_COLORS or RAID_CLASS_COLORS
        local c=class and colors and colors[class]
        if c then return c.r,c.g,c.b end
    end
    return ORANGE[1],ORANGE[2],ORANGE[3]
end
local function knownTrue(api,unit)
    if not api then return false end
    local ok,value=pcall(api,unit)
    return ok and plain(value)==true
end
local function knownFalse(api,unit)
    if not api then return false end
    local ok,value=pcall(api,unit)
    return ok and plain(value)==false
end
local function outOfRange(unit)
    if unit=="player" or not UnitInRange then return false end
    local ok,inRange,checked=pcall(UnitInRange,unit)
    if not ok or secret(inRange) or secret(checked) then return false end
    -- A nil or uncheckable result must NOT mean out of range.
    return checked==true and inRange==false
end
local function paint(f)
    if not f or not f.active or not f.unit then showState(f,"empty") return end
    local unit=f.unit
    if knownFalse(UnitExists,unit) then
        showState(f,"empty")
        return
    end
    if knownFalse(UnitIsConnected,unit) then showState(f,"offline") return end
    if knownTrue(UnitIsDeadOrGhost,unit) then showState(f,"dead") return end
    local r,g,b
    -- MINI-05: fixed readable HP palette; do not use class/reaction colors.
    if f.kind=="target" then r,g,b=unpack(TARGET_RED) else r,g,b=unpack(ORANGE) end
    f.bar:SetStatusBarColor(r,g,b)
    if outOfRange(unit) then showState(f,"out-of-range") return end
    showState(f,"normal")
    local ok,h,m=pcall(function()return UnitHealth(unit),UnitHealthMax(unit) end)
    if not ok or m==nil then
        if f.incomingHeal then f.incomingHeal:Hide() end
        return
    end
    -- Combat HP can be secret.  The native StatusBar setters are permitted
    -- consumers.  NEVER branch on/format/compare h or m in Lua.
    pcall(f.bar.SetMinMaxValues,f.bar,0,m)
    pcall(f.bar.SetValue,f.bar,h)
    if f.incomingHeal and HB.UpdateIncomingHealBar then
        HB.UpdateIncomingHealBar(f.incomingHeal,unit,m)
    end
end
-- HF17 MIN-06: follower Mini UI hides known Blizzard HUD surfaces, Spy
-- Nearby and registered trackers. This bounded list must NEVER be replaced
-- by EnumerateFrames, which caused severe performance regressions in HF8.
-- User-opened map, character, spellbook, other panels and UIParent are left
-- alone. Secure/protected Blizzard surfaces are faded rather than Hide()'d.
-- This is intentionally a bounded lookup list. NEVER EnumerateFrames()/GetRegions()
-- on a ticker: that global scan caused the HF8 performance incident.
local HUD_NAMES={
    "MinimapCluster","Minimap","MinimapBackdrop",
    "ObjectiveTrackerFrame","WatchFrame","QuestWatchFrame","QuestTimerFrame",
    "MainMenuBar","MainMenuBarArtFrame","MainMenuBarArtFrameBackground","MainActionBar",
    "MultiBarBottomLeft","MultiBarBottomRight","MultiBarLeft","MultiBarRight",
    "MultiBar5","MultiBar6","MultiBar7","MultiBar8","MultiBar9","MultiBar10",
    "MicroButtonAndBagsBar","BagsBar","MicroMenu","MicroMenuContainer",
    "MainMenuBarBackpackButton","MainMenuBarPerformanceBarFrame",
    "MainMenuBarPageNumber","MainMenuBarVehicleLeaveButton",
    "StanceBar","StanceBarFrame","PetActionBar","PetActionBarFrame",
    "ExtraActionBarFrame","ZoneAbilityFrame","PossessBarFrame","OverrideActionBar",
    "PlayerFrame","TargetFrame","FocusFrame","PetFrame","PartyFrame",
    "CompactRaidFrameContainer","CompactRaidFrameManager",
    "BuffFrame","DebuffFrame","TemporaryEnchantFrame",
    "MainStatusTrackingBarContainer","StatusTrackingBarManager",
    -- HF26.20.6: KEEP the player's native castbar visible while in Mini UI.
    -- Classic uses CastingBarFrame; modern clients use PlayerCastingBarFrame.
    -- These stay owned by Blizzard: no forced Show/Hide or secure frame writes.
    -- Keep enemy/target castbar hidden, preserving the existing compact HUD.
    "TargetFrameSpellBar",
    "MirrorTimer1","MirrorTimer2","MirrorTimer3",
    "ChatFrameMenuButton","ChatFrameChannelButton","QuickJoinToastButton",
    -- Common optional addons / trackers (when installed).
    "QuestieTrackerFrame","QuestieTracker","Questie_Tracker","Questie_BaseFrame",
    "QuestieFrame","QuestieArrowFrame","QuestieQuestTracker",
    "QuestieTrackerQuestFrame","QuestieMapNotesFrame",
    "ZygorGuidesViewerFrame","ZygorGuidesViewer","ZygorGuidesViewerFrame_M",
    "ZygorGuidesViewerFrame_Viewer","ZygorGuidesViewerFrame_Border",
    "ZygorGuidesViewerFrame_Mini","ZygorGuidesViewerFrame_Small",
    "DetailsBaseFrame","DetailsWindowFrame","SkadaBarWindow",
    "SkadaBarWindowSkada","SkadaBarWindowDamage","SkadaBarWindowDamage Done",
    "Recount_MainWindow","TinyDPSFrame",
    -- Known optional swing timer window names only; do not inspect every frame.
    "WeaponSwingTimerFrame","WeaponSwingTimerPlayerFrame",
    "WeaponSwingTimer_PlayerFrame","WeaponSwingTimerMainFrame",
    "WST_PlayerFrame","WSTMainFrame","WeaponSwingTimerBar",
    "ClassicSwingTimerFrame","ForeverSwingFrame","ForeverSwingMainFrame",
    "BetterSwingTimerFrame","BetterSwingTimerMainFrame",
    "Quartz3SwingTimerFrame","QuartzSwingTimerBar",
    -- HF19: exact frame from the user's Blizzard Frame Stack screenshot.
    -- Source: Interface/AddOns/Blizzard_SwingTimer/Blizzard_SwingTimer.xml:21.
    -- Hiding the PARENT also hides its Main Hand children; Main UI restores it.
    "SwingTimerMainHandFrame",
    -- HF20: user verified /fstack Blizzard native DamageMeterSessionWindow1.
    -- Hide this PARENT (its Header and Minimizer children follow naturally).
    -- Source: Interface/AddOns/Blizzard_DamageMeter/DamageMeter.lua:285.
    "DamageMeterSessionWindow1",
    -- Spy versions use a named main window or Spy.MainWindow.
    "Spy_MainWindow","SpyMainWindow","SpyMainWindowFrame","Spy_MainFrame",
    "Spy_StatsWindow","SpyStatsWindow","Spy_AlertFrame","SpyAlertFrame",
    "SpyWarningFrame","Spy_WarningFrame"
}
for i=1,10 do
    HUD_NAMES[#HUD_NAMES+1]="ChatFrame"..i
    HUD_NAMES[#HUD_NAMES+1]="ChatFrame"..i.."Tab"
    HUD_NAMES[#HUD_NAMES+1]="ChatFrame"..i.."EditBox"
end
for i=1,8 do
    HUD_NAMES[#HUD_NAMES+1]="DetailsBaseFrame"..i
    HUD_NAMES[#HUD_NAMES+1]="DetailsWindowFrame"..i
    HUD_NAMES[#HUD_NAMES+1]="SkadaBarWindow"..i
end
-- The names over characters in the world are NOT necessarily nameplates.
-- Capture exactly the CVars that exist on this client and restore the same
-- values on Main UI or logout (never force account-wide preferences on login).
local nameplateCVars={
    "nameplateShowAll","nameplateShowEnemies","nameplateShowFriends",
    "nameplateShowSelf","nameplateShowFriendlyPlayerName",
    "UnitNameOwn","UnitNameFriendlyPlayerName","UnitNameEnemyPlayerName",
    "UnitNamePlayerGuild","UnitNameFriendlyPetName","UnitNameEnemyPetName",
    -- Green overhead NPC names (visible in the HF17 screenshot) are separate
    -- from player-name CVars. Only modify keys supported by this client.
    "UnitNameNPC","UnitNameFriendlyNPCName","UnitNameEnemyNPCName",
    "UnitNameFriendlySpecialNPCName","UnitNameHostleNPC",
    "UnitNameNonCombatCreatureName","UnitNameInteractiveNPC",
    "nameplateShowFriendlyNPCs","nameplateShowEnemyNPCs"
}
local savedNameplateCVars={}
local nameplatesMuted=false
local function toggleNameplates(mini)
    local get=(C_CVar and C_CVar.GetCVar) or GetCVar
    local set=(C_CVar and C_CVar.SetCVar) or SetCVar
    if not (get and set) then return end
    if mini then
        if not nameplatesMuted then
            for _,key in ipairs(nameplateCVars) do
                local ok,value=pcall(get,key)
                if ok and type(value)=="string" and value~="" then
                    -- Capture once, so repeated mini refreshes cannot overwrite
                    -- the original account/character name preferences.
                    local okSet=pcall(set,key,"0")
                    if okSet then savedNameplateCVars[key]=value end
                end
            end
            nameplatesMuted=true
        else
            -- Some addons re-enable names after zone changes. Reassert only
            -- supported, already captured keys; original settings stay safe.
            for key in pairs(savedNameplateCVars) do
                local ok,current=pcall(get,key)
                if ok and current~="0" then pcall(set,key,"0") end
            end
        end
    elseif nameplatesMuted then
        for key,value in pairs(savedNameplateCVars) do
            pcall(set,key,value)
            savedNameplateCVars[key]=nil
        end
        nameplatesMuted=false
    end
end
-- Snapshot by FRAME rather than by global name. Spy.MainWindow and its
-- named global can point to the same frame, and must restore only once.
local function usableFrame(frame)
    if not frame or type(frame)~="table" and type(frame)~="userdata" then return false end
    if not (frame.Hide and frame.GetAlpha and frame.SetAlpha) then return false end
    -- Older clients do not always expose IsForbidden on every UI widget.
    if frame.IsForbidden then
        local ok,forbidden=pcall(frame.IsForbidden,frame)
        if not ok or forbidden then return false end
    end
    return true
end
local function suppressFrame(frame)
    if not usableFrame(frame) then return end
    local prior=suppressed[frame]
    if prior then
        -- Addons can show a hidden window again after the Mini transition.
        if prior.mode=="hide" then pcall(frame.Hide,frame)
        elseif prior.mode=="fade" then pcall(frame.SetAlpha,frame,0) end
        return
    end
    local okShown,shown=pcall(frame.IsShown,frame)
    local okAlpha,alpha=pcall(frame.GetAlpha,frame)
    local okProtected,protected=true,false
    if frame.IsProtected then okProtected,protected=pcall(frame.IsProtected,frame) end
    if not (okShown and okAlpha and okProtected) then return end
    local snap={frame=frame,shown=shown,alpha=alpha}
    -- HF23: a cast/chat/swing window can Show() between the 1s HUD pulses,
    -- including mid-combat. Hook known NON-secure frames individually so
    -- their pixels are muted immediately; do not touch protected frames in
    -- combat or run the old HF8 global EnumerateFrames scan.
    if not protected and not suppressionHooks[frame] and frame.HookScript then
        local installed=pcall(frame.HookScript,frame,"OnShow",function(self)
            if not (HB.db and HB.db.miniHealMode and suppressed[self]) then return end
            local protectedNow=false
            if self.IsProtected then
                local ok,isProtected=pcall(self.IsProtected,self)
                protectedNow=not ok or isProtected
            end
            if not protectedNow then pcall(self.SetAlpha,self,0) end
        end)
        if installed then suppressionHooks[frame]=true end
    end
    if protected then
        -- Only a visual property: no restricted Hide() on secure bars.
        if not pcall(frame.SetAlpha,frame,0) then return end
        snap.mode="fade"
    else
        if pcall(frame.Hide,frame) then snap.mode="hide"
        elseif pcall(frame.SetAlpha,frame,0) then snap.mode="fade"
        else return end
    end
    suppressed[frame]=snap
end
local function spyFrames()
    -- Spy-twow / Spy Classic exposes Spy.MainWindow (Nearby) and
    -- Spy_MainWindow. Other optional Spy windows are bounded references.
    local spy=_G.Spy
    if type(spy)~="table" then return end
    for _,key in ipairs({"MainWindow","StatsWindow","AlertFrame","WarningFrame"}) do
        suppressFrame(spy[key])
    end
end
-- HF18: damage meters often create windows under USER-DEFINED names rather
-- than the default numbered globals. Resolve through the addon's own bounded
-- registry; do not run an unbounded frame scan (HF8 performance hard rule).
local function addonWindows()
    local skada=_G.Skada
    if type(skada)=="table" and type(skada.GetWindows)=="function" then
        local ok,wins=pcall(skada.GetWindows,skada)
        if ok and type(wins)=="table" then
            local visited=0
            for _,win in pairs(wins) do
                visited=visited+1
                if visited>12 then break end
                if type(win)=="table" then
                    suppressFrame(win.bargroup)
                    suppressFrame(win.frame)
                    if type(win.bargroup)=="table" then
                        suppressFrame(win.bargroup.frame)
                    end
                    local named=win.db and win.db.name
                    if type(named)=="string" and #named<=64 then
                        suppressFrame(_G["SkadaBarWindow"..named])
                    end
                end
            end
        end
    end
    -- Swing-timer addons vary; use only public, known module references.
    -- No guessing with unnamed children or full-frame enumerations.
    for _,key in ipairs({"WeaponSwingTimer","WeaponSwingTimerAddon",
                          "BetterSwingTimer","ForeverSwing","ClassicSwingTimer",
                          "SwingTimer","Quartz3"}) do
        local addon=_G[key]
        if type(addon)=="table" then
            suppressFrame(addon.frame)
            suppressFrame(addon.mainFrame)
            suppressFrame(addon.mainBar)
            suppressFrame(addon.playerFrame)
            local player=addon.player
            if type(player)=="table" then
                suppressFrame(player.frame)
                suppressFrame(player.mainFrame)
            end
        end
    end
end
-- Restore each HUD frame from the exact state captured when Mini UI
-- suppressed it.  During combat we may restore visual alpha and NON-secure
-- windows, but must NEVER Show/Hide protected frames or their parents.
-- Retain any failed restore so PLAYER_REGEN_ENABLED can retry it safely.
local function restoreSuppressedFrame(frame)
    local item=frame and suppressed[frame]
    if not item or not usableFrame(frame) then return false end
    local inCombat=locked()
    local protected=false
    if frame.IsProtected then
        local ok,p=pcall(frame.IsProtected,frame)
        if not ok then return false end
        protected=p==true
    end
    -- SetAlpha is a visual operation on supported native UI widgets.  Some
    -- clients may reject it in combat, so keep the snapshot if it fails.
    if not pcall(frame.SetAlpha,frame,item.alpha) then return false end
    if item.mode=="hide" then
        if inCombat and protected then return false end
        local ok
        if item.shown then ok=pcall(frame.Show,frame)
        else ok=pcall(frame.Hide,frame) end
        if not ok then return false end
    end
    suppressed[frame]=nil
    return true
end
local function restoreHUD()
    for frame in pairs(suppressed) do restoreSuppressedFrame(frame) end
    -- Nameplate CVars and nonvisual mode settings are restored after combat;
    -- restoring native action bars must NOT wait for those CVars.
    if not locked() then toggleNameplates(false) end
    hudHidden=(next(suppressed)~=nil) or nameplatesMuted
end
local function setHUD(isMini)
    if locked() then
        pendingLayout=true
        if not isMini then
            -- Emergency recovery through the SAME Main/Mini toggle. Bring
            -- back original Blizzard bars, target/party UI and nonsecure HUD
            -- now; leave secure Mini Heal buttons in place until combat ends.
            restoreHUD()
        end
        -- Entering Mini while in combat cannot create/show secure Mini
        -- Heal frames. Keep the active Main UI accessible until regeneration.
        return
    end
    if isMini then
        toggleNameplates(true)
        local keepMap=HB.WantsGatheringMiniMap and HB.WantsGatheringMiniMap()
        if keepMap then restoreSuppressedFrame(_G.Minimap) end
        for _,name in ipairs(HUD_NAMES) do
            -- The native Minimap is detached by GatheringMap.lua and placed
            -- in Lyra's Mini UI. Keep hiding the old cluster/chrome.
            if not (keepMap and name=="Minimap") then suppressFrame(_G[name]) end
        end
        spyFrames()
        addonWindows()
        hudHidden=true
    elseif hudHidden or next(suppressed)~=nil or nameplatesMuted then
        restoreHUD()
    end
end
local function bottomHeight(screenH)
    -- Preserve the old MiniHeal tile TOP edge while extending DOWN to zero.
    local oldHeight=math.max(60,math.min(104,math.floor(screenH*0.22)))
    return math.min(math.floor(screenH*0.76),oldHeight*3)+42
end
local function arrange()
    local w,h=UIParent:GetWidth(),UIParent:GetHeight()
    if not usableNumber(w) or w<1 then w=800 end
    if not usableNumber(h) or h<1 then h=450 end
    local oldBh=math.min(h*0.86,bottomHeight(h))
    local bh=oldBh*0.75 -- MIN-02: 25% shorter, same fixed bottom edge
    local each=w/4
    root:SetSize(w,bh)
    root:ClearAllPoints();root:SetPoint("BOTTOMLEFT",UIParent,"BOTTOMLEFT",0,0)
    for i=1,4 do
        local f=slots[i]
        f:ClearAllPoints()
        f:SetPoint("BOTTOMLEFT",root,"BOTTOMLEFT",each*(i-1),0)
        f:SetSize(each,bh)
        f.icon:SetSize(math.min(46,math.max(24,bh*0.16)),math.min(46,math.max(24,bh*0.16)))
    end
    local topH=math.max(65,math.min(h*0.17,145))
    local gap=math.max(22,math.min(55,h*0.06))
    for _,f in ipairs({selfSlot,targetSlot}) do f:SetSize(each,topH) end
    selfSlot:ClearAllPoints()
    selfSlot:SetPoint("BOTTOMLEFT",UIParent,"BOTTOMLEFT",0,bh+gap)
    targetSlot:ClearAllPoints()
    targetSlot:SetPoint("BOTTOMRIGHT",UIParent,"BOTTOMRIGHT",0,bh+gap)
    -- MIN-04: six HP blocks only.  Use the existing /hb view main
    -- or Toggle Main / Mini UI keybind to return to Main UI.
end
local function sameName(a,b)
    if HB.SameTeamMember and HB.SameTeamMember(a,b) then return true end
    return HB.Norm and HB.Norm(a) and HB.Norm(a)==HB.Norm(b)
end
local function bind(f,unit)
    f.unit=unit
    f.active=unit~=nil
    -- protected attributes and click handlers are edited only out of combat
    f:SetAttribute("unit",unit)
    f:EnableMouse(unit~=nil)
    if not unit then showState(f,"empty") else paint(f) end
end
local function rebuildRoster()
    local people=HB.VisiblePartyNames and HB.VisiblePartyNames() or {}
    local myName=HB.UnitIdent and HB.UnitIdent("player")
    local j=0
    for _,name in ipairs(people) do
        if not (myName and sameName(name,myName)) and j<4 then
            j=j+1
            local u=HB.ResolvePartyUnit and HB.ResolvePartyUnit(name)
            bind(slots[j],u)
        end
    end
    for i=j+1,4 do bind(slots[i],nil) end
    bind(selfSlot,"player")
    local unit=(HB.IAmLeader and HB.IAmLeader()) and "target" or "party1target"
    if targetSlot.unit~=unit then
        if UnregisterUnitWatch then pcall(UnregisterUnitWatch,targetSlot) end
        bind(targetSlot,unit)
        if RegisterUnitWatch then
            -- Secure unit-existence driver: hidden immediately if the leader
            -- has no target, including during combat (no insecure Hide calls).
            pcall(RegisterUnitWatch,targetSlot)
        end
    end
end
function HB.GetMiniHealSettingsAnchor() return settingsButton end
function HB.UpdateMiniHealLayout()
    if not (root and HB.db) then return end
    if locked() then pendingLayout=true return end
    pendingLayout=false
    if not HB.db.miniHealMode then
        root:Hide()
        if HB.RestoreGatheringMiniMap then HB.RestoreGatheringMiniMap() end
        setHUD(false)
        return
    end
    arrange()
    rebuildRoster()
    root:Show()
    if exitButton then exitButton:Hide() end
    if settingsButton then settingsButton:Hide() end
    setHUD(true)
    if HB.ApplyGatheringMiniMap then HB.ApplyGatheringMiniMap() end
end
local function applyMode(enabled,silent)
    HB.db.miniHealMode=(enabled==true)
    HB.db.controlsOpen=false
    if HB.HideQuickSubmenus then HB.HideQuickSubmenus() end
    if HB.LayoutPartyFrame then HB.LayoutPartyFrame() end
    HB.UpdateMiniHealLayout()
    if HB.RefreshControls then HB.RefreshControls() end
    if HB.ApplyBlizzardAuraVisibility then HB.ApplyBlizzardAuraVisibility() end
    -- Another module may have refreshed native aura visibility during the
    -- switch; Mini UI owns the final HUD presentation while it is active.
    if enabled then
        setHUD(true)
        if HB.ApplyGatheringMiniMap then HB.ApplyGatheringMiniMap() end
    end
    if not silent and HB.print then HB.print("Local UI: "..(enabled and "MINI" or "MAIN")) end
end
function HB.SetMiniHealMode(enabled)
    if not HB.db then return false end
    enabled=not not enabled
    if locked() then
        -- The normal toggle remains the ONLY control. Publish the requested
        -- state immediately so OnShow hooks do not re-hide restored HUD.
        -- All secure Party/Mini Heal frame layout and attributes wait for
        -- combat to end; the last keypress wins.
        pendingDesired=enabled
        HB.db.miniHealMode=enabled
        -- Mini Buff Overview is an ordinary display frame: hide it now,
        -- even though secure Party/Mini frame changes must wait for regen.
        if HB.ApplyBuffOverviewCombatMode then HB.ApplyBuffOverviewCombatMode() end
        setHUD(enabled) -- visual-only partial transition (no protected edits)
        if HB.print then
            HB.print("Local UI: "..(enabled and "MINI" or "MAIN")
                .." (combat: safe HUD now; secure layout after combat)")
        end
        return true
    end
    pendingDesired=nil
    applyMode(enabled,false)
    return true
end
function HB.ToggleMiniHealMode()
    if not HB.db then return false end
    local current=pendingDesired
    if current==nil then current=HB.db.miniHealMode end
    return HB.SetMiniHealMode(not current)
end
local function refreshLive()
    if not (root and root:IsShown()) then return end
    for _,f in ipairs(slots) do paint(f) end
    paint(selfSlot)
    paint(targetSlot)
end
local ev=CreateFrame("Frame")
for _,event in ipairs({"PLAYER_LOGIN","PLAYER_ENTERING_WORLD","PLAYER_REGEN_ENABLED",
    "GROUP_ROSTER_UPDATE","UNIT_TARGET","UNIT_HEALTH","UNIT_MAXHEALTH",
    "UNIT_HEAL_PREDICTION","UNIT_CONNECTION","UNIT_FLAGS","UI_SCALE_CHANGED",
    "DISPLAY_SIZE_CHANGED","PLAYER_LOGOUT"}) do ev:RegisterEvent(event) end
ev:SetScript("OnEvent",function(_,event,a,isReloadingUi)
    if event=="PLAYER_LOGIN" then
        root=CreateFrame("Frame","HaploBoxMiniHealRoot",UIParent)
        root:SetFrameStrata("LOW")
        root:SetFrameLevel(12)
        root:EnableMouse(false) -- no full-screen invisible click blocker
        for i=1,4 do slots[i]=createSlot(i,"party") end
        selfSlot=createSlot("Self","self")
        targetSlot=createSlot("Party1Target","target")
        root:Hide()
        if C_Timer and C_Timer.NewTicker then
            C_Timer.NewTicker(0.16,HB.Diag.Wrap("MiniHeal 0.16s", refreshLive))
            C_Timer.NewTicker(1.0,HB.Diag.Wrap("MiniHeal HUD 1s", function()
                if HB.db and HB.db.miniHealMode and not locked() then
                    -- Blizzard and other addons can re-show native HUD
                    -- after zone changes; keep previously captured state.
                    setHUD(true)
                end
            end))
        end
    elseif event=="PLAYER_LOGOUT" then
        -- Never leave saved user HUD/CVar preferences altered on /reload.
        if HB.RestoreGatheringMiniMap then HB.RestoreGatheringMiniMap() end
        setHUD(false)
        toggleNameplates(false)
    elseif event=="PLAYER_ENTERING_WORLD" then
        -- PLAYER_ENTERING_WORLD explicitly identifies login vs /reload.
        -- Logout/login -> MAIN; /reload in the same session -> retain MODE.
        if a==true and HB.db then
            local wasMini=HB.db.miniHealMode
            HB.db.miniHealMode=false
            if wasMini then
                if HB.LayoutPartyFrame then HB.LayoutPartyFrame() end
                if HB.RefreshControls then HB.RefreshControls() end
                if HB.ApplyBlizzardAuraVisibility then HB.ApplyBlizzardAuraVisibility() end
            end
        end
        HB.UpdateMiniHealLayout()
    elseif event=="PLAYER_REGEN_ENABLED" then
        if pendingDesired~=nil then
            local desired=pendingDesired
            pendingDesired=nil
            applyMode(desired,true) -- silent deferred transition
        elseif pendingLayout then HB.UpdateMiniHealLayout()
        end
    elseif event=="UNIT_TARGET" then
        -- UnitWatch ensures immediate target visibility even in combat.
        -- Repaint follows the live party1target/target token, not stale GUIDs.
        if root and root:IsShown() and (a=="party1" or a=="player") then paint(targetSlot) end
    elseif event=="GROUP_ROSTER_UPDATE" or event=="UI_SCALE_CHANGED" or
           event=="DISPLAY_SIZE_CHANGED" then
        HB.UpdateMiniHealLayout()
    elseif root and root:IsShown() then
        refreshLive()
    end
end)

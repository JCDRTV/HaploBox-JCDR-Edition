-- HaploBox Profession Guide – Phase 1 screens. No changes to Dungeon Advisor, Pawn or Weapon Sets.
local PG = HaploBoxProfessionGuide
local WHITE = "Interface\\Buttons\\WHITE8X8"
local C = {
    bg={0.065,0.075,0.095,0.98}, panel={0.105,0.125,0.155,1},
    tile={0.14,0.16,0.19,1}, hover={0.19,0.235,0.27,1},
    green={0.31,0.77,0.50,1}, gold={0.97,0.73,0.33,1},
    gray={0.56,0.61,0.66,1}, white={0.91,0.93,0.95,1}, red={0.85,0.38,0.38,1},
}
local function fill(parent, color)
    local t=parent:CreateTexture(nil,"BACKGROUND")
    t:SetTexture(WHITE)
    t:SetVertexColor(unpack(color))
    t:SetAllPoints()
    return t
end
local function text(parent, textValue, size, color, width, justify)
    local t=parent:CreateFontString(nil,"OVERLAY", size == "large" and "GameFontNormalLarge" or "GameFontHighlight")
    t:SetText(textValue or "")
    t:SetTextColor(unpack(color or C.white))
    if width then t:SetWidth(width) end
    t:SetJustifyH(justify or "LEFT")
    return t
end
local function button(parent, label, width, height, callback)
    local b=CreateFrame("Button",nil,parent)
    b:SetSize(width,height)
    b.tint=fill(b,C.tile)
    local l=text(b,label,nil,C.white,width-10,"CENTER")
    l:SetPoint("CENTER",0,0)
    b.label=l
    b:SetScript("OnEnter",function(self) self.tint:SetVertexColor(unpack(C.hover)) end)
    b:SetScript("OnLeave",function(self) self.tint:SetVertexColor(unpack(C.tile)) end)
    b:SetScript("OnClick",callback)
    return b
end
local function drag(frame,handle)
    frame:SetMovable(true)
    frame:SetClampedToScreen(true)
    handle:EnableMouse(true)
    handle:RegisterForDrag("LeftButton")
    handle:SetScript("OnDragStart",function() if not InCombatLockdown or not InCombatLockdown() then frame:StartMoving() end end)
    handle:SetScript("OnDragStop",function() frame:StopMovingOrSizing() end)
end
local function panel(name,width,height,title,anchor)
    local f=CreateFrame("Frame",name,UIParent)
    f:SetSize(width,height)
    f:SetFrameStrata("DIALOG")
    f:SetPoint("CENTER",UIParent,"CENTER",anchor or 0,0)
    f:EnableMouse(true)
    fill(f,C.bg)
    local header=CreateFrame("Frame",nil,f)
    header:SetPoint("TOPLEFT",f,"TOPLEFT",0,0)
    header:SetPoint("TOPRIGHT",f,"TOPRIGHT",0,0)
    header:SetHeight(42)
    fill(header,C.panel)
    local t=text(header,title,"large")
    t:SetPoint("LEFT",header,"LEFT",15,0)
    drag(f,header)
    local close=button(header,"X",28,26,function() f:Hide() end)
    close:SetPoint("RIGHT",header,"RIGHT",-10,0)
    f:Hide()
    return f,header
end
local function progress(parent,w,h)
    local bg=CreateFrame("Frame",nil,parent)
    bg:SetSize(w,h)
    fill(bg,C.tile)
    local bar=bg:CreateTexture(nil,"ARTWORK")
    bar:SetTexture(WHITE)
    bar:SetVertexColor(unpack(C.green))
    bar:SetPoint("LEFT",bg,"LEFT",0,0)
    bar:SetHeight(h)
    function bg:SetPercent(n)
        bar:SetWidth(math.max(0.01,w*math.max(0,math.min(1,n or 0))))
    end
    bg:SetPercent(0)
    return bg
end
local function teamSnapshot(code)
    local rows = {}
    local names=PG.GetRoster()
    for _, name in ipairs(names) do
        local state=PG.db and PG.db.team and PG.db.team[name]
        local skill=state and state.skills and state.skills[code]
        rows[#rows+1]={name=name,state=state,skill=skill}
    end
    return rows
end
local function timeStatus(state)
    if not state or not state.updated then return "NO DATA",C.gold end
    local now=type(GetServerTime)=="function" and GetServerTime() or (type(time)=="function" and time() or 0)
    if now>0 and state.updated>0 and (now-state.updated)>180 then return "CACHED",C.gold end
    return "SYNCED",C.green
end
local function selectedSkill(code)
    local rows=teamSnapshot(code)
    local focus=PG.focus
    for _, row in ipairs(rows) do
        if row.name==focus then return row.skill,row.name end
    end
    for _, row in ipairs(rows) do
        if row.skill then
            PG.focus=row.name
            return row.skill,row.name
        end
    end
    PG.focus=rows[1] and rows[1].name or nil
    return nil,PG.focus
end
local function currentBand(skill)
    if not skill then return "Unknown" end
    for _, b in ipairs(PG.BANDS) do
        if skill < b.endSkill then return b.name .. " (" .. b.startSkill .. "-" .. b.endSkill .. ")" end
    end
    return "300 / 300 complete"
end

function PG.CreateUI()
    if PG.main then return end
    local m=panel("HaploBoxProfessionAdvisor",876,535,"HAPLOBOX  /  PROFESSION ADVISOR",-60)
    PG.main=m
    PG.mainSub=text(m,"WO W FOREVER  |  PARTY SKILLS  |  1-300",nil,C.gray)
    PG.mainSub:SetPoint("TOPLEFT",m,"TOPLEFT",18,-55)
    local cards={}
    PG.cards=cards
    for i, code in ipairs(PG.ORDER) do
        local p=PG.PROFESSIONS[code]
        local col=(i-1)%3
        local row=math.floor((i-1)/3)
        local x=18+col*164
        local y=-90-row*118
        local b=button(m,"",154,106,function()
            PG.db.selected=code
            PG.focus=nil
            PG.RefreshUI()
        end)
        b:SetPoint("TOPLEFT",m,"TOPLEFT",x,y)
        local ico=b:CreateTexture(nil,"ARTWORK")
        ico:SetTexture(p.icon)
        ico:SetSize(36,36)
        ico:SetPoint("TOP",b,"TOP",0,-6)
        local n=text(b,p.name,nil,C.white,140,"CENTER")
        n:SetPoint("TOP",ico,"BOTTOM",0,-7)
        local stat=text(b,"—",nil,C.gray,140,"CENTER")
        stat:SetPoint("TOP",n,"BOTTOM",0,-5)
        cards[code]={button=b,name=n,stat=stat,back=b.tint}
    end
    local separator=CreateFrame("Frame",nil,m)
    separator:SetSize(1,409)
    separator:SetPoint("TOPLEFT",m,"TOPLEFT",518,-85)
    fill(separator,C.tile)
    local head=text(m,"LEATHERWORKING","large",C.white,320)
    head:SetPoint("TOPLEFT",m,"TOPLEFT",540,-91)
    PG.mainHead=head
    PG.mainDetail=text(m,"Party-wide profession progress",nil,C.gray,308)
    PG.mainDetail:SetPoint("TOPLEFT",head,"BOTTOMLEFT",0,-8)
    PG.memberRows={}
    for i=1,5 do
        local cell=button(m,"",310,48,function()
            local row=PG.memberRows[i]
            if row and row.member then PG.focus=row.member; PG.RefreshUI() end
        end)
        cell:SetPoint("TOPLEFT",m,"TOPLEFT",538,-163-(i-1)*55)
        local nm=text(cell,"—",nil,C.white,140)
        nm:SetPoint("LEFT",cell,"LEFT",10,7)
        local skill=text(cell,"—",nil,C.green,120,"RIGHT")
        skill:SetPoint("RIGHT",cell,"RIGHT",-9,7)
        local sync=text(cell,"",nil,C.gray,180)
        sync:SetPoint("LEFT",cell,"LEFT",10,-11)
        PG.memberRows[i]={cell=cell,name=nm,skill=skill,sync=sync}
    end
    local refresh=button(m,"SCAN / SYNC",130,31,function()
        PG.ScanMySkills();PG.Broadcast(true)
        PG.RefreshUI()
    end)
    refresh:SetPoint("BOTTOMLEFT",m,"BOTTOMLEFT",539,18)
    local launch=button(m,"OPEN GUIDE",164,31,function() PG.OpenRun(PG.db.selected) end)
    launch:SetPoint("LEFT",refresh,"RIGHT",12,0)
    PG.launch=launch
    local foot=text(m,"Phase 1 TEST - overview + run window. Recipe steps/material NEED are not enabled yet.",nil,C.gray,817)
    foot:SetPoint("BOTTOMLEFT",m,"BOTTOMLEFT",18,17)
    PG.foot=foot

    local r=panel("HaploBoxProfessionRun",448,431,"PROFESSION RUN",220)
    PG.run=r
    PG.runTitle=text(r,"Leatherworking","large",C.white,330)
    PG.runTitle:SetPoint("TOPLEFT",r,"TOPLEFT",16,-58)
    PG.runToon=button(r,"CHARACTER",160,26,function()
        local code=PG.db.selected
        local rows=teamSnapshot(code)
        local have={}
        for _, row in ipairs(rows) do if row.skill then have[#have+1]=row.name end end
        if #have==0 then return end
        local index=0
        for i,name in ipairs(have) do if name==PG.focus then index=i;break end end
        PG.focus=have[index%#have+1]
        PG.RefreshUI()
    end)
    PG.runToon:SetPoint("TOPRIGHT",r,"TOPRIGHT",-15,-57)
    PG.runProgress=progress(r,415,9)
    PG.runProgress:SetPoint("TOPLEFT",r,"TOPLEFT",16,-100)
    PG.runLevel=text(r,"Skill unavailable",nil,C.white,410)
    PG.runLevel:SetPoint("TOPLEFT",r,"TOPLEFT",16,-122)
    PG.runBand=text(r,"",nil,C.gray,405)
    PG.runBand:SetPoint("TOPLEFT",r,"TOPLEFT",16,-146)
    local stepPane=CreateFrame("Frame",nil,r)
    stepPane:SetPoint("TOPLEFT",r,"TOPLEFT",16,-179)
    stepPane:SetSize(416,146)
    fill(stepPane,C.panel)
    PG.stepTitle=text(stepPane,"NEXT LEVELING STEP","large",C.white,381)
    PG.stepTitle:SetPoint("TOPLEFT",stepPane,"TOPLEFT",13,-14)
    PG.stepText=text(stepPane,"Loading...",nil,C.gold,386)
    PG.stepText:SetPoint("TOPLEFT",stepPane,"TOPLEFT",13,-48)
    PG.stepText:SetJustifyV("TOP")
    PG.stepText:SetHeight(79)
    local matTitle=text(r,"PARTY MATERIAL FINDER",nil,C.white,410)
    matTitle:SetPoint("TOPLEFT",r,"TOPLEFT",17,-345)
    local matInfo=text(r,"Not enabled in Phase 1. No speculative NEED flags.",nil,C.gold,415)
    matInfo:SetPoint("TOPLEFT",r,"TOPLEFT",17,-369)
    local back=button(r,"BACK TO ADVISOR",170,28,function() r:Hide();m:Show() end)
    back:SetPoint("BOTTOMRIGHT",r,"BOTTOMRIGHT",-15,12)
    local scan=button(r,"SYNC PARTY",120,28,function() PG.ScanMySkills();PG.Broadcast(true);PG.RefreshUI() end)
    scan:SetPoint("BOTTOMLEFT",r,"BOTTOMLEFT",16,12)
    PG.RefreshUI()
    -- The original HaploBox slash command remains intact. Other commands are forwarded unmodified.
    if SlashCmdList and type(SlashCmdList.HAPLOBOX)=="function" and not PG.hookedSlash then
        local original=SlashCmdList.HAPLOBOX
        SlashCmdList.HAPLOBOX=function(msg,...)
            local normalized=(msg or ""):lower():match("^%s*(.-)%s*$")
            if normalized=="profession" or normalized=="professions" or normalized=="prof" then
                PG.ToggleMain()
                return
            end
            return original(msg,...)
        end
        PG.hookedSlash=true
    end
end
function PG.RefreshUI()
    if not PG.main or not PG.db then return end
    local code=PG.db.selected or "LW"
    local profession=PG.PROFESSIONS[code]
    PG.mainHead:SetText(profession.name:upper())
    local roster=PG.GetRoster()
    PG.mainDetail:SetText(#roster .. " party character(s)  |  Select a row to focus")
    for _, pcode in ipairs(PG.ORDER) do
        local card=PG.cards[pcode]
        local n, highest=0,0
        for _, row in ipairs(teamSnapshot(pcode)) do
            if row.skill then n=n+1;highest=math.max(highest,row.skill.skill) end
        end
        card.stat:SetText(n==0 and "no skill reported" or (n .. " toon(s)  |  " .. highest .. "/300"))
        if pcode==code then card.back:SetVertexColor(0.17,0.28,0.26,1)
        else card.back:SetVertexColor(unpack(C.tile)) end
    end
    local rows=teamSnapshot(code)
    for i=1,5 do
        local display=PG.memberRows[i]
        local entry=rows[i]
        display.member=entry and entry.name or nil
        display.cell:SetShown(entry~=nil)
        if entry then
            display.name:SetText(entry.name .. (entry.name==PG.focus and "  *" or ""))
            display.skill:SetText(entry.skill and (entry.skill.skill.." / "..(entry.skill.cap>0 and entry.skill.cap or "?")) or "—")
            local status,color=timeStatus(entry.state)
            display.sync:SetText(status .. (entry.state and not entry.skill and "  |  not trained" or ""))
            display.sync:SetTextColor(unpack(color))
        end
    end
    if not PG.run then return end
    PG.runTitle:SetText(profession.name)
    local skill, name=selectedSkill(code)
    PG.runToon.label:SetText(name or "NO CHARACTER")
    local n=skill and skill.skill or 0
    PG.runProgress:SetPercent(n/300)
    PG.runLevel:SetText(skill and ("Skill  "..n.." / 300   |   Trained cap: "..(skill.cap>0 and skill.cap or "?")) or "No current skill data for this profession")
    PG.runBand:SetText("Current bracket: "..currentBand(skill and n))
    local steps=PG.GUIDES[code] or {}
    local active
    for _, step in ipairs(steps) do
        if n < step.to then active=step;break end
    end
    if active and skill then
        PG.stepTitle:SetText("STEP  "..active.from.." - "..active.to)
        PG.stepText:SetText(active.name .. "\n" .. (active.note or "Recipe material counts will appear in the Material Finder phase."))
    elseif n>=300 then
        PG.stepTitle:SetText("PROFESSION COMPLETE")
        PG.stepText:SetText("300 / 300 achieved. The leveling guide has no further steps.")
    else
        PG.stepTitle:SetText("RECIPE ROUTE NOT LOADED")
        PG.stepText:SetText("Phase 1 shows live party skills. Verified 1-300 recipes, trainer checkpoints and material calculations are added in phases 3 and 4.\n\nNo recipe or material quantities are guessed.")
    end
end
function PG.OpenRun(code)
    if not PG.main then PG.CreateUI() end
    if code and PG.PROFESSIONS[code] then PG.db.selected=code end
    PG.RefreshUI()
    PG.main:Hide()
    PG.run:Show()
end
function PG.ToggleMain()
    if not PG.db then return end
    if not PG.main then PG.CreateUI() end
    if PG.main:IsShown() then PG.main:Hide()
    else PG.RefreshUI();PG.run:Hide();PG.main:Show() end
end
SLASH_HBPG1="/hbpg"
SLASH_HBPG2="/hbprof"
SLASH_HBPG3="/haploprof"
SlashCmdList.HBPG=function(msg)
    local cmd=(msg or ""):lower():match("^%s*(.-)%s*$")
    if cmd=="run" then
        if PG.db then PG.OpenRun() end
    elseif cmd=="scan" then
        if PG.db then PG.ScanMySkills();PG.Broadcast(true) end
    else
        PG.ToggleMain()
    end
end

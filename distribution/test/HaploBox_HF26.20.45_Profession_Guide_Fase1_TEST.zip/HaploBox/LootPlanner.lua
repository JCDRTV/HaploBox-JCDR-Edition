-- HF26.20.44: Need dice priorities, shared original dice/upgrade header icons, inline Pawn status harmonization.
-- HF26.20.43: AtlasLoot-like two-line item typography, muted scrollers, matched role badge sizing.
-- HF26.20.42: item-scoped Pawn rating recovery, matching circular UI glyphs, AtlasLoot-like loot icons.
-- HF26.20.41: WoW-safe icon glyphs, compact proportional scrollbars, and explicit trustworthy rating labels.
-- HF26.20.40: proportional scroll thumb with up/down arrows; UNI/Score icon headers; numeric score without question marks.
-- HF26.20.39: compact gameplay UI, linked Run action, collapsible bosses, score/colour, visible scrollbars.
-- HF26.20.38: role-icon-only separate dungeon priority columns, safely clamped within Advisor.
-- HF26.20.37: unique-role physical loot priority, four scrollable lists, verified SPECIAL effect handling.
-- HF26.20.36: readable Advisor status, rank labels, compact UI; extended without overwriting TEST 36.
-- HF26.20.35: read-only BiS coverage, incomplete weapon-set comparisons, verified 1H+OH pair targets, Forever polearms.
-- HF26.20.32: Skip already-owned Unique/Unique-Equipped gear on the owning Druid.
-- HF26.20.31: Run Guide can shrink to 350px, with responsive header and non-overlapping loot columns.
-- HF26.20.30: Independently resizable Dungeon Advisor and Dungeon Run Guide, stored sizes and reflowed columns.
-- HF26.20.29: Batched addressed Pawn requests with compact paced reply packets.
-- HF26.20.28: Fast safe scan: skip provably unusable loot and reuse resolved results within one scan.
-- HF26.20.27: Party BiS farm shortlist; ranked target dungeons, boss-only run, wider Pawn-style columns.
-- HF26.20.26: Level-range Dungeon BiS; only best currently equippable scanned drops per toon/slot.
-- HF26.20.22: Locked per-character weapon set comparison in Run Guide.
-- HF26.20.21: Conservative pacing experiment for reliable PARTY item requests.
-- HF26.20.20: Serialized per-follower initial Pawn requests + scan-aware request telemetry.
-- HF26.20.19: Complete bounded per-character scan retry + transparent reply diagnostics.
-- HF26.20.18: Narrow collapsible Run Guide + persistent manual Stealth/Normal timer.
-- HF26.20.14: Strict per-boss score confidence; 5-client coverage; safe gear-change invalidation.
-- HF26.20.13: Compact on-demand Dungeon Run Guide using existing AtlasLoot/Pawn scan.
-- HF26.19: Explicit scan scope, partial-score confidence, native roles and priority diagnostics.
-- HF26.18: Fast all-level dungeon scan, responsive Team A subset and future planning.
-- HF26.17: All-Dungeon boss-loot scanner, aligned role/need/upgrade rows.
-- HF26.14: Cache follow-up adapter + complete bag weapon pairs + mixed healer fit.
-- HF26.13: Role evidence + future-level tooltip Pawn while preserving HF26.12 scans.
-- HF26.10: Exact Pawn role-scale routing for all five Druids.
-- Read-only scale selection; preserves Pawn's own stat weights and tooltip math.
-- Based cumulatively on HF26.5. Existing MenuStyle/party/BoxMode remain untouched.
-- AtlasLoot remains the item browser; this is an on-demand, event-driven planner.
-- Only reads AtlasLoot and Pawn. Does not alter secure frames or other modules.
local HB=HaploBox
local addonPrefix="HBLP26"
local atlasModule="AtlasLootClassic_DungeonsAndRaids"
local names={"Mael","Lyra","Elya","Nyra","Ayla"}
local roster={Mael=true,Lyra=true,Elya=true,Nyra=true,Ayla=true}
local roles={Mael="feral",Lyra="restoration",Elya="balance",Nyra="balance",Ayla="balance"}
local frame, statusText, titleText, availableScanButton, allScanButton, pageText, detailPageText
local dungeonButtons, detailRows={},{}
local dungeons, visibleDungeons, scans, best={}, {}, {}, {}
local chosen, chosenBoss, chosenItem, dungeonPage, bossPage, itemPage=nil,nil,nil,1,1,1
local scanJob, sequence= nil,0
local allScan, worker, workerTick, startDungeonScan, startAllScan
local runRefresh -- compact Run Guide; no Mini UI hooks or new scanner
local advisorCache={}
local detailPage=1
-- HF26.18: Snapshot participants once per explicit scan. No wait for absent toons.
local activeNames={"Mael"}
-- This describes the scope ACTUALLY SCANNED, not a passive view toggle.
local scanScope="available"
local showAllLoot=false
local allLootButton
-- Views and cache live in one namespace to respect WoW Lua chunk-local limits.
HB.DungeonBiSView={enabled=true,cache=nil,button=nil,header=nil}
local evalCache={}
local function scanMembers(scan) return (scan and scan.names) or activeNames end
local function copyList(t)
    local c={}
    for _,v in ipairs(t or {}) do c[#c+1]=v end
    return c
end
local tick
local lastScanCount=0
local lastScanFeedback=nil
local lastInvalidate=0
local selectedSummary
local net={registered=false,registerError=nil,received=0,requests=0,replies=0,sends=0,failures=0,
    lastSendError=nil,lastRecv=nil,lastChannel=nil,lastSender=nil,lastReply=nil,acks={},pingToken=nil,recognized=0,rejected=0,lastRejected=nil,malformed=0,
    replyAccepted=0,replyDuplicate=0,replyUnknownScan=0,replyUnexpected=0,replyLateCache=0,
    lastReplyIssue=nil,retrySent=0,retryFailed=0,retrySkipped=0,
    firstWaveSent=0,firstWaveFailed=0,requestsBroadcast=0,requestsTargeted=0,
    requestsOtherTarget=0,requestsMalformed=0}
local PROTOCOL="HF26.32" -- KEEP: network protocol unchanged by HF26.20.37.
-- Exact verified special-effect-only item; never extrapolate this exemption to
-- unknown IDs. A Pawn NO_ITEM on other loot remains an unresolved scan error.
HB.DungeonBiSView.specialEffectOnly={ [273820]=true } -- Nightskulker Ring (Forever)
function HB.DungeonBiSView.IsSpecial(itemID,r)
    return HB.DungeonBiSView.specialEffectOnly[tonumber(itemID)]==true
        and type(r)=="table" and r.status=="NOSTATS"
        and (r.why=="NO_ITEM" or r.why=="NO_STATS" or r.why=="NO_SCORE")
end
function HB.DungeonBiSView.CoverageStatus(itemID,r)
    if HB.DungeonBiSView.IsSpecial(itemID,r) then return "SPECIAL" end
    return r and r.status or "NO_REPLY"
end
-- Virtualized list scrollbar: slim arrow buttons and a proportional thumb.
-- All four scrollers retain their existing wheel/page offsets. No Pawn work.
function HB.DungeonBiSView.NewScrollbar(parent,onValue)
    -- Frame wrapper permits arrows ABOVE and BELOW the drag track, rather
    -- than letting a full-height Slider's thumb overlap those buttons.
    local bar=CreateFrame("Frame",nil,parent)
    bar:SetSize(14,100)
    bar.index=1;bar.maxStart=1;bar.total=0;bar.pageSize=1
    local back=bar:CreateTexture(nil,"BACKGROUND")
    back:SetAllPoints();back:SetColorTexture(.06,.075,.09,.66)
    local slider=CreateFrame("Slider",nil,bar)
    slider:SetOrientation("VERTICAL")
    slider:SetPoint("TOPLEFT",bar,"TOPLEFT",1,-17)
    slider:SetPoint("BOTTOMRIGHT",bar,"BOTTOMRIGHT",-1,17)
    slider:SetMinMaxValues(1,1);slider:SetValueStep(1)
    local track=slider:CreateTexture(nil,"BACKGROUND")
    track:SetAllPoints();track:SetColorTexture(.085,.105,.12,.62)
    slider:SetThumbTexture("Interface\\Buttons\\UI-ScrollBar-Knob")
    local thumb=slider:GetThumbTexture()
    if thumb then
        thumb:SetColorTexture(.30,.365,.39,.92)
        thumb:SetSize(10,24)
    end
    bar.slider=slider;bar.thumb=thumb
    local function arrowButton(up)
        local b=CreateFrame("Button",nil,bar)
        b:SetSize(14,17)
        b:SetPoint(up and "TOP" or "BOTTOM",bar,up and "TOP" or "BOTTOM",0,0)
        local normal="Interface\\AddOns\\HaploBox\\Media\\hf41-scroll-"..(up and "up" or "down")..".tga"
        b:SetNormalTexture(normal)
        b:SetPushedTexture(normal)
        b:SetHighlightTexture("Interface\\Buttons\\UI-Common-MouseHilight")
        if b:GetNormalTexture() then b:GetNormalTexture():SetVertexColor(.62,.69,.70,.82) end
        if b:GetPushedTexture() then b:GetPushedTexture():SetVertexColor(.70,.77,.78,.95) end
        if b:GetHighlightTexture() then b:GetHighlightTexture():SetAlpha(.22) end
        b:SetScript("OnClick",function()
            local nextIndex=math.max(1,math.min(bar.maxStart,bar.index+(up and -1 or 1)))
            if nextIndex~=bar.index then slider:SetValue(nextIndex) end
        end)
        return b
    end
    bar.upButton=arrowButton(true)
    bar.downButton=arrowButton(false)
    local function updateButtons()
        if bar.index<=1 then bar.upButton:Disable() else bar.upButton:Enable() end
        if bar.index>=bar.maxStart then bar.downButton:Disable() else bar.downButton:Enable() end
    end
    local function updateThumb()
        if not bar.thumb then return end
        local trackHeight=math.max(1,bar:GetHeight()-2*17)
        -- Smaller lists => larger thumb; longer lists => smaller thumb.
        -- Thumb can never cover the up/down controls.
        local proportion=math.min(1,bar.pageSize/math.max(1,bar.total))
        local thumbHeight=math.min(trackHeight,math.max(math.min(16,trackHeight),
            math.floor(trackHeight*proportion+0.5)))
        bar.thumb:SetSize(10,thumbHeight)
        bar.thumbHeight=thumbHeight
    end
    bar.updateThumb=updateThumb
    bar:SetScript("OnSizeChanged",function() updateThumb() end)
    slider:SetScript("OnValueChanged",function(self,value)
        if self.syncing then return end
        local rounded=math.max(1,math.min(bar.maxStart,math.floor(value+0.5)))
        bar.index=rounded
        updateButtons()
        onValue(rounded)
    end)
    return bar
end
function HB.DungeonBiSView.SetScrollbar(bar,index,total,pageSize)
    if not bar then return end
    total=math.max(0,tonumber(total) or 0)
    pageSize=math.max(1,tonumber(pageSize) or 1)
    local maxStart=math.max(1,total-pageSize+1)
    local clamped=math.max(1,math.min(tonumber(index) or 1,maxStart))
    bar.total=total;bar.pageSize=pageSize;bar.maxStart=maxStart;bar.index=clamped
    bar.slider.syncing=true
    bar.slider:SetMinMaxValues(1,maxStart)
    bar.slider:SetValue(clamped)
    bar.slider.syncing=false
    bar.updateThumb()
    bar.upButton:SetEnabled(clamped>1)
    bar.downButton:SetEnabled(clamped<maxStart)
    bar:SetShown(maxStart>1)
end
-- Only manual/weapon-set percentages need this conservative guard. The official
-- Pawn tooltip comparison is authoritative, even above 300%, unless it reports
-- an empty-slot sentinel (10000%). That is a qualitative NEW, not a real %.
local REVIEW_PCT=300
local PAWN_EMPTY_SLOT_PCT=10000
local function isUnverifiedHigh(r)
    if not r or (r.status~="UP" and r.status~="FUP") or type(r.pct)~="number" then return false end
    -- A complete LOCKED_SET uses two explicit, locally Pawn-valued sets. The
    -- 300% heuristic only guards free-form guesses, not exact locked bases.
    if r.why=="PAWN_UI" then return r.pct>=PAWN_EMPTY_SLOT_PCT end
    if r.why=="LOCK_TWO" or r.why=="LOCK_ONE" then
        return not (type(r.baseline)=="number" and r.baseline>0
            and type(r.weaponBase)=="number" and r.weaponBase>0)
    end
    return r.pct>REVIEW_PCT
end
local pendingCache={} -- itemID -> {[scan sequence]=true}; only UNCACHED results enter here
local cacheResolvedCount=0
local cacheFrame, cacheCheckItem, registerCachePending
local cachePulseElapsed,cachePulseLifetime=0,0
local CACHE_PULSE_INTERVAL,CACHE_PULSE_MAX=2,32
local function cacheCount()
    local items,requests=0,0
    for _,seqs in pairs(pendingCache) do
        items=items+1
        for _ in pairs(seqs) do requests=requests+1 end
    end
    return items,requests
end
local function channelForParty()
    if not (IsInGroup and IsInGroup()) then return nil end
    if IsInGroup and type(LE_PARTY_CATEGORY_INSTANCE)=="number" and IsInGroup(LE_PARTY_CATEGORY_INSTANCE) then return "INSTANCE_CHAT" end
    if IsInRaid and IsInRaid() then return "RAID" end
    return "PARTY"
end
local function registerPrefix()
    if not (C_ChatInfo and type(C_ChatInfo.RegisterAddonMessagePrefix)=="function") then
        net.registered=false;net.registerError="RegisterAddonMessagePrefix missing";return false
    end
    local ok,accepted=pcall(C_ChatInfo.RegisterAddonMessagePrefix,addonPrefix)
    net.registered=ok and accepted~=false
    net.registerError=not ok and tostring(accepted) or (accepted==false and "Prefix registration rejected" or nil)
    return net.registered
end
-- Forever sometimes supplies a roleplay surname after a space, or a realm after a hyphen.
-- Match only the five exact team first names with a safe separator; never accept random prefixes.
local function canonicalTeamName(raw)
    if type(raw)~="string" then return nil end
    local clean=raw:match("^%s*(.-)%s*$")
    for _,first in ipairs(names) do
        if clean==first or clean:match("^"..first.."[%s%-]") then return first end
    end
    return nil
end
local function me() return canonicalTeamName(UnitName("player")) end
local function plainName(raw)
    local name=tostring(raw or "")
    name=name:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", "")
    name=name:gsub("|T.-|t", ""):gsub("|A.-|a", "")
    name=name:gsub("|Interface[^%s]*", ""):gsub("%s+", " ")
    return (name:match("^%s*(.-)%s*$") or name)
end
local function pretty(s,limit)
    s=plainName(s)
    if #s>(limit or 99) then return s:sub(1,limit-3).."..." end
    return s
end
local function say(s) print("|cffd9b66eHaplo Loot:|r "..tostring(s)) end
local function state()
    if type(HB.db)~="table" then return nil end
    if type(HB.db.lootPlanner)~="table" then HB.db.lootPlanner={} end
    local s=HB.db.lootPlanner
    if type(s.pins)~="table" then s.pins={} end
    for _,name in ipairs(names) do
        if type(s.pins[name])~="table" then s.pins[name]={} end
    end
    return s
end
local function info(id)
    local fn=(C_Item and C_Item.GetItemInfo) or _G.GetItemInfo
    if type(fn)~="function" then return end
    local ok,a,b,c,d,e,f,g,h,i,j,k,l,m=pcall(fn,id)
    if ok then return a,b,c,d,e,f,g,h,i,j,k,l,m end
end
local function hydrate(id)
    local loader=C_Item and C_Item.RequestLoadItemDataByID
    if type(loader)=="function" then pcall(loader,id) end
end
-- Item ownership is checked on the character running Pawn, never inferred from
-- Mael's bags or another party member's equipped slots.  This is essential
-- for Unique-Equipped jewelry: Pawn can still return an upgrade for an item
-- which the character is legally unable to equip a second time.
-- Keep one inventory snapshot and refresh on actual equipment/bag changes;
-- do not repeatedly traverse all bags for hundreds of scanned item IDs.
HB.LootUnique=HB.LootUnique or {}
function HB.LootUnique.Owned()
    if HB.LootUnique.inventoryMap then return HB.LootUnique.inventoryMap end
    local map={}
    local function add(link)
        local id=type(link)=="string" and tonumber(link:match("item:(%d+)"))
        if id then map[id]=(map[id] or 0)+1 end
    end
    if type(GetInventoryItemLink)=="function" then
        for slot=1,19 do
            local ok,link=pcall(GetInventoryItemLink,"player",slot)
            if ok then add(link) end
        end
    end
    local countSlots=(C_Container and C_Container.GetContainerNumSlots) or _G.GetContainerNumSlots
    local itemLink=(C_Container and C_Container.GetContainerItemLink) or _G.GetContainerItemLink
    if type(countSlots)=="function" and type(itemLink)=="function" then
        for bag=0,4 do
            local ok,n=pcall(countSlots,bag)
            if ok and type(n)=="number" then
                for slot=1,n do
                    local found,link=pcall(itemLink,bag,slot)
                    if found then add(link) end
                end
            end
        end
    end
    HB.LootUnique.inventoryMap=map
    return map
end
function HB.LootUnique.OnInventoryChange()
    local previous=HB.LootUnique.inventoryMap
    HB.LootUnique.inventoryMap=nil
    if not previous then return false end
    local now=HB.LootUnique.Owned()
    for id in pairs(HB.LootUnique.tracked or {}) do
        if (now[id] or 0)~=(previous[id] or 0) then return true end
    end
    return false
end
function HB.LootUnique.HasUniqueRestriction(link)
    local function matches(raw)
        if type(raw)~="string" then return false end
        local line=raw:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", "")
        line=(line:match("^%s*(.-)%s*$") or line):lower()
        -- Restriction lines, not an item name such as "Unique Pearl Ring".
        if line=="unique" or line=="unique-equipped"
            or line:match("^unique:%s*") or line:match("^unique%s*%(")
            or line:match("^unique%-equipped:%s*") or line:match("^unique%-equipped%s*%(") then return true end
        for _,key in ipairs({"ITEM_UNIQUE","ITEM_UNIQUE_EQUIPPABLE"}) do
            local label=_G[key]
            if type(label)=="string" then
                label=label:gsub("%%s", ""):gsub(":.*$", "")
                label=(label:match("^%s*(.-)%s*$") or label):lower()
                if label~="" and (line==label or line:sub(1,#label+1)==label..":"
                    or line:sub(1,#label+1)==label.."(") then return true end
            end
        end
        return false
    end
    -- C_TooltipInfo is optional on Classic/Forever client builds.
    if C_TooltipInfo and type(C_TooltipInfo.GetHyperlink)=="function" then
        local ok,data=pcall(C_TooltipInfo.GetHyperlink,link)
        if ok and type(data)=="table" and type(data.lines)=="table" then
            local readable=false
            for _,line in ipairs(data.lines) do
                if type(line.leftText)=="string" or type(line.rightText)=="string" then readable=true end
                if matches(line.leftText) or matches(line.rightText) then return true end
            end
            if readable then return false end -- otherwise try legacy hidden tooltip
        end
    end
    -- Blizzard-compatible fallback: the hidden tooltip works on Classic.
    if type(CreateFrame)~="function" then return nil end
    if not HB.LootUnique.tooltip then
        local ok,t=pcall(CreateFrame,"GameTooltip","HaploLootUniqueScanTooltip",UIParent,"GameTooltipTemplate")
        if not ok or not t then return nil end
        HB.LootUnique.tooltip=t
    end
    local tip=HB.LootUnique.tooltip
    if type(tip.SetHyperlink)~="function" or type(tip.NumLines)~="function" then return nil end
    local ok=pcall(function()
        tip:SetOwner(UIParent,"ANCHOR_NONE")
        tip:ClearLines()
        tip:SetHyperlink(link)
    end)
    if not ok then return nil end
    local count=tip:NumLines()
    if type(count)~="number" or count<1 then return nil end
    for i=1,count do
        local left=_G["HaploLootUniqueScanTooltipTextLeft"..i]
        local right=_G["HaploLootUniqueScanTooltipTextRight"..i]
        local l=left and left.GetText and left:GetText()
        local r=right and right.GetText and right:GetText()
        if matches(l) or matches(r) then tip:Hide();return true end
    end
    tip:Hide()
    return false
end

local function addonMessage(message)
    local channel=channelForParty()
    if not channel then net.lastSendError="Not grouped";net.failures=net.failures+1;return false end
    if not (C_ChatInfo and type(C_ChatInfo.SendAddonMessage)=="function") then
        net.lastSendError="SendAddonMessage missing";net.failures=net.failures+1;return false
    end
    if not net.registered then registerPrefix() end
    local ok,accepted=pcall(C_ChatInfo.SendAddonMessage,addonPrefix,message,channel)
    -- Some Forever clients return nil on accepted sends; only explicit false or errors are failures.
    local success=ok and accepted~=false
    if success then net.sends=net.sends+1 else
        net.failures=net.failures+1
        net.lastSendError=not ok and tostring(accepted) or "SendAddonMessage returned false"
    end
    return success
end
local batch={}
batch.size=16 -- max item IDs per addressed request, well below 255-byte addon payload
batch.maxPacket=224 -- safe headroom below WoW addon-message payload limits
batch.replyInterval=0.42 -- deliberately paced multi-result packets
batch.statuses={"UP","NOUP","NEW","UNUSABLE","FUTURE","NOSCALE","NOSTATS","UNCACHED","VERIFY","NOGEAR","NEEDPAIR","FUP","FNEW","FPAIR","OWNED"}
batch.statusCode={}
batch.slotNames={"UNKNOWN","WEAPON_SET","INVTYPE_HEAD","INVTYPE_NECK","INVTYPE_SHOULDER",
    "INVTYPE_BODY","INVTYPE_CHEST","INVTYPE_WAIST","INVTYPE_LEGS","INVTYPE_FEET",
    "INVTYPE_WRIST","INVTYPE_HAND","INVTYPE_FINGER","INVTYPE_TRINKET","INVTYPE_CLOAK"}
batch.slotCode={}
batch.whys={"NONE","PAWN_UI","LOCK_ONE","LOCK_TWO","BAG_PAIR","BAG_PENDING","NO_PAIR",
    "EMPTY_SENTINEL","NO_TOOLTIP_UP","PAWN_UNKNOWN","PAWN_API","SCALE_ERROR","SCALE_HIDDEN",
    "COMPARE_ERROR","PERCENT_ERROR","LOCK_UNKNOWN","UNIQUE_UNKNOWN"}
batch.whyCode={}
for i,name in ipairs(batch.statuses) do batch.statusCode[name]=string.char(96+i) end
for i,name in ipairs(batch.slotNames) do batch.slotCode[name]=string.char(64+i) end
for i,name in ipairs(batch.whys) do batch.whyCode[name]=string.char(64+i) end
batch.sendQueue={}
batch.frame=nil
batch.elapsed=0
batch.sent=0
batch.failed=0
batch.packetsReceived=0
batch.rowsReceived=0
batch.requestsReceived=0
batch.requestsSent=0
batch.retryRequestsSent=0
batch.fallbackSent=0
batch.maxPending=0
function batch.number(x,precision)
    local v=tonumber(x)
    if not v then return "-1" end
    local n=string.format("%."..tostring(precision or 6).."f",v)
    n=n:gsub("0+$",""):gsub("%.$","")
    return n
end
function batch.encode(id,code,pct,slot,req,lvl,raw,weaponBase,why,baseline)
    local c=batch.statusCode[code]
    local g=batch.slotCode[slot or "UNKNOWN"]
    local w=batch.whyCode[why or "NONE"]
    if not c or not g or not w then return nil end
    return table.concat({tostring(id),c,batch.number(pct,2),g,tostring(req or 0),
        tostring(lvl or 0),batch.number(raw,6),batch.number(weaponBase,6),w,
        batch.number(baseline,6)},",")
end
function batch.decode(row)
    local id,c,pct,g,req,lvl,raw,base,w,old=row:match(
        "^(%d+),([a-z]),([%d%.%-]+),([A-Z]),(%d+),(%d+),([%d%.%-]+),([%d%.%-]+),([A-Z]),([%d%.%-]+)$")
    if not id or not c or not g or not w then return nil end
    local result={id=tonumber(id),code=batch.statuses[string.byte(c)-96],
        pct=tonumber(pct),slot=batch.slotNames[string.byte(g)-64],required=tonumber(req),
        level=tonumber(lvl),raw=tonumber(raw),weaponBase=tonumber(base),
        why=batch.whys[string.byte(w)-64],baseline=tonumber(old)}
    local function safe(x,hi)
        return x and x==x and x>=-1 and x<=hi
    end
    if not result.id or result.id<1 or result.id>3000000 or not result.code or not result.slot or not result.why
        or not safe(result.pct,100000) or not safe(result.raw,10000000)
        or not safe(result.weaponBase,10000000) or not safe(result.baseline,10000000)
        or not result.required or result.required>1000 or not result.level or result.level>1000 then return nil end
    return result
end
function batch.queueReply(packet)
    if #packet>batch.maxPacket then return false end
    batch.sendQueue[#batch.sendQueue+1]=packet
    batch.maxPending=math.max(batch.maxPending,#batch.sendQueue)
    if not batch.frame then batch.frame=CreateFrame("Frame") end
    if not batch.frame:GetScript("OnUpdate") then
        batch.elapsed=0
        batch.frame:SetScript("OnUpdate",function(self,elapsed)
            batch.elapsed=batch.elapsed+elapsed
            if batch.elapsed<batch.replyInterval then return end
            batch.elapsed=0
            if #batch.sendQueue==0 then self:SetScript("OnUpdate",nil);return end
            local message=table.remove(batch.sendQueue,1)
            if addonMessage(message) then batch.sent=batch.sent+1 else batch.failed=batch.failed+1 end
            if #batch.sendQueue==0 then self:SetScript("OnUpdate",nil) end
        end)
    end
    return true
end

-- Pawn's Forever provider has four druid specs: Balance=1, Feral DPS=2,
-- Feral TANK=3 and Restoration=4.  HF26.9.1 accidentally mapped Mael to 2.
-- This lookup uses Pawn's own "Classic" provider keys and never copies weights.
local specForRole={balance=1,feral=3,restoration=4}
local scaleDiagnostics={}
local function pawnVisible(label)
    if type(PawnIsScaleVisible)~="function" then return false end
    local ok,visible=pcall(PawnIsScaleVisible,label)
    return ok and visible==true
end
local function eligibleScale(label,expected)
    if type(label)~="string" or not (PawnCommon and PawnCommon.Scales) then return false end
    local scale=PawnCommon.Scales[label]
    if type(scale)~="table" or type(scale.Values)~="table" then return false end
    if tonumber(scale.ClassID)~=11 or tonumber(scale.SpecID)~=expected then return false end
    if scale.Provider and scale.ProviderActive==false then return false end
    return pawnVisible(label)
end
local function chooseScale()
    local current=me()
    local role=roles[current]
    if not role then return nil end
    local expected=specForRole[role]
    local preferred='"Classic":DRUID'..expected -- PawnGetProviderScaleName("Classic","DRUID"..spec)
    if type(PawnCommon)~="table" or type(PawnCommon.Scales)~="table" then
        scaleDiagnostics[current]="Pawn unavailable; expected "..preferred
        return nil
    end
    local db=HB.db
    local manual=db and db.lootPlannerScales and db.lootPlannerScales[current]
    local earlier=db and db.lootAdvisorScale
    local skipped={}
    -- Keep an explicitly chosen PER-CHARACTER custom scale only if it is visible
    -- and carries the correct druid class/spec metadata. A stale HF25 shared
    -- LootAdvisor scale is NEVER valid authority for the full five-druid team.
    if type(manual)=="string" then
        if eligibleScale(manual,expected) then
            scaleDiagnostics[current]="manual (role checked): "..manual
            return manual
        end
        skipped[#skipped+1]="ignored invalid/hidden manual="..manual
    end
    if type(earlier)=="string" and earlier~=preferred then
        skipped[#skipped+1]="ignored legacy="..earlier
    end
    if eligibleScale(preferred,expected) then
        scaleDiagnostics[current]="Forever Classic role scale: "..preferred
            ..(#skipped>0 and ("; "..table.concat(skipped,"; ")) or "")
        return preferred
    end
    -- In older localized builds the provider key may differ. Only allow a
    -- unique, VISIBLE scale with the EXACT class/spec; never guess by label.
    local matches={}
    for label in pairs(PawnCommon.Scales) do
        if eligibleScale(label,expected) then matches[#matches+1]=label end
    end
    table.sort(matches)
    if #matches==1 then
        scaleDiagnostics[current]="unique matching role: "..matches[1]
        return matches[1]
    end
    scaleDiagnostics[current]=(#matches==0 and "no VISIBLE exact-spec scale" or
        "ambiguous exact-spec scales: "..table.concat(matches,", "))
        .."; expected "..preferred
        ..(#skipped>0 and ("; "..table.concat(skipped,"; ")) or "")
    return nil -- do not rank when scale is missing/hidden/ambiguous
end
HB.HaploLootGetScale=chooseScale -- read-only for CharacterFrame weapon set proposals
local function pawnValue(link,s)
    if type(PawnGetItemData)~="function" or type(PawnGetSingleValueFromItem)~="function" then
        return nil,nil,"PAWN_API"
    end
    if not link then return nil,nil,"NO_LINK" end
    local ok,item=pcall(PawnGetItemData,link)
    if not ok then return nil,nil,"ITEM_ERROR" end
    if type(item)~="table" then
        -- Pawn may reject a custom Forever item type before even parsing its tooltip.
        -- Distinguish this from a recognized item whose Pawn data is absent.
        if type(PawnCanItemHaveStats)=="function" then
            local checked,allowed=pcall(PawnCanItemHaveStats,link)
            if checked and allowed==false then return nil,nil,"TYPE_REJECT" end
            if not checked then return nil,nil,"TYPE_ERROR" end
        end
        return nil,nil,"NO_ITEM"
    end
    if type(item.Stats)~="table" then return nil,nil,"NO_STATS" end
    local yes,value=pcall(PawnGetSingleValueFromItem,item,s)
    if not yes then return nil,nil,"SCORE_ERROR" end
    if type(value)~="number" or value~=value then return nil,nil,"NO_SCORE" end
    return value,item,"OK"
end
-- Pawn's green tooltip % is NOT (enchanted candidate value - enchanted equipped
-- item value) / equipped item value. PawnIsItemAnUpgrade uses its own best-item
-- tracking and UNENCHANTED scores for the relevant inventory type. This call is
-- made locally on each Druid, and must be our source of truth for standard gear.
local function pawnTooltipPercent(item,scaleName)
    if type(PawnIsItemAnUpgrade)~="function" then return nil,"PAWN_API" end
    if type(PawnIsScaleVisible)=="function" then
        local ok,visible=pcall(PawnIsScaleVisible,scaleName)
        if not ok then return nil,"SCALE_ERROR" end
        if not visible then return nil,"SCALE_HIDDEN" end
    end
    local ok,upgrades=pcall(PawnIsItemAnUpgrade,item)
    if not ok then return nil,"COMPARE_ERROR" end
    if type(upgrades)=="table" then
        for _,v in pairs(upgrades) do
            if type(v)=="table" and v.ScaleName==scaleName then
                local ratio=tonumber(v.PercentUpgrade)
                if ratio==nil or ratio~=ratio or ratio<0 or ratio>PAWN_EMPTY_SLOT_PCT/100 then
                    return nil,"PERCENT_ERROR"
                end
                return 100*ratio,"PAWN_UI"
            end
        end
    end
    -- No matching entry can mean "no upgrade" OR "best-items not ready".
    -- We check the equipped-only score independently and never invent a %.
    return 0,"NO_TOOLTIP_UP"
end
local function gearValue(slot,s)
    local link=GetInventoryItemLink("player",slot)
    if not link then return 0 end
    return pawnValue(link,s) -- nil means unknown and is NEVER treated as zero
end
local slots={
    INVTYPE_HEAD={1},INVTYPE_NECK={2},INVTYPE_SHOULDER={3},INVTYPE_BODY={4},
    INVTYPE_CHEST={5},INVTYPE_ROBE={5},INVTYPE_WAIST={6},INVTYPE_LEGS={7},
    INVTYPE_FEET={8},INVTYPE_WRIST={9},INVTYPE_HAND={10},INVTYPE_FINGER={11,12},
    INVTYPE_TRINKET={13,14},INVTYPE_CLOAK={15},INVTYPE_2HWEAPON={16},
    INVTYPE_WEAPONMAINHAND={16},INVTYPE_WEAPON={16},INVTYPE_HOLDABLE={17},
    INVTYPE_WEAPONOFFHAND={17},INVTYPE_SHIELD={17},INVTYPE_RANGED={18},
    INVTYPE_RANGEDRIGHT={18},INVTYPE_RELIC={18},INVTYPE_THROWN={18},
}
local weapon={INVTYPE_2HWEAPON=true,INVTYPE_WEAPONMAINHAND=true,INVTYPE_WEAPON=true,
    INVTYPE_HOLDABLE=true,INVTYPE_WEAPONOFFHAND=true,INVTYPE_SHIELD=true}
local function slotGroup(inv)
    if weapon[inv] then return "WEAPON_SET" end
    if inv=="INVTYPE_ROBE" then return "INVTYPE_CHEST" end
    return inv or "UNKNOWN"
end
-- Only guaranteed, druid-legal categories are auto-scored. No guess for unsupported weapon types.
local function druidEquipment(classID,subclassID,inv)
    if not slots[inv] then return false end
    if inv=="INVTYPE_SHIELD" or inv=="INVTYPE_RANGED" or inv=="INVTYPE_RANGEDRIGHT"
            or inv=="INVTYPE_THROWN" or inv=="INVTYPE_RELIC"
            or inv=="INVTYPE_WEAPONOFFHAND" then return false end
    if classID==4 then
        -- Armor: generic/cloaks, cloth, leather; exclude mail, plate and shields.
        return subclassID==0 or subclassID==1 or subclassID==2
    end
    if classID==2 then
        -- Forever: 4=1H mace, 5=2H mace, 6=polearm (level 20+),
        -- 10=staff, 13=fist, 15=dagger. The client handles trained proficiency.
        return subclassID==4 or subclassID==5 or subclassID==6
            or subclassID==10 or subclassID==13 or subclassID==15
    end
    return false
end
-- Conservative item ROLE FIT for the current five-druid team.
-- Pawn stays authoritative for upgrade PERCENTAGES, while this independent
-- stat profile prevents a large percentage on poor old gear from awarding a
-- defensive drop to a caster in the automated dungeon score.
-- We NEVER compare raw Pawn score magnitudes across different spec scales.
-- Unknown or mixed stat profiles are deliberately not force-assigned.
local roleFitCache={}
local function classifyStats(stats)
    if type(stats)~="table" then return "UNKNOWN" end
    local defense,physical,caster,healing,genericCaster=0,0,0,0,0
    local healingValue,damageValue=0,0
    for key,value in pairs(stats) do
        if type(key)=="string" and type(value)=="number" and value>0 then
            local k=key:lower()
            if k:find("resist",1,true) or k=="defense" or k=="defenserating"
                    or k=="dodge" or k=="dodgerating" or k=="parryrating"
                    or k=="blockrating" or k=="bonusarmor" then
                defense=defense+1
            elseif k=="strength" or k=="agility" or k=="ap"
                    or k=="attackpower" or k=="meleedps" or k=="meleecrit"
                    or k=="feralattackpower" then
                physical=physical+1
            elseif k=="healing" or k=="bonushealing" or k=="mp5"
                    or k=="manaper5sec" or k=="manaregen" then
                healing=healing+1
                if k=="healing" or k=="bonushealing" then healingValue=healingValue+value end
            elseif k=="spelldamage" or k=="spellhit" or k=="spellhitrating"
                    or k=="spellcritrating" or k=="spellhaste" or k=="spellpower"
                    or k=="spellcrit" or k=="spelldamageandhealing" then
                caster=caster+1
                if k=="spelldamage" or k=="spellpower" then damageValue=damageValue+value end
            elseif k=="intellect" or k=="spirit" then
                genericCaster=genericCaster+1
            end
        end
    end
    if (defense>0 or physical>0) and caster==0 and healing==0 and genericCaster==0 then return "TANK" end
    if healing>0 and caster==0 and physical==0 and defense==0 then return "RESTO" end
    if caster>0 and healing==0 and physical==0 and defense==0 then return "BALANCE" end
    -- A staff with both +Healing and +Spell Damage is not automatically
    -- 'MIXED'. Strong 2:1 evidence is enough for conservative specialization
    -- guidance, but we do not compare different Pawn scales numerically.
    if healing>0 and caster>0 and physical==0 and defense==0
            and healingValue>0 and damageValue>0 then
        if healingValue>=2*damageValue then return "RESTO" end
        if damageValue>=2*healingValue then return "BALANCE" end
    end
    if genericCaster>0 and defense==0 and physical==0 and healing==0 and caster==0 then return "CASTER" end
    if defense==0 and physical==0 and caster==0 and healing==0 and genericCaster==0 then return "NEUTRAL" end
    return "MIXED"
end
local function itemRoleFit(id,exactItemString)
    local key=exactItemString or id
    if roleFitCache[key] then return roleFitCache[key] end
    local _,link=info(key)
    if not link or type(PawnGetItemData)~="function" then return "UNKNOWN" end
    local ok,item=pcall(PawnGetItemData,link)
    if not ok or type(item)~="table" or type(item.Stats)~="table" then return "UNKNOWN" end
    local fit=classifyStats(item.Stats)
    roleFitCache[key]=fit
    return fit
end
HB.HaploLootItemRoleFit=itemRoleFit
-- The historical PIN behaviour stays available to the unchanged HF26.16
-- mouseover adapter; the automatic Dungeon V1 scanner ignores those pins.
local function roleRelevantAuto(name,id,exactItemString)
    local fit=itemRoleFit(id,exactItemString)
    if fit=="TANK" then return name=="Mael" end
    if fit=="RESTO" then return name=="Lyra" end
    if fit=="BALANCE" then return name=="Elya" or name=="Nyra" or name=="Ayla" end
    if fit=="CASTER" then return name~="Mael" end
    -- NEUTRAL/MIXED/UNKNOWN: no evidence to exclude a role.
    return true
end
local function roleRelevant(name,id,exactItemString)
    local s=HB.db and HB.db.lootPlanner
    if s and s.pins and s.pins[name] and s.pins[name][tostring(id)] then return true end
    return roleRelevantAuto(name,id,exactItemString)
end
-- The approved Party Pawn tooltip retains the original role predicate.
HB.HaploLootRoleRelevant=roleRelevant

-- Complete 1H+held-offhand alternatives from the player's CARRIED bags.
-- Pawns raw values are always evaluated on this character's own scale. Never
-- treat a single 1H as a replacement for a complete equipped 2H set.
-- NOTE: Druids cannot dual wield; only INVTYPE_HOLDABLE is an offhand partner.
local function bestBagPartner(s,kind)
    local getCount=(C_Container and C_Container.GetContainerNumSlots) or _G.GetContainerNumSlots
    local getLink=(C_Container and C_Container.GetContainerItemLink) or _G.GetContainerItemLink
    if type(getCount)~="function" or type(getLink)~="function" then return nil,false end
    local best,unresolved=nil,false
    for bag=0,4 do
        local ok,count=pcall(getCount,bag)
        if ok and type(count)=="number" then
            for slot=1,count do
                local linked,link=pcall(getLink,bag,slot)
                if linked and type(link)=="string" then
                    local _,_,_,_,req,_,_,_,inv,_,_,classID,subclassID=info(link)
                    if not inv then
                        -- Cache the bag item when it may be a missing partner.
                        local bagID=tonumber(link:match("item:(%d+)"))
                        if bagID then hydrate(bagID) end
                        unresolved=true
                    elseif (kind=="OFF" and inv=="INVTYPE_HOLDABLE")
                        or (kind=="MAIN" and (inv=="INVTYPE_WEAPON" or inv=="INVTYPE_WEAPONMAINHAND")
                            and druidEquipment(classID,subclassID,inv)) then
                        if req==nil then
                            unresolved=true
                        elseif tonumber(req)<=tonumber(UnitLevel("player") or 0) then
                            local v=pawnValue(link,s)
                            if v==nil then unresolved=true
                            elseif v>=0 and (not best or v>best) then best=v end
                        end
                    end
                end
            end
        end
    end
    return best,unresolved
end
local function bagSetResult(candidate,baseline,s,partnerKind,group,required,lvl)
    local partner,unresolved=bestBagPartner(s,partnerKind)
    if partner==nil then
        -- If bag item data is missing, do not assert that no pair exists.
        if unresolved then return "NOGEAR",-1,group,required,lvl,candidate,baseline,"BAG_PENDING" end
        return "NEEDPAIR",-1,group,required,lvl,candidate,baseline,"NO_PAIR"
    end
    local complete=candidate+partner
    -- Raw is ALWAYS the candidate's standalone Pawn value: the dungeon pair
    -- builder needs to sum two candidate items, not double-count a bag partner.
    if complete<=baseline then return "NOUP",0,group,required,lvl,candidate,baseline,"BAG_PAIR",baseline end
    if baseline<=0 then return "NEW",-1,group,required,lvl,candidate,baseline,"BAG_PAIR",baseline end
    return "UP",(complete-baseline)/baseline*100,group,required,lvl,candidate,baseline,"BAG_PAIR",baseline
end

local function evaluate(id,exactItemString,allowFuturePercent)
    local lvl=UnitLevel("player") or 0
    -- Hover checks may supply the exact bag-item variant (suffix/bonus data).
    -- Dungeon scans continue to use item IDs. Never substitute a generic item
    -- for an uncached exact variant and invent an upgrade percentage.
    local name,link,_,_,required,_,_,_,inv,_,_,classID,subclassID=info(exactItemString or id)
    if not name or not link then hydrate(id);return "UNCACHED",-1,"UNKNOWN",0,lvl end
    if (not inv or inv=="" or not classID or not subclassID) and C_Item and type(C_Item.GetItemInfoInstant)=="function" then
        local ok,_,_,_,instantInv,_,instantClass,instantSub=pcall(C_Item.GetItemInfoInstant,id)
        if ok then
            classID=classID or instantClass
            subclassID=subclassID or instantSub
            if not inv or inv=="" then inv=instantInv end
        end
    end
    if not inv or inv=="" then hydrate(id);return "UNCACHED",-1,"UNKNOWN",0,lvl end
    if required==nil then hydrate(id);return "UNCACHED",-1,slotGroup(inv),0,lvl end
    required=tonumber(required) or 0
    if classID==2 and subclassID==6 then required=math.max(required,20) end
    local group=slotGroup(inv)
    if not druidEquipment(classID,subclassID,inv) then return "UNUSABLE",-1,group,required,lvl end
    -- Detect already-owned Unique/Unique-Equipped items *before* trusting Pawn.
    -- A non-unique ring already worn may still legally fill the other ring slot.
    -- An unreadable owned jewelry tooltip remains CHECK, never a false BiS.
    HB.LootUnique.tracked=HB.LootUnique.tracked or {}
    HB.LootUnique.tracked[id]=true
    if (HB.LootUnique.Owned()[id] or 0)>0 then
        local unique=HB.LootUnique.HasUniqueRestriction(link)
        if unique==true then return "OWNED",0,group,required,lvl end
        if unique==nil and (group=="INVTYPE_FINGER" or group=="INVTYPE_TRINKET") then
            return "VERIFY",-1,group,required,lvl,nil,nil,"UNIQUE_UNKNOWN"
        end
    end
    -- Current ranking never counts future gear. Tooltip and Dungeon Advisor
    -- may ask Pawn for its actual current-gear comparison as a *future estimate*.
    local future=required>lvl
    if future and not allowFuturePercent then return "FUTURE",-1,group,required,lvl end
    local s=chooseScale()
    if not s then return "NOSCALE",-1,group,required,lvl end
    local n,item,why=pawnValue(link,s)
    if n==nil then return "NOSTATS",-1,group,required,lvl,nil,nil,why end
    -- Pawn/Blizzard may report CanEquip=false solely because player is low level.
    -- Retain class/type screening above and leave future items excluded from scans.
    if item.CanEquip==false and not future then return "UNUSABLE",-1,group,required,lvl end
    if group=="WEAPON_SET" and HB.WeaponSets and HB.WeaponSets.Compare then
        local compare=HB.WeaponSets.Compare(link,inv,n,s)
        if compare then
            if not compare.ok then
                if compare.why=="NEEDPAIR" and type(compare.base)=="number" then
                    -- Lyra-style case: a locked 2H but no owned 1H reference.
                    -- Evaluate only complete 1H+OH opportunities, not a naked 1H.
                    local partnerKind=(inv=="INVTYPE_HOLDABLE") and "MAIN" or "OFF"
                    return bagSetResult(n,compare.base,s,partnerKind,group,required,lvl)
                end
                return "VERIFY",-1,group,required,lvl,n,nil,compare.why or "LOCK_UNKNOWN"
            end
            if compare.pct>0.01 then
                return "UP",compare.pct,group,required,lvl,n,compare.other,
                    compare.why,compare.base
            end
            return "NOUP",0,group,required,lvl,n,compare.other,compare.why,compare.base
        end
    end
    local ss=slots[inv]
    local base
    local equippedWeaponSet=-1
    if group=="WEAPON_SET" then
        local mh,oh=gearValue(16,s),gearValue(17,s)
        if mh==nil or oh==nil then return "NOGEAR",-1,group,required,lvl end
        equippedWeaponSet=mh+oh
    end
    if inv=="INVTYPE_2HWEAPON" then
        local mh,oh=gearValue(16,s),gearValue(17,s)
        if mh==nil or oh==nil then return "NOGEAR",-1,group,required,lvl end
        base=mh+oh
    elseif inv=="INVTYPE_WEAPONMAINHAND" or inv=="INVTYPE_WEAPON" then
        local mh=GetInventoryItemLink("player",16)
        local _,_,_,_,_,_,_,_,typ=info(mh)
        if mh and not typ then return "NOGEAR",-1,group,required,lvl end
        if typ=="INVTYPE_2HWEAPON" then
            return bagSetResult(n,equippedWeaponSet,s,"OFF",group,required,lvl)
        end
        base=gearValue(16,s)
    elseif inv=="INVTYPE_HOLDABLE" or inv=="INVTYPE_WEAPONOFFHAND" then
        local mh=GetInventoryItemLink("player",16)
        local _,_,_,_,_,_,_,_,typ=info(mh)
        if mh and not typ then return "NOGEAR",-1,group,required,lvl end
        if not mh or typ=="INVTYPE_2HWEAPON" then
            return bagSetResult(n,equippedWeaponSet,s,"MAIN",group,required,lvl)
        end
        base=gearValue(17,s)
    elseif #ss==2 then
        local a,b=gearValue(ss[1],s),gearValue(ss[2],s)
        if a==nil or b==nil then return "NOGEAR",-1,group,required,lvl end
        base=math.min(a,b)
    else
        base=gearValue(ss[1],s)
    end
    -- Standard armor, cloak, jewelry, etc: match the ACTUAL Pawn tooltip.
    -- Weapons remain separate because the custom 1H+OH vs 2H rule needs a
    -- verified complete set and Pawn hides such cross-handedness upgrades.
    if group~="WEAPON_SET" then
        local tooltipPct,origin=pawnTooltipPercent(item,s)
        if origin=="PAWN_UI" then
            if tooltipPct>=PAWN_EMPTY_SLOT_PCT-0.001 then
                if base==0 then return "NEW",-1,group,required,lvl,n,equippedWeaponSet,"PAWN_UI",base end
                return "VERIFY",-1,group,required,lvl,n,equippedWeaponSet,"EMPTY_SENTINEL",base
            end
            if tooltipPct>0 then
                return "UP",tooltipPct,group,required,lvl,n,equippedWeaponSet,"PAWN_UI",base
            end
            return "NOUP",0,group,required,lvl,n,equippedWeaponSet,"PAWN_UI",base
        elseif origin=="NO_TOOLTIP_UP" then
            -- Pawn can take items already in bags into account; a candidate
            -- better than EQUIPPED gear may still not beat the best owned item.
            if (base==nil or n>base) then
                return "VERIFY",-1,group,required,lvl,n,equippedWeaponSet,"NO_TOOLTIP_UP",base
            end
            return "NOUP",0,group,required,lvl,n,equippedWeaponSet,"PAWN_UI",base
        end
        return "VERIFY",-1,group,required,lvl,n,equippedWeaponSet,origin or "PAWN_UNKNOWN",base
    end
    if base==nil then return "NOGEAR",-1,group,required,lvl end
    -- Return numeric raw Pawn values only when the item was successfully read.
    -- The party leader uses these ONLY to compare complete weapon combinations.
    if n<=base then return "NOUP",0,group,required,lvl,n,equippedWeaponSet,"NONE",base end
    if base<=0 then return "NEW",-1,group,required,lvl,n,equippedWeaponSet,"NONE",base end
    local delta=(n-base)/base*100
    return "UP",delta,group,required,lvl,n,equippedWeaponSet,"NONE",base
end
-- Expose the EXISTING, validated per-client Pawn comparison to tooltip adapters.
-- No duplicated scoring formulas, no copied stat weights.
HB.HaploLootEvaluateItem=evaluate
HB.HaploLootEvaluateHoverItem=function(id,exactItemString)
    return evaluate(id,exactItemString,true)
end

-- Dungeon-only estimation: future equippable items may have REAL Pawn model
-- values versus today's equipment. They are NEVER called currently usable
-- upgrades, Need winners or scored in the current-level dungeon ranking.
local function evaluateForDungeon(id)
    local cached=evalCache[id]
    if cached then return (unpack or table.unpack)(cached) end
    local status,pct,slot,req,lvl,raw,weaponBase,why,baseline=evaluate(id,nil,true)
    if req and lvl and req>lvl then
        if status=="UP" then status="FUP"
        elseif status=="NEW" then status="FNEW"
        elseif status=="NOUP" then status="FNOUP"
        elseif status=="NEEDPAIR" then status="FPAIR" end
    end
    if status~="UNCACHED" and not (status=="NOGEAR" and why=="BAG_PENDING") then
        evalCache[id]={status,pct,slot,req,lvl,raw,weaponBase,why,baseline}
    end
    return status,pct,slot,req,lvl,raw,weaponBase,why,baseline
end

local function atlasReady()
    if not (_G.AtlasLoot and AtlasLoot.ItemDB) then return false,"AtlasLoot not loaded" end
    local db=AtlasLoot.ItemDB
    if not db:Get(atlasModule) then
        if InCombatLockdown and InCombatLockdown() then return false,"Open outside combat" end
        local load=(C_AddOns and C_AddOns.LoadAddOn) or _G.LoadAddOn
        if type(load)=="function" then pcall(load,atlasModule) end
    end
    if not db:Get(atlasModule) then return false,"AtlasLoot dungeon data unavailable" end
    return true
end
-- AtlasLoot exposes raids in the same data module; Dungeon Advisor V1 deliberately
-- excludes raids even when the group eventually reaches level 60.
local raidIDs={MoltenCore=true,BlackwingLair=true,Naxxramas=true,Onyxia=true,
    OnyxiasLair=true,ZulGurub=true,ZulGurubClassic=true,TempleOfAhnQiraj=true,
    RuinsOfAhnQiraj=true,AhnQiraj=true,AQ20=true,AQ40=true,WorldBosses=true}
local function dungeonOnly(id,d)
    if raidIDs[id] or d.IsRaid==true or d.Raid==true or d.Type=="RAID" then return false end
    local cap=tonumber(d.PlayerLimit or d.MaxPlayers or d.GroupSize)
    if cap and cap>10 then return false end
    return true
end
local function loadDungeons()
    local ok,msg=atlasReady()
    if not ok then return false,msg end
    wipe(dungeons)
    local source=AtlasLoot.ItemDB:Get(atlasModule)
    for id,d in pairs(source) do
        if type(id)=="string" and type(d)=="table" and type(d.items)=="table"
                and type(d.LevelRange)=="table" and not d.ExtraList and dungeonOnly(id,d) then
            dungeons[#dungeons+1]={id=id,name=plainName(d.name or id),ref=d,min=tonumber(d.MinLevel) or tonumber(d.LevelRange[1]) or 0,
                rec=tonumber(d.LevelRange[2]) or tonumber(d.LevelRange[1]) or 0,
                recHigh=tonumber(d.LevelRange[3]) or tonumber(d.LevelRange[2]) or 0}
        end
    end
    table.sort(dungeons,function(a,b) if a.min==b.min then return a.id<b.id end return a.min<b.min end)
    return true
end
local function bossesFor(d)
    local found={}
    if not d or not d.ref or type(d.ref.items)~="table" then return found end
    for i,b in ipairs(d.ref.items) do
        if type(b)=="table" and not b.link then
            local labelName=plainName(b.name or ("Boss "..i))
            local lower=labelName:lower()
            -- Only named boss/encounter sections in V1; quest, crafting, vendor
            -- and trash source categories are reserved for later loot modules.
            local excluded=lower:find("trash",1,true) or lower:find("quest",1,true)
                or lower:find("vendor",1,true) or lower:find("profession",1,true)
                or lower:find("craft",1,true)
            if not excluded then found[#found+1]={index=i,name=labelName} end
        end
    end
    return found
end
-- The safe fast filter runs on Mael BEFORE sending any Q packets. We skip
-- only item types/subclasses that no Druid can ever equip and known items above
-- the highest ONLINE team member's level. Unknown cache/class/level data is
-- deliberately INCLUDED to prevent missing a real BiS candidate.
function HB.DungeonBiSView.possibleForParty(itemID,maxLevel)
    local _,_,_,_,req,_,_,_,inv,_,_,classID,subclassID=info(itemID)
    if (not inv or inv=="" or classID==nil or subclassID==nil)
            and C_Item and type(C_Item.GetItemInfoInstant)=="function" then
        local ok,_,_,_,instInv,_,instClass,instSub=pcall(C_Item.GetItemInfoInstant,itemID)
        if ok then
            if not inv or inv=="" then inv=instInv end
            classID=classID or instClass
            subclassID=subclassID or instSub
        end
    end
    -- A known non-equipment class (consumable, material, recipe, etc.)
    -- cannot possibly contain a druid BiS slot item, even with no cached tooltip.
    if type(classID)=="number" and classID~=2 and classID~=4 then
        return false,"NON_EQUIPMENT_CLASS"
    end
    -- Empty equip locations are authoritative only once item class is known.
    if inv=="" and type(classID)=="number" then return false,"NO_EQUIP_SLOT" end
    if type(inv)~="string" or inv==""
            or type(classID)~="number" or type(subclassID)~="number" then
        return true,"UNKNOWN" -- never skip an unclassified item
    end
    if not druidEquipment(classID,subclassID,inv) then return false,"NOT_DRUID_EQUIPMENT" end
    if classID==2 and subclassID==6 then req=math.max(tonumber(req) or 0,20) end
    if type(req)=="number" and type(maxLevel)=="number" and maxLevel>0
            and req>maxLevel then return false,"ABOVE_PARTY_LEVEL" end
    return true,"POSSIBLE"
end
local function rawDrops(d,bossIndex)
    local db=AtlasLoot.ItemDB
    local diff=d.ref.LoadDifficulty or 1
    local ok,rows=pcall(db.GetItemTable,db,atlasModule,d.id,bossIndex,diff)
    if not ok or type(rows)~="table" then
        local boss=d.ref.items[bossIndex]
        rows=boss and boss[diff]
    end
    local found,seen={},{}
    if type(rows)=="table" then
        for _,row in ipairs(rows) do
            local id=type(row)=="table" and tonumber(row[2])
            if id and id>0 and not seen[id] then
                seen[id]=true;found[#found+1]=id
            end
        end
    end
    return found
end
local function markStale(name)
    -- Do not share results obtained before a gear/level/weapon-lock change.
    if allScan and allScan.running then
        allScan.sharedResults={}
        allScan.invalidated=true
    end
    HB.DungeonBiSView.cache=nil
    wipe(best)
    wipe(evalCache)
    wipe(advisorCache)
    for _,scan in pairs(scans) do
        if scan.members then
            for _,r in pairs(scan.members) do r[name]=nil end
            scan.stale=true
            scan.invalidated=true -- even a later finishScan must not clear this flag
        end
    end
end
-- A manual lock change is equivalent to a gear-reference change. Never reuse
-- old percentages even if the character has not actually equipped the set.
HB.HaploLootWeaponSetChanged=function()
    wipe(evalCache)
    wipe(advisorCache)
    if me()=="Mael" then
        markStale("Mael")
        if statusText then statusText:SetText("Weapon set changed; rescan before trusting scores.") end
    elseif roster[me()] then
        addonMessage("I") -- existing trusted leader invalidation protocol
    end
    if runRefresh then runRefresh() end
end
-- Pair one-handed weapons with offhands from the SAME fully scanned dungeon.
-- It is an optional set opportunity, not a claim that either drop alone replaces a 2H.
-- Pawns raw item scores were calculated locally by the respective client using its
-- own scale. Never combine raw values across characters or across scales.
local function rebuildPairs(scan)
    scan.weaponPairs={};scan.pairByItem={}
    if not scan or not scan.finished or scan.stale then return end
    local mainTypes={INVTYPE_WEAPON=true,INVTYPE_WEAPONMAINHAND=true}
    local offTypes={INVTYPE_HOLDABLE=true,INVTYPE_WEAPONOFFHAND=true}
    local main,off={},{}
    for id,members in pairs(scan.members) do
        local _,_,_,_,_,_,_,_,inv=info(id)
        if mainTypes[inv] then main[#main+1]=id end
        if offTypes[inv] then off[#off+1]=id end
    end
    for _,name in ipairs(scanMembers(scan)) do
        if scan.levels[name] and scan.levels[name]>=scan.dungeon.min then
            local strongest
            for _,mID in ipairs(main) do
                local a=scan.members[mID][name]
                for _,oID in ipairs(off) do
                    local b=scan.members[oID][name]
                    if a and b and a.raw and b.raw and a.raw>0 and b.raw>0
                      and a.required<=a.level and b.required<=b.level
                      and a.weaponBase and b.weaponBase
                      and a.why~="LOCK_ONE" and b.why~="LOCK_ONE"
                      and a.why~="LOCK_TWO" and b.why~="LOCK_TWO"
                      and math.abs(a.weaponBase-b.weaponBase)<0.01
                      and (a.status=="NEEDPAIR" or a.status=="UP" or a.status=="NOUP" or a.status=="NEW")
                      and (b.status=="NEEDPAIR" or b.status=="UP" or b.status=="NOUP" or b.status=="NEW") then
                        local total=a.raw+b.raw
                        local base=a.weaponBase
                        local improvement=total-base
                        if improvement>0.01 and (not strongest or improvement>strongest.improvement) then
                            strongest={main=mID,off=oID,base=base,raw=total,
                                improvement=improvement,pct=base>0 and improvement/base*100 or nil}
                        end
                    end
                end
            end
            if strongest then
                scan.weaponPairs[name]=strongest
                scan.pairByItem[name]={[strongest.main]=strongest,[strongest.off]=strongest}
            end
        end
    end
end
local function scanState(scan)
    if not scan or not scan.finished or scan.stale or scan.incomplete or scan.missingGroup then return "INCOMPLETE" end
    local future=false
    local participating=scanMembers(scan)
    for _,name in ipairs(participating) do
        local lvl=scan.levels[name]
        if not lvl then return "INCOMPLETE" end
        if lvl<scan.dungeon.min then future=true end
    end
    local provisional=false
    local unknown={NOSCALE=true,NOSTATS=true,NOGEAR=true,UNCACHED=true,VERIFY=true}
    for itemID,members in pairs(scan.members) do
        for _,name in ipairs(participating) do
            local result=members[name]
            if not result then return "INCOMPLETE" end
            if unknown[result.status] and not HB.DungeonBiSView.IsSpecial(itemID,result) then return "UNKNOWN" end
            if result.status=="UP" and (not result.pct or isUnverifiedHigh(result)) then
                return "UNKNOWN"
            end
            if result.status=="NEEDPAIR" or result.status=="NEW" or result.status=="FPAIR" or result.status=="FNEW" then provisional=true end
        end
    end
    for _,pair in pairs(scan.weaponPairs or {}) do
        if pair.pct and pair.pct>REVIEW_PCT then return "UNKNOWN" end
    end
    if future then return "FUTURE" end
    return provisional and "PROVISIONAL" or "READY"
end
local function uncertainty(scan)
    local counts={}
    if not scan or not scan.members then return counts end
    for itemID,members in pairs(scan.members) do
        for _,name in ipairs(scanMembers(scan)) do
            local r=members[name]
            local code=HB.DungeonBiSView.CoverageStatus(itemID,r)
            counts[code]=(counts[code] or 0)+1
        end
    end
    return counts
end
local function diagnosticSummary(scan)
    local counts=uncertainty(scan)
    local parts={}
    for _,code in ipairs({"NEW","NEEDPAIR","VERIFY","NOSCALE","NOSTATS","SPECIAL","UNCACHED","NOGEAR","NO_REPLY"}) do
        if (counts[code] or 0)>0 then parts[#parts+1]=code.."="..counts[code] end
    end
    local review=0
    if scan and scan.members then
        for _,members in pairs(scan.members) do
            for _,name in ipairs(scanMembers(scan)) do
                local r=members[name]
                if isUnverifiedHigh(r) then review=review+1 end
            end
        end
    end
    if review>0 then parts[#parts+1]="REVIEW="..review end
    return #parts>0 and table.concat(parts," ") or "All scores resolved"
end
-- Keep verified individual upgrades visible even if other items are uncached,
-- but do not put an UNKNOWN dungeon into the ranked numeric comparison.
local function scoreable(scan)
    local state=scanState(scan)
    return state=="READY" or state=="PROVISIONAL" or state=="UNKNOWN",state
end
local function buildBest()
    wipe(best)
    -- Best possible upgrades across SCANNED and CURRENTLY ACCESSIBLE dungeons only.
    -- A ring/trinket may need two copies; weapons need full set optimization:
    -- do NOT suppress alternative items in those categories.
    for _,name in ipairs(names) do best[name]={} end
    for dungeonID,scan in pairs(scans) do
        local quality=scanState(scan)
        -- Never let an UNKNOWN dungeon suppress a reliable wish elsewhere.
        if quality=="READY" or quality=="PROVISIONAL" then
                for itemID,members in pairs(scan.members) do
                    for _,name in ipairs(scanMembers(scan)) do
                        local r=members[name]
                        if r and (r.status=="UP" or r.status=="NEW") and r.slot
                                and roleRelevant(name,itemID) then
                            local group=r.slot
                            if group~="INVTYPE_FINGER" and group~="INVTYPE_TRINKET" and group~="WEAPON_SET" then
                                local previous=best[name][group]
                                local quality=(r.status=="UP" and r.pct and not isUnverifiedHigh(r) and r.pct)
                                    or (r.status=="NEW" and r.raw)
                                -- Do not rank unknown scores, and never compare a percentage
                                -- with a raw Pawn score. A slot can be NEW or already occupied.
                                if quality and quality>0 and (not previous
                                  or (previous.status==r.status and quality>previous.quality)) then
                                    best[name][group]={id=itemID,dungeonID=dungeonID,
                                        status=r.status,quality=quality}
                                end
                            end
                        end
                    end
                end
        end
    end
end
local function decision(name,id,d)
    local s=state()
    local pinned=s and s.pins[name][tostring(id)]
    local scan=scans[d.id]
    local group=scan and scan.members[id]
    local r=group and group[name]
    if not r then
        if scan and scan.finished then return pinned and "PIN?" or "NO REPLY",false end
        return pinned and "PIN?" or "",false
    end
    if HB.DungeonBiSView.IsSpecial(id,r) then return "SPECIAL",false end
    -- A partial group scan is shown for troubleshooting, but NEVER counted in dungeon ranking.
    if not scan.finished or scan.stale then
        if r.status=="UP" and type(r.pct)=="number" and r.pct>0 then
            return string.format("CHECK +%.0f%%",r.pct),false
        end
        local pending={NOSCALE="SET SCALE",NOSTATS="NO PAWN",NOGEAR="GEAR ?",
            UNCACHED="CACHE ?",VERIFY="VERIFY",NEEDPAIR="NEEDS OH",FUTURE="LV"..tostring(r.required or "?"),NEW="CHECK NEW"}
        return pending[r.status] or (pinned and "PIN?" or ""),false
    end
    local pair=scan.pairByItem and scan.pairByItem[name] and scan.pairByItem[name][id]
    if pinned then
        if r.status=="FUTURE" then return "PIN-LV"..r.required,false end
        for _,toon in ipairs(scanMembers(scan)) do
            if not scan.levels[toon] or scan.levels[toon]<d.min then return "PIN-LOCK",false end
        end
        if pair then
            if pair.pct and pair.pct>REVIEW_PCT then
                return string.format("PIN VERIFY SET +%.0f%%",pair.pct),false
            end
            if pair.pct then return string.format("PIN SET +%.0f%%",pair.pct),true end
            return "PIN NEW SET",true
        end
        if isUnverifiedHigh(r) then
            return string.format("PIN VERIFY +%.0f%%",r.pct),false
        end
        if r.status=="UP" and r.pct and r.pct>0 then return string.format("PIN +%.0f%%",r.pct),true end
        if r.status=="NEW" then return "PIN NEW SLOT",true end
        return "PIN",true
    end
    if r.status=="FUTURE" then return "LV"..r.required,false end
    if (r.status=="UP" or r.status=="NEW") and not roleRelevant(name,id) then
        return itemRoleFit(id).." FIT",false
    end
    if pair then
        if pair.pct and pair.pct>REVIEW_PCT then
            return string.format("VERIFY SET +%.0f%%",pair.pct),false
        end
        if pair.pct then return string.format("SET +%.0f%%",pair.pct),true end
        return "NEW SET",true
    end
    if r.status=="NEW" then
        local preferred=best[name] and best[name][r.slot]
        if preferred and (preferred.id~=id or preferred.dungeonID~=d.id) then return "REPLACED",false end
        return "NEW SLOT",true
    end
    local diagnostic={NOSCALE="SET SCALE",NOSTATS="NO PAWN",NOGEAR="GEAR ?",
        UNCACHED="CACHE ?",VERIFY="VERIFY",NEEDPAIR="NEEDS OH"}
    if diagnostic[r.status] then return diagnostic[r.status],false end
    if r.status~="UP" or type(r.pct)~="number" or r.pct<=0 then return "",false end
    if isUnverifiedHigh(r) then
        return string.format("VERIFY +%.0f%%",r.pct),false
    end
    for _,toon in ipairs(scanMembers(scan)) do
        if not scan.levels[toon] or scan.levels[toon]<d.min then return "LOCKED",false end
    end
    if r.slot~="INVTYPE_FINGER" and r.slot~="INVTYPE_TRINKET" and r.slot~="WEAPON_SET" then
        local preferred=best[name] and best[name][r.slot]
        if preferred and (preferred.id~=id or preferred.dungeonID~=d.id) then return "REPLACED",false end
    end
    return string.format("+%.0f%%",r.pct),true
end
local function scoreDungeon(d)
    local scan=scans[d.id]
    if not scoreable(scan) then return nil,0,0,0 end
    local total,count,peak,qualitative=0,0,0,0
    local strongestWeapons={}
    local countedPair={}
    for itemID,members in pairs(scan.members) do
        for _,name in ipairs(scanMembers(scan)) do
            local desc,good=decision(name,itemID,d)
            if good and not roleRelevant(name,itemID) then good=false end
            local r=members[name]
            local pair=scan.pairByItem and scan.pairByItem[name] and scan.pairByItem[name][itemID]
            if good and r and r.status=="UP" and r.pct and r.pct>0 then
                if r.slot=="WEAPON_SET" then
                    strongestWeapons[name]=math.max(strongestWeapons[name] or 0,r.pct)
                else
                    total=total+r.pct;count=count+1
                    peak=math.max(peak,r.pct)
                end
            elseif good and r and r.status=="NEW" and not pair then
                qualitative=qualitative+1
            end
            if good and pair and not countedPair[name] then
                countedPair[name]=true
                if pair.pct then
                    strongestWeapons[name]=math.max(strongestWeapons[name] or 0,pair.pct)
                else
                    qualitative=qualitative+1
                end
            end
        end
    end
    for _,n in pairs(strongestWeapons) do
        if n>0 then total=total+n;count=count+1;peak=math.max(peak,n) end
    end
    return total,count,peak,qualitative
end
-- Normalize CONFIRMED increases across different characters and equipment slots.
-- One item per slot (two for rings/trinkets) counts; this prevents ten drops for
-- a single slot from counting ten times. 100 * pct/(100+pct) approaches 100,
-- so a huge ratio cannot dominate every other potential upgrade.
-- NEW SLOT has no trustworthy percent; it is shown separately, not invented.
local function gearIndex(d)
    local scan=scans[d.id]
    if not scoreable(scan) then return nil,0 end
    local eligible={}
    for _,name in ipairs(scanMembers(scan)) do eligible[name]={} end
    local pairCounted={}
    local function offer(name,slot,pct)
        if not pct or pct<=0 then return end
        local group=eligible[name]
        if not group[slot] then group[slot]={} end
        group[slot][#group[slot]+1]=pct
    end
    for id,members in pairs(scan.members) do
        for _,name in ipairs(scanMembers(scan)) do
            local _,good=decision(name,id,d)
            if good and not roleRelevant(name,id) then good=false end
            local r=members[name]
            if good and r and r.status=="UP" and r.slot then
                if not isUnverifiedHigh(r) then offer(name,r.slot,r.pct) end
            end
            local pair=scan.pairByItem and scan.pairByItem[name]
                and scan.pairByItem[name][id]
            if good and pair and not pairCounted[name] then
                pairCounted[name]=true
                offer(name,"WEAPON_SET",pair.pct)
            end
        end
    end
    local index,opportunities=0,0
    for _,name in ipairs(scanMembers(scan)) do
        for slot,values in pairs(eligible[name]) do
            table.sort(values,function(a,b) return a>b end)
            local limit=(slot=="INVTYPE_FINGER" or slot=="INVTYPE_TRINKET") and 2 or 1
            for i=1,math.min(limit,#values) do
                index=index+100*values[i]/(100+values[i])
                opportunities=opportunities+1
            end
        end
    end
    return index,opportunities
end
-- Only confirmed Pawn upgrades enter the ranked utility; unresolved rows
-- have explicit reasons, not invented zero scores.
local function validUpgrade(scan,id,name,ignoreHeuristicRoleFit)
    if not scan or not scan.finished or scan.stale then return nil end
    local r=scan.members[id] and scan.members[id][name]
    -- Run Guide uses the actual character's selected Pawn scale, not the
    -- additional heuristic role-fit filter used by the older ranked planner.
    -- A heuristic must never silently hide an upgrade that Pawn identified.
    if not r or (not ignoreHeuristicRoleFit and not roleRelevantAuto(name,id))
        or not r.level or not r.required then return nil end
    -- An item from a dungeon above the active player's level is future loot
    -- even when the ITEM itself has a lower minimum equip level.
    local levelGate=math.max(r.required,scan.dungeon.min or 0)
    if levelGate>r.level then
        if (r.status=="FUP" or r.status=="UP") and type(r.pct)=="number" and r.pct>0
                and not isUnverifiedHigh(r) then
            return r.pct,r.slot,false,false,true,levelGate
        end
        if r.status=="FNEW" or r.status=="NEW" then
            return nil,r.slot,false,true,true,levelGate
        end
        return nil
    end
    if r.status=="UP" and type(r.pct)=="number" and r.pct>0
            and not isUnverifiedHigh(r) then return r.pct,r.slot,false end
    local pair=scan.pairByItem and scan.pairByItem[name] and scan.pairByItem[name][id]
    if pair and pair.pct and pair.pct>0 and pair.pct<=REVIEW_PCT then
        return pair.pct,"WEAPON_SET",true
    end
    if r.status=="NEW" then return nil,r.slot,false,true end
    return nil
end
-- Need priority is per ITEM, not a personal loot wish list: exactly one winner
-- after every relevant active client has a comparable, reliable Pawn result.
-- A missing winner exposes a reason on the item row instead of silently hiding it.
-- Priority is intentionally distinct from the weighted dungeon SCORE.
-- A verified Tank upgrade beats Healer, who beats all DPS; among DPS the
-- highest verified percentage wins, ties use fixed party order Elya/Nyra/Ayla.
-- We require reliable results for everyone who could outrank the recipient,
-- but a different boss's provisional state must not hide a verified item dice.
local function priorityForItem(scan,id)
    if not scan or not scan.finished or scan.stale or scan.missingGroup then
        return nil,"UNVERIFIED","The relevant party scan is not complete."
    end
    local function candidate(name)
        local r=scan.members[id] and scan.members[id][name]
        if not r then return nil,"UNVERIFIED",name..": no Pawn result for this item" end
        if not r.level or not scan.levels[name] or r.level~=scan.levels[name] then
            return nil,"UNVERIFIED",name..": character level unknown or changed"
        end
        if r.level < (scan.dungeon.min or 0) then return nil,"NOUP" end
        if HB.DungeonBiSView.IsSpecial(id,r) then return nil,"SPECIAL" end
        if r.status=="NOUP" or r.status=="UNUSABLE" or r.status=="OWNED"
                or r.status=="FNOUP" or r.status=="FUTURE" then
            return nil,"NOUP"
        end
        if r.status=="NEW" or r.status=="FNEW" then
            return nil,"UNVERIFIED",name..": EMPTY has no comparable Pawn increase"
        end
        if r.status=="UP" or r.status=="FUP" or r.status=="NEEDPAIR" then
            local pct,_,_,_,future=validUpgrade(scan,id,name,true)
            if future then return nil,"NOUP" end
            if type(pct)=="number" and pct>0 then return pct,"UP" end
            return nil,"UNVERIFIED",name..": Pawn/set score is not verified"
        end
        return nil,"UNVERIFIED",name..": unresolved "..tostring(r.status or "NO RESULT")
    end
    -- The priority is evaluated from highest role to lowest. An unresolved
    -- higher-priority result blocks an unsafe award to a lower-priority member.
    for _,name in ipairs({"Mael","Lyra"}) do
        local pct,status,detail=candidate(name)
        if status=="UNVERIFIED" then return nil,status,detail end
        if pct then return name,nil,nil end
    end
    local bestName,bestPct
    for _,name in ipairs({"Elya","Nyra","Ayla"}) do
        local pct,status,detail=candidate(name)
        if status=="UNVERIFIED" then return nil,status,detail end
        -- Strict > keeps original team order on an exactly tied Pawn increase.
        if pct and (not bestPct or pct>bestPct+0.000001) then
            bestName,bestPct=name,pct
        end
    end
    if bestName then return bestName,nil,nil end
    return nil,"NOUP","No verified Need recipient for this item"
end
local function advisorStats(d)
    local existing=advisorCache[d.id]
    if existing then return existing end
    local result={rows={},byBoss={},count=0,currentCount=0,bossItemCount=0,
        qualitative=0,roles={tank=0,heal=0,dps=0},coverage={},
        score=nil,scoreProvisional=false,quality="NOT SCANNED",unknown=0,futureCount=0}
    local scan=scans[d.id]
    if not scan or not scan.finished then return result end
    result.quality=scanState(scan)
    if scan.stale then result.quality="INCOMPLETE" end
    local unknownCodes={UNCACHED=true,NOSCALE=true,NOSTATS=true,NOGEAR=true,VERIFY=true,NEEDPAIR=true}
    local slotBest={}
    local countedNeeds={}
    local scoreSeen={}
    local distinctBossItems={}
    for _,name in ipairs(scanMembers(scan)) do slotBest[name]={} end
    for _,boss in ipairs(bossesFor(d)) do
        local rows={}
        for _,id in ipairs(scan.bossItems[boss.index] or {}) do
            distinctBossItems[id]=true
            local winner,priorityCode,priorityDetail=priorityForItem(scan,id)
            local itemRows={}
            for _,name in ipairs(scanMembers(scan)) do
                local member=scan.members[id] and scan.members[id][name]
                if member and unknownCodes[member.status]
                    and not HB.DungeonBiSView.IsSpecial(id,member) then
                    result.unknown=result.unknown+1
                end
                local pct,slot,isPair,isNew,isFuture,requiredLevel=validUpgrade(scan,id,name)
                if pct or isNew then
                    local row={id=id,name=name,pct=pct,slot=slot,pair=isPair,
                        qualitative=isNew,future=isFuture,required=requiredLevel,
                        need=(not isFuture and name==winner),boss=boss.index}
                    itemRows[#itemRows+1]=row
                    local key=name..":"..id
                    -- Distinct item/character NEED, not distinct item IDs. A repeat
                    -- encounter entry must never inflate the dungeon overview.
                    if not countedNeeds[key] then
                        countedNeeds[key]=true
                        result.count=result.count+1
                        result.coverage[name]=true
                        if isFuture then result.futureCount=result.futureCount+1
                        else result.currentCount=result.currentCount+1 end
                        local role=roles[name]
                        local bucket=role=="feral" and "tank" or role=="restoration" and "heal" or "dps"
                        result.roles[bucket]=result.roles[bucket]+1
                        if isNew and not isFuture then result.qualitative=result.qualitative+1 end
                    end
                    if pct and slot and not isFuture and not scoreSeen[key] then
                        scoreSeen[key]=true
                        local list=slotBest[name][slot]
                        if not list then list={};slotBest[name][slot]=list end
                        if not (isPair and list._pairs and list._pairs[pct]) then
                            list[#list+1]=pct
                        end
                        if isPair then
                            list._pairs=list._pairs or {};list._pairs[pct]=true
                        end
                    end
                elseif member and unknownCodes[member.status] and roleRelevantAuto(name,id)
                    and not HB.DungeonBiSView.IsSpecial(id,member) then
                    -- The unexplained item is visible and auditable, but NEVER
                    -- counted as a confirmed loot need or numeric Pawn score.
                    itemRows[#itemRows+1]={id=id,name=name,diagnostic=member.status,
                        prioDetail=name..": "..member.status.." ("..tostring(member.why or "no detail")..")",
                        boss=boss.index}
                end
            end
            -- One diagnosis per distinct item, not a fake dice for each Druid.
            if not winner and #itemRows>0 then
                itemRows[1].prioCode=priorityCode or "CHECK?"
                itemRows[1].prioDetail=priorityDetail or itemRows[1].prioDetail or "Need priority is unverified."
            end
            for _,row in ipairs(itemRows) do
                rows[#rows+1]=row
                result.rows[#result.rows+1]=row
            end
        end
        if #rows>0 then result.byBoss[boss.index]=rows end
    end
    for _ in pairs(distinctBossItems) do result.bossItemCount=result.bossItemCount+1 end
    -- Capped, per-slot confirmed Pawn gain. A partially unknown dungeon can
    -- still show a CLEARLY MARKED provisional relative ranking from verified
    -- upgrades; unknown stats never silently count as zero.
    local utility=0
    for _,name in ipairs(scanMembers(scan)) do
        for slot,values in pairs(slotBest[name]) do
            table.sort(values,function(a,b) return a>b end)
            local limit=(slot=="INVTYPE_FINGER" or slot=="INVTYPE_TRINKET") and 2 or 1
            for k=1,math.min(limit,#values) do
                utility=utility+100*values[k]/(100+values[k])
            end
        end
    end
    if utility>0 then
        result.score=utility
        result.scoreProvisional=(result.quality~="READY" and result.quality~="PROVISIONAL")
    end
    advisorCache[d.id]=result
    return result
end
local function rebuildVisible()
    wipe(visibleDungeons)
    -- SCAN is the only source of target dungeons. Never list unrelated
    -- instances (or pretend an unscanned instance has no upgrades).
    HB.BuildDungeonBiS()
    local cache=HB.DungeonBiSView.cache
    local ranked=cache and cache.byDungeon or {}
    local lowest=(allScan and allScan.minLevel) or tonumber(UnitLevel("player")) or 0
    for _,d in ipairs(dungeons) do
        local bucket=ranked[d.id]
        if d.min<=lowest and bucket and bucket.count>0 then
            visibleDungeons[#visibleDungeons+1]=d
        end
    end
    table.sort(visibleDungeons,function(a,b)
        local ba,bb=ranked[a.id],ranked[b.id]
        if ba.priority~=bb.priority then return ba.priority>bb.priority end
        if ba.uniqueCount~=bb.uniqueCount then return ba.uniqueCount>bb.uniqueCount end
        if a.min~=b.min then return a.min<b.min end
        return a.id<b.id
    end)
    local perPage=HB.DungeonBiSView.dungeonPageSize or 12
    dungeonPage=math.max(1,math.min(dungeonPage,math.max(1,#visibleDungeons-perPage+1)))
    return #visibleDungeons
end

local function label(parent,text,x,y,w,large)
    local t=parent:CreateFontString(nil,"OVERLAY",large and "GameFontNormal" or "GameFontHighlightSmall")
    t:SetPoint("TOPLEFT",parent,"TOPLEFT",x,y);t:SetWidth(w)
    t:SetJustifyH("LEFT");t:SetText(text or "")
    return t
end
local function button(parent,text,x,y,w,h,fn)
    local b=CreateFrame("Button",nil,parent,"UIPanelButtonTemplate")
    b:SetSize(w,h);b:SetPoint("TOPLEFT",parent,"TOPLEFT",x,y);b:SetText(text)
    b:SetScript("OnClick",fn)
    if HB.MenuStyle then HB.MenuStyle.Button(b,"blue") end
    return b
end
local function btnState(b,mode)
    if HB.MenuStyle then HB.MenuStyle.Button(b,mode or "blue") end
end
-- HF26.20.23 DUNGEON BIS. A user-visible, conservative objective list:
-- across every completed *accessible* AtlasLoot dungeon scan, choose the top
-- usable Pawn-valued drop on each participant's own scale. Never extrapolate
-- outside scanned AtlasLoot drops or count a future-level item as wearable.
-- Source is a dungeon + boss; unknown/stale/partial scans are not proof of BiS.
do
local bisSlotOrder={"INVTYPE_HEAD","INVTYPE_NECK","INVTYPE_SHOULDER",
    "INVTYPE_CHEST","INVTYPE_WAIST","INVTYPE_LEGS","INVTYPE_FEET",
    "INVTYPE_WRIST","INVTYPE_HAND","INVTYPE_FINGER","INVTYPE_TRINKET",
    "INVTYPE_CLOAK","BIS_TWO","BIS_MAIN","BIS_OFF","INVTYPE_BODY"}
local bisSlotNames={INVTYPE_HEAD="Head",INVTYPE_NECK="Neck",INVTYPE_SHOULDER="Shoulder",
    INVTYPE_CHEST="Chest",INVTYPE_WAIST="Waist",INVTYPE_LEGS="Legs",
    INVTYPE_FEET="Feet",INVTYPE_WRIST="Wrist",INVTYPE_HAND="Hands",
    INVTYPE_FINGER="Ring",INVTYPE_TRINKET="Trinket",INVTYPE_CLOAK="Back",
    BIS_TWO="2H set",BIS_MAIN="1H set",BIS_OFF="Off-hand set",INVTYPE_BODY="Shirt"}
local function bisSlot(inv)
    if inv=="INVTYPE_ROBE" then return "INVTYPE_CHEST" end
    if inv=="INVTYPE_2HWEAPON" then return "BIS_TWO" end
    if inv=="INVTYPE_WEAPON" or inv=="INVTYPE_WEAPONMAINHAND" then return "BIS_MAIN" end
    if inv=="INVTYPE_HOLDABLE" then return "BIS_OFF" end
    return bisSlotNames[inv] and inv or nil
end
local function bisScanSummary()
    local level=(allScan and allScan.minLevel) or (tonumber(UnitLevel("player")) or 0)
    local scanned,eligible,unknown,pending,stale=0,0,0,0,0
    for _,d in ipairs(dungeons) do
        if d.min<=level then
            eligible=eligible+1
            local scan=scans[d.id]
            if not scan or not scan.finished then pending=pending+1
            elseif scan.stale or scan.incomplete or scan.missingGroup then stale=stale+1
            else
                local quality=scanState(scan)
                if quality=="READY" or quality=="PROVISIONAL" or quality=="UNKNOWN" then
                    scanned=scanned+1
                    if quality~="READY" then unknown=unknown+1 end
                else stale=stale+1 end
            end
        end
    end
    return level,scanned,eligible,unknown,pending,stale
end
function HB.BuildDungeonBiS()
    if HB.DungeonBiSView.cache then return HB.DungeonBiSView.cache.entries,HB.DungeonBiSView.cache.summary end
    local level,scanned,eligible,unknown,pending,stale=bisScanSummary()
    local buckets={}
    local covered={}
    local participants=activeNames
    for _,name in ipairs(participants) do buckets[name]={};covered[name]=0 end
    for _,d in ipairs(dungeons) do
        local scan=scans[d.id]
        if d.min<=level and scan and scan.finished and not scan.stale
            and not scan.incomplete and not scan.missingGroup then
            local quality=scanState(scan)
            if quality=="READY" or quality=="PROVISIONAL" or quality=="UNKNOWN" then
                local members={}
                for _,name in ipairs(scanMembers(scan)) do members[name]=true end
                for _,name in ipairs(participants) do
                    if members[name] and scan.levels[name] and scan.levels[name]>=d.min then
                        covered[name]=covered[name]+1
                    end
                end
                for _,boss in ipairs(bossesFor(d)) do
                    for _,id in ipairs(scan.bossItems[boss.index] or {}) do
                        local membersForItem=scan.members[id] or {}
                        local _,_,_,_,_,_,_,_,inv=info(id)
                        local group=bisSlot(inv)
                        if group then
                            for _,name in ipairs(participants) do
                                local r=members[name] and membersForItem[name] or nil
                                -- No absent follower, unchecked role heuristics or future gear.
                                if r and tonumber(r.required) and tonumber(r.level)
                                        and r.required<=r.level and r.level>=d.min then
                                    local pct,slot,_,isNew,isFuture=validUpgrade(scan,id,name,true)
                                    if not isFuture and (pct or isNew) and slot==r.slot then
                                        local isWeapon=group=="BIS_TWO" or group=="BIS_MAIN" or group=="BIS_OFF"
                                        local locked=(group=="BIS_TWO" and r.why=="LOCK_TWO")
                                            or ((group=="BIS_MAIN" or group=="BIS_OFF")
                                                and (r.why=="LOCK_ONE" or r.why=="BAG_PAIR"))
                                        local score
                                        if isWeapon then
                                            -- A verified SAME-DUNGEON pair must be rated as a
                                            -- COMPLETE set. Never rank the standalone 1H raw score.
                                            local pair=scan.pairByItem and scan.pairByItem[name]
                                                and scan.pairByItem[name][id]
                                            if pair and type(pair.raw)=="number" and pair.raw>0
                                                and type(pair.pct)=="number" and pair.pct>0 then
                                                score=pair.raw
                                            elseif locked and type(r.baseline)=="number" and r.baseline>0
                                                and type(pct)=="number" and pct>0 then
                                                score=r.baseline*(1+pct/100)
                                            end
                                        elseif type(r.raw)=="number" and r.raw>0 then
                                            -- Raw is comparable only within one character's
                                            -- Pawn scale and the SAME ordinary equipment slot.
                                            score=r.raw
                                        end
                                        if score and score>0 then
                                            local groupBucket=buckets[name][group]
                                            if not groupBucket then groupBucket={};buckets[name][group]=groupBucket end
                                            local existing=groupBucket[id]
                                            if not existing then
                                                local pair=scan.pairByItem and scan.pairByItem[name]
                                                    and scan.pairByItem[name][id]
                                                existing={id=id,name=name,group=group,pct=pct,
                                                    pairNeeded=pair and true or false,
                                                    new=isNew,score=score,dungeon=d.name,boss=boss.name,
                                                    sources={},locations={},uncertain=quality~="READY"}
                                                groupBucket[id]=existing
                                            elseif score>existing.score+0.00001 then
                                                existing.score=score;existing.pct=pct;existing.new=isNew
                                                existing.dungeon=d.name;existing.boss=boss.name
                                            end
                                            local source=d.name.." - "..boss.name
                                            local found=false
                                            for _,v in ipairs(existing.sources) do if v==source then found=true;break end end
                                            if not found then
                                                existing.sources[#existing.sources+1]=source
                                                existing.locations[#existing.locations+1]={dungeonID=d.id,
                                                    bossIndex=boss.index,bossName=boss.name,dungeonName=d.name}
                                            end
                                            if quality~="READY" then existing.uncertain=true end
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
    local entries,targets,byDungeon={},0,{}
    local questionable=pending>0 or stale>0 or unknown>0 or scanned<eligible
    -- A single-client scan is never a certified five-Druid result.
    for _,name in ipairs(participants) do
        if covered[name]<scanned then questionable=true end
    end
    for _,name in ipairs(participants) do
        local rows={}
        for _,group in ipairs(bisSlotOrder) do
            local candidates={}
            for _,candidate in pairs(buckets[name][group] or {}) do
                candidates[#candidates+1]=candidate
            end
            table.sort(candidates,function(a,b)
                if math.abs(a.score-b.score)>0.00001 then return a.score>b.score end
                return a.id<b.id
            end)
            -- One certified best target per character/slot. A second ring or
            -- trinket cannot be certified jointly with existing Pawn replies;
            -- don't clutter the farm list with a speculative second target.
            local limit=1
            for i=1,math.min(#candidates,limit) do
                local c=candidates[i]
                c.slotLabel=(bisSlotNames[group] or group)..(c.pairNeeded and " [PAIR]" or "")
                    ..(i>1 and " 2?" or "")
                c.second=i>1
                local scanForSource=scans[(c.locations[1] and c.locations[1].dungeonID) or ""]
                local needWinner=scanForSource and priorityForItem(scanForSource,c.id)
                local target={id=c.id,name=name,pct=c.pct,slot=group,
                    need=(name==needWinner),
                    bis=true,bisSlot=c.slotLabel,bisDungeon=c.dungeon,bisBoss=c.boss,
                    bisSources=c.sources,bisNew=c.new,bisSecond=false,bisPair=c.pairNeeded,
                    -- A validated Pawn item score is NOT invalidated because
                    -- another dungeon/item in the global scan is provisional.
                    -- Keep coverage distinct for diagnosis and BiS-certification.
                    bisUncertain=false,bisCoverageUncertain=questionable or c.uncertain}
                rows[#rows+1]=target
                targets=targets+1
                -- Every source containing the winning item contributes ONE
                -- farm objective for this character and physical gear slot.
                -- A repeated loot entry from two bosses does not double the
                -- dungeon objective count, but both bosses remain actionable.
                for _,src in ipairs(c.locations or {}) do
                    local bucket=byDungeon[src.dungeonID]
                    if not bucket then
                        bucket={count=0,uniqueCount=0,priority=0,
                            roleCounts={tank=0,heal=0,dps=0},uniqueNeeds={},
                            byBoss={},seen={},dungeonName=src.dungeonName}
                        byDungeon[src.dungeonID]=bucket
                    end
                    local objectiveKey=name..":"..group..":"..tostring(c.id)
                    if not bucket.seen[objectiveKey] then
                        bucket.count=bucket.count+1;bucket.seen[objectiveKey]=true
                        local physical=bucket.uniqueNeeds[c.id]
                        if not physical then physical={};bucket.uniqueNeeds[c.id]=physical end
                        local role=roles[name]
                        local kind=role=="feral" and "tank" or role=="restoration" and "heal" or "dps"
                        physical[kind]=true
                    end
                    local bossList=bucket.byBoss[src.bossIndex]
                    if not bossList then bossList={};bucket.byBoss[src.bossIndex]=bossList end
                    local exists=false
                    for _,old in ipairs(bossList) do
                        if old.id==target.id and old.name==target.name and old.slot==target.slot then
                            exists=true;break
                        end
                    end
                    if not exists then
                        local sourceWinner=priorityForItem(scans[src.dungeonID],c.id)
                        local sourceTarget={}
                        for k,v in pairs(target) do sourceTarget[k]=v end
                        sourceTarget.need=sourceWinner==name
                        bossList[#bossList+1]=sourceTarget
                    end
                end
            end
        end
        entries[#entries+1]={heading=string.format("%s | %d best target%s%s",name,#rows,
            #rows==1 and "" or "s",covered[name]==0 and " | NOT SCANNED" or "")}
        if #rows>0 then
            for _,row in ipairs(rows) do entries[#entries+1]=row end
        else
            entries[#entries+1]={bisEmpty=true,name=name,
                missing=(covered[name]==0),uncertain=questionable}
        end
    end
    -- Unique item IDs are the physical loot opportunities in each dungeon.
    -- The same drop needed by five Druids contributes ONCE to priority.
    -- Role counters are independent: one item can help more than one role,
    -- but its PRIORITY uses only the highest applicable role weight.
    -- Tank=3, Healer=2, DPS=1. No unknown/provisional score is invented.
    for _,bucket in pairs(byDungeon) do
        for _,need in pairs(bucket.uniqueNeeds) do
            bucket.uniqueCount=bucket.uniqueCount+1
            if need.tank then bucket.roleCounts.tank=bucket.roleCounts.tank+1 end
            if need.heal then bucket.roleCounts.heal=bucket.roleCounts.heal+1 end
            if need.dps then bucket.roleCounts.dps=bucket.roleCounts.dps+1 end
            bucket.priority=bucket.priority+(need.tank and 3 or need.heal and 2 or 1)
        end
    end
    local summary=string.format("%d targets | %d/%d accessible dungeons checked | %s",
        targets,scanned,eligible,questionable and "PROVISIONAL: incomplete/unknown data" or "scanned-dungeon coverage OK")
    HB.DungeonBiSView.cache={entries=entries,summary=summary,byDungeon=byDungeon,
        party=copyList(participants),provisional=questionable}
    return entries,summary
end
function HB.DungeonBiSForDungeon(dungeonID)
    HB.BuildDungeonBiS()
    local cached=HB.DungeonBiSView.cache
    return cached and cached.byDungeon and cached.byDungeon[dungeonID] or nil
end
end -- local BiS helpers scoped away; protect WoW Lua 200-local chunk cap.
local function detailEntries(d)
    local entries={}
    if not d then return entries end
    local stats=advisorStats(d)
    local scan=scans[d.id]
    local ordinal=0
    for _,boss in ipairs(bossesFor(d)) do
        local rows=stats.byBoss[boss.index] or {}
        local contents={}
        if showAllLoot then
            local indexed={}
            for _,r in ipairs(rows) do
                if not indexed[r.id] then indexed[r.id]={} end
                indexed[r.id][#indexed[r.id]+1]=r
            end
            for _,id in ipairs(scan and scan.bossItems[boss.index] or rawDrops(d,boss.index)) do
                if indexed[id] then
                    for _,r in ipairs(indexed[id]) do contents[#contents+1]=r end
                else contents[#contents+1]={id=id,unranked=true,pending=not (scan and scan.finished)} end
            end
        else
            contents=rows
        end
        if #contents>0 then
            ordinal=ordinal+1
            entries[#entries+1]={heading=ordinal..". "..pretty(boss.name,67)}
            for _,r in ipairs(contents) do entries[#entries+1]=r end
        end
    end
    return entries
end
function HB.DungeonBiSEntriesForView()
    local rows={}
    if not chosen then return rows end
    local farm=HB.DungeonBiSForDungeon(chosen.id)
    if not farm then return rows end
    local db=state()
    local collapsed=db and db.advisorCollapsed and db.advisorCollapsed[chosen.id] or {}
    for _,boss in ipairs(bossesFor(chosen)) do
        local targets=farm.byBoss[boss.index]
        if targets and #targets>0 then
            local expanded=collapsed[boss.index]~=true
            rows[#rows+1]={heading=boss.name,headingBoss=boss.index,
                headingCount=#targets,headingExpanded=expanded}
            if expanded then
                for _,target in ipairs(targets) do rows[#rows+1]=target end
            end
        end
    end
    local scan=scans[chosen.id]
    local specials={}
    for id,members in pairs(scan and scan.members or {}) do
        for _,name in ipairs(scanMembers(scan)) do
            if HB.DungeonBiSView.IsSpecial(id,members[name]) then specials[id]=true;break end
        end
    end
    local ids={}
    for id in pairs(specials) do ids[#ids+1]=id end
    table.sort(ids)
    if #ids>0 then
        rows[#rows+1]={heading="SPECIAL EFFECTS · MANUAL REVIEW"}
        for _,id in ipairs(ids) do rows[#rows+1]={id=id,bisSpecial=true} end
    end
    return rows
end
local ICON_TANK="Interface\\Icons\\Ability_Warrior_DefensiveStance"
local ICON_HEAL="Interface\\Icons\\Spell_Holy_HolyBolt"
local ICON_DPS="Interface\\Icons\\Ability_DualWield"
local ICON_NEED="Interface\\Buttons\\UI-GroupLoot-Dice-Up"
local ICON_PAWN="Interface\\AddOns\\Pawn\\Textures\\UpgradeArrow"
-- HF26.20.42: AtlasLoot-like compact quality outline on the EXISTING
-- native item icon; item text keeps Blizzard rarity colors and the approved
-- native tooltip/ALT-hover behavior. Never changes item data or Pawn ratings.
function HB.DungeonBiSView.StyleLootIcon(holder,quality)
    if not holder then return end
    if not holder.hbQualityEdges then
        holder.hbQualityEdges={}
        for _,edge in ipairs({"TOP","BOTTOM","LEFT","RIGHT"}) do
            local t=holder:CreateTexture(nil,"OVERLAY")
            if edge=="TOP" then
                t:SetPoint("TOPLEFT",holder,"TOPLEFT",0,0)
                t:SetPoint("TOPRIGHT",holder,"TOPRIGHT",0,0)
                t:SetHeight(1)
            elseif edge=="BOTTOM" then
                t:SetPoint("BOTTOMLEFT",holder,"BOTTOMLEFT",0,0)
                t:SetPoint("BOTTOMRIGHT",holder,"BOTTOMRIGHT",0,0)
                t:SetHeight(1)
            elseif edge=="LEFT" then
                t:SetPoint("TOPLEFT",holder,"TOPLEFT",0,0)
                t:SetPoint("BOTTOMLEFT",holder,"BOTTOMLEFT",0,0)
                t:SetWidth(1)
            else
                t:SetPoint("TOPRIGHT",holder,"TOPRIGHT",0,0)
                t:SetPoint("BOTTOMRIGHT",holder,"BOTTOMRIGHT",0,0)
                t:SetWidth(1)
            end
            holder.hbQualityEdges[#holder.hbQualityEdges+1]=t
        end
    end
    local r,g,b=.45,.50,.55
    if type(quality)=="number" and type(GetItemQualityColor)=="function" then
        local cr,cg,cb=GetItemQualityColor(quality)
        if cr and cg and cb then r,g,b=cr,cg,cb end
    end
    for _,edge in ipairs(holder.hbQualityEdges) do
        edge:SetColorTexture(r,g,b,.96)
        edge:Show()
    end
end
-- HF26.20.43: only presentation data from WoW GetItemInfo. No new item
-- selection, filters or Pawn estimates. Original rarity colors remain native.
function HB.DungeonBiSView.ItemTypeLine(inv,itemType,itemSubType)
    local slots={INVTYPE_HEAD="Head",INVTYPE_NECK="Neck",INVTYPE_SHOULDER="Shoulder",
        INVTYPE_CHEST="Chest",INVTYPE_ROBE="Chest",INVTYPE_WAIST="Waist",
        INVTYPE_LEGS="Legs",INVTYPE_FEET="Feet",INVTYPE_WRIST="Wrist",
        INVTYPE_HAND="Hands",INVTYPE_FINGER="Ring",INVTYPE_TRINKET="Trinket",
        INVTYPE_CLOAK="Back",INVTYPE_2HWEAPON="Two-Hand",
        INVTYPE_WEAPON="One-Hand",INVTYPE_WEAPONMAINHAND="Main Hand",
        INVTYPE_HOLDABLE="Off Hand",INVTYPE_BODY="Shirt"}
    local a=slots[inv]
    local b=type(itemSubType)=="string" and itemSubType~="" and itemSubType or nil
    if a and b and a~=b and b~="Miscellaneous" then return a..", "..b end
    if a then return a end
    if b then return b end
    return type(itemType)=="string" and itemType or ""
end
local BLIZZARD_ROLE_TEXTURE="Interface\\LFGFrame\\UI-LFG-ICON-PORTRAITROLES"
local function roleIcon(parent,x,role,fallback)
    local t=parent:CreateTexture(nil,"OVERLAY")
    t:SetSize(15,15);t:SetPoint("LEFT",parent,"LEFT",x,0)
    local coords=GetTexCoordsForRoleSmallCircle or GetTexCoordsForRole
    local ok,a,b,c,d=false,nil,nil,nil,nil
    if type(coords)=="function" then ok,a,b,c,d=pcall(coords,role) end
    if ok and type(a)=="number" and type(b)=="number"
        and type(c)=="number" and type(d)=="number" then
        t:SetTexture(BLIZZARD_ROLE_TEXTURE)
        t:SetTexCoord(a,b,c,d)
    else
        -- Older clients without Blizzard's role atlas use the legacy icons,
        -- still without any duplicate T / H / D letters.
        t:SetTexture(fallback)
    end
    return t
end
local function smallText(parent,width,x,alignment)
    local t=parent:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
    t:SetPoint("LEFT",parent,"LEFT",x,0)
    t:SetWidth(width);t:SetJustifyH(alignment or "LEFT")
    return t
end
local function renderRow(row,entry)
    row.ItemID=nil
    row:SetScript("OnEnter",nil);row:SetScript("OnLeave",nil)
    row:SetScript("OnClick",nil)
    row.iconHitbox.ItemID=nil
    row.iconHitbox:Hide()
    row.itemSub:Hide()
    row.prioHitbox:Hide()
    row.needStatus:Hide()
    row:Show()
    if entry.heading then
        row.back:SetColorTexture(0.18,0.16,0.12,0.86)
        row.heading:SetText(entry.headingBoss and
            ((entry.headingExpanded and "v " or "> ")..entry.heading.." ("..tostring(entry.headingCount or 0)..")")
            or entry.heading)
        row.heading:Show()
        row.itemIcon:Hide();row.dice:Hide();row.arrow:Hide()
        row.itemName:SetText("");row.character:SetText("");row.percent:SetText("")
        if entry.headingBoss then
            row:Enable()
            row:SetScript("OnClick",function()
                if HB.DungeonBiSView.ToggleAdvisorBoss then
                    HB.DungeonBiSView.ToggleAdvisorBoss(entry.headingBoss)
                end
            end)
        else row:Disable() end
        return
    end
    if entry.bisEmpty then
        row:Disable();row.heading:Hide();row.itemIcon:Hide();row.dice:Hide();row.arrow:Hide()
        row.itemName:SetText(entry.missing and "NOT SCANNED" or "No verified upgrade")
        row.character:SetText("");row.percent:SetText(entry.uncertain and "UNVERIFIED" or "--")
        row.percent:SetTextColor(entry.uncertain and 1 or .7,entry.uncertain and .35 or .7,entry.uncertain and .36 or .7)
        row.back:SetColorTexture(0.08,0.10,0.14,0.45)
        return
    end
    row:Enable();row.heading:Hide()
    row.back:SetColorTexture(0.08,0.10,0.14,0.45)
    row.ItemID=entry.id
    row.iconHitbox.ItemID=entry.id
    local nm,link,quality,_,_,itemType,itemSubType,_,itemInv,texture=info(entry.id)
    if not nm then hydrate(entry.id);nm="Item #"..entry.id end
    row.itemIcon:SetTexture(texture or "Interface\\Icons\\INV_Misc_QuestionMark")
    row.itemIcon:SetTexCoord(.07,.93,.07,.93)
    row.itemIcon:Show()
    row.iconHitbox:Show()
    HB.DungeonBiSView.StyleLootIcon(row.iconHitbox,quality)
    -- Keep full AtlasLoot-style quality name; never prepend an equipment slot.
    row.itemName:SetText(pretty(nm,row.nameChars or 39))
    local itemTypeLine=HB.DungeonBiSView.ItemTypeLine(itemInv,itemType,itemSubType)
    row.itemSub:SetText(pretty(itemTypeLine,row.nameChars or 39))
    row.itemSub:SetShown(itemTypeLine~="")
    if entry.bis then
        row.character:SetText(entry.name or "")
        local druid=_G.RAID_CLASS_COLORS and _G.RAID_CLASS_COLORS.DRUID
        row.character:SetTextColor(druid and druid.r or 1,druid and druid.g or .49,druid and druid.b or .04)
        if entry.bisUncertain then
            row.percent:SetText("UNVERIFIED")
            row.percent:SetTextColor(1,.35,.36)
        elseif entry.pct then
            row.percent:SetText(string.format("+%d%%",math.floor(entry.pct+.5)))
            row.percent:SetTextColor(.30,.92,.45)
        else
            row.percent:SetText("EMPTY")
            row.percent:SetTextColor(.98,.77,.35)
        end
        row.dice:SetShown(entry.need==true and not entry.bisUncertain and not entry.bisSecond)
        row.arrow:SetShown(not entry.bisSecond)
        -- Item icon continues to use the original native item tooltip.
    end
    if quality and type(GetItemQualityColor)=="function" then
        local r,g,b=GetItemQualityColor(quality)
        row.itemName:SetTextColor(r or 1,g or 1,b or 1)
    else row.itemName:SetTextColor(.77,.80,.83) end
    if entry.bisSpecial then
        row.character:SetText("MANUAL")
        row.percent:SetText("SPECIAL")
        row.percent:SetTextColor(.98,.72,.37)
        row.dice:Hide();row.arrow:Hide()
        return
    end
    if entry.bis then return end
    row.dice:SetShown(entry.need==true)
    row.arrow:SetShown(not entry.unranked and not entry.diagnostic)
    if not entry.need and entry.prioCode then
        -- Priority/winner is unresolved; do not show a loot-need dice.
        -- The Pawn upgrade itself has already been validated separately.
        row.dice:Hide()
    end
    row.character:SetText(entry.name or "")
    local c=_G.RAID_CLASS_COLORS and _G.RAID_CLASS_COLORS.DRUID
    row.character:SetTextColor(c and c.r or 1,c and c.g or 0.49,c and c.b or 0.04)
    if entry.diagnostic then
        row.percent:SetText("UNVERIFIED")
        row.percent:SetTextColor(1,.35,.36)
    elseif entry.unranked then
        row.percent:SetText(entry.pending and "UNVERIFIED" or "—")
        if entry.pending then row.percent:SetTextColor(1,.35,.36)
        else row.percent:SetTextColor(.70,.71,.74) end
    elseif entry.future then
        row.percent:SetText(entry.required and ("LV"..tostring(entry.required)) or "UNVERIFIED")
        if entry.required then row.percent:SetTextColor(.98,.77,.35)
        else row.percent:SetTextColor(1,.35,.36) end
    else
        row.percent:SetText(entry.pct and string.format("+%.0f%%",entry.pct) or "EMPTY")
        if entry.pct then row.percent:SetTextColor(.30,.92,.45)
        else row.percent:SetTextColor(.98,.77,.35) end
    end
    -- A priority tie/cache issue must NEVER overwrite a separately verified
    -- positive Pawn score. The unresolved winner remains in chat diagnostics.
    -- Item tooltip ONLY on 24px item icon; the rest of the row is silent.
    -- The icon's tooltip uses CURSOR anchoring and the existing ALT + Hover
    -- Party Pawn hook without changing any LootHover.lua or approved layout.
end

local function scanCounts(job,short)
    local rows={}
    for _,name in ipairs(job and job.scan and job.scan.names or activeNames) do
        local count=0
        if job and job.scan and job.scan.members then
            for _,id in ipairs(job.queue) do
                if job.scan.members[id] and job.scan.members[id][name] then count=count+1 end
            end
        end
        rows[#rows+1]=(short and name:sub(1,1) or name).." "..count..(short and "" or ("/"..(job and #job.queue or 0)))
    end
    return table.concat(rows,short and "  " or "  ·  ")
end
local function recommended(d)
    if not d then return "?" end
    if d.recHigh and d.recHigh>d.rec then return d.rec.."-"..d.recHigh end
    return tostring(d.rec)
end
local function refresh()
    if runRefresh then runRefresh() end
    if not frame or not frame:IsShown() then return end
    local peak=rebuildVisible()
    if chosen then
        local keep=false
        for _,d in ipairs(visibleDungeons) do if d.id==chosen.id then keep=true;break end end
        if not keep then chosen=nil end
    end
    if not chosen and visibleDungeons[1] then chosen=visibleDungeons[1] end
    if HB.DungeonBiSView.header then
        HB.DungeonBiSView.header:SetText("BIS LOOT")
    end
    local _,summary=HB.BuildDungeonBiS()
    titleText:SetText("PARTY BIS")
    if chosen then
        local target=HB.DungeonBiSForDungeon(chosen.id)
        selectedSummary:SetText(pretty(chosen.name,32).." · "
            ..tostring(target and target.uniqueCount or 0).." items · "
            ..tostring(target and target.count or 0).." needs")
    else selectedSummary:SetText("No farm dungeon selected") end
    if HB.DungeonBiSView.coverageSummary then
        HB.DungeonBiSView.coverageSummary:SetText(summary:gsub(" accessible dungeons checked"," checked")
            :gsub("PROVISIONAL: incomplete/unknown data","PROVISIONAL"))
    end
    local reportUI=HB.DungeonBiSView.ui
    if reportUI and reportUI.summaryHitbox then reportUI.summaryHitbox.full=summary end
    local nameChars=math.max(9,math.min(25,
        math.floor(((reportUI and reportUI.farmNameWidth) or 160)/7)))
    for i,b in ipairs(dungeonButtons) do
        local d=i<=(HB.DungeonBiSView.dungeonPageSize or 12)
            and visibleDungeons[dungeonPage+i-1] or nil
        if d then
            local farm=HB.DungeonBiSForDungeon(d.id)
            b:Enable();b:Show();b:SetText("")
            b.labels[1]:SetText(pretty(d.name,nameChars))
            for j=2,8 do b.labels[j]:SetText("") end
            b.labels[4]:SetText(tostring(farm and farm.uniqueCount or 0))
            local rc=farm and farm.roleCounts or {}
            b.labels[5]:SetText(tostring(rc.tank or 0))
            b.labels[6]:SetText(tostring(rc.heal or 0))
            b.labels[7]:SetText(tostring(rc.dps or 0))
            b.priorityDetail=farm
            b.priorityDungeon=d.name
            b.priorityProvisional=HB.DungeonBiSView.cache
                and HB.DungeonBiSView.cache.provisional
            -- Plain numeric score. Ambiguous coverage is still retained for
            -- chat diagnostics; amber score is a subtle visual caution.
            b.labels[8]:SetText(tostring(farm and farm.priority or 0))
            if b.priorityProvisional then b.labels[8]:SetTextColor(.98,.78,.46)
            else b.labels[8]:SetTextColor(.90,.93,.95) end
            b.runButton.dungeon=d;b.runButton:Show()
            btnState(b,chosen==d and "green" or "neutral")
        else
            b:Disable();b:SetText("");b.priorityDetail=nil
            b.runButton.dungeon=nil;b.runButton:Hide()
            for _,text in ipairs(b.labels) do text:SetText("") end
            btnState(b,"disabled")
        end
    end
    pageText:SetText(string.format("Farm dungeons %d-%d / %d",#visibleDungeons>0 and dungeonPage or 0,
        math.min(dungeonPage+(HB.DungeonBiSView.dungeonPageSize or 12)-1,#visibleDungeons),#visibleDungeons))
    local entries=HB.DungeonBiSEntriesForView()
    local ui=HB.DungeonBiSView.ui
    if ui and ui.bossToggleAll then
        local hasBoss,anyOpen=false,false
        for _,entry in ipairs(entries) do
            if entry.headingBoss then
                hasBoss=true
                if entry.headingExpanded then anyOpen=true end
            end
        end
        ui.bossToggleAll:SetShown(hasBoss)
        ui.bossToggleAll:SetText(anyOpen and "COLLAPSE ALL" or "EXPAND ALL")
    end
    detailPage=math.max(1,math.min(detailPage,
        math.max(1,#entries-(HB.DungeonBiSView.detailPageSize or 16)+1)))
    for i,r in ipairs(detailRows) do
        local e=i<=(HB.DungeonBiSView.detailPageSize or 16)
            and entries[detailPage+i-1] or nil
        if e then renderRow(r,e) else r:Hide();r.ItemID=nil end
    end
    detailPageText:SetText(string.format("Loot %d-%d / %d",#entries>0 and detailPage or 0,
        math.min(detailPage+(HB.DungeonBiSView.detailPageSize or 16)-1,#entries),#entries))
    if ui then
        HB.DungeonBiSView.SetScrollbar(ui.farmScroll,dungeonPage,#visibleDungeons,
            HB.DungeonBiSView.dungeonPageSize or 12)
        HB.DungeonBiSView.SetScrollbar(ui.detailScroll,detailPage,#entries,
            HB.DungeonBiSView.detailPageSize or 16)
    end
    if allScan and allScan.running then
        statusText:SetText("SCANNING...")
    elseif allScan and allScan.finished then
        statusText:SetText("SCAN COMPLETE"..(HB.DungeonBiSView.cache
            and HB.DungeonBiSView.cache.provisional and " · UNVERIFIED" or ""))
    else
        statusText:SetText("READY")
    end
    for _,b in ipairs({availableScanButton,allScanButton}) do
        if b then
            if allScan and allScan.running then b:Disable();btnState(b,"disabled")
            else b:Enable();btnState(b,b==availableScanButton and "green" or "blue") end
        end
    end
end
-- One dungeon scan is a bounded job using the original, validated HBLP26 party
-- request/response protocol; the batch scheduler advances after each job.
startDungeonScan=function(target)
    if not target or scanJob then return end
    sequence=sequence+1
    local s={dungeon=target,scanID=sequence,bossItems={},members={},levels={},
        names=copyList(activeNames),missingGroup=allScan and ((allScan.unresponsive and #allScan.unresponsive>0)
            or (allScan.ignored and #allScan.ignored>0)),
        finished=false,stale=true,incomplete=false,weaponPairs={},pairByItem={},
        requestStats={sent=0,failed=0,skipped=0,byFollower={}}}
    local queue,seen={},{}
    s.prefilterSkipped=0;s.prefilterUncertain=0;s.reused=0;s.totalListed=0
    for _,boss in ipairs(bossesFor(target)) do
        local usable={}
        for _,id in ipairs(rawDrops(target,boss.index)) do
            s.totalListed=s.totalListed+1
            local possible,reason=HB.DungeonBiSView.possibleForParty(id,allScan and allScan.maxLevel)
            if possible then
                usable[#usable+1]=id
                if reason=="UNKNOWN" then s.prefilterUncertain=s.prefilterUncertain+1 end
                if not seen[id] then
                    queue[#queue+1]=id;seen[id]=true
                    hydrate(id)
                end
            else
                s.prefilterSkipped=s.prefilterSkipped+1
            end
        end
        s.bossItems[boss.index]=usable
    end
    -- Reuse only fully resolved results from THIS explicit party scan,
    -- with the same participating character and observed party level.
    -- All previous-scan cache is discarded by startAllScan; gear events wipe
    -- this cache and invalidate all previously completed dungeon rankings.
    if allScan and not allScan.invalidated then
        for _,id in ipairs(queue) do
            s.members[id]={}
            local cached=allScan.sharedResults and allScan.sharedResults[id]
            for _,name in ipairs(s.names) do
                local r=cached and cached[name]
                local partyLevel=allScan.partyLevels and allScan.partyLevels[name]
                if r and type(partyLevel)=="number" and partyLevel>0
                        and r.level==partyLevel then
                    s.members[id][name]=r;s.levels[name]=r.level
                    s.reused=s.reused+1
                end
            end
        end
    else
        for _,id in ipairs(queue) do s.members[id]={} end
    end
    s.queue=queue
    scans[target.id]=s;advisorCache[target.id]=nil;HB.DungeonBiSView.cache=nil
    if #queue==0 then
        s.finished=true;s.stale=false;s.incomplete=true
        if allScan then
            allScan.completed=allScan.completed+1
            allScan.uncertain=(allScan.uncertain or 0)+1
        end
        return
    end
    scanJob={id=sequence,dungeon=target,queue=queue,pos=1,memberPos=1,localDone=false,
        elapsed=0,scan=s,grace=0,pending={},retryQueue=nil,retryPos=1,
        retried=0,retryRounds=0,retrySkipped=0,retryFailed=0}
    lastScanCount=#queue
    refresh()
end

local function partyCandidates()
    local current=me()
    if not current then return nil,"This build supports only Team A characters" end
    local present={[current]=true}
    local ignored={}
    if IsInGroup and IsInGroup() then
        for i=1,4 do
            local unit="party"..i
            if UnitExists and UnitExists(unit) and (not UnitIsConnected or UnitIsConnected(unit)) then
                local fullname=UnitName(unit)
                local name=canonicalTeamName(fullname)
                if name then present[name]=true
                elseif fullname then ignored[#ignored+1]=tostring(fullname) end
            end
        end
    end
    local candidates={}
    for _,name in ipairs(names) do if present[name] then candidates[#candidates+1]=name end end
    return candidates,nil,ignored
end

local function activateResponders()
    local responsive={}
    local missing={}
    for _,name in ipairs(allScan.candidates or {"Mael"}) do
        if name=="Mael" or net.acks[name] then responsive[#responsive+1]=name
        else missing[#missing+1]=name end
    end
    activeNames=responsive
    allScan.unresponsive=missing
    allScan.probing=false
    local extra=(#missing>0) and ("; no reply from "..table.concat(missing,",")) or ""
    if #allScan.ignored>0 then extra=extra.."; unsupported classes: "..table.concat(allScan.ignored,",") end
    say("Scan team: "..table.concat(responsive,",")..extra)
    if #responsive==1 then evalCache={} end
end

startAllScan=function(scope, singleDungeon)
    if scanJob then return end
    if me()~="Mael" then say("Start full scan on Mael (Team A leader).");return end
    if allScan and allScan.running then return end
    if InCombatLockdown and InCombatLockdown() then
        say("Start outside combat.");return
    end
    local ok,msg=loadDungeons()
    if not ok then say(msg);if statusText then statusText:SetText(msg) end;return end
    local candidates,why,ignored=partyCandidates()
    if not candidates then say(why);if statusText then statusText:SetText(why) end;return end
    local lowest=tonumber(UnitLevel("player")) or 1
    local maxLevel=lowest
    local partyLevels={Mael=lowest}
    if IsInGroup and IsInGroup() then
        for i=1,4 do
            local unit="party"..i
            if UnitExists and UnitExists(unit)
                    and (not UnitIsConnected or UnitIsConnected(unit)) then
                local lvl=tonumber(UnitLevel(unit))
                if lvl and lvl>0 then
                    lowest=math.min(lowest,lvl)
                    maxLevel=math.max(maxLevel,lvl)
                    local name=canonicalTeamName(UnitName(unit))
                    if name then partyLevels[name]=lvl end
                end
            end
        end
    end
    -- A focused Run Guide scan uses the same trusted party probe and queue,
    -- but retains prior dungeon results and the large advisor's selection.
    local single=(type(singleDungeon)=="table" and type(singleDungeon.id)=="string")
    scope=single and "selected" or ((scope=="all") and "all" or "available")
    if not single then scanScope=scope end
    local targets={}
    if single then
        for _,d in ipairs(dungeons) do
            if d.id==singleDungeon.id then targets[1]=d;break end
        end
        if #targets==0 then say("Dungeon not found in AtlasLoot.");return end
    else
        for _,d in ipairs(dungeons) do
            if scope=="all" or d.min<=lowest then targets[#targets+1]=d end
        end
    end
    if not single then wipe(scans);wipe(advisorCache);wipe(best) end
    HB.DungeonBiSView.cache=nil
    wipe(evalCache)
    HB.LootUnique.inventoryMap=nil
    HB.LootUnique.tracked={}
    sequence=sequence+1
    allScan={running=true,finished=false,queue=targets,scope=scope,index=0,
        startedAt=type(GetTime)=="function" and GetTime() or nil,
        completed=0,skipped=0,minLevel=lowest,maxLevel=maxLevel,
        partyLevels=partyLevels,sharedResults={},invalidated=false,
        delay=0,candidates=candidates,ignored=ignored or {},unresponsive={},
        probing=#candidates>1,probeElapsed=0,probeResent=false}
    if allScan.probing then
        net.acks={};net.pingToken=sequence
        addonMessage("P|"..sequence.."|"..PROTOCOL)
    else
        net.acks={};net.pingToken=nil
        activateResponders()
    end
    if not single then dungeonPage=1;detailPage=1;chosen=nil end
    lastScanFeedback=nil
    say("Scanning "..#allScan.queue.." "
        ..(scope=="selected" and "selected" or (scope=="available" and "available" or "all"))
        .." AtlasLoot dungeons.")
    worker=worker or CreateFrame("Frame")
    worker:SetScript("OnUpdate",workerTick)
    refresh()
end

local function handleResult(name,jobID,itemID,status,pct,slot,required,lvl,raw,weaponBase,why,baseline)
    if not roster[name] or type(status)~="string" or not status:match("^[A-Z]+$") then return false end
    local scan
    if scanJob and jobID==scanJob.id then scan=scanJob.scan
    else
        -- Cache updates may arrive AFTER a finished scan. Only update the exact
        -- matching scan generation; never apply a stale reply to a newer scan.
        for _,candidate in pairs(scans) do
            if candidate.scanID==jobID and candidate.finished and not candidate.stale then
                scan=candidate;break
            end
        end
    end
    if not scan then return false,"UNKNOWN_SCAN" end
    if not scan.members[itemID] then return false,"UNEXPECTED_ITEM" end
    local included=false
    for _,member in ipairs(scanMembers(scan)) do if member==name then included=true;break end end
    if not included then return false,"UNEXPECTED_MEMBER" end
    local old=scan.members[itemID][name]
    -- Late UNCACHED packets must never overwrite a now-resolved cache value.
    if old and old.status~="UNCACHED" and status=="UNCACHED" then return false,"LATE_UNCACHED" end
    if old and old.status==status and old.pct==(pct>=0 and pct or nil)
       and old.raw==((raw and raw>=0) and raw or nil)
       and old.baseline==((baseline and baseline>=0) and baseline or nil)
       and old.why==why then return false,"DUPLICATE" end
    scan.members[itemID][name]={status=status,pct=pct>=0 and pct or nil,slot=slot,
        required=required,level=lvl,raw=(raw and raw>=0) and raw or nil,
        weaponBase=(weaponBase and weaponBase>=0) and weaponBase or nil,
        baseline=(baseline and baseline>=0) and baseline or nil,
        why=why}
    scan.levels[name]=lvl
    -- One item can drop in several dungeons. The Pawn evaluation is identical
    -- until equipment, level or lock changes, so keep completed replies in
    -- memory for the remaining dungeons of THIS scan (never across rescans).
    if allScan and allScan.running and not allScan.invalidated
            and not scan.invalidated and status~="UNCACHED"
            and not (status=="NOGEAR" and why=="BAG_PENDING")
            and allScan.partyLevels and allScan.partyLevels[name]==lvl then
        local shared=allScan.sharedResults[itemID]
        if not shared then shared={};allScan.sharedResults[itemID]=shared end
        shared[name]=scan.members[itemID][name]
    end
    if scan.finished then
        if scan.incomplete and scan.queue then
            local complete=true
            for _,qID in ipairs(scan.queue) do
                for _,member in ipairs(scanMembers(scan)) do
                    if not (scan.members[qID] and scan.members[qID][member]) then complete=false;break end
                end
                if not complete then break end
            end
            scan.incomplete=not complete
        end
        advisorCache[scan.dungeon.id]=nil
        HB.DungeonBiSView.cache=nil
        if not scan.incomplete then rebuildPairs(scan) end
        buildBest() -- late Pawn cache replies may alter best-per-slot priority
        if frame and frame:IsShown() then
            if chosen and chosen.id==scan.dungeon.id and status~="UNCACHED" and status~="NOSTATS" then
                if statusText then statusText:SetText("Cache update received: "..diagnosticSummary(scan)..". Rank: "..scanState(scan)) end
            end
            refresh()
        end
    end
    return true
end
-- Send the same versioned Pawn result both during the scan and when uncached
-- item information becomes available. No background full-team rescan.
local function sendPawnResult(seq,itemID,code,pct,group,req,lvl,raw,weaponBase,why,baseline)
    local ok=addonMessage(string.format("R|%d|%d|%s|%.2f|%s|%d|%d|%.6f|%.6f|%s|%.6f",seq,itemID,code,
        tonumber(pct) or -1,group or "UNKNOWN",tonumber(req) or 0,tonumber(lvl) or 0,
        tonumber(raw) or -1,tonumber(weaponBase) or -1,why or "NONE",tonumber(baseline) or -1))
    if ok then net.replies=net.replies+1 end
    return ok
end
local function waitingOnItemData(code,why)
    return code=="UNCACHED" or (code=="NOGEAR" and why=="BAG_PENDING")
end
function batch.queueResults(seq,ids)
    -- Group enough fully faithful, compressed result records to remain <=224
    -- bytes. A rare unfamiliar Pawn diagnostic uses legacy R, never guesses.
    local prefix="V|"..seq.."|"
    local packet=prefix
    for _,id in ipairs(ids) do
        local code,pct,group,req,lvl,raw,weaponBase,why,baseline=evaluateForDungeon(id)
        if waitingOnItemData(code,why) then registerCachePending(id,seq) end
        local row=batch.encode(id,code,pct,group,req,lvl,raw,weaponBase,why,baseline)
        if row and (#prefix+#row)<=batch.maxPacket then
            local sep=(packet==prefix) and "" or ";"
            if #packet+#sep+#row>batch.maxPacket then
                batch.queueReply(packet);packet=prefix;sep=""
            end
            packet=packet..sep..row
        else
            -- Preserve original fields, including unknown why/slot strings.
            if packet~=prefix then batch.queueReply(packet);packet=prefix end
            local msg=string.format("R|%d|%d|%s|%.2f|%s|%d|%d|%.6f|%.6f|%s|%.6f",seq,id,code,
                tonumber(pct) or -1,group or "UNKNOWN",tonumber(req) or 0,tonumber(lvl) or 0,
                tonumber(raw) or -1,tonumber(weaponBase) or -1,why or "NONE",tonumber(baseline) or -1)
            if batch.queueReply(msg) then batch.fallbackSent=batch.fallbackSent+1 end
        end
    end
    if packet~=prefix then batch.queueReply(packet) end
end
-- Cache reconciliation has two triggers: GET_ITEM_INFO_RECEIVED/ITEM_DATA_LOAD_RESULT,
-- and a bounded fallback pulse (for custom Forever clients without reliable events).
-- This is active ONLY while uncached item IDs are outstanding, never permanently.
cacheCheckItem=function(itemID)
    local seqs=pendingCache[itemID]
    if not seqs then return end
    local code,pct,group,req,lvl,raw,weaponBase,why,baseline=evaluateForDungeon(itemID)
    if waitingOnItemData(code,why) then return end
    for seq in pairs(seqs) do
        local delivered
        if me()=="Mael" then
            handleResult("Mael",seq,itemID,code,pct,group,req,lvl,raw,weaponBase,why,baseline)
            delivered=true
        else
            delivered=sendPawnResult(seq,itemID,code,pct,group,req,lvl,raw,weaponBase,why,baseline)
        end
        if delivered then seqs[seq]=nil;cacheResolvedCount=cacheResolvedCount+1 end
    end
    if not next(seqs) then pendingCache[itemID]=nil end
end
local function onCachePulse(_,elapsed)
    cachePulseElapsed=cachePulseElapsed+elapsed
    cachePulseLifetime=cachePulseLifetime+elapsed
    if cachePulseElapsed<CACHE_PULSE_INTERVAL then return end
    cachePulseElapsed=0
    local ids={}
    for itemID in pairs(pendingCache) do ids[#ids+1]=itemID end
    for _,itemID in ipairs(ids) do cacheCheckItem(itemID) end
    if not next(pendingCache) or cachePulseLifetime>=CACHE_PULSE_MAX then
        cacheFrame:SetScript("OnUpdate",nil) -- no idle polling
    end
end
registerCachePending=function(itemID,seq)
    if not itemID or not seq then return end
    if not pendingCache[itemID] then pendingCache[itemID]={} end
    -- Retain a bounded fallback window after the latest missing item was observed.
    if not pendingCache[itemID][seq] then cachePulseLifetime=0 end
    pendingCache[itemID][seq]=true
    if not cacheFrame then cacheFrame=CreateFrame("Frame") end
    if not cacheFrame:GetScript("OnUpdate") then
        cachePulseLifetime=0;cachePulseElapsed=0
        cacheFrame:SetScript("OnUpdate",onCachePulse)
    end
end
-- Explicit scans only. Send one follower request at a time. In HF26.20.20,
-- Mael reported 120 accepted first-wave Q but every follower received only
-- 76 shared Q packets (19 addressed, 57 for other members). SendAddonMessage
-- success is not an end-to-end delivery acknowledgement. Slow the stream to
-- 0.90s per request for a falsifiable transport-pacing acceptance test.
-- Preserve two bounded missing-pair retries. NO_REPLY remains CHECK.
local ITEM_SPACING=0.90
local MAX_RETRY_ROUNDS=2
local function missingFor(job,id)
    local missing={}
    local members=job.scan.members[id] or {}
    for _,name in ipairs(scanMembers(job.scan)) do
        if not members[name] then missing[#missing+1]=name end
    end
    return missing
end
local function finishScan(job)
    scanJob=nil
    local stillMissing=0
    for _,itemID in ipairs(job.queue) do stillMissing=stillMissing+#missingFor(job,itemID) end
    job.scan.retryStats={rounds=job.retryRounds or 0,sent=job.retried or 0,
        failed=job.retryFailed or 0,skipped=job.retrySkipped or 0,missing=stillMissing}
    job.scan.finished=true
    local complete=true
    for _,id in ipairs(job.queue) do
        if #missingFor(job,id)>0 then complete=false;break end
    end
    -- Gear/level changes can arrive DURING this bounded scan. A post-change
    -- result is NOT a coherent equipment snapshot, even when every response
    -- eventually arrives. Require a fresh explicit scan to certify it.
    job.scan.stale=job.scan.invalidated==true
    job.scan.incomplete=(not complete) or job.scan.invalidated==true
    if complete and not job.scan.invalidated then rebuildPairs(job.scan) end
    advisorCache[job.dungeon.id]=nil
    HB.DungeonBiSView.cache=nil
    local quality=scanState(job.scan)
    if allScan and allScan.running then
        allScan.skipped=(allScan.skipped or 0)+(job.scan.prefilterSkipped or 0)
        allScan.reused=(allScan.reused or 0)+(job.scan.reused or 0)
        allScan.completed=allScan.completed+1
        if quality~="READY" and quality~="PROVISIONAL" and quality~="FUTURE" then
            allScan.uncertain=(allScan.uncertain or 0)+1
        end
        allScan.delay=0
    else
        lastScanFeedback="Dungeon scan finished: "..quality.." · "..diagnosticSummary(job.scan)
        say(lastScanFeedback)
    end
    refresh()
end
local function performLocal(itemID,job)
    local code,pct,group,req,lvl,raw,weaponBase,why,baseline=evaluateForDungeon(itemID)
    handleResult("Mael",job.id,itemID,code,pct,group,req,lvl,raw,weaponBase,why,baseline)
    if waitingOnItemData(code,why) then registerCachePending(itemID,job.id) end
end

tick=function(_,elapsed)
    local job=scanJob
    if not job then return end
    job.elapsed=job.elapsed+elapsed
    -- Prepare all local Mael results. Do at most 8 per frame (no network wait).
    if not job.batchPlans then
        job.localIndex=job.localIndex or 1
        local stop=math.min(#job.queue,job.localIndex+7)
        for i=job.localIndex,stop do
            local id=job.queue[i]
            if not (job.scan.members[id] and job.scan.members[id].Mael) then performLocal(id,job) end
        end
        job.localIndex=stop+1
        if job.localIndex<=#job.queue then return end
        job.batchPlans={}
        -- Target ONE follower per packet, at the known-safe 0.90s interval.
        -- A packet contains up to 16 different item IDs; follower responses
        -- are compact and paced instead of 16 immediate individual R messages.
        local members=scanMembers(job.scan)
        for first=1,#job.queue,batch.size do
            for _,name in ipairs(members) do
                if name~="Mael" then
                    local ids={}
                    for i=first,math.min(#job.queue,first+batch.size-1) do
                        local id=job.queue[i]
                        if not (job.scan.members[id] and job.scan.members[id][name]) then ids[#ids+1]=id end
                    end
                    if #ids>0 then job.batchPlans[#job.batchPlans+1]={name=name,ids=ids,upto=math.min(#job.queue,first+batch.size-1)} end
                end
            end
        end
        job.batchPos=1
        job.pos=1
        job.grace=0
    end
    if job.elapsed<ITEM_SPACING then return end
    local step=job.elapsed
    job.elapsed=0
    -- A completely acknowledged dungeon needs NO additional timeout/grace.
    -- This removes 3.6 seconds of dead wait for every successful dungeon.
    if job.batchPos>#job.batchPlans then
        local complete=true
        for _,id in ipairs(job.queue) do
            if #missingFor(job,id)>0 then complete=false;break end
        end
        if complete then finishScan(job);return end
    end
    if job.batchPos<=#job.batchPlans then
        local plan=job.batchPlans[job.batchPos]
        job.batchPos=job.batchPos+1
        job.pos=plan.upto
        local pending={}
        for _,id in ipairs(plan.ids) do
            if not (job.scan.members[id] and job.scan.members[id][plan.name]) then pending[#pending+1]=id
            else job.scan.requestStats.skipped=job.scan.requestStats.skipped+1 end
        end
        if #pending>0 then
            local msg=string.format("B|%d|%s|%s",job.id,plan.name,table.concat(pending,","))
            if #msg>batch.maxPacket then
                -- This is a protocol bug, not permission to truncate item IDs.
                job.scan.requestStats.failed=job.scan.requestStats.failed+1
                net.firstWaveFailed=net.firstWaveFailed+1
            else
                local ok=addonMessage(msg)
                if ok then
                    job.scan.requestStats.sent=job.scan.requestStats.sent+1
                    job.scan.requestStats.byFollower[plan.name]=(job.scan.requestStats.byFollower[plan.name] or 0)+1
                    net.firstWaveSent=net.firstWaveSent+1
                    batch.requestsSent=batch.requestsSent+1
                else
                    job.scan.requestStats.failed=job.scan.requestStats.failed+1
                    net.firstWaveFailed=net.firstWaveFailed+1
                end
            end
        end
        return
    end
    -- The last follower may still be draining paced multi-result packets.
    -- Allow 3.6s after initial wave before first bounded retry snapshot.
    if not job.retryQueue or job.retryPos>#job.retryQueue then
        job.grace=job.grace+step
        if job.grace<3.6 then return end
        job.grace=0
        if #activeNames<=1 or job.scan.invalidated then finishScan(job);return end
        local missingByFollower={}
        for _,id in ipairs(job.queue) do
            for _,name in ipairs(missingFor(job,id)) do
                if name~="Mael" then
                    if not missingByFollower[name] then missingByFollower[name]={} end
                    missingByFollower[name][#missingByFollower[name]+1]=id
                end
            end
        end
        if not next(missingByFollower) or job.retryRounds>=MAX_RETRY_ROUNDS then
            finishScan(job);return
        end
        job.retryRounds=job.retryRounds+1
        job.retryQueue={}
        for _,name in ipairs(scanMembers(job.scan)) do
            local ids=missingByFollower[name]
            if ids then
                for first=1,#ids,batch.size do
                    local subset={}
                    for i=first,math.min(#ids,first+batch.size-1) do subset[#subset+1]=ids[i] end
                    job.retryQueue[#job.retryQueue+1]={name=name,ids=subset}
                end
            end
        end
        job.retryPos=1
    end
    local plan=job.retryQueue[job.retryPos]
    job.retryPos=job.retryPos+1
    local remaining={}
    for _,id in ipairs(plan.ids) do
        if not (job.scan.members[id] and job.scan.members[id][plan.name]) then remaining[#remaining+1]=id
        else job.retrySkipped=job.retrySkipped+1;net.retrySkipped=net.retrySkipped+1 end
    end
    if #remaining>0 then
        local msg=string.format("B|%d|%s|%s",job.id,plan.name,table.concat(remaining,","))
        if #msg<=batch.maxPacket and addonMessage(msg) then
            job.retried=job.retried+1;net.retrySent=net.retrySent+1;batch.retryRequestsSent=batch.retryRequestsSent+1
        else job.retryFailed=job.retryFailed+1;net.retryFailed=net.retryFailed+1 end
    end
end

workerTick=function(self,elapsed)
    if allScan and allScan.running and allScan.probing then
        allScan.probeElapsed=allScan.probeElapsed+elapsed
        if allScan.probeElapsed>0.7 and not allScan.probeResent then
            allScan.probeResent=true
            addonMessage("P|"..net.pingToken.."|"..PROTOCOL)
        end
        if allScan.probeElapsed>=1.6 then activateResponders();refresh() end
        return
    end
    if scanJob then tick(self,elapsed);return end
    if allScan and allScan.running then
        allScan.delay=(allScan.delay or 0)+elapsed
        if allScan.delay<0.15 then return end
        allScan.delay=0
        allScan.index=allScan.index+1
        local dungeon=allScan.queue[allScan.index]
        if dungeon then startDungeonScan(dungeon)
        else
            allScan.running=false;allScan.finished=true
            allScan.finishedAt=type(date)=="function" and date("%H:%M") or "current session"
            lastScanFeedback=(allScan.uncertain or 0)>0
                and ((allScan.uncertain or 0).." scans need data review; [?] is not zero.")
                or "Completed; future gear estimates are not currently equippable."
            if #allScan.unresponsive>0 then
                lastScanFeedback=lastScanFeedback.." No reply: "..table.concat(allScan.unresponsive,",").."."
            end
            local elapsed=(type(GetTime)=="function" and allScan.startedAt)
                and math.max(0,GetTime()-allScan.startedAt) or nil
            if elapsed then lastScanFeedback=string.format("Elapsed %.1fs. ",elapsed)..lastScanFeedback end
            say((allScan.scope=="available" and "Available-dungeon" or "All-dungeon")
                .." scan complete. Filtered "..tostring(allScan.skipped or 0)
                .." certainly unusable loot entries; reused "..tostring(allScan.reused or 0)
                .." party/item results. "..lastScanFeedback)
            self:SetScript("OnUpdate",nil)
            buildBest() -- existing REPLACED mechanic is now based on completed scans
            wipe(advisorCache) -- previous detail rows used pre-completion rankings
            HB.DungeonBiSView.cache=nil
            refresh()
        end
    else self:SetScript("OnUpdate",nil) end
end
local function makeUI()
    frame=CreateFrame("Frame","HaploBoxLootPlannerHF26",UIParent)
    local cfg=state()
    local parentWidth=UIParent:GetWidth()
    local parentHeight=UIParent:GetHeight()
    local w=math.max(820,math.min(tonumber(cfg and cfg.advisorWidth) or 1175,
        math.max(820,parentWidth-18)))
    local h=math.max(475,math.min(tonumber(cfg and cfg.advisorHeight) or 706,
        math.max(475,parentHeight-18)))
    frame:SetSize(w,h);frame:SetPoint("CENTER",UIParent,"CENTER",0,0)
    frame:SetClampedToScreen(true);frame:EnableMouse(true);frame:SetMovable(true)
    if type(frame.SetResizable)=="function" then frame:SetResizable(true) end
    local ui={};HB.DungeonBiSView.ui=ui
    HB.DungeonBiSView.dungeonPageSize=12
    HB.DungeonBiSView.detailPageSize=16
    frame:SetFrameStrata("DIALOG");frame:SetFrameLevel(180)
    if HB.MenuStyle then HB.MenuStyle.Window(frame,30) end
    local trim=frame:CreateTexture(nil,"OVERLAY")
    trim:SetPoint("TOPLEFT",frame,"TOPLEFT",4,-30)
    trim:SetPoint("TOPRIGHT",frame,"TOPRIGHT",-4,-30)
    trim:SetHeight(2);trim:SetColorTexture(0.72,0.54,0.24,0.94)
    local top=CreateFrame("Frame",nil,frame)
    top:SetPoint("TOPLEFT");top:SetPoint("TOPRIGHT");top:SetHeight(29)
    top:EnableMouse(true);top:RegisterForDrag("LeftButton")
    top:SetScript("OnDragStart",function()
        if HB.db and HB.db.lootPlannerUnlocked and not (InCombatLockdown and InCombatLockdown()) then frame:StartMoving() end
    end)
    top:SetScript("OnDragStop",function() frame:StopMovingOrSizing() end)
    local header=label(top,"HAPLO LOOT  |cffd9b66eDUNGEON ADVISOR / BIS|r",14,-8,760,true)
    header:SetTextColor(1,.82,.40)
    local close=button(top,"X",1140,-4,27,21,function() frame:Hide() end)
    local lock=button(top,"L",1107,-4,27,21,function(self)
        if not HB.db or (InCombatLockdown and InCombatLockdown()) then return end
        HB.db.lootPlannerUnlocked=not HB.db.lootPlannerUnlocked
        if HB.MenuStyle then HB.MenuStyle.LockButton(self,not HB.db.lootPlannerUnlocked) end
    end)
    ui.headerText=header
    ui.closeButton=close;ui.lockButton=lock
    label(frame,"SCAN",16,-43,295,true)
    availableScanButton=button(frame,"AVAILABLE DUNGEONS",16,-63,211,28,function()
        startAllScan("available")
    end)
    -- One simple SCAN button; no all-dungeons view.
    availableScanButton:SetText("SCAN PARTY BIS")
    ui.farmHeader=label(frame,"DUNGEONS",16,-104,410,true)
    titleText=label(frame,"Select a dungeon",465,-43,675,true)
    selectedSummary=label(frame,"",465,-61,685)
    HB.DungeonBiSView.coverageSummary=label(frame,"",465,-78,685)
    HB.DungeonBiSView.coverageSummary:SetTextColor(.92,.77,.46)
    -- Coverage remains in /hbbiscoverage and /hblootnet diagnostics.
    HB.DungeonBiSView.coverageSummary:Hide()
    ui.summaryHitbox=CreateFrame("Frame",nil,frame)
    ui.summaryHitbox:SetPoint("TOPLEFT",selectedSummary,"TOPLEFT",0,1)
    ui.summaryHitbox:SetSize(300,35)
    ui.summaryHitbox:EnableMouse(true)
    ui.summaryHitbox:SetScript("OnEnter",function(self)
        if not GameTooltip then return end
        GameTooltip:SetOwner(self,"ANCHOR_CURSOR")
        GameTooltip:SetText("Dungeon BiS coverage",1,.83,.41)
        GameTooltip:AddLine(self.full or "Scan not completed",1,1,1,true)
        GameTooltip:AddLine("PROVISIONAL is not a verified complete scan.",1,.67,.36,true)
        GameTooltip:Show()
    end)
    ui.summaryHitbox:SetScript("OnLeave",function() if GameTooltip then GameTooltip:Hide() end end)
    ui.summaryHitbox:EnableMouse(false);ui.summaryHitbox:Hide()
    local head=CreateFrame("Frame",nil,frame)
    head:SetPoint("TOPLEFT",frame,"TOPLEFT",16,-134);head:SetSize(432,18)
    ui.dungeonHead=head;ui.headTexts={}
    -- Three actual role-icon columns instead of a merged T/H/D caption.
    -- Icons reuse the native WoW role atlas with fallbacks for Forever clients.
    local nameTitle=smallText(head,263,4,"LEFT")
    nameTitle:SetText("Dungeon");nameTitle:SetTextColor(.82,.69,.43)
    ui.headTexts[1]=nameTitle
    -- Only glyphs above the numeric columns; no UNI/Score words.
    ui.uniqueHeader=head:CreateTexture(nil,"OVERLAY")
    ui.uniqueHeader:SetSize(15,15)
    ui.uniqueHeader:SetTexture(ICON_NEED)
    ui.scoreHeader=head:CreateTexture(nil,"OVERLAY")
    ui.scoreHeader:SetSize(15,15)
    ui.scoreHeader:SetTexture(ICON_PAWN)
    ui.roleHeaders={
        roleIcon(head,309,"TANK",ICON_TANK),
        roleIcon(head,336,"HEALER",ICON_HEAL),
        roleIcon(head,363,"DAMAGER",ICON_DPS),
    }
    -- Scrollable virtual rows; priorities are ONE score per physical item ID.
    for i=1,12 do
        local b=button(frame,"",16,-158-(i-1)*32,432,29,function()
            local d=visibleDungeons[dungeonPage+i-1]
            if d then chosen=d;HB.DungeonBiSView.enabled=true;detailPage=1;refresh() end
        end)
        b.runButton=button(b,"RUN",0,-3,38,23,function(self)
            local d=self.dungeon
            if not d then return end
            chosen=d;HB.DungeonBiSView.enabled=true;detailPage=1;refresh()
            if HB.OpenDungeonBiSRun then HB.OpenDungeonBiSRun(d) end
        end)
        b.labels={}
        -- [1] dungeon, [4] unique items, [5/6/7] TANK/HEALER/DPS counts,
        -- [8] priority. Spare [2/3] indices retain the established render API.
        for _,field in ipairs({{5,263,"LEFT"},{166,1,"CENTER"},{199,1,"CENTER"},
            {273,25,"CENTER"},{303,25,"CENTER"},{330,25,"CENTER"},
            {357,25,"CENTER"},{384,32,"CENTER"}}) do
            b.labels[#b.labels+1]=smallText(b,field[2],field[1],field[3])
        end
        dungeonButtons[i]=b
    end
    HB.DungeonBiSView.header=label(frame,"BIS LOOT",465,-95,680,true)
    ui.bossToggleAll=button(frame,"COLLAPSE ALL",995,-89,110,23,function()
        if not chosen then return end
        local farm=HB.DungeonBiSForDungeon(chosen.id)
        if not farm then return end
        local db=state();if not db then return end
        db.advisorCollapsed=db.advisorCollapsed or {}
        local opened=db.advisorCollapsed[chosen.id] or {}
        db.advisorCollapsed[chosen.id]=opened
        local anyOpen=false
        for _,boss in ipairs(bossesFor(chosen)) do
            if farm.byBoss[boss.index] and #farm.byBoss[boss.index]>0
                and opened[boss.index]~=true then anyOpen=true;break end
        end
        for _,boss in ipairs(bossesFor(chosen)) do
            if farm.byBoss[boss.index] and #farm.byBoss[boss.index]>0 then
                opened[boss.index]=anyOpen and true or nil
            end
        end
        detailPage=1;refresh()
    end)
    HB.DungeonBiSView.ToggleAdvisorBoss=function(bossID)
        if not chosen then return end
        local db=state();if not db then return end
        db.advisorCollapsed=db.advisorCollapsed or {}
        local opened=db.advisorCollapsed[chosen.id] or {}
        db.advisorCollapsed[chosen.id]=opened
        if opened[bossID] then opened[bossID]=nil else opened[bossID]=true end
        detailPage=1;refresh()
    end
    for i=1,16 do
        local row=CreateFrame("Button",nil,frame)
        row:SetPoint("TOPLEFT",frame,"TOPLEFT",465,-119-(i-1)*30)
        row:SetSize(690,28)
        local bg=row:CreateTexture(nil,"BACKGROUND")
        bg:SetAllPoints();bg:SetColorTexture(0.08,0.10,0.14,0.45)
        row.back=bg
        local glow=row:CreateTexture(nil,"HIGHLIGHT")
        glow:SetAllPoints();glow:SetColorTexture(.35,.42,.52,.18)
        row.heading=smallText(row,650,7,"LEFT");row.heading:SetTextColor(.98,.77,.39)
        row.itemIcon=row:CreateTexture(nil,"ARTWORK")
        row.itemIcon:SetPoint("LEFT",row,"LEFT",5,0);row.itemIcon:SetSize(24,24)
        row.iconHitbox=CreateFrame("Button",nil,row)
        row.iconHitbox:SetPoint("CENTER",row.itemIcon,"CENTER",0,0)
        row.iconHitbox:SetSize(24,24)
        row.iconHitbox:EnableMouse(true)
        row.iconHitbox:SetScript("OnEnter",function(self)
            if not (self.ItemID and GameTooltip) then return end
            GameTooltip:SetOwner(self,"ANCHOR_CURSOR")
            local ok=pcall(GameTooltip.SetHyperlink,GameTooltip,"item:"..tostring(self.ItemID))
            if ok then GameTooltip:Show() end
        end)
        row.iconHitbox:SetScript("OnLeave",function()
            if GameTooltip then GameTooltip:Hide() end
        end)
        row.itemName=smallText(row,270,36,"LEFT")
        row.itemName:ClearAllPoints();row.itemName:SetPoint("LEFT",row,"LEFT",36,6)
        row.itemSub=smallText(row,270,36,"LEFT")
        row.itemSub:ClearAllPoints();row.itemSub:SetPoint("LEFT",row,"LEFT",36,-7)
        row.itemSub:SetTextColor(.56,.62,.68);row.itemSub:Hide()
        row.needStatus=smallText(row,55,306,"CENTER")
        row.needStatus:SetTextColor(.98,.72,.37)
        row.needStatus:Hide()
        row.prioHitbox=CreateFrame("Frame",nil,row)
        row.prioHitbox:SetPoint("LEFT",row,"LEFT",306,0)
        row.prioHitbox:SetSize(55,24)
        row.prioHitbox:EnableMouse(true)
        row.prioHitbox:SetScript("OnEnter",function(self)
            if not GameTooltip then return end
            GameTooltip:SetOwner(self,"ANCHOR_CURSOR")
            GameTooltip:SetText("Need priority: unresolved",1,.75,.35)
            GameTooltip:AddLine(self.detail or "Check Pawn data on all relevant characters.",1,1,1,true)
            GameTooltip:Show()
        end)
        row.prioHitbox:SetScript("OnLeave",function()
            if GameTooltip then GameTooltip:Hide() end
        end)
        row.dice=row:CreateTexture(nil,"OVERLAY")
        row.dice:SetPoint("LEFT",row,"LEFT",341,0);row.dice:SetSize(16,16);row.dice:SetTexture(ICON_NEED)
        row.arrow=row:CreateTexture(nil,"OVERLAY")
        row.arrow:SetPoint("LEFT",row,"LEFT",365,0);row.arrow:SetSize(16,16);row.arrow:SetTexture(ICON_PAWN)
        row.character=smallText(row,110,390,"LEFT")
        row.percent=smallText(row,126,552,"RIGHT")
        row:Hide();detailRows[i]=row
    end
    ui.farmPrev=button(frame,"<",16,-553,32,22,function()
        dungeonPage=math.max(1,dungeonPage-(HB.DungeonBiSView.dungeonPageSize or 12));refresh()
    end)
    ui.farmNext=button(frame,">",54,-553,32,22,function()
        local count=HB.DungeonBiSView.dungeonPageSize or 12
        dungeonPage=math.min(math.max(1,#visibleDungeons-count+1),dungeonPage+count)
        refresh()
    end)
    pageText=label(frame,"",98,-559,350)
    ui.detailPrev=button(frame,"<",465,-607,32,22,function()
        detailPage=math.max(1,detailPage-(HB.DungeonBiSView.detailPageSize or 16));refresh()
    end)
    ui.detailNext=button(frame,">",503,-607,32,22,function()
        local entries=HB.DungeonBiSEntriesForView()
        local count=HB.DungeonBiSView.detailPageSize or 16
        detailPage=math.min(math.max(1,#entries-count+1),detailPage+count)
        refresh()
    end)
    detailPageText=label(frame,"",547,-612,290)
    ui.farmPrev:Hide();ui.farmNext:Hide()
    ui.detailPrev:Hide();ui.detailNext:Hide()
    pageText:Hide();detailPageText:Hide()
    local function wheelFarm(_,delta)
        local maxStart=math.max(1,#visibleDungeons-(HB.DungeonBiSView.dungeonPageSize or 12)+1)
        dungeonPage=math.max(1,math.min(maxStart,dungeonPage-(delta>0 and 2 or -2)))
        refresh()
    end
    local function wheelDetail(_,delta)
        local rows=HB.DungeonBiSEntriesForView()
        local maxStart=math.max(1,#rows-(HB.DungeonBiSView.detailPageSize or 16)+1)
        detailPage=math.max(1,math.min(maxStart,detailPage-(delta>0 and 2 or -2)))
        refresh()
    end
    ui.farmScroll=HB.DungeonBiSView.NewScrollbar(frame,function(value)
        dungeonPage=value;refresh()
    end)
    ui.detailScroll=HB.DungeonBiSView.NewScrollbar(frame,function(value)
        detailPage=value;refresh()
    end)
    for _,b in ipairs(dungeonButtons) do
        b:EnableMouseWheel(true);b:SetScript("OnMouseWheel",wheelFarm)
        b.runButton:EnableMouseWheel(true);b.runButton:SetScript("OnMouseWheel",wheelFarm)
    end
    for _,row in ipairs(detailRows) do
        row:EnableMouseWheel(true);row:SetScript("OnMouseWheel",wheelDetail)
        row.iconHitbox:EnableMouseWheel(true);row.iconHitbox:SetScript("OnMouseWheel",wheelDetail)
    end
    ui.dungeonHead:EnableMouseWheel(true);ui.dungeonHead:SetScript("OnMouseWheel",wheelFarm)
    -- Keep the arrow buttons as a keyboard/fallback path, not required for scrolling.
    -- AtlasLoot owns detailed item browsing. This screen deliberately offers
    -- no 'all boss loot' or alternate score view.
    HB.DungeonBiSView.enabled=true
    statusText=label(frame,"Ready",16,-591,425)
    statusText:SetJustifyV("TOP");statusText:SetHeight(89)
    statusText:SetTextColor(.99,.86,.53)
    ui.footerText=label(frame,"",465,-655,685)
    ui.footerText:Hide()

    -- The Advisor is independently resizable from Dungeon Run. No scanner,
    -- Pawn data or saved run state is touched by reflow.
    ui.layout=function()
        local width,height=frame:GetWidth(),frame:GetHeight()
        if width<1 or height<1 then return end
        local farmWidth=math.max(345,math.min(490,math.floor((width-36)*.41)))
        local rightX=33+farmWidth
        local detailWidth=math.max(430,width-rightX-17)
        HB.DungeonBiSView.dungeonPageSize=math.max(2,math.min(#dungeonButtons,
            math.floor((height-240)/32)))
        HB.DungeonBiSView.detailPageSize=math.max(2,math.min(#detailRows,
            math.floor((height-170)/30)))
        local function place(o,x,y)
            o:ClearAllPoints();o:SetPoint("TOPLEFT",frame,"TOPLEFT",x,y)
        end
        local function bottom(o,x,y)
            o:ClearAllPoints();o:SetPoint("BOTTOMLEFT",frame,"BOTTOMLEFT",x,y)
        end
        local function inRow(o,parent,x)
            o:ClearAllPoints();o:SetPoint("LEFT",parent,"LEFT",x,0)
        end
        ui.closeButton:ClearAllPoints()
        ui.closeButton:SetPoint("TOPRIGHT",top,"TOPRIGHT",-8,-4)
        ui.lockButton:ClearAllPoints()
        ui.lockButton:SetPoint("TOPRIGHT",top,"TOPRIGHT",-40,-4)
        ui.headerText:SetWidth(math.max(290,width-125))
        ui.farmHeader:SetWidth(farmWidth)
        ui.farmHeader:SetText("DUNGEONS")
        place(titleText,rightX,-43);titleText:SetWidth(detailWidth-4)
        place(selectedSummary,rightX,-61);selectedSummary:SetWidth(detailWidth-4)
        place(HB.DungeonBiSView.coverageSummary,rightX,-78)
        HB.DungeonBiSView.coverageSummary:SetWidth(detailWidth-4)
        ui.summaryHitbox:ClearAllPoints()
        ui.summaryHitbox:SetPoint("TOPLEFT",selectedSummary,"TOPLEFT",0,2)
        ui.summaryHitbox:SetWidth(math.min(400,detailWidth-4))
        place(HB.DungeonBiSView.header,rightX,-95)
        HB.DungeonBiSView.header:SetWidth(detailWidth-130)
        place(ui.bossToggleAll,rightX+detailWidth-126,-91)
        -- DUNGEON | UNI | Tank | Healer | DPS | Score | RUN | scrollbar.
        -- Every column is calculated from the CURRENT panel width and remains
        -- within the button and window even at the minimum 820px Advisor size.
        local runX=farmWidth-57
        local scoreX=runX-43
        local dpsX=scoreX-28
        local healerX=dpsX-28
        local tankX=healerX-28
        local uniqueX=tankX-32
        local nameWidth=math.max(75,uniqueX-8)
        ui.farmNameWidth=nameWidth
        ui.dungeonHead:SetWidth(farmWidth-17)
        ui.headTexts[1]:SetWidth(nameWidth)
        inRow(ui.uniqueHeader,ui.dungeonHead,uniqueX+5)
        inRow(ui.scoreHeader,ui.dungeonHead,scoreX+11)
        for i,x in ipairs({tankX+5,healerX+5,dpsX+5}) do
            inRow(ui.roleHeaders[i],ui.dungeonHead,x)
        end
        for i,b in ipairs(dungeonButtons) do
            b:SetWidth(farmWidth-19)
            b.labels[1]:SetWidth(nameWidth)
            inRow(b.labels[4],b,uniqueX);b.labels[4]:SetWidth(26)
            inRow(b.labels[5],b,tankX);b.labels[5]:SetWidth(26)
            inRow(b.labels[6],b,healerX);b.labels[6]:SetWidth(26)
            inRow(b.labels[7],b,dpsX);b.labels[7]:SetWidth(26)
            inRow(b.labels[8],b,scoreX);b.labels[8]:SetWidth(38)
            inRow(b.runButton,b,runX)
            if i>HB.DungeonBiSView.dungeonPageSize then b:Hide() end
        end
        for i,r in ipairs(detailRows) do
            place(r,rightX,-119-(i-1)*30)
            r:SetWidth(detailWidth-14) -- reserve scrollbar gutter
            r.heading:SetWidth(math.max(210,detailWidth-30))
            r.itemName:SetWidth(math.max(150,detailWidth-260))
            r.itemSub:SetWidth(math.max(150,detailWidth-260))
            r.nameChars=math.max(13,math.min(55,math.floor((detailWidth-260)/6.2)))
            inRow(r.character,r,detailWidth-218);r.character:SetWidth(97)
            inRow(r.arrow,r,detailWidth-114)
            inRow(r.percent,r,detailWidth-111);r.percent:SetWidth(87)
            inRow(r.needStatus,r,detailWidth-325)
            inRow(r.prioHitbox,r,detailWidth-325)
            inRow(r.dice,r,detailWidth-303)
            if i>HB.DungeonBiSView.detailPageSize then r:Hide() end
        end
        ui.farmScroll:ClearAllPoints()
        ui.farmScroll:SetPoint("TOPLEFT",frame,"TOPLEFT",16+farmWidth-14,-158)
        ui.farmScroll:SetHeight(math.max(60,HB.DungeonBiSView.dungeonPageSize*32-4))
        ui.detailScroll:ClearAllPoints()
        ui.detailScroll:SetPoint("TOPLEFT",frame,"TOPLEFT",rightX+detailWidth-14,-119)
        ui.detailScroll:SetHeight(math.max(60,HB.DungeonBiSView.detailPageSize*30-4))
        bottom(ui.farmPrev,16,131);bottom(ui.farmNext,54,131)
        bottom(pageText,98,136);pageText:SetWidth(math.max(130,farmWidth-86))
        bottom(ui.detailPrev,rightX,77);bottom(ui.detailNext,rightX+38,77)
        bottom(detailPageText,rightX+82,82);detailPageText:SetWidth(math.max(150,detailWidth-95))
        bottom(statusText,16,26);statusText:SetWidth(farmWidth)
        bottom(ui.footerText,rightX,39);ui.footerText:SetWidth(detailWidth)
        -- Clamp both pagers when the window has been reduced.
        dungeonPage=math.max(1,math.min(dungeonPage,
            math.max(1,#visibleDungeons-HB.DungeonBiSView.dungeonPageSize+1)))
        local items=HB.DungeonBiSEntriesForView()
        detailPage=math.max(1,math.min(detailPage,
            math.max(1,#items-HB.DungeonBiSView.detailPageSize+1)))
    end
    ui.sizeGrip=CreateFrame("Button",nil,frame)
    ui.sizeGrip:SetSize(19,19)
    ui.sizeGrip:SetPoint("BOTTOMRIGHT",frame,"BOTTOMRIGHT",-2,2)
    ui.sizeGrip:SetFrameLevel(frame:GetFrameLevel()+25)
    ui.sizeGrip:SetNormalTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Up")
    ui.sizeGrip:SetHighlightTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Highlight")
    ui.sizeGrip:SetPushedTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Down")
    ui.sizeGrip:RegisterForDrag("LeftButton")
    ui.sizeGrip:SetScript("OnDragStart",function()
        if InCombatLockdown and InCombatLockdown() then return end
        local left,topEdge=frame:GetLeft(),frame:GetTop()
        if left and topEdge then
            frame:ClearAllPoints()
            frame:SetPoint("TOPLEFT",UIParent,"BOTTOMLEFT",left,topEdge)
        end
        frame:StartSizing("BOTTOMRIGHT")
    end)
    local function stopAdvisorResize()
        frame:StopMovingOrSizing()
        local db=state()
        if db then
            db.advisorWidth=math.floor(frame:GetWidth()+.5)
            db.advisorHeight=math.floor(frame:GetHeight()+.5)
        end
        ui.layout();refresh()
    end
    ui.sizeGrip:SetScript("OnDragStop",stopAdvisorResize)
    ui.sizeGrip:SetScript("OnMouseUp",stopAdvisorResize)
    frame:SetScript("OnSizeChanged",function(self,newWidth,newHeight)
        local capW=math.max(820,math.min(newWidth,math.max(820,UIParent:GetWidth()-18)))
        local capH=math.max(475,math.min(newHeight,math.max(475,UIParent:GetHeight()-18)))
        if math.abs(capW-newWidth)>.5 or math.abs(capH-newHeight)>.5 then
            self:SetSize(capW,capH);return
        end
        local db=state()
        if db then
            db.advisorWidth=math.floor(capW+.5)
            db.advisorHeight=math.floor(capH+.5)
        end
        -- Resize motion only reflows widgets; the expensive BiS refresh runs
        -- once at drag-stop rather than on every pixel dragged.
        ui.layout()
    end)
    ui.layout()
    frame:SetScript("OnShow",function()
        if HB.MenuStyle then HB.MenuStyle.LockButton(lock,not (HB.db and HB.db.lootPlannerUnlocked)) end
        local ok,msg=loadDungeons()
        if not ok then statusText:SetText(msg);return end
        if chosen and not chosen.ref then chosen=nil end
        refresh()
    end)
    -- Do NOT cancel a user-requested batch when the window is closed: the paced
    -- scan keeps running and can be inspected when the planner is reopened.
    frame:Hide()
end

function HB.ToggleLootPlanner()
    if me()~="Mael" then say("Open Haplo Loot on Mael (team leader).") return end
    if not frame then makeUI() end
    if frame:IsShown() then frame:Hide() else frame:Show() end
end
-- HF26.20.13: Run Guide is a compact *view* on existing HBLP26 boss-item
-- scans. No extra chat protocol and no duplicate AtlasLoot/Pawn scoring engine.
local runFrame,runSelector,runSelected,runRows,runChoiceRows,runStatus,runTitle
local runPageText,runScanButton,runChooserPageText,runFutureButton
-- Only this Run Guide overlay is changed; AtlasLoot/Pawn scan and confidence gates remain original.
local runBody,runHeaderText,runHeaderTimer,runHeaderPause,runCollapseButton
local runTimerLine,runTimerSummary,runStealthButton,runNormalButton
local runPauseButton,runFinishButton,runCancelButton
local RUN_WIDTH,RUN_HEIGHT,RUN_COLLAPSED_HEIGHT=548,638,32
local runRefreshTimerUI,runSetCollapsed
local runPage=1
local runChooserPage,runExpanded,runShowFuture=1,{},false
local RUN_PAGE_SIZE=11
-- Lua 5.1 global chunk is close to the 200-local limit; runRows/runChoiceRows
-- also hold private layout widgets instead of introducing top-level locals.
local WC_ROUTE={"anacondra","cobrahn","kresh","faerie dragon","pythas",
    "skum","serpentis","verdan","mutanus"}
local function runState()
    local db=state()
    if not db then return nil end
    if type(db.runGuide)~="table" then db.runGuide={} end
    local rs=db.runGuide
    if type(rs.done)~="table" then rs.done={} end
    if type(rs.expanded)~="table" then rs.expanded={} end
    if type(rs.history)~="table" then rs.history={} end
    return rs
end
-- Epoch-backed times intentionally survive /reload, a hidden window and disconnects.
-- No remote calls, no automatic starts/stops, no timers outside this UI.
local function runNow()
    if type(GetServerTime)=="function" then
        local ok,t=pcall(GetServerTime)
        if ok and type(t)=="number" and t>0 then return math.floor(t) end
    end
    if type(time)=="function" then
        local ok,t=pcall(time)
        if ok and type(t)=="number" and t>0 then return math.floor(t) end
    end
    return nil
end
local function runTimeString(seconds)
    local n=math.max(0,math.floor(tonumber(seconds) or 0))
    local hrs=math.floor(n/3600)
    local mins=math.floor((n%3600)/60)
    if hrs>0 then return string.format("%d:%02d:%02d",hrs,mins,n%60) end
    return string.format("%02d:%02d",mins,n%60)
end
local function runElapsed(timer,stamp)
    if type(timer)~="table" then return 0,0 end
    stamp=stamp or runNow() or tonumber(timer.startedAt) or 0
    local total=math.max(0,stamp-(tonumber(timer.startedAt) or stamp))
    local active=math.max(0,tonumber(timer.activeSeconds) or 0)
    if type(timer.activeFrom)=="number" then
        active=active+math.max(0,stamp-timer.activeFrom)
    end
    return math.min(active,total),total
end
local function runActiveTimer()
    local rs=runState()
    if not rs or type(rs.timer)~="table" then return nil end
    local timer=rs.timer
    if timer.mode~="stealth" and timer.mode~="normal" then return nil end
    if type(timer.startedAt)~="number" or type(timer.dungeonID)~="string" then return nil end
    return timer
end
local function runStartTimer(mode)
    if mode~="stealth" and mode~="normal" then return end
    if not runSelected then say("Select a dungeon first.");return end
    if runActiveTimer() then say("A run is already active. Finish or cancel it first.");return end
    local now=runNow()
    if not now then say("Cannot start: a reliable clock is unavailable.");return end
    local rs=runState();if not rs then return end
    rs.timer={mode=mode,dungeonID=runSelected.id,dungeonName=runSelected.name,
        startedAt=now,activeFrom=now,activeSeconds=0}
    say((mode=="stealth" and "STEALTH" or "NORMAL").." run started: "..runSelected.name)
    if runRefreshTimerUI then runRefreshTimerUI() end
end
local function runPauseOrResume()
    local timer=runActiveTimer()
    if not timer then return end
    local now=runNow()
    if not now then say("Clock unavailable; pause/resume not changed.");return end
    if timer.activeFrom then
        timer.activeSeconds=runElapsed(timer,now)
        timer.activeFrom=nil
        say("Run paused (active time frozen; total time continues).")
    else
        timer.activeFrom=now
        say("Run resumed.")
    end
    if runRefreshTimerUI then runRefreshTimerUI() end
end
local function runFinishTimer()
    local timer=runActiveTimer()
    if not timer then return end
    local now=runNow()
    if not now then say("Clock unavailable; cannot finish run.");return end
    local active,total=runElapsed(timer,now)
    local rs=runState();if not rs then return end
    local record={dungeonID=timer.dungeonID,dungeonName=timer.dungeonName,
        mode=timer.mode,startedAt=timer.startedAt,finishedAt=now,
        activeSeconds=active,totalSeconds=total,pausedSeconds=math.max(0,total-active)}
    table.insert(rs.history,1,record)
    while #rs.history>120 do table.remove(rs.history) end
    rs.timer=nil
    say("SAVED "..string.upper(record.mode).." "..record.dungeonName
        .." · active "..runTimeString(active).." / total "..runTimeString(total))
    if runRefreshTimerUI then runRefreshTimerUI() end
end
local function runCancelTimer()
    local timer=runActiveTimer()
    if not timer then return end
    local rs=runState();if not rs then return end
    rs.timer=nil -- Cancel never adds a completed record.
    say("Run cancelled; no time saved.")
    if runRefreshTimerUI then runRefreshTimerUI() end
end
local function runPrintHistory()
    local rs=runState()
    if not rs or not runSelected then return end
    local shown,bestStealth,bestNormal=0,nil,nil
    say("Saved runs for "..runSelected.name.." (active / total):")
    for _,record in ipairs(rs.history) do
        if record.dungeonID==runSelected.id and (record.mode=="stealth" or record.mode=="normal") then
            local secs=tonumber(record.activeSeconds) or 0
            if record.mode=="stealth" and (not bestStealth or secs<bestStealth) then bestStealth=secs end
            if record.mode=="normal" and (not bestNormal or secs<bestNormal) then bestNormal=secs end
            if shown<8 then
                say(string.upper(record.mode).." "..runTimeString(secs)
                    .." / "..runTimeString(record.totalSeconds).." · "
                    ..(date and date("%d-%m-%Y %H:%M",record.finishedAt) or tostring(record.finishedAt)))
                shown=shown+1
            end
        end
    end
    if shown==0 then say("No completed runs saved yet.") end
    say("Best: stealth "..(bestStealth and runTimeString(bestStealth) or "--")
        .." · normal "..(bestNormal and runTimeString(bestNormal) or "--"))
end
local function runBosses(d)
    local list=bossesFor(d)
    -- WC gets a commonly used route. AtlasLoot may list bosses in its
    -- own database order, which is NOT reliably a walkable route.
    if d and ((d.id or ""):lower():find("wailing",1,true)
        or (d.name or ""):lower():find("wailing",1,true)) then
        local function rank(name)
            local lower=(name or ""):lower()
            for i,token in ipairs(WC_ROUTE) do
                if lower:find(token,1,true) then return i end
            end
            return #WC_ROUTE+1
        end
        table.sort(list,function(a,b)
            local ar,br=rank(a.name),rank(b.name)
            if ar~=br then return ar<br end
            return a.index<b.index
        end)
    end
    return list
end
local function runSetSelected(d)
    if not d then return end
    local oldTimer=runActiveTimer()
    if oldTimer and oldTimer.dungeonID~=d.id then
        say("Finish or cancel the ongoing "..string.upper(oldTimer.mode)
            .." run before changing dungeons.")
        return
    end
    runSelected=d;runPage=1
    local rs=runState()
    if rs then rs.selected=d.id end
    if runRefresh then runRefresh() end
end
local function runEnsureSelected()
    local ok,msg=loadDungeons()
    if not ok then return false,msg end
    local rs=runState()
    local selected=rs and rs.selected
    rebuildVisible()
    local previous
    local timer=runActiveTimer()
    -- Never silently switch the active run to a different instance when its
    -- objective count falls to zero due to a gear update.
    if timer then
        for _,d in ipairs(dungeons) do
            if d.id==timer.dungeonID then previous=d;break end
        end
    else
        for _,d in ipairs(visibleDungeons) do
            if d.id==selected then previous=d;break end
        end
    end
    runSelected=previous or visibleDungeons[1]
    if not runSelected then return false,"SCAN PARTY BIS first; no current targets found." end
    if rs then rs.selected=runSelected.id end
    return true
end
-- Per-boss reliability is stricter than a partial Dungeon Advisor ranking.
-- It certifies only score coverage against the active Team A configuration,
-- never a guarantee that AtlasLoot lists every drop on the Forever server.
-- A different boss may be missing data without hiding fully checked bosses.
local function runBossAudit(scan,boss)
    if not scan or not scan.finished then return false,"NOT SCANNED",0 end
    if scan.stale or scan.invalidated then return false,"GEAR CHANGED",0 end
    if scan.missingGroup then return false,"TEAM INCOMPLETE",0 end
    local participating=scanMembers(scan)
    if #participating~=#activeNames then
        return false,tostring(#participating).."/"..tostring(#activeNames).." PARTY RESPONDERS",0
    end
    local have={}
    for _,toon in ipairs(participating) do have[toon]=true end
    for _,toon in ipairs(activeNames) do
        if not have[toon] or not scan.levels[toon] or scan.levels[toon]<1 then
            return false,"MISSING "..toon,0
        end
    end
    local ids=scan.bossItems and scan.bossItems[boss.index]
    if type(ids)~="table" or #ids==0 then return false,"NO BOSS LOOT DATA",0 end
    local unknown,first=0,nil
    for _,id in ipairs(ids) do
        local people=scan.members and scan.members[id]
        for _,toon in ipairs(activeNames) do
            local r=people and people[toon]
            local reason=nil
            if not r then reason="NO REPLY"
            elseif not r.level or r.level~=scan.levels[toon] then reason="LEVEL CHANGED"
            elseif HB.DungeonBiSView.IsSpecial(id,r) then
                -- Verified special-only item: Pawn cannot score it; do not
                -- block the entire boss, and NEVER claim a 0% upgrade.
            elseif r.status=="NOUP" or r.status=="UNUSABLE" or r.status=="OWNED" or r.status=="FNOUP"
                or r.status=="FUTURE" then
                -- A definite no-upgrade or class/level restriction is a complete result.
            elseif r.status=="UP" or r.status=="FUP" then
                local validSource=(r.why=="PAWN_UI")
                    or (r.slot=="WEAPON_SET" and (r.why=="NONE" or r.why=="BAG_PAIR"
                        or r.why=="LOCK_TWO" or r.why=="LOCK_ONE"))
                if not validSource or type(r.pct)~="number" or r.pct~=r.pct
                    or r.pct<=0 or isUnverifiedHigh(r) then reason="VERIFY SCORE" end
            elseif r.status=="NEEDPAIR" or r.status=="FPAIR" then
                local pair=scan.pairByItem and scan.pairByItem[toon]
                    and scan.pairByItem[toon][id]
                if not pair or type(pair.pct)~="number" or pair.pct<=0
                    or pair.pct>REVIEW_PCT then reason="VERIFY WEAPON PAIR" end
            else
                -- NEW/FNEW have no numeric baseline; UNCACHED/NOSTATS/VERIFY/
                -- NOSCALE/NOGEAR and unrecognized states are never certified.
                reason=r.status or "UNKNOWN"
            end
            if reason then
                unknown=unknown+1
                if not first then first=toon.." "..tostring(reason).." #"..tostring(id) end
            end
        end
    end
    if unknown>0 then return false,tostring(unknown).." CHECK · "..tostring(first),unknown end
    return true,tostring(#activeNames).."/"..tostring(#activeNames).." PAWN RESPONSES",0
end
-- Read-only audit metadata for ingame diagnosis and targeted regression tests.
HB.HaploRunBossAudit=function(dungeonID,bossIndex)
    local scan=dungeonID and scans[dungeonID]
    if not scan then return false,"NOT SCANNED",0 end
    return runBossAudit(scan,{index=bossIndex})
end
local function runEntries()
    local entries={}
    local d=runSelected
    if not d then return entries end
    local farm=HB.DungeonBiSForDungeon(d.id)
    if not farm then return entries end
    local scan=scans[d.id]
    local rs=runState()
    local opened=rs and rs.expanded[d.id] or {}
    local ordinal=0
    for _,boss in ipairs(runBosses(d)) do
        local targets=farm.byBoss[boss.index]
        -- A boss with no current party-BiS target does not exist in this view.
        if targets and #targets>0 then
            ordinal=ordinal+1
            local trusted,reason=runBossAudit(scan,boss)
            local expanded=opened[boss.name]~=false -- default expanded
            entries[#entries+1]={kind="boss",boss=boss,ordinal=ordinal,
                count=#targets,certified=trusted,reason=reason,
                expanded=expanded}
            if expanded then
                for _,target in ipairs(targets) do
                    local item=scan and scan.members[target.id]
                        and scan.members[target.id][target.name] or nil
                    local setKind=item and (item.why=="LOCK_TWO" and "2H"
                        or (item.why=="LOCK_ONE" and "1H+OFF" or nil))
                    entries[#entries+1]={kind="item",item={id=target.id,
                        name=target.name,pct=target.pct,slot=target.slot,need=target.need,
                        qualitative=target.bisNew,certified=not target.bisUncertain,
                        setKind=setKind,provisional=target.bisUncertain,
                        bossCoverageUncertain=not trusted or target.bisCoverageUncertain}}
                end
            end
        end
    end
    return entries
end

local function runToggleExpanded(bossName)
    if not runSelected then return end
    local rs=runState();if not rs then return end
    local opened=rs.expanded[runSelected.id] or {}
    rs.expanded[runSelected.id]=opened
    if opened[bossName]==false then opened[bossName]=nil
    else opened[bossName]=false end
    if runRefresh then runRefresh() end
end
local function runSelectPageRefresh()
    if not runSelector or not runSelector:IsShown() then return end
    rebuildVisible()
    local total=#visibleDungeons
    local maxStart=math.max(1,total-runChoiceRows.pageSize+1)
    runChooserPage=math.max(1,math.min(runChooserPage,maxStart))
    runChooserPageText:SetText(string.format("Dungeons %d-%d / %d",
        total>0 and runChooserPage or 0,math.min(total,runChooserPage+runChoiceRows.pageSize-1),total))
    HB.DungeonBiSView.SetScrollbar(runChoiceRows.scroll,runChooserPage,total,runChoiceRows.pageSize)
    for i,b in ipairs(runChoiceRows) do
        local d=i<=runChoiceRows.pageSize
            and visibleDungeons[runChooserPage+i-1] or nil
        if d then
            local farm=HB.DungeonBiSForDungeon(d.id)
            b.dungeon=d;b:SetText(pretty(d.name,43).."  ·  "..tostring(farm and farm.count or 0).." BiS targets")
            b:Show();btnState(b,runSelected and d.id==runSelected.id and "green" or "neutral")
        else b.dungeon=nil;b:Hide() end
    end
end
runRefresh=function()
    if not runFrame or not runFrame:IsShown() then return end
    local d=runSelected
    if not d then
        runStatus:SetText("Select a dungeon from the list.");return
    end
    if runRefreshTimerUI then runRefreshTimerUI() end
    runTitle:SetText(pretty(d.name,43).."  |cffb9aa81"..tostring(d.min).."+|r")
    if runFutureButton then
        runFutureButton:SetText(runShowFuture and "FUTURE ON" or "FUTURE OFF")
        btnState(runFutureButton,runShowFuture and "yellow" or "neutral")
    end
    local scan=scans[d.id]
    local quality=scan and (scan.stale and "STALE" or scanState(scan)) or "NOT SCANNED"
    local members=scan and scan.names or activeNames
    local checked,total=0,0
    if scan and scan.finished then
        local farm=HB.DungeonBiSForDungeon(d.id)
        for _,boss in ipairs(runBosses(d)) do
            if farm and farm.byBoss[boss.index] and #farm.byBoss[boss.index]>0 then
                total=total+1
                if runBossAudit(scan,boss) then checked=checked+1 end
            end
        end
    end
    local progress=allScan and allScan.running and allScan.scope=="selected"
        and allScan.queue[1] and allScan.queue[1].id==d.id
    if progress then
        runStatus:SetText("SCANNING...")
    elseif quality=="NOT SCANNED" then
        runStatus:SetText("NOT SCANNED")
    elseif quality=="STALE" then
        runStatus:SetText("UNVERIFIED · RESCAN")
        runStatus:SetTextColor(1,.35,.36)
    elseif checked==total and total>0 then
        runStatus:SetText("READY")
    else
        runStatus:SetText("UNVERIFIED")
        runStatus:SetTextColor(1,.35,.36)
    end
    if allScan and allScan.running then
        runScanButton:Disable();btnState(runScanButton,"disabled")
    else runScanButton:Enable();btnState(runScanButton,"green") end
    local entries=runEntries()
    if runRows and runRows.toggleAll then
        local hasBoss,anyOpen=false,false
        for _,entry in ipairs(entries) do
            if entry.kind=="boss" then
                hasBoss=true
                if entry.expanded then anyOpen=true end
            end
        end
        runRows.toggleAll:SetShown(hasBoss)
        runRows.toggleAll:SetText(anyOpen and "COLLAPSE ALL" or "EXPAND ALL")
    end
    if #entries==0 and scan and scan.finished and quality~="STALE" then
        runStatus:SetText("NO BIS TARGETS")
    end
    local maxStart=math.max(1,#entries-RUN_PAGE_SIZE+1)
    runPage=math.max(1,math.min(runPage,maxStart))
    runPageText:SetText(string.format("%d-%d / %d",#entries>0 and runPage or 0,
        math.min(runPage+RUN_PAGE_SIZE-1,#entries),#entries))
    HB.DungeonBiSView.SetScrollbar(runRows.scroll,runPage,#entries,RUN_PAGE_SIZE)
    for i,row in ipairs(runRows) do
        local e=i<=RUN_PAGE_SIZE and entries[runPage+i-1] or nil
        row.entry=e
        row.icon.ItemID=nil;row.icon:Hide()
        row.character:SetText("");row.percent:SetText("");row.pawnArrow:Hide();row.dice:Hide()
        row.subline:Hide()
        row:SetScript("OnEnter",nil);row:SetScript("OnLeave",nil)
        if not e then row:Hide()
        elseif e.kind=="boss" then
            row:Show();row.bg:SetColorTexture(.16,.16,.15,.88)
            row.name:SetWidth(math.max(96,row:GetWidth()-180))
            row.detail:SetWidth(96)
            row.name:SetText((e.expanded and "v " or "> ")..tostring(e.ordinal)..". "..pretty(e.boss.name,36).." ("..tostring(e.count or 0)..")")
            row.name:SetTextColor(.99,.83,.48)
            if e.certified then row.detail:SetText(tostring(e.count or 0).." OK")
            else row.detail:SetText("UNVERIFIED") end
            if e.certified then row.detail:SetTextColor(.38,.92,.42)
            else row.detail:SetTextColor(1,.35,.36) end
            row:SetScript("OnMouseUp",function(self,mouse)
                if mouse=="LeftButton" and self.entry and self.entry.kind=="boss" then
                    runToggleExpanded(self.entry.boss.name)
                end
            end)
        elseif e.kind=="item" then
            row:Show();row.bg:SetColorTexture(.075,.095,.12,.84)
            local item=e.item
            local nm,_,quality,_,_,itemType,itemSubType,_,itemInv,texture=info(item.id)
            if not nm then hydrate(item.id);nm="Item #"..item.id end
            row.name:SetWidth(math.max(96,row:GetWidth()-220))
            row.detail:SetText("")
            -- Truncate by available item-column width, preserving right-aligned percentages.
            local chars=math.max(13,math.min(70,math.floor((row:GetWidth()-220)/6.2)))
            row.name:SetText(pretty(nm,chars))
            local itemTypeLine=HB.DungeonBiSView.ItemTypeLine(itemInv,itemType,itemSubType)
            row.subline:SetText(pretty(itemTypeLine,chars))
            row.subline:SetShown(itemTypeLine~="")
            local r,g,b=.77,.80,.83
            if quality and type(GetItemQualityColor)=="function" then
                r,g,b=GetItemQualityColor(quality)
            end
            row.name:SetTextColor(r or 1,g or 1,b or 1)
            -- Match Pawn's visible whole-percent rounding; do not alter the
            -- underlying precise scores, audit gates or ranking decisions.
            local shownPct=item.pct and string.format("+%d%%",math.floor(item.pct+0.5)) or "EMPTY"
            local setTag=item.setKind and (item.setKind=="2H" and " 2H" or " 1H") or ""
            row.character:SetText(pretty(item.name,5)..setTag)
            local druid=_G.RAID_CLASS_COLORS and _G.RAID_CLASS_COLORS.DRUID
            row.character:SetTextColor(druid and druid.r or 1,druid and druid.g or .49,druid and druid.b or .04)
            if not item.certified or item.provisional then
                row.percent:SetText("UNVERIFIED")
                row.percent:SetTextColor(1,.35,.36)
                row.pawnArrow:Hide()
            else
                row.percent:SetText(shownPct)
                if item.pct then row.percent:SetTextColor(.30,.92,.45)
                else row.percent:SetTextColor(.98,.77,.35) end
                row.pawnArrow:Show()
            end
            row.dice:SetShown(item.need==true and item.certified and not item.provisional)
            row.icon.ItemID=item.id;row.icon.icon:SetTexture(texture or "Interface\\Icons\\INV_Misc_QuestionMark")
            row.icon.icon:SetTexCoord(.07,.93,.07,.93)
            row.icon:Show()
            HB.DungeonBiSView.StyleLootIcon(row.icon,quality)
            row:SetScript("OnMouseUp",nil)
        else
            row:Show();row.bg:SetColorTexture(.07,.09,.11,.7)
            row.name:SetText(e.unknown and "    Pawn results not yet complete" or "    No Pawn upgrades for Team A")
            row.name:SetTextColor(.56,.62,.66)
            row.detail:SetText("")
            row:SetScript("OnMouseUp",nil)
        end
    end
end
-- Update the lightweight timer widgets, without touching the expensive Pawn scan.
runRefreshTimerUI=function()
    if not runFrame then return end
    local timer=runActiveTimer()
    local active,total=runElapsed(timer)
    if timer then
        local paused=not timer.activeFrom
        local isNarrow=runFrame and runFrame:GetWidth()<450
        runHeaderTimer:SetText((timer.mode=="stealth"
            and (isNarrow and "S " or "STEALTH ")
            or (isNarrow and "N " or "NORMAL "))
            ..runTimeString(active)..(paused and " ||" or ""))
        runTimerLine:SetText(string.upper(timer.mode).."  "..runTimeString(active)
            .." active  /  "..runTimeString(total).." total"
            ..(paused and "  PAUSED" or ""))
        runHeaderPause:SetText(paused and ">" or "||")
        runHeaderPause:Show()
        runStealthButton:Hide();runNormalButton:Hide()
        runPauseButton:SetText(paused and "RESUME" or "PAUSE")
        runPauseButton:Show();runFinishButton:Show();runCancelButton:Show()
        runTimerSummary:SetText("")
    else
        runHeaderTimer:SetText("NO RUN")
        runTimerLine:SetText("")
        runHeaderPause:Hide()
        runStealthButton:Show();runNormalButton:Show()
        runPauseButton:Hide();runFinishButton:Hide();runCancelButton:Hide()
        local rs=runState()
        local last=nil
        for _,record in ipairs(rs and rs.history or {}) do
            if runSelected and record.dungeonID==runSelected.id then last=record;break end
        end
        if last then
            runTimerSummary:SetText("LAST "..string.upper(last.mode).." "
                ..runTimeString(last.activeSeconds).." active / "
                ..runTimeString(last.totalSeconds).." total")
        else runTimerSummary:SetText("") end
    end
end
runSetCollapsed=function(value)
    if not runFrame then return end
    local collapsed=value==true
    local rs=runState();if rs then rs.collapsed=collapsed end
    -- Preserve exact title-bar screen position when changing frame height.
    -- Center-anchored frames otherwise jump half the height difference.
    local left,top=runFrame:GetLeft(),runFrame:GetTop()
    if left and top then
        runFrame:ClearAllPoints()
        runFrame:SetPoint("TOPLEFT",UIParent,"BOTTOMLEFT",left,top)
        if rs then rs.left=left;rs.top=top end
    end
    runBody:SetShown(not collapsed)
    local preferred=rs and tonumber(rs.height) or RUN_HEIGHT
    preferred=math.max(405,preferred)
    runFrame:SetHeight(collapsed and RUN_COLLAPSED_HEIGHT or preferred)
    if runRows and runRows.sizeGrip then runRows.sizeGrip:SetShown(not collapsed) end
    runCollapseButton:SetText(collapsed and "+" or "-")
    if not collapsed and runRows and runRows.layout then runRows.layout() end
    if not collapsed and runRefresh then runRefresh() end
    if runRefreshTimerUI then runRefreshTimerUI() end
end
local function makeRunGuide()
    runRows={}
    runChoiceRows={pageSize=8}
    runFrame=CreateFrame("Frame","HaploBoxDungeonRunGuideHF26",UIParent)
    local rs=runState()
    local screenW,screenH=UIParent:GetWidth(),UIParent:GetHeight()
    local initialW=math.max(350,math.min(tonumber(rs and rs.width) or RUN_WIDTH,
        math.max(350,screenW-16)))
    local initialH=math.max(405,math.min(tonumber(rs and rs.height) or RUN_HEIGHT,
        math.max(405,screenH-16)))
    runFrame:SetSize(initialW,initialH);runFrame:SetClampedToScreen(true)
    runFrame:EnableMouse(true);runFrame:SetMovable(true)
    -- WoW classic/modern clients both support StartSizing; do not modify secure frames.
    if type(runFrame.SetResizable)=="function" then runFrame:SetResizable(true) end
    runFrame:SetFrameStrata("DIALOG");runFrame:SetFrameLevel(185)
    if HB.MenuStyle then HB.MenuStyle.Window(runFrame,32) end
    if rs and type(rs.left)=="number" and type(rs.top)=="number" then
        runFrame:SetPoint("TOPLEFT",UIParent,"BOTTOMLEFT",rs.left,rs.top)
    elseif rs and type(rs.offsetX)=="number" and type(rs.offsetY)=="number" then
        runFrame:SetPoint("CENTER",UIParent,"CENTER",rs.offsetX,rs.offsetY)
    else
        -- Right-hand docking default, then user can freely drag it into the Zygor spot.
        runFrame:SetPoint("TOPRIGHT",UIParent,"TOPRIGHT",-48,-115)
    end
    local titleBar=CreateFrame("Frame",nil,runFrame)
    titleBar:SetPoint("TOPLEFT");titleBar:SetPoint("TOPRIGHT");titleBar:SetHeight(32)
    titleBar:EnableMouse(true);titleBar:RegisterForDrag("LeftButton")
    titleBar:SetScript("OnDragStart",function()
        if not (InCombatLockdown and InCombatLockdown()) then runFrame:StartMoving() end
    end)
    titleBar:SetScript("OnDragStop",function()
        runFrame:StopMovingOrSizing()
        local x,y=runFrame:GetCenter()
        local db=runState()
        if db and x and y then
            db.offsetX=x-UIParent:GetWidth()/2
            db.offsetY=y-UIParent:GetHeight()/2
            db.left=runFrame:GetLeft()
            db.top=runFrame:GetTop()
        end
    end)
    runHeaderText=label(titleBar,"DUNGEON RUN",9,-9,165,true)
    runHeaderTimer=label(titleBar,"NO RUN",275,-10,166)
    runHeaderTimer:SetJustifyH("RIGHT")
    runHeaderPause=button(titleBar,"||",455,-4,24,23,runPauseOrResume)
    runCollapseButton=button(titleBar,"-",485,-4,24,23,function()
        local db=runState();runSetCollapsed(not (db and db.collapsed))
    end)
    runRows.closeButton=button(titleBar,"X",516,-4,24,23,function() runFrame:Hide() end)

    runBody=CreateFrame("Frame",nil,runFrame)
    runBody:SetPoint("TOPLEFT",runFrame,"TOPLEFT",0,-32)
    runBody:SetPoint("TOPRIGHT",runFrame,"TOPRIGHT",0,-32)
    runBody:SetPoint("BOTTOMLEFT",runFrame,"BOTTOMLEFT",0,0)
    label(runBody,"DUNGEON",13,-12,110)
    runTitle=label(runBody,"Select dungeon",13,-34,425,true)
    runTimerLine=label(runBody,"No active run",13,-64,510)
    runStealthButton=button(runBody,"START STEALTH",13,-86,127,25,function() runStartTimer("stealth") end)
    runNormalButton=button(runBody,"START NORMAL",146,-86,128,25,function() runStartTimer("normal") end)
    runPauseButton=button(runBody,"PAUSE",13,-86,87,25,runPauseOrResume)
    runFinishButton=button(runBody,"FINISH",107,-86,80,25,runFinishTimer)
    runCancelButton=button(runBody,"CANCEL",194,-86,80,25,runCancelTimer)
    runRows.historyButton=button(runBody,"RUNS",485,-86,51,25,runPrintHistory)
    runTimerSummary=label(runBody,"",13,-117,510)
    runScanButton=button(runBody,"SCAN PARTY BIS",13,-145,170,26,function()
        startAllScan("available")
    end)
    runRows.toggleAll=button(runBody,"COLLAPSE ALL",191,-145,129,26,function()
        if not runSelected then return end
        local db=runState();if not db then return end
        local farm=HB.DungeonBiSForDungeon(runSelected.id)
        if not farm then return end
        local opened=db.expanded[runSelected.id] or {}
        db.expanded[runSelected.id]=opened
        local anyOpen=false
        for _,boss in ipairs(runBosses(runSelected)) do
            if farm.byBoss[boss.index] and #farm.byBoss[boss.index]>0
                and opened[boss.name]~=false then anyOpen=true;break end
        end
        for _,boss in ipairs(runBosses(runSelected)) do
            if farm.byBoss[boss.index] and #farm.byBoss[boss.index]>0 then
                if anyOpen then opened[boss.name]=false else opened[boss.name]=nil end
            end
        end
        runPage=1;runRefresh()
    end)
    -- Current-level objectives only. No misleading future-item toggle.
    runStatus=label(runBody,"",13,-178,510)
    runStatus:SetHeight(39);runStatus:SetJustifyV("TOP")
    local shade=runBody:CreateTexture(nil,"ARTWORK")
    shade:SetPoint("TOPLEFT",runBody,"TOPLEFT",12,-218)
    shade:SetPoint("TOPRIGHT",runBody,"TOPRIGHT",-12,-218)
    shade:SetHeight(1);shade:SetColorTexture(.7,.51,.25,.8)
    for i=1,26 do
        local row=CreateFrame("Frame",nil,runBody)
        row:SetPoint("TOPLEFT",runBody,"TOPLEFT",13,-225-(i-1)*30)
        row:SetSize(522,28);row:EnableMouse(true)
        row.bg=row:CreateTexture(nil,"BACKGROUND");row.bg:SetAllPoints()
        row.bg:SetColorTexture(.08,.1,.12,.8)
        row.name=smallText(row,245,34,"LEFT")
        row.name:ClearAllPoints();row.name:SetPoint("LEFT",row,"LEFT",34,6)
        row.subline=smallText(row,245,34,"LEFT")
        row.subline:ClearAllPoints();row.subline:SetPoint("LEFT",row,"LEFT",34,-7)
        row.subline:SetTextColor(.56,.62,.68);row.subline:Hide()
        row.detail=smallText(row,96,385,"RIGHT")
        row.character=smallText(row,106,283,"LEFT")
        row.dice=row:CreateTexture(nil,"OVERLAY")
        row.dice:SetPoint("LEFT",row,"LEFT",378,0)
        row.dice:SetSize(16,16)
        row.dice:SetTexture(ICON_NEED)
        row.dice:Hide()
        row.pawnArrow=row:CreateTexture(nil,"OVERLAY")
        row.pawnArrow:SetPoint("LEFT",row,"LEFT",399,0)
        row.pawnArrow:SetSize(16,16)
        row.pawnArrow:SetTexture("Interface\\AddOns\\Pawn\\Textures\\UpgradeArrow")
        row.pawnArrow:Hide()
        row.percent=smallText(row,78,416,"RIGHT")
        row.icon=CreateFrame("Button",nil,row)
        row.icon:SetSize(23,23);row.icon:SetPoint("LEFT",row,"LEFT",5,0)
        row.icon.icon=row.icon:CreateTexture(nil,"ARTWORK");row.icon.icon:SetAllPoints()
        row.icon:SetScript("OnEnter",function(self)
            if not (self.ItemID and GameTooltip) then return end
            GameTooltip:SetOwner(self,"ANCHOR_CURSOR")
            local ok=pcall(GameTooltip.SetHyperlink,GameTooltip,"item:"..tostring(self.ItemID))
            if ok then GameTooltip:Show() end
        end)
        row.icon:SetScript("OnLeave",function() if GameTooltip then GameTooltip:Hide() end end)
        runRows[i]=row;row:Hide()
    end
    runRows.prevButton=button(runBody,"<",13,-560,30,24,function()
        runPage=math.max(1,runPage-RUN_PAGE_SIZE);runRefresh()
    end)
    runRows.nextButton=button(runBody,">",49,-560,30,24,function()
        runPage=runPage+RUN_PAGE_SIZE;runRefresh()
    end)
    runPageText=label(runBody,"",91,-565,120)
    runRows.footerText=label(runBody,"",13,-592,510)
    runRows.prevButton:Hide();runRows.nextButton:Hide()
    runPageText:Hide();runRows.footerText:Hide()
    -- Selector stays inside the collapsible body. No new Blizzard frames or scanners.
    runSelector=CreateFrame("Frame",nil,runBody)
    runSelector:SetPoint("TOPLEFT",runBody,"TOPLEFT",6,-4)
    runSelector:SetPoint("BOTTOMRIGHT",runBody,"BOTTOMRIGHT",-6,7)
    runSelector:SetFrameLevel(runBody:GetFrameLevel()+15)
    runSelector:EnableMouse(true)
    local cover=runSelector:CreateTexture(nil,"BACKGROUND");cover:SetAllPoints()
    cover:SetColorTexture(.035,.058,.079,.985)
    runChoiceRows.title=label(runSelector,"CHOOSE BIS FARM DUNGEON",13,-12,470,true)
    runChoiceRows.closeButton=button(runSelector,"X",502,-8,27,23,function() runSelector:Hide() end)
    for i=1,8 do
        local choice=button(runSelector,"",13,-52-(i-1)*48,505,40,function(self)
            if self.dungeon then
                runSetSelected(self.dungeon)
                runSelector:Hide()
            end
        end)
        runChoiceRows[i]=choice
    end
    runChoiceRows.prevButton=button(runSelector,"<",13,-456,31,24,function()
        runChooserPage=math.max(1,runChooserPage-runChoiceRows.pageSize);runSelectPageRefresh()
    end)
    runChoiceRows.nextButton=button(runSelector,">",49,-456,31,24,function()
        runChooserPage=runChooserPage+runChoiceRows.pageSize;runSelectPageRefresh()
    end)
    runChooserPageText=label(runSelector,"",96,-462,215)
    runChoiceRows.prevButton:Hide();runChoiceRows.nextButton:Hide()
    runChooserPageText:Hide()
    runRows.scroll=HB.DungeonBiSView.NewScrollbar(runBody,function(value)
        runPage=value;runRefresh()
    end)
    runChoiceRows.scroll=HB.DungeonBiSView.NewScrollbar(runSelector,function(value)
        runChooserPage=value;runSelectPageRefresh()
    end)
    local function wheelRun(_,delta)
        if runSelector and runSelector:IsShown() then return end
        local count=#runEntries()
        runPage=math.max(1,math.min(math.max(1,count-RUN_PAGE_SIZE+1),
            runPage-(delta>0 and 2 or -2)))
        runRefresh()
    end
    local function wheelSelector(_,delta)
        rebuildVisible()
        runChooserPage=math.max(1,math.min(math.max(1,#visibleDungeons-runChoiceRows.pageSize+1),
            runChooserPage-(delta>0 and 2 or -2)))
        runSelectPageRefresh()
    end
    runBody:EnableMouseWheel(true);runBody:SetScript("OnMouseWheel",wheelRun)
    for _,row in ipairs(runRows) do
        row:EnableMouseWheel(true);row:SetScript("OnMouseWheel",wheelRun)
        row.icon:EnableMouseWheel(true);row.icon:SetScript("OnMouseWheel",wheelRun)
    end
    runSelector:EnableMouseWheel(true);runSelector:SetScript("OnMouseWheel",wheelSelector)
    for _,row in ipairs(runChoiceRows) do
        row:EnableMouseWheel(true);row:SetScript("OnMouseWheel",wheelSelector)
    end
    runSelector:Hide()

    -- Reflow only the Run Guide: anchored action buttons, aligned item/character/
    -- Pawn-percent columns, and rows/pagination matched to actual window height.
    runRows.layout=function()
        if not runFrame or not runBody then return end
        local width=runFrame:GetWidth()
        local bodyHeight=runBody:GetHeight()
        if bodyHeight<1 then return end
        local rowWidth=math.max(324,width-26)
        RUN_PAGE_SIZE=math.max(1,math.min(26,
            math.floor((bodyHeight-225-46)/30)))
        runChoiceRows.pageSize=math.max(1,math.min(#runChoiceRows,
            math.floor((bodyHeight-145)/48)))
        local function topRight(widget,x,y)
            widget:ClearAllPoints()
            widget:SetPoint("TOPRIGHT",widget:GetParent(),"TOPRIGHT",x,y)
        end
        topRight(runRows.closeButton,-8,-4)
        topRight(runCollapseButton,-39,-4)
        topRight(runHeaderPause,-69,-4)
        topRight(runHeaderTimer,-107,-10)
        -- At 350-449px keep the title and timer out of one another.
        runHeaderText:SetWidth(width<450 and 125 or 165)
        runHeaderTimer:SetWidth(width<450 and 104 or 166)
        topRight(runRows.historyButton,-12,-86)
        runTitle:SetWidth(math.max(200,width-123))
        runTimerLine:SetWidth(math.max(220,width-38))
        runTimerSummary:SetWidth(math.max(220,width-38))
        runStatus:SetWidth(math.max(220,width-38))
        runRows.scroll:ClearAllPoints()
        runRows.scroll:SetPoint("TOPRIGHT",runBody,"TOPRIGHT",-5,-225)
        runRows.scroll:SetHeight(math.max(60,RUN_PAGE_SIZE*30-5))
        runChoiceRows.scroll:ClearAllPoints()
        runChoiceRows.scroll:SetPoint("TOPRIGHT",runSelector,"TOPRIGHT",-4,-52)
        runChoiceRows.scroll:SetHeight(math.max(60,runChoiceRows.pageSize*48-8))
        for i,row in ipairs(runRows) do
            row:SetWidth(rowWidth-8)
            row.name:SetWidth(math.max(96,rowWidth-220))
            row.subline:SetWidth(math.max(96,rowWidth-220))
            row.character:ClearAllPoints()
            row.character:SetPoint("LEFT",row,"LEFT",rowWidth-180,0)
            row.character:SetWidth(56)
            row.dice:ClearAllPoints()
            row.dice:SetPoint("LEFT",row,"LEFT",rowWidth-143,0)
            row.pawnArrow:ClearAllPoints()
            row.pawnArrow:SetPoint("LEFT",row,"LEFT",rowWidth-124,0)
            row.percent:ClearAllPoints()
            row.percent:SetPoint("LEFT",row,"LEFT",rowWidth-105,0)
            row.percent:SetWidth(75)
            row.detail:ClearAllPoints()
            row.detail:SetPoint("LEFT",row,"LEFT",rowWidth-137,0)
            row.detail:SetWidth(88)
            if i>RUN_PAGE_SIZE then row:Hide() end
        end
        runRows.prevButton:ClearAllPoints()
        runRows.prevButton:SetPoint("BOTTOMLEFT",runBody,"BOTTOMLEFT",13,22)
        runRows.nextButton:ClearAllPoints()
        runRows.nextButton:SetPoint("BOTTOMLEFT",runBody,"BOTTOMLEFT",49,22)
        runPageText:ClearAllPoints()
        runPageText:SetPoint("BOTTOMLEFT",runBody,"BOTTOMLEFT",91,27)
        runRows.footerText:ClearAllPoints()
        runRows.footerText:SetPoint("BOTTOMLEFT",runBody,"BOTTOMLEFT",13,7)
        runRows.footerText:SetWidth(math.max(200,width-46))
        runChoiceRows.title:SetWidth(math.max(180,width-78))
        topRight(runChoiceRows.closeButton,-9,-8)
        for i,choice in ipairs(runChoiceRows) do
            choice:SetWidth(math.max(220,width-62))
            if i>runChoiceRows.pageSize then choice:Hide() end
        end
        runChoiceRows.prevButton:ClearAllPoints()
        runChoiceRows.prevButton:SetPoint("BOTTOMLEFT",runSelector,"BOTTOMLEFT",13,25)
        runChoiceRows.nextButton:ClearAllPoints()
        runChoiceRows.nextButton:SetPoint("BOTTOMLEFT",runSelector,"BOTTOMLEFT",49,25)
        runChooserPageText:ClearAllPoints()
        runChooserPageText:SetPoint("BOTTOMLEFT",runSelector,"BOTTOMLEFT",96,30)
    end

    runRows.sizeGrip=CreateFrame("Button",nil,runFrame)
    runRows.sizeGrip:SetSize(18,18)
    runRows.sizeGrip:SetPoint("BOTTOMRIGHT",runFrame,"BOTTOMRIGHT",-2,2)
    runRows.sizeGrip:SetFrameLevel(runFrame:GetFrameLevel()+25)
    runRows.sizeGrip:SetNormalTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Up")
    runRows.sizeGrip:SetHighlightTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Highlight")
    runRows.sizeGrip:SetPushedTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Down")
    runRows.sizeGrip:RegisterForDrag("LeftButton")
    runRows.sizeGrip:SetScript("OnDragStart",function()
        if InCombatLockdown and InCombatLockdown() then return end
        -- Pin the top-left corner: resizing must not push the guide across screen.
        local left,top=runFrame:GetLeft(),runFrame:GetTop()
        if left and top then
            runFrame:ClearAllPoints()
            runFrame:SetPoint("TOPLEFT",UIParent,"BOTTOMLEFT",left,top)
        end
        runFrame:StartSizing("BOTTOMRIGHT")
    end)
    local function finishResize()
        runFrame:StopMovingOrSizing()
        local db=runState()
        if db and not db.collapsed then
            db.width=math.floor(runFrame:GetWidth()+.5)
            db.height=math.floor(runFrame:GetHeight()+.5)
            db.left=runFrame:GetLeft()
            db.top=runFrame:GetTop()
        end
        runRows.layout()
        if runRefresh then runRefresh() end
        if runSelector and runSelector:IsShown() then runSelectPageRefresh() end
    end
    runRows.sizeGrip:SetScript("OnDragStop",finishResize)
    runRows.sizeGrip:SetScript("OnMouseUp",finishResize)
    runFrame:SetScript("OnSizeChanged",function(self,width,height)
        local db=runState()
        if db and not db.collapsed then
            local cappedW=math.max(350,math.min(width,
                math.max(350,UIParent:GetWidth()-16)))
            local cappedH=math.max(405,math.min(height,
                math.max(405,UIParent:GetHeight()-16)))
            if math.abs(cappedW-width)>.5 or math.abs(cappedH-height)>.5 then
                self:SetSize(cappedW,cappedH)
                return
            end
            db.width=math.floor(width+.5)
            db.height=math.floor(height+.5)
        end
        if not (db and db.collapsed) then runRows.layout() end
    end)
    runRows.layout()
    local uiTimerElapsed=0
    runFrame:SetScript("OnUpdate",function(self,elapsed)
        if not runActiveTimer() then return end
        uiTimerElapsed=uiTimerElapsed+(elapsed or 0)
        if uiTimerElapsed>=.45 then
            uiTimerElapsed=0
            if runRefreshTimerUI then runRefreshTimerUI() end
        end
    end)
    runFrame:SetScript("OnShow",function()
        local ok,msg=runEnsureSelected()
        if not ok then runStatus:SetText(msg) end
        local db=runState()
        runSetCollapsed(db and db.collapsed==true)
        if ok then runRefresh() end
    end)
    runSetCollapsed(rs and rs.collapsed==true)
    runFrame:Hide()
end
function HB.OpenDungeonBiSRun(d)
    if me()~="Mael" or not d then return end
    if not runFrame then makeRunGuide() end
    if runActiveTimer() and runActiveTimer().dungeonID~=d.id then
        say("Finish or cancel the current run before changing dungeons.");return
    end
    runSetSelected(d)
    runFrame:Show()
    if runRefresh then runRefresh() end
end
function HB.ToggleDungeonRunGuide()
    if me()~="Mael" then say("Open Run Guide on Mael (Team A leader).") return end
    if not runFrame then makeRunGuide() end
    if runFrame:IsShown() then runFrame:Hide() else runFrame:Show() end
end
SLASH_HAPLO_RUN_GUIDE1="/hbrun"
SlashCmdList.HAPLO_RUN_GUIDE=function() HB.ToggleDungeonRunGuide() end
-- Test-only read-only view of entries; no forced scans, no network side effects.
HB.HaploRunGuideDebug=function()
    return runSelected and runSelected.id,runEntries(),runFrame and runFrame:IsShown()
end
SLASH_HAPLO_RUN_AUDIT1="/hbrunaudit"
SlashCmdList.HAPLO_RUN_AUDIT=function()
    if not runSelected then say("Open /hbrun and select a dungeon first.");return end
    local scan=scans[runSelected.id]
    say("Run Guide Pawn audit: "..tostring(runSelected.name))
    for _,boss in ipairs(runBosses(runSelected)) do
        local ok,why,count=runBossAudit(scan,boss)
        say((ok and "OK " or "CHECK ")..pretty(boss.name,31)..": "..why)
    end
end

-- Optional diagnostics, no second public browser entry in the standard Quick Menu.
function HB.LootPlannerRescan() if me()=="Mael" then startAllScan(scanScope) end end
-- HF26.20.35: read-only full-scan coverage report. A missing recommendation
-- must be explainable as NOUP, NEEDPAIR, unresolved, owned, or absent loot.
SLASH_HAPLO_BIS_COVERAGE1="/hbbiscoverage"
SlashCmdList.HAPLO_BIS_COVERAGE=function(arg)
    if me()~="Mael" then say("Run /hbbiscoverage on Mael after SCAN PARTY BIS.");return end
    if allScan and allScan.running then say("Coverage pending: scan in progress.");return end
    local filter=tostring(arg or ""):match("^%s*(.-)%s*$")
    local selected={}
    for _,name in ipairs(names) do
        if filter=="" or filter:lower()==name:lower() then selected[#selected+1]=name end
    end
    if #selected==0 then say("Use /hbbiscoverage [Mael|Lyra|Elya|Nyra|Ayla].");return end
    local types={TWO="2H",MAIN="1H",OFF="Off-Hand",RING="Ring"}
    local groups={"TWO","MAIN","OFF","RING"}
    for _,name in ipairs(selected) do
        local counts={};local complete=0;local incomplete=0
        for _,key in ipairs(groups) do counts[key]={total=0,codes={}} end
        for _,d in ipairs(dungeons) do
            local scan=scans[d.id]
            if scan and scan.finished and not scan.stale and not scan.incomplete
                and not scan.missingGroup and scan.levels[name]
                and scan.levels[name]>=d.min then
                complete=complete+1
                for id,members in pairs(scan.members or {}) do
                    local r=members[name]
                    if r then
                        local _,_,_,_,_,_,_,_,inv=info(id)
                        local key=inv=="INVTYPE_2HWEAPON" and "TWO"
                            or ((inv=="INVTYPE_WEAPON" or inv=="INVTYPE_WEAPONMAINHAND") and "MAIN")
                            or (inv=="INVTYPE_HOLDABLE" and "OFF")
                            or (inv=="INVTYPE_FINGER" and "RING") or nil
                        if key then
                            local bucket=counts[key]
                            bucket.total=bucket.total+1
                            local code=HB.DungeonBiSView.CoverageStatus(id,r)
                            bucket.codes[code]=(bucket.codes[code] or 0)+1
                        end
                    end
                end
            elseif d.min<=((allScan and allScan.maxLevel) or 0) then incomplete=incomplete+1 end
        end
        say("COVERAGE "..name.." dungeons="..complete.." unresolved="..incomplete
            .." (only candidates sent to Pawn; prefiltered loot not included)")
        for _,key in ipairs(groups) do
            local b=counts[key];local results={}
            for status,n in pairs(b.codes) do results[#results+1]=status.."="..n end
            table.sort(results)
            say(types[key].." scanned="..b.total.." "..(#results>0 and table.concat(results," ") or "NO CANDIDATES"))
        end
    end
end
-- Small, on-demand audit: exact item ID, character and Pawn failure reason.
local function auditRows(scan,mode)
    local rows={}
    if not scan or not scan.members then return rows end
    for id,members in pairs(scan.members) do
        for _,name in ipairs(names) do
            local r=members[name]
            if r and ((mode=="nostats" and r.status=="NOSTATS") or
                (mode=="review" and (r.status=="VERIFY" or isUnverifiedHigh(r)))) then
                rows[#rows+1]={id=id,name=name,r=r}
            end
        end
    end
    table.sort(rows,function(a,b) if a.id==b.id then return a.name<b.name end return a.id<b.id end)
    return rows
end
local function printAudit(scan,mode)
    local rows=auditRows(scan,mode)
    say(string.upper(mode).." records="..#rows.."; IDs and names refer to the selected dungeon.")
    for i=1,math.min(#rows,20) do
        local entry=rows[i]
        local itemName=info(entry.id) or ("Item #"..entry.id)
        if mode=="nostats" then
            say(entry.name.." #"..entry.id.." "..pretty(itemName,29).." · "..tostring(entry.r.why or "UNKNOWN"))
        else
            local r=entry.r
            say(entry.name.." #"..entry.id.." "..pretty(itemName,24)
                ..string.format(" VERIFY pct=%s raw=%.4f equipped=%.4f slot=%s why=%s",
                    r.pct and string.format("+%.1f%%",r.pct) or "?",r.raw or -1,
                    r.baseline or -1,tostring(r.slot),tostring(r.why or "UNKNOWN")))
        end
    end
    if #rows>20 then say("..."..(#rows-20).." more records; select a narrower dungeon.") end
end
-- A separate, protected command for scale diagnosis. The very first line is
-- emitted before accessing Pawn, so a failed Pawn API cannot result in silence.
-- This is deliberately independent of the stable /hb dispatcher and does not
-- modify Pawn settings or guess stat weights.
local function reportPawnScales()
    say("HF26.10 Pawn role diagnostic START | character="..tostring(UnitName("player")))
    local current=me()
    say("Team="..tostring(current or "NOT RECOGNIZED").." | intended role="..tostring(roles[current] or "UNKNOWN")
        .." | target spec="..tostring(specForRole[roles[current]] or "UNKNOWN"))
    local pawn=_G.PawnCommon
    if type(pawn)~="table" or type(pawn.Scales)~="table" then
        say("Pawn scales NOT AVAILABLE on this client; verify Pawn is enabled and loaded.")
        return
    end
    local keys={}
    for label,scale in pairs(pawn.Scales) do
        if type(label)=="string" and type(scale)=="table" then keys[#keys+1]=label end
    end
    table.sort(keys)
    say("Pawn scales found="..tostring(#keys).." | showing first 16 below")
    local ok,chosenOrError=pcall(chooseScale)
    if ok then
        say("Haplo Loot selected="..tostring(chosenOrError or "NONE")
            .." | role candidates="..tostring(scaleDiagnostics[current] or "none"))
    else
        say("ERROR while selecting scale: "..tostring(chosenOrError))
    end
    local manual=HB and HB.db and HB.db.lootPlannerScales and HB.db.lootPlannerScales[current]
    local legacy=HB and HB.db and HB.db.lootAdvisorScale
    say("Manual selection="..tostring(manual or "none").." | old LootAdvisor selection="..tostring(legacy or "none"))
    local spec=specForRole[roles[current]]
    local target=spec and ('"Classic":DRUID'..spec) or nil
    local scale=target and pawn.Scales[target]
    local selected=ok and chosenOrError and pawn.Scales[chosenOrError]
    say("TARGET="..tostring(target or "N/A").." | exists="..tostring(scale~=nil)
        .." | visible="..tostring(target and pawnVisible(target) or false))
    if type(selected)=="table" then
        local v=selected.Values or {}
        say("SELECTED="..tostring(chosenOrError).." class="..tostring(selected.ClassID)
            .." spec="..tostring(selected.SpecID).." provider="..tostring(selected.Provider)
            .." visible="..tostring(pawnVisible(chosenOrError)))
        if spec==3 then
            say("FOREVER anchors: Stamina="..tostring(v.Stamina).." Agility="..tostring(v.Agility)
                .." MeleeDps="..tostring(v.MeleeDps).." DefenseRating="..tostring(v.DefenseRating))
        elseif spec==4 then
            say("FOREVER anchors: Intellect="..tostring(v.Intellect).." Spirit="..tostring(v.Spirit)
                .." Healing="..tostring(v.Healing).." Mp5="..tostring(v.Mp5))
        elseif spec==1 then
            say("FOREVER anchors: Intellect="..tostring(v.Intellect).." Spirit="..tostring(v.Spirit)
                .." SpellDamage="..tostring(v.SpellDamage).." SpellHitRating="..tostring(v.SpellHitRating))
        end
    else
        say("NO VALID ROLE SCALE - upgrades remain UNKNOWN. Check Pawn scale visibility.")
    end
    for i=1,math.min(16,#keys) do
        local label=keys[i]
        local scale=pawn.Scales[label]
        local class=scale and scale.ClassID
        local spec=scale and scale.SpecID
        local flag=(ok and chosenOrError==label) and " [SELECTED]" or ""
        say(tostring(i)..". "..pretty(label,55).." class="..tostring(class)
            .." spec="..tostring(spec).." values="..tostring(type(scale and scale.Values))..flag)
    end
    if #keys>16 then say("..."..tostring(#keys-16).." additional scales") end
end
SLASH_HAPLOSCALEREPORT1="/hbscales"
SlashCmdList.HAPLOSCALEREPORT=reportPawnScales
-- Standalone command so we do NOT touch the stable Core.lua /hb slash dispatcher.
SLASH_HAPLOLOOTNET1="/hblootnet"
SlashCmdList.HAPLOLOOTNET=function(arg)
    arg=(arg or ""):lower():match("^%s*(.-)%s*$")
    if arg=="scales" then reportPawnScales(); return end
    local inspectID=tonumber(arg:match("^inspect%s+(%d+)$"))
    if inspectID and inspectID>0 and inspectID<=3000000 then
        local nm,link,_,_,required,_,_,_,inv,_,_,classID,subclassID=info(inspectID)
        say(string.format("Inspect #%d: %s req=%s inv=%s class=%s subclass=%s link=%s",
            inspectID,pretty(nm or "NOT CACHED",32),tostring(required),tostring(inv),
            tostring(classID),tostring(subclassID),link and "YES" or "NO"))
        if link and type(PawnCanItemHaveStats)=="function" then
            local ok,v=pcall(PawnCanItemHaveStats,link)
            say("PawnCanItemHaveStats="..(ok and tostring(v) or ("ERROR: "..tostring(v))))
        end
        local s=chooseScale()
        say("Pawn scale="..tostring(s or "NONE").." role="..tostring(roles[me()]))
        if link and s then
            local value,rawItem,why=pawnValue(link,s)
            say("Pawn parser="..tostring(why).." score="..tostring(value)
                .." itemStats="..tostring(rawItem and type(rawItem.Stats) or "NONE"))
            if rawItem then
                local official,src=pawnTooltipPercent(rawItem,s)
                say("Pawn tooltip source="..tostring(src).." upgrade%="..tostring(official)
                    .." (source is PawnIsItemAnUpgrade; manual equipped ratio is NOT tooltip)")
            end
        end
        local code,pct,group,req,lvl,raw,weaponBase,why,baseline=evaluate(inspectID)
        say(string.format("Current evaluation: %s pct=%s raw=%s equipped=%s slot=%s source=%s",
            tostring(code),tostring(pct),tostring(raw),tostring(baseline),
            tostring(group),tostring(why)))
    end
    if arg=="diag" then
        local cacheItems,cacheRequests=cacheCount()
        say("Cache pending locally: "..cacheItems.." item IDs / "..cacheRequests.." scan requests; resolved="..cacheResolvedCount.."; event + max "..CACHE_PULSE_MAX.."s fallback.")
    end
    if (arg=="nostats" or arg=="review") and me()=="Mael" then
        printAudit(chosen and scans[chosen.id],arg)
    end
    if arg=="diag" and me()=="Mael" then
        local current=chosen and scans[chosen.id]
        say("Dungeon="..tostring(chosen and pretty(chosen.name,40)).." state="..scanState(current))
        say("Reasons: "..diagnosticSummary(current))
        local first=current and current.requestStats
        if first then
            say(string.format("Selected scan first wave: addressed sent=%d failed=%d skipped=%d unique items=%d",
                first.sent,first.failed,first.skipped,#(current.queue or {})))
            local counts={}
            for _,member in ipairs(scanMembers(current)) do
                local seen=0
                for _,itemID in ipairs(current.queue or {}) do
                    if current.members[itemID] and current.members[itemID][member] then seen=seen+1 end
                end
                counts[#counts+1]=member.." "..seen.."/"..#(current.queue or {})
                    ..(member=="Mael" and " local" or " initialQ="..(first.byFollower[member] or 0))
            end
            say("Selected scan Pawn coverage: "..table.concat(counts,"; "))
        end
        local metrics=current and current.retryStats
        if metrics then
            local missingNow=0
            for _,itemID in ipairs(current.queue or {}) do
                local people=current.members and current.members[itemID] or {}
                for _,name in ipairs(scanMembers(current)) do if not people[name] then missingNow=missingNow+1 end end
            end
            say(string.format("Selected scan retries: %d rounds, sent=%d failed=%d skipped=%d missing at finish=%d, now=%d",
                metrics.rounds,metrics.sent,metrics.failed,metrics.skipped,metrics.missing,missingNow))
        end
        local raw,count,peak,newCount=0,0,0,0
        local idx,opps=0,0
        if chosen then
            raw,count,peak,newCount=scoreDungeon(chosen)
            idx,opps=gearIndex(chosen)
        end
        say(string.format("Verified: %d upgrades, %d new slots, peak +%.1f%%; slot index %.2f/%d opportunities; legacy raw sum %.1f (NOT priority)",
            count or 0,newCount or 0,peak or 0,idx or 0,opps or 0,raw or 0))
        if current then printAudit(current,"nostats"); printAudit(current,"review") end
        if current and current.weaponPairs then
            for _,name in ipairs(names) do
                local pair=current.weaponPairs[name]
                if pair then
                    say(name.." paired "..pair.main.."+"..pair.off.." -> "
                      ..(pair.pct and string.format("+%.1f%%",pair.pct) or "NEW SET (no %)") )
                end
            end
        end
    end
    if arg=="ping" then
        local token=math.floor(((type(GetTime)=="function" and GetTime()) or 0)*100)%1000000
        net.pingToken=token;net.acks={}
        say("PING sent="..tostring(addonMessage("P|"..token.."|"..PROTOCOL)))
    end
    local ack={}
    for _,name in ipairs(names) do if name~="Mael" then
        ack[#ack+1]=name.."="..(net.acks[name] or "--")
    end end
    say(PROTOCOL.." local="..tostring(me()).." grouped="..tostring(IsInGroup and IsInGroup())
        .." channel="..tostring(channelForParty()).." prefix="..tostring(net.registered))
    say("sent="..net.sends.." sendFailed="..net.failures.." recv="..net.received
        .." recognized="..net.recognized.." rejected="..net.rejected.." malformed="..net.malformed
        .." requests="..net.requests.." repliesSent="..net.replies)
    if me()~="Mael" then
        say("Pawn requests: addressed="..net.requestsTargeted
            .." broadcast="..net.requestsBroadcast
            .." ignored-other-target="..net.requestsOtherTarget
            .." invalid="..net.requestsMalformed)
        say("B batches="..batch.requestsReceived.." V packets sent="..batch.sent
            .." packetFail="..batch.failed.." pending="..#batch.sendQueue
            .." legacyFallback="..batch.fallbackSent)
    else
        say("Initial addressed Q: sent="..net.firstWaveSent
            .." failed="..net.firstWaveFailed)
        say("Batch interval: "..string.format("%.2fs",ITEM_SPACING).." per addressed B, up to "..batch.size.." items; follower reply pacing "..batch.replyInterval.."s")
        say("Batch packets: Q sent="..batch.requestsSent.." retry="..batch.retryRequestsSent
            .." V received="..batch.packetsReceived.." rows="..batch.rowsReceived)
        say("Pawn replies: applied="..net.replyAccepted.." duplicate="..net.replyDuplicate
            .." oldScan="..net.replyUnknownScan.." unexpected="..net.replyUnexpected
            .." lateCache="..net.replyLateCache)
        say("Targeted retries: sent="..net.retrySent.." failed="..net.retryFailed
            .." skipped="..net.retrySkipped)
        if net.lastReplyIssue then say("Last ignored Pawn reply: "..net.lastReplyIssue) end
    end
    if net.lastRejected then say("last rejected sender="..tostring(net.lastRejected)) end
    say("last sender="..tostring(net.lastSender).." last channel="..tostring(net.lastChannel)
        .." last msg="..tostring(net.lastRecv).." last send error="..tostring(net.lastSendError))
    say("PING ACKs: "..table.concat(ack,", "))
    if net.registerError then say("Prefix issue: "..net.registerError) end
end
local events=CreateFrame("Frame")
events:RegisterEvent("PLAYER_LOGIN")
events:RegisterEvent("CHAT_MSG_ADDON")
events:RegisterEvent("PLAYER_EQUIPMENT_CHANGED")
events:RegisterEvent("PLAYER_LEVEL_UP")
pcall(events.RegisterEvent,events,"BAG_UPDATE_DELAYED")
-- Register only when the custom client supports these events.
pcall(events.RegisterEvent,events,"GET_ITEM_INFO_RECEIVED")
pcall(events.RegisterEvent,events,"ITEM_DATA_LOAD_RESULT")
events:SetScript("OnEvent",function(_,event,...)
    if event=="GET_ITEM_INFO_RECEIVED" or event=="ITEM_DATA_LOAD_RESULT" then
        local itemID=tonumber((...))
        if itemID then cacheCheckItem(itemID) end
        return
    end
    if event=="PLAYER_LOGIN" then
        registerPrefix()
        return
    end
    if event=="BAG_UPDATE_DELAYED" then
        if HB.LootUnique.OnInventoryChange() then
            wipe(evalCache)
            if me()=="Mael" then markStale("Mael")
            elseif roster[me()] then addonMessage("I") end
            if runRefresh then runRefresh() end
        end
        return
    end
    if event=="PLAYER_EQUIPMENT_CHANGED" or event=="PLAYER_LEVEL_UP" then
        HB.LootUnique.inventoryMap=nil
        wipe(evalCache)
        if me()=="Mael" then markStale("Mael");if frame and frame:IsShown() then refresh() end
        elseif roster[me()] then
            -- Equipment/level events are infrequent and correctness-critical.
            -- Do not drop a second change inside the old 2-second throttle.
            addonMessage("I")
        end
        -- Client-side event invalidation will be sent on next explicit request as well.
        if runRefresh then runRefresh() end
        return
    end
    local prefix,msg,channel,sender=...
    if prefix~=addonPrefix or type(msg)~="string" then return end
    -- A valid party can use PARTY, RAID, or INSTANCE_CHAT; do not silently drop those.
    if channel~="PARTY" and channel~="RAID" and channel~="INSTANCE_CHAT" then return end
    net.received=net.received+1;net.lastRecv=msg:sub(1,90);net.lastSender=sender;net.lastChannel=channel
    if not (IsInGroup and IsInGroup()) then return end
    local from=canonicalTeamName(sender)
    if not from then
        net.rejected=net.rejected+1;net.lastRejected=tostring(sender)
        return
    end
    net.recognized=net.recognized+1
    local kind=msg:sub(1,2)
    if kind=="P|" and from=="Mael" and me()~="Mael" then
        local token,ver=msg:match("^P|(%d+)|([%w%.]+)$")
        if token and ver==PROTOCOL then
            wipe(evalCache)
            HB.LootUnique.inventoryMap=nil
            HB.LootUnique.tracked={}
            -- A new explicit scan supersedes older queued reply packets.
            if batch.frame then batch.frame:SetScript("OnUpdate",nil) end
            wipe(batch.sendQueue);batch.elapsed=0
            addonMessage("A|"..token.."|"..PROTOCOL)
        else net.malformed=net.malformed+1 end
        return
    elseif kind=="A|" and me()=="Mael" and from~="Mael" then
        local token,ver=msg:match("^A|(%d+)|([%w%.]+)$")
        if token and ver==PROTOCOL and tonumber(token)==tonumber(net.pingToken) then
            net.acks[from]=ver or "ACK"
            if frame and frame:IsShown() then refresh() end
        else net.malformed=net.malformed+1 end
        return
    end
    if kind=="B|" and from=="Mael" and me()~="Mael" then
        local seq,target,items=msg:match("^B|(%d+)|([%a]+)|([%d,]+)$")
        local requestID=tonumber(seq)
        if not requestID or not target or not items or #items>batch.size*8 then
            net.requestsMalformed=net.requestsMalformed+1;return
        end
        if target~=me() then net.requestsOtherTarget=net.requestsOtherTarget+1;return end
        local ids,seen={},{}
        for token in items:gmatch("[^,]+") do
            local id=tonumber(token)
            if not id or id<1 or id>3000000 or seen[id] or #ids>=batch.size then
                net.requestsMalformed=net.requestsMalformed+1;return
            end
            ids[#ids+1]=id;seen[id]=true
        end
        if #ids==0 or items:sub(1,1)=="," or items:sub(-1)=="," or items:find(",,",1,true) then
            net.requestsMalformed=net.requestsMalformed+1;return
        end
        net.requests=net.requests+1;net.requestsTargeted=net.requestsTargeted+1
        batch.requestsReceived=batch.requestsReceived+1
        batch.queueResults(requestID,ids)
        return
    elseif kind=="V|" and me()=="Mael" and from~="Mael" then
        local seq,payload=msg:match("^V|(%d+)|(.+)$")
        if not seq or #msg>batch.maxPacket then net.malformed=net.malformed+1;return end
        local rows={}
        for rec in payload:gmatch("[^;]+") do
            local decoded=batch.decode(rec)
            if not decoded or #rows>=batch.size then net.malformed=net.malformed+1;return end
            rows[#rows+1]=decoded
        end
        if #rows==0 or payload:sub(1,1)==";" or payload:sub(-1)==";" or payload:find(";;",1,true) then
            net.malformed=net.malformed+1;return
        end
        batch.packetsReceived=batch.packetsReceived+1
        for _,r in ipairs(rows) do
            local applied,disposition=handleResult(from,tonumber(seq),r.id,r.code,r.pct,r.slot,
                r.required,r.level,r.raw,r.weaponBase,r.why,r.baseline)
            if applied then net.replyAccepted=net.replyAccepted+1;batch.rowsReceived=batch.rowsReceived+1
            elseif disposition=="DUPLICATE" then net.replyDuplicate=net.replyDuplicate+1
            elseif disposition=="UNKNOWN_SCAN" then net.replyUnknownScan=net.replyUnknownScan+1
            elseif disposition=="LATE_UNCACHED" then net.replyLateCache=net.replyLateCache+1
            else net.replyUnexpected=net.replyUnexpected+1 end
            if not applied then net.lastReplyIssue=from.." #"..r.id.." scan="..seq.." "..tostring(disposition) end
        end
        if frame and frame:IsShown() and scanJob then refresh() end
        return
    end
    if kind=="Q|" and from=="Mael" and me()~="Mael" then
        local seq,id,target=msg:match("^Q|(%d+)|(%d+)|([%a]+)$")
        if not seq then seq,id=msg:match("^Q|(%d+)|(%d+)$") end
        local requestID,itemID=tonumber(seq),tonumber(id)
        if not requestID or not itemID or itemID<1 or itemID>3000000 then
            net.requestsMalformed=net.requestsMalformed+1;return
        end
        if target and target~=me() then
            net.requestsOtherTarget=net.requestsOtherTarget+1;return
        end
        net.requests=net.requests+1
        if target then net.requestsTargeted=net.requestsTargeted+1
        else net.requestsBroadcast=net.requestsBroadcast+1 end
        local code,pct,group,req,lvl,raw,weaponBase,why,baseline=evaluateForDungeon(itemID)
        if waitingOnItemData(code,why) then registerCachePending(itemID,requestID) end
        sendPawnResult(requestID,itemID,code,pct,group,req,lvl,raw,weaponBase,why,baseline)
    elseif kind=="R|" and me()=="Mael" and from~="Mael" then
        local seq,id,code,pct,slot,req,lvl,raw,weaponBase,why,baseline=msg:match(
            "^R|(%d+)|(%d+)|([A-Z]+)|([%d%.%-]+)|([A-Z_]+)|(%d+)|(%d+)|([%d%.%-]+)|([%d%.%-]+)|([A-Z_]+)|([%d%.%-]+)$")
        if not seq then net.malformed=net.malformed+1;return end
        local number,nraw,nbase,nold=tonumber(pct),tonumber(raw),tonumber(weaponBase),tonumber(baseline)
        if not number or number~=number or number>100000 or number< -1
           or not nraw or nraw~=nraw or nraw>10000000 or nraw< -1
           or not nbase or nbase~=nbase or nbase>10000000 or nbase< -1
           or not nold or nold~=nold or nold>10000000 or nold< -1 then
            net.malformed=net.malformed+1;return
        end
        local applied,disposition=handleResult(from,tonumber(seq),tonumber(id),code,number,slot,tonumber(req),tonumber(lvl),nraw,nbase,why,nold)
        if applied then net.replyAccepted=net.replyAccepted+1
        elseif disposition=="DUPLICATE" then net.replyDuplicate=net.replyDuplicate+1
        elseif disposition=="UNKNOWN_SCAN" then net.replyUnknownScan=net.replyUnknownScan+1
        elseif disposition=="LATE_UNCACHED" then net.replyLateCache=net.replyLateCache+1
        else net.replyUnexpected=net.replyUnexpected+1 end
        if not applied then
            net.lastReplyIssue=from.." #"..id.." scan="..seq.." "..tostring(disposition)
        end
        if frame and frame:IsShown() and scanJob and tonumber(id)%5==0 then refresh() end
    elseif msg=="I" and me()=="Mael" then
        markStale(from)
        if frame and frame:IsShown() then statusText:SetText(from.." changed gear or level; scan again.");refresh() end
        if runRefresh then runRefresh() end
    end
end)

-- HaploBox TB19.1s: UI-only category configuration and per-character layout.
-- Normal, non-secure control frames. Protected frame operations defer in combat.
local HB=HaploBox
local configs=nil
local layoutFrame
local COLORS={bg={0.095,0.11,0.14,0.99}, gold={0.72,0.54,0.24,0.94}}
local function lockedCombat()
    return InCombatLockdown and InCombatLockdown()
end
local function label(parent,text,x,y,w)
    local f=parent:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
    f:SetPoint("TOPLEFT",parent,"TOPLEFT",x,y)
    f:SetWidth(w or 385);f:SetJustifyH("LEFT")
    f:SetText(text)
    return f
end
local function button(parent,text,x,y,w,fn)
    local b=CreateFrame("Button",nil,parent,"UIPanelButtonTemplate")
    b:SetSize(w or 185,25)
    b:SetPoint("TOPLEFT",parent,"TOPLEFT",x,y)
    b:SetText(text)
    b:SetScript("OnClick",fn)
    if HB.MenuStyle then HB.MenuStyle.Button(b,"blue") end
    return b
end
local function localPos(frame)
    if not (HB.db and frame and frame.hbMenuName) then return end
    local scale=frame:GetEffectiveScale()/(UIParent:GetEffectiveScale() or 1)
    local l,t=frame:GetLeft(),frame:GetTop()
    local w,h=UIParent:GetWidth(),UIParent:GetHeight()
    if not (l and t and w and h and w>0 and h>0) then return end
    HB.db.submenuPositions=HB.db.submenuPositions or {}
    HB.db.submenuPositions[frame.hbMenuName]={
        math.max(0,math.min(0.97,l*scale/w)),
        math.max(0,math.min(0.97,1-t*scale/h)),
    }
end
local function makeWindow(id,title,w,h)
    local frame=CreateFrame("Frame","HaploBox"..id,UIParent)
    frame.hbMenuName=id
    frame:SetSize(w,h)
    frame:SetClampedToScreen(true);frame:SetMovable(true);frame:EnableMouse(true)
    frame:SetFrameStrata("DIALOG");frame:SetFrameLevel(170)
    if HB.MenuStyle then HB.MenuStyle.Window(frame,31) end
    local backdrop=frame:CreateTexture(nil,"BACKGROUND")
    backdrop:SetAllPoints();backdrop:SetColorTexture(unpack(COLORS.bg))
    local trim=frame:CreateTexture(nil,"OVERLAY")
    trim:SetPoint("TOPLEFT",frame,"TOPLEFT",4,-31)
    trim:SetPoint("TOPRIGHT",frame,"TOPRIGHT",-4,-31)
    trim:SetHeight(2);trim:SetColorTexture(unpack(COLORS.gold))
    local head=CreateFrame("Frame",nil,frame)
    head:SetPoint("TOPLEFT",frame,"TOPLEFT",0,0)
    head:SetPoint("TOPRIGHT",frame,"TOPRIGHT",0,0)
    head:SetHeight(29);head:EnableMouse(true)
    head:RegisterForDrag("LeftButton")
    head:SetScript("OnDragStart",function()
        HB.db.submenuLocks=HB.db.submenuLocks or {}
        if HB.db.submenuLocks[id]==false and not lockedCombat() then frame:StartMoving() end
    end)
    head:SetScript("OnDragStop",function()
        frame:StopMovingOrSizing()
        if HB.db.submenuLocks and HB.db.submenuLocks[id]==false then localPos(frame) end
    end)
    local heading=label(head,title,13,-8,w-95)
    heading:SetTextColor(1,0.82,0.40)
    local close=button(head,"X",w-37,-4,28,function() frame:Hide() end)
    close:SetSize(28,20)
    local lock=button(head,"L",w-69,-4,27,function(self)
        if lockedCombat() then HB.print("Change menu lock after combat.") return end
        HB.db.submenuLocks=HB.db.submenuLocks or {}
        local isLocked=(HB.db.submenuLocks[id]~=false)
        HB.db.submenuLocks[id]=isLocked and false or true
        if not isLocked then localPos(frame) end
        if HB.MenuStyle then HB.MenuStyle.LockButton(self,not isLocked)
        else self:SetText(isLocked and "U" or "L") end
    end)
    lock:SetSize(27,20)
    local function refreshLock()
        local isLocked=not (HB.db.submenuLocks and HB.db.submenuLocks[id]==false)
        if HB.MenuStyle then HB.MenuStyle.LockButton(lock,isLocked)
        else lock:SetText(isLocked and "L" or "U") end
    end
    frame:HookScript("OnShow",refreshLock)
    frame:Hide()
    return frame
end
local function checkButton(frame,text,x,y,getValue,setValue)
    -- Label on the left, colored ON/OFF control on the right; original
    -- saved variable and its click behavior stay exactly the same.
    local caption=label(frame,text,x,y-6,315)
    local cb=button(frame,"OFF",frame:GetWidth()-108,y,88,function(self)
        if lockedCombat() then
            HB.print("Change UI settings after combat.")
        else setValue(not getValue()) end
        local active=not not getValue()
        self:SetText(active and "ON" or "OFF")
        if HB.MenuStyle then HB.MenuStyle.Button(self,active and "green" or "red") end
    end)
    frame:HookScript("OnShow",function()
        local active=not not getValue()
        cb:SetText(active and "ON" or "OFF")
        if HB.MenuStyle then HB.MenuStyle.Button(cb,active and "green" or "red") end
    end)
    return cb
end
local function getConfigs()
    if configs then return configs end
    configs={}
    local play=makeWindow("PlayModesConfig","PLAY MODES CONFIG",450,168)
    label(play,"Detailed Play Modes settings will appear here as they are approved.",20,-51,405)
    label(play,"Quick toggles remain in Play Modes for fast access.",20,-79,405)
    configs.play=play

    local team=makeWindow("TeamManagementConfig","TEAM MANAGEMENT CONFIG",450,191)
    label(team,"Quest sharing diagnostics",19,-47,395):SetTextColor(0.97,0.82,0.46)
    checkButton(team,"Quest Share Error Alert",17,-77,
        function() return HB.db.shareErrorAlert==true end,
        function(on) HB.db.shareErrorAlert=on end)
    label(team,"Shows an alert when a quest share fails.",48,-113,368)
    label(team,"Quest Sharing ON/OFF stays in the Quick Menu.",19,-143,395)
    configs.team=team

    local menus=makeWindow("MenusConfig","MENUS CONFIG",450,168)
    label(menus,"Menu-related advanced settings can be added here later.",20,-51,405)
    label(menus,"Every Quick Menu category has its own Config button.",20,-79,405)
    configs.menus=menus
    return configs
end
function HB.OpenCategoryConfig(category)
    local frame=getConfigs()[category]
    if not frame then return end
    if HB.OpenQuickSubmenu then HB.OpenQuickSubmenu(frame) end
end
local function applyPartyVisibility(on)
    if lockedCombat() then HB.print("Change Party Frames after combat.") return end
    HB.db.teamFrame=on and "show" or "hide"
    local a4=HaploBoxA4
    if a4 and a4.db and a4.db.ui then
        a4.db.ui.hideBlizzardParty=on
        if a4.UpdateBlizzardParty then a4.UpdateBlizzardParty() end
    end
    if HB.LayoutPartyFrame then HB.LayoutPartyFrame() end
end
local function refreshLayoutButtons(frame)
    if not (frame and HB.db) then return end
    for _,f in ipairs(frame.refreshers or {}) do f() end
end
local function ensureLayout()
    if layoutFrame then return layoutFrame end
    local frame=makeWindow("UILayout","UI LAYOUT",490,467)
    layoutFrame=frame
    frame.refreshers={}
    local function action(labelText,x,y,width,getLabel,handler)
        local b=button(frame,labelText,x,y,width,function()
            if lockedCombat() then HB.print("Change UI Layout after combat.") return end
            handler();refreshLayoutButtons(frame)
        end)
        if getLabel then frame.refreshers[#frame.refreshers+1]=function()
            local textValue=getLabel()
            b:SetText(textValue)
            if HB.MenuStyle then
                local state=(textValue:find(": OFF",1,true) or textValue:find("Unlock",1,true)) and "red" or
                    (textValue:find(": ON",1,true) or textValue:find("Lock",1,true)) and "green" or "blue"
                HB.MenuStyle.Button(b,state)
            end
        end end
        return b
    end
    label(frame,"Each character has its own layout. Sync is manual.",17,-41,454)
    label(frame,"PARTY FRAMES",18,-71,420):SetTextColor(1,0.81,0.39)
    action("Party Frames",18,-92,212,
        function() return HB.db.teamFrame=="hide" and "Party Frames: OFF" or "Party Frames: ON" end,
        function() applyPartyVisibility(HB.db.teamFrame=="hide") end)
    action("Lock",239,-92,226,
        function() return HB.db.teamLocked and "Unlock / Resize" or "Lock / Save Size" end,
        function() if HB.SetTeamFrameLocked then HB.SetTeamFrameLocked(not HB.db.teamLocked) end end)
    action("Class Colors",18,-123,447,
        function() return HB.db.teamClassColors and "Class Colors: ON" or "Class Colors: OFF" end,
        function()
            HB.db.teamClassColors=not HB.db.teamClassColors
            if HB.RefreshPartyFrame then HB.RefreshPartyFrame() end
        end)
    label(frame,"BUFF OVERVIEW",18,-157,420):SetTextColor(1,0.81,0.39)
    action("Buff Overview",18,-178,212,
        function() return HB.db.buffOverviewEnabled~=false and "Buff Overview: ON" or "Buff Overview: OFF" end,
        function() if HB.SetOverviewEnabled then HB.SetOverviewEnabled("buff",HB.db.buffOverviewEnabled==false) end end)
    action("Buff Lock",239,-178,226,
        function() return HB.db.buffOverviewUnlocked and "Lock Buff Overview" or "Unlock Buff Overview" end,
        function() if HB.SetBuffOverviewUnlocked then HB.SetBuffOverviewUnlocked(not HB.db.buffOverviewUnlocked) end end)
    -- HF23: the retired Debuff panel's old layout slot is now Mael's HoT monitor.
    label(frame,"MAEL MINI HOT MONITOR",18,-215,445):SetTextColor(1,0.81,0.39)
    action("HoT Monitor",18,-234,212,
        function() return HB.db.hotMonitorEnabled~=false and "HoT Monitor: ON" or "HoT Monitor: OFF" end,
        function() if HB.SetHotMonitorEnabled then HB.SetHotMonitorEnabled(HB.db.hotMonitorEnabled==false) end end)
    action("HoT Lock",239,-234,226,
        function() return HB.db.hotMonitorUnlocked and "Lock HoT Monitor" or "Unlock HoT Monitor" end,
        function() if HB.SetHotMonitorUnlocked then HB.SetHotMonitorUnlocked(not HB.db.hotMonitorUnlocked) end end)
    label(frame,"LAYOUT ACTIONS",18,-276,420):SetTextColor(1,0.81,0.39)
    action("Reset My Layout",18,-300,212,nil,function()
        if HB.ResetPartyPosition then HB.ResetPartyPosition() end
        if HB.ResetBuffOverviewPosition then HB.ResetBuffOverviewPosition() end
        if HB.ResetHotMonitorPosition then HB.ResetHotMonitorPosition() end
        if HB.ResetDebuffOverviewPosition then HB.ResetDebuffOverviewPosition() end
        HB.db.quickMenuPos=nil
        HB.db.submenuPositions={}
        if HB.PositionQuickSettings then HB.PositionQuickSettings(true) end
        if HB.PositionDockedSubmenu then HB.PositionDockedSubmenu(frame,true) end
        HB.print("Layout positions reset on this character. Visible components unchanged.")
    end)
    action("Sync Layout to Team",239,-300,226,nil,function()
        local a4=HaploBoxA4
        if a4 and a4.ShareLayoutOnly then a4.ShareLayoutOnly()
        else HB.print("Layout sync is unavailable.") end
    end)
    label(frame,"Sync sends layout only to trusted clients; it never sends macros.",18,-350,452)
    frame:HookScript("OnShow",function() refreshLayoutButtons(frame) end)
    return frame
end
function HB.OpenUILayout()
    local frame=ensureLayout()
    if HB.OpenQuickSubmenu then HB.OpenQuickSubmenu(frame) end
end

-- HaploBox Alpha 5 Testbuild 4: resilient aura pipeline for buff/HoT/debuff,
-- deterministic priority sorting, compact timers, and missing-required-buff icons.
-- The visual aura region is mouse-transparent; the secure unit row hitbox never
-- extends into this column. All aura inspection is local to the current client.
local HB = HaploBox
local HOT_IDS = {
    [774]=true,[1058]=true,[1430]=true,[2090]=true,[2091]=true,[3627]=true,
    [8910]=true,[9839]=true,[9840]=true,[9841]=true,[25299]=true,
    [26982]=true,[48440]=true,[48441]=true,[8936]=true,[8938]=true,
    [8939]=true,[8940]=true,[8941]=true,[9750]=true,[9856]=true,
    [9857]=true,[9858]=true,[26980]=true,[33763]=true,[48438]=true,[740]=true,
}
local HOT_NAMES = {rejuvenation=true,regrowth=true,lifebloom=true,["wild growth"]=true,tranquility=true}
local HOT_PRIORITY = {rejuvenation=1,regrowth=2,lifebloom=3,["wild growth"]=4,tranquility=5}
local DISPEL = {Magic={0.32,0.65,1.0},Curse={0.72,0.32,0.98},Poison={0.30,0.85,0.28},Disease={0.75,0.55,0.25}}
local DISPEL_PRIORITY = {Magic=1,Curse=2,Poison=3,Disease=4}
-- The Sleeping Bag Well-Rested aura is spell 429959 (Blizzard native texture).
local SLEEPING_BAG_XP_SPELL = 429959
local REQUIRED_ORDER = {"xp","food","camp","mark","thorns","intellect","fortitude","blessing"}
local TRACKING_ORDER = {"minerals","herbs"}
local REQUIRED = {
    xp={label="Sleeping Bag +3% XP",spell=SLEEPING_BAG_XP_SPELL,icon="Interface\\Icons\\INV_Drink_15"},
    food={label="Food",spell=0,icon="Interface\\Icons\\INV_Misc_Food_15"},
    camp={label="Camp",spell=0,icon="Interface\\Icons\\Spell_Fire_Fire"},
    mark={label="Mark of the Wild",spell=1126,icon="Interface\\Icons\\Spell_Nature_Regeneration"},
    thorns={label="Thorns",spell=467,icon="Interface\\Icons\\Spell_Nature_Thorns"},
    intellect={label="Arcane Intellect",spell=1459,icon="Interface\\Icons\\Spell_Holy_MagicalSentry"},
    fortitude={label="Power Word: Fortitude",spell=1243,icon="Interface\\Icons\\Spell_Holy_WordFortitude"},
    blessing={label="Paladin Blessing",spell=19740,icon="Interface\\Icons\\Spell_Holy_FistOfJustice"},
}
local function safe(v) return v ~= nil and (not HB.secret or not HB.secret(v)) end
local function cleanText(v)
    return safe(v) and type(v)=="string" and v:lower() or ""
end
local function family(a)
    local n=cleanText(a and a.name)
    if n=="mark of the wild" or n=="gift of the wild" then return "mark" end
    if n=="thorns" then return "thorns" end
    if n=="arcane intellect" or n=="arcane brilliance" then return "intellect" end
    if n=="power word: fortitude" or n=="prayer of fortitude" then return "fortitude" end
    if n:find("blessing of ",1,true)==1 or n:find("greater blessing of ",1,true)==1 then return "blessing" end
    -- The temporary Eating/Food aura is NOT Well Fed. Never suppress MISSING Food until
    -- a genuine completed Well Fed aura is present.
    if n=="well fed" or n=="well-fed" or n:find("well fed",1,true) then return "food" end
    -- WoW Forever: Campfire Nearby / Welcoming Campfire are only progress.
    -- "Camp Benefits" is the earned one-hour bonus; Sleeping Bag is separate.
    if n == "camp benefits" or n:find("camp benefits",1,true) then return "camp" end
    -- Only the 3-stack Sleeping Bag reward satisfies the REQUIRED XP alert.
    -- Student Fodder and other XP gains remain visible buffs, not substitutions.
    if n == "well-rested" or (safe(a and a.id) and a.id == SLEEPING_BAG_XP_SPELL) then return "xp" end
end
local function aura(unit,index,filter)
    local helpful=filter=="HELPFUL"
    if C_UnitAuras then
        local fn=helpful and C_UnitAuras.GetBuffDataByIndex or C_UnitAuras.GetDebuffDataByIndex
        local data
        if fn then
            local ok,a=pcall(fn,unit,index)
            if ok and type(a)=="table" and safe(a.name) then data=a end
        end
        if not data and C_UnitAuras.GetAuraDataByIndex then
            local ok,a=pcall(C_UnitAuras.GetAuraDataByIndex,unit,index,filter)
            if ok and type(a)=="table" and safe(a.name) then data=a end
        end
        if data then
            local artwork=data.icon
            if not safe(artwork) and safe(data.spellId) then
                local fn=(C_Spell and C_Spell.GetSpellTexture) or GetSpellTexture
                if fn then local ok,v=pcall(fn,data.spellId);if ok and safe(v) then artwork=v end end
            end
            return {icon=artwork or "Interface\\Icons\\INV_Misc_QuestionMark",id=data.spellId,name=data.name,expiration=data.expirationTime,
                duration=data.duration,dispel=data.dispelName,source=data.sourceUnit,count=data.applications,
                auraInstanceID=data.auraInstanceID,index=index}
        end
    end
    local fn=helpful and UnitBuff or UnitDebuff
    if fn then
        local ok,name,texture,count,dtype,duration,expiration,source,_,_,id=pcall(fn,unit,index)
        if ok and safe(name) and safe(texture) then
            return {name=name,icon=texture,count=count,dispel=dtype,duration=duration,
                expiration=expiration,source=source,id=id,index=index}
        end
    end
    if UnitAura then
        local ok,name,texture,count,dtype,duration,expiration,source,_,_,id=pcall(UnitAura,unit,index,filter)
        if ok and safe(name) and safe(texture) then
            return {name=name,icon=texture,count=count,dispel=dtype,duration=duration,
                expiration=expiration,source=source,id=id,index=index}
        end
    end
end
local function isHot(a)
    return (safe(a.id) and HOT_IDS[a.id]) or
        (safe(a.name) and HOT_NAMES[cleanText(a.name)]) or false
end
local function icon(parent)
    local t=parent:CreateTexture(nil,"ARTWORK")
    t:SetTexCoord(0.08,0.92,0.08,0.92)
    local sides={}
    for i=1,4 do
        local edge=parent:CreateTexture(nil,"OVERLAY")
        edge:SetColorTexture(0,0,0,0)
        sides[i]=edge
    end
    local stack=parent:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
    stack:SetPoint("TOPRIGHT",t,"TOPRIGHT",-1,-1)
    stack:SetJustifyH("RIGHT")
    stack:SetWordWrap(false)
    stack:SetShadowOffset(1,-1)
    if STANDARD_TEXT_FONT then stack:SetFont(STANDARD_TEXT_FONT,9,"OUTLINE") end
    stack:SetText("")
    local font=parent:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
    font:SetPoint("BOTTOM",t,"BOTTOM",0,1)
    font:SetJustifyH("CENTER")
    font:SetJustifyV("BOTTOM")
    font:SetWordWrap(false)
    font:SetTextColor(1,1,1,1)
    font:SetShadowOffset(1,-1)
    font:SetText("")
    t:Hide()
    return {tex=t,sides=sides,time=font,stack=stack,aura=nil}
end
local function setSize(o,width)
    o.tex:SetSize(width,width)
    -- A smaller font prevents WoW's own text truncation/ellipsis in 20px icons.
    o.time:SetWidth(math.max(38,width+12))
    o.time:SetHeight(math.max(9,math.floor(width*0.48)))
    o.timerFontSize=math.max(7,math.min(9,math.floor(width*0.34)))
    o.stack:SetWidth(math.max(width+8,36)) -- full XP 1/3, 2/3, 3/3 without crop
    o.stack:SetHeight(12)
    if STANDARD_TEXT_FONT and o.time.SetFont then
        o.time:SetFont(STANDARD_TEXT_FONT,o.timerFontSize,"OUTLINE")
    end
    local t=o.tex
    local e=o.sides
    e[1]:ClearAllPoints();e[1]:SetPoint("TOPLEFT",t,"TOPLEFT");e[1]:SetSize(width,1)
    e[2]:ClearAllPoints();e[2]:SetPoint("BOTTOMLEFT",t,"BOTTOMLEFT");e[2]:SetSize(width,1)
    e[3]:ClearAllPoints();e[3]:SetPoint("TOPLEFT",t,"TOPLEFT");e[3]:SetSize(1,width)
    e[4]:ClearAllPoints();e[4]:SetPoint("TOPRIGHT",t,"TOPRIGHT");e[4]:SetSize(1,width)
end
local function sides(o,c)
    for _,e in ipairs(o.sides) do
        if c then e:SetColorTexture(c[1],c[2],c[3],c[4] or 1)
        else e:SetColorTexture(0,0,0,0) end
    end
end
local function setIcon(o,a,warning)
    o.aura=a
    if a and safe(a.icon) then
        o.tex:SetTexture(a.icon)
        o.tex:Show()
        sides(o,warning and {0.95,0.19,0.13,1} or (safe(a.dispel) and DISPEL[a.dispel] or nil))
        local c=a.count
        if safe(c) and type(c)=="number" and c>=(warning and 1 or 2) then
            o.stack:SetText(warning and (tostring(c).."/3") or tostring(c))
        else o.stack:SetText("") end
    else
        o.tex:Hide()
        o.time:SetText("")
        o.stack:SetText("")
        sides(o,nil)
    end
end
local function fitTimer(o, label)
    o.time:SetText(label)
    if o.isNormalBuff then
        -- HF21: never drop the unit (5m must not become "5" or "5...").
        -- Allow the timer to extend past its icon without resizing the icon.
        if STANDARD_TEXT_FONT and o.time.SetFont then
            o.time:SetFont(STANDARD_TEXT_FONT,o.timerFontSize or 11,"THICKOUTLINE")
        end
        if label~="" and o.time.GetUnboundedStringWidth then
            local ok,w=pcall(o.time.GetUnboundedStringWidth,o.time)
            if ok and safe(w) and type(w)=="number" then
                o.time:SetWidth(math.max(38,math.ceil(w)+4))
            end
        end
        return
    end
    if not (STANDARD_TEXT_FONT and o.time.SetFont and label ~= "") then return end
    local fontSize = o.timerFontSize or 7
    local limit = math.max(10, o.time:GetWidth())
    o.time:SetFont(STANDARD_TEXT_FONT,fontSize,"OUTLINE")
    -- Text must never become clipped or replaced by WoW ellipsis. A smaller
    -- font is preferred to expanding the text beyond the existing HoT icon.
    if o.time.GetUnboundedStringWidth then
        local width = o.time:GetUnboundedStringWidth()
        while type(width)=="number" and safe(width) and width>limit and fontSize>6 do
            fontSize=fontSize-0.5
            o.time:SetFont(STANDARD_TEXT_FONT,fontSize,"OUTLINE")
            width=o.time:GetUnboundedStringWidth()
        end
    end
end
local function updateTime(o)
    local a=o.aura
    if not a or not o.tex:IsShown() then return end
    local expiration,duration=a.expiration,a.duration
    if not (safe(expiration) and safe(duration) and type(expiration)=="number"
        and type(duration)=="number" and duration>0) then fitTimer(o,"");return end
    local remaining=expiration-GetTime()
    if not safe(remaining) or type(remaining)~="number" or remaining<=0 then
        fitTimer(o,"");return
    end
    if o.isNormalBuff then
        if remaining<=60 then o.time:SetTextColor(1,1,1,1)
        else o.time:SetTextColor(1,0.83,0.49,1) end
    end
    if o.isNormalBuff and remaining>=3600 then
        fitTimer(o,tostring(math.min(99,math.ceil(remaining/3600))).."h")
    elseif remaining>=60 then fitTimer(o,tostring(math.ceil(remaining/60)).."m")
    else fitTimer(o,tostring(math.max(1,math.floor(remaining)))) end
end
local function sourceName(a)
    if not safe(a.source) or type(a.source)~="string" then return "" end
    if UnitName then
        local ok,n=pcall(UnitName,a.source)
        if ok and safe(n) and type(n)=="string" then return n:lower() end
    end
    return cleanText(a.source)
end
local function stableSort(items,kind)
    local keys={}
    for _,a in ipairs(items) do
        local name=cleanText(a.name)
        local f=family(a)
        local priority=99
        if kind=="buff" then
            if f then for i,k in ipairs(REQUIRED_ORDER) do if k==f then priority=i break end end end
        elseif kind=="hot" then priority=HOT_PRIORITY[name] or 99
        else priority=DISPEL_PRIORITY[a.dispel] or 99 end
        keys[a]={priority=priority,name=name,id=safe(a.id) and type(a.id)=="number" and a.id or 0,
            source=sourceName(a)}
    end
    table.sort(items,function(a,b)
        local x,y=keys[a],keys[b]
        if x.priority~=y.priority then return x.priority<y.priority end
        -- Personal extras are sorted by numeric spell ID, not alphabetically.
        if x.priority==99 and kind=="buff" and x.id~=y.id then return x.id<y.id end
        if x.name~=y.name then return x.name<y.name end
        if x.id~=y.id then return x.id<y.id end
        return x.source<y.source
    end)
end
-- 12.1+ Forever client: during combat the Lua-facing aura fields become
-- secret, and in later clients the index APIs refuse access entirely. The
-- engine-owned AuraContainer is the supported way to render live auras then.
-- The container classifies and changes icons itself, WITHOUT exposing secret
-- spell IDs, icons or expiration data to our addon code. On older clients we
-- retain the existing legacy renderer with an expiry-bounded combat fallback.
local BUFF_ROW_H, BUFF_ICON, BUFF_STEP, BUFF_NUM_W = 41,27,30,37
-- Each number tile is ICON-sized and uses the existing timer-provided row gap.
-- HF23: party debuffs inherit live HoT cell dimensions and countdown face.
local DEBUFF_NUM_W=37
-- TB18.3 / P1: ONE horizontal HoT row, exactly the height of the blue
-- INNER FACE of Focus (excluding gold edges). Never wrap into a second row.
-- This resolves the conflicting 2-row size/height requirements: there is
-- now one full-height icon per cell and additional HoTs flow RIGHT.
local HOT_COLUMNS, HOT_BORDER_INSET=16,2
-- HF12: all auras exposed through the per-unit API, rather than the old
-- sixteen-icon artificial display cap. No UI-wide frame enumeration.
local MAX_UNIT_AURA_INDEX=255
local MAX_BUFFS, MAX_MISSING = MAX_UNIT_AURA_INDEX,#REQUIRED_ORDER+#TRACKING_ORDER
local function hotGeometry(focusH)
    local blueH=math.max(8,(focusH or 0)-2*HOT_BORDER_INSET)
    return blueH,blueH
end
local function nativeAuraButton(button,size,timerBelow,kind)
    button:SetSize(size,size)
    -- Native aura buttons can show Blizzard's own tooltip and securely
    -- cancel permitted PLAYER buffs on right-click. HoT/debuff buttons stay
    -- mouse-transparent to preserve party-world clicks and secure unit frames.
    button:EnableMouse(kind=="normal")
    if kind=="normal" then
        if button.RegisterForClicks then button:RegisterForClicks("RightButtonUp") end
        if button.SetCancelAuraButtons then pcall(button.SetCancelAuraButtons,button,"RightButton") end
        if button.SetTooltipAnchorPoint then pcall(button.SetTooltipAnchorPoint,button,"ANCHOR_BOTTOM") end
    end
    local artwork=button:CreateTexture(nil,"ARTWORK")
    artwork:SetAllPoints(button)
    artwork:SetTexCoord(0.08,0.92,0.08,0.92)
    button:SetIcon(artwork)
    local timer=button:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
    local below=timerBelow or kind=="hots"
    if below then
        timer:SetPoint("TOP",button,"BOTTOM",0,-1)
    else
        timer:SetPoint("BOTTOM",button,"BOTTOM",0,1)
    end
    timer:SetSize(size+8,below and 12 or 10)
    timer:SetJustifyH("CENTER")
    timer:SetJustifyV("TOP")
    timer:SetWordWrap(false)
    timer:SetShadowOffset(1,-1)
    if STANDARD_TEXT_FONT then
        local fsize=(kind=="hots" or kind=="debuffs") and math.max(8,math.min(10,size*0.30)) or math.max(7,math.min(9,size*0.40))
        timer:SetFont(STANDARD_TEXT_FONT,fsize,"THICKOUTLINE")
    end
    if timerBelow then timer:SetTextColor(1,0.83,0.49,1) end
    if button.SetDurationText then button:SetDurationText(timer) end
    -- Blizzard owns this stack label, including secret aura values in combat.
    local stack=button:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
    stack:SetPoint("TOPRIGHT",button,"TOPRIGHT",-1,-1)
    stack:SetSize(math.max(size+8,36),12) -- no clipped XP stack numerals
    stack:SetJustifyH("RIGHT")
    stack:SetWordWrap(false)
    stack:SetShadowOffset(1,-1)
    if STANDARD_TEXT_FONT then stack:SetFont(STANDARD_TEXT_FONT,size<18 and 7 or 9,"OUTLINE") end
    -- The engine owns protected stack values. Allow single-stack application
    -- labels where the 12.1+ client exposes them (e.g. Camp Benefits).
    if button.SetApplicationCount then pcall(button.SetApplicationCount,button,stack,{minApplications=1}) end
    if kind=="debuffs" and button.SetAuraBorder then
        -- Let the engine own live dispel-type markings (including secret
        -- combat auras). Display native Curse/Poison styling without Lua reads.
        local border=button:CreateTexture(nil,"OVERLAY")
        border:SetAllPoints(button)
        pcall(button.SetAuraBorder,button,border,{showWhenHarmful=true,showWithoutDispelType=false})
    end
    for side=1,4 do
        local edge=button:CreateTexture(nil,"OVERLAY")
        edge:SetColorTexture(0.52,0.57,0.64,0.9)
        if side==1 then edge:SetPoint("TOPLEFT");edge:SetPoint("TOPRIGHT");edge:SetHeight(1)
        elseif side==2 then edge:SetPoint("BOTTOMLEFT");edge:SetPoint("BOTTOMRIGHT");edge:SetHeight(1)
        elseif side==3 then edge:SetPoint("TOPLEFT");edge:SetPoint("BOTTOMLEFT");edge:SetWidth(1)
        else edge:SetPoint("TOPRIGHT");edge:SetPoint("BOTTOMRIGHT");edge:SetWidth(1) end
    end
end
local function makeNativeAura(parent,kind,filter,count,size,candidates,timerBelow,fromRight,columns)
    local ok,container=pcall(CreateFrame,"AuraContainer",nil,parent,"CustomAuraContainerTemplate")
    if not ok or not container or not container.AddAuraGroup or not container.SetUnit then return nil end
    local success=pcall(function()
        container:EnableMouse(false)
        -- The engine needs positive dimensions *before* the group is added.
        -- A HoT group has enough width for ALL 16 icons in ONE row.
        container:SetSize((columns or count)*(size+3)+3,size)
        local anchor=container.SetFlowLayoutAnchorPoint or container.SetAuraLayoutAnchorPoint
        local growth=container.SetFlowLayoutGrowthDirection or container.SetAuraLayoutGrowthDirection
        if anchor then anchor(container,fromRight and "TOPRIGHT" or "TOPLEFT") end
        if growth and AnchorUtil and AnchorUtil.FlowDirection then
            -- Native Blizzard container still owns all combat aura presentation.
            -- Only the visual FLOW direction differs for the upper-right panel.
            local fd=AnchorUtil.FlowDirection
            growth(container,fromRight and (fd.Left or fd.Right) or fd.Right,fd.Down)
        end
        container:AddAuraGroup(kind,filter,{
            maxFrameCount=count,
            candidateFilters=candidates or {},
            layout={elementWidth=size,elementHeight=size,elementSpacing=3,lineSpacing=5},
            initializeFrame=function(button) nativeAuraButton(button,size,timerBelow,kind) end,
        })
        container:Show()
    end)
    if not success then pcall(container.Hide,container);return nil end
    return container
end
-- Classic/legacy clients do not expose the 12.1 intrinsic. They use the
-- original out-of-combat aura algorithm with a combat snapshot fallback.
local function setupNativeAuras(r)
    -- HF21: Blizzard PLAYER/!PLAYER partitions by LOCAL caster, not by
    -- party-sustainable buff family. Draw these two zones from safe snapshots.
    r.nativeBuff=nil
    r.nativeExternalBuff=nil
    -- FocusTile has already been sized by Party before creation, so the
    -- intrinsic Blizzard aura group gets its CORRECT button dimensions.
    local hotCell=hotGeometry(r.focusTile:GetHeight())
    r.hotNativeCell=hotCell
    r.nativeHots=makeNativeAura(r.auraArea,"hots","HELPFUL",16,hotCell,{includeSpellIDs=HOT_IDS},false,false,HOT_COLUMNS)
    -- Native AuraContainer creates visible buttons on demand; its C-side
    -- combat-safe list, not Lua sorting or an old 16-slot cap, drives icons.
    r.debuffNativeCell=hotCell
    r.nativeDebuffs=makeNativeAura(r.debuffArea,"debuffs","HARMFUL",MAX_UNIT_AURA_INDEX,hotCell,{},true,false,16)
    if r.nativeHots and r.nativeDebuffs then
        r.nativeAurasReady=true
        HB.auraEngine="native HoT/debuff; party-classified buffs (OOC)"
        for _,group in ipairs({r.hots,r.debuffs}) do
            for _,o in ipairs(group) do o.tex:Hide();o.time:SetText("") end
        end
    else
        -- Partial setup must not create duplicate/overlapping aura rows.
        for _,c in ipairs({r.nativeHots,r.nativeDebuffs}) do
            if c then pcall(c.Hide,c) end
        end
        r.nativeAurasReady=false
        if not HB.auraEngine then HB.auraEngine="legacy (combat snapshot only)" end
    end
end
function HB.BindAuraUnit(r)
    if not r.nativeAurasReady or not r.unit then return end
    local success=true
    for _,c in ipairs({r.nativeHots,r.nativeDebuffs}) do
        if not pcall(c.SetUnit,c,r.unit) then success=false end
    end
    if not success then
        r.nativeAurasReady=false
        HB.auraEngine="legacy (native SetUnit failed)"
        for _,c in ipairs({r.nativeHots,r.nativeDebuffs}) do pcall(c.Hide,c) end
    end
end
-- TB15: visually independent, mouse-transparent five-player Buff/Missing panel.
-- The existing aura engine, timers, missing detection and secure native containers
-- are intentionally unchanged. This only moves their DISPLAY parents and anchors.
-- Native AuraContainer allocates buttons on demand, not a fixed 16-slot cap.
-- Classified buff icons freeze in combat; native HoT/debuffs remain live.
local BUFF_HANDLE_H, BUFF_FRAME_W = 22,120
local BUFF_GROUP_GAP, BUFF_MISSING_GAP = 8,7
local BUFF_MISSING_NUDGE = 4 -- red borders clear the vertical separator

local buffOverview
-- TB19.1c: visual HP-bar-style SQUARE numeral tile, sized to the existing
-- icon on that rail. Existing buff/debuff aura scanners, timers and secure UI
-- handling are not changed here. Badge carries the old class-colour tint.
local function styleOverviewNumber(text,iconSize)
    local face=STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF"
    text:SetFont(face,iconSize>=27 and 15 or 14,"THICKOUTLINE")
    text:SetSize(iconSize,iconSize)
    text:SetJustifyH("CENTER")
    text:SetJustifyV("MIDDLE")
    text:SetTextColor(1,1,0.98,1)
    text:SetShadowColor(0,0,0,1)
    text:SetShadowOffset(0,0) -- outlined numeral is centered in the square
end
local function makeOverviewNumberTile(parent,iconSize,point,relative,x,y)
    local tile=parent:CreateTexture(nil,"ARTWORK")
    tile:SetColorTexture(1,1,1,0.90)
    tile:SetSize(iconSize,iconSize)
    tile:SetVertexColor(1,0.49,0.04,0.98) -- class-colour updated as before
    tile:SetPoint(point,parent,relative,x,y)
    -- Straight borders and thin highlight, same rectangular geometry as HP.
    for edge=1,4 do
        local t=parent:CreateTexture(nil,"OVERLAY")
        t:SetColorTexture(0.025,0.035,0.045,0.98)
        if edge==1 then t:SetPoint("TOPLEFT",tile,"TOPLEFT",0,0)
            t:SetPoint("TOPRIGHT",tile,"TOPRIGHT",0,0);t:SetHeight(1)
        elseif edge==2 then t:SetPoint("BOTTOMLEFT",tile,"BOTTOMLEFT",0,0)
            t:SetPoint("BOTTOMRIGHT",tile,"BOTTOMRIGHT",0,0);t:SetHeight(1)
        elseif edge==3 then t:SetPoint("TOPLEFT",tile,"TOPLEFT",0,0)
            t:SetPoint("BOTTOMLEFT",tile,"BOTTOMLEFT",0,0);t:SetWidth(1)
        else t:SetPoint("TOPRIGHT",tile,"TOPRIGHT",0,0)
            t:SetPoint("BOTTOMRIGHT",tile,"BOTTOMRIGHT",0,0);t:SetWidth(1) end
    end
    local accent=parent:CreateTexture(nil,"OVERLAY")
    accent:SetColorTexture(0.69,0.55,0.28,0.91)
    accent:SetPoint("TOPLEFT",tile,"TOPLEFT",1,-1)
    accent:SetPoint("TOPRIGHT",tile,"TOPRIGHT",-1,-1)
    accent:SetHeight(1)
    return tile
end
local function ensureBuffOverview()
    if buffOverview then return buffOverview end
    local f=CreateFrame("Frame","HaploBoxBuffOverview",UIParent)
    -- Compact draggable anchor: visible even if aura trails extend off-screen.
    -- Aura rails may extend LEFT; the actual movable frame/handle never can.
    f:SetSize(BUFF_FRAME_W,BUFF_HANDLE_H+BUFF_ROW_H*5)
    f:SetFrameStrata("MEDIUM")
    f:SetMovable(true)
    f:EnableMouse(false)
    f:SetClampedToScreen(true)
    local function clampedPosition(x,y)
        local uiW,uiH=UIParent:GetWidth() or 1200,UIParent:GetHeight() or 800
        local maxX=math.max(0,uiW-f:GetWidth()-6)
        local maxY=math.max(0,uiH-f:GetHeight()-6)
        x=type(x)=="number" and x or -205
        y=type(y)=="number" and y or -68
        return math.max(-maxX,math.min(0,x)), math.max(-maxY,math.min(0,y))
    end
    f.ClampPosition=clampedPosition
    local saved=HB.db and HB.db.buffOverviewPos
    local px,py=clampedPosition(type(saved)=="table" and saved[1],type(saved)=="table" and saved[2])
    f:SetPoint("TOPRIGHT",UIParent,"TOPRIGHT",px,py)
    if HB.db and saved then HB.db.buffOverviewPos={px,py} end
    f:RegisterEvent("UI_SCALE_CHANGED")
    f:RegisterEvent("DISPLAY_SIZE_CHANGED")
    f:RegisterEvent("PLAYER_REGEN_ENABLED")
    f:SetScript("OnEvent",function(self)
        if InCombatLockdown and InCombatLockdown() then return end
        local x=(self:GetRight() or 0)-(UIParent:GetRight() or 0)
        local y=(self:GetTop() or 0)-(UIParent:GetTop() or 0)
        x,y=self.ClampPosition(x,y)
        self:ClearAllPoints()
        self:SetPoint("TOPRIGHT",UIParent,"TOPRIGHT",x,y)
        if HB.db then HB.db.buffOverviewPos={x,y} end
    end)
    f.rows={}
    f.labels={}
    f.badges={}
    for i=1,5 do
        local bg=makeOverviewNumberTile(f,BUFF_ICON,"TOPRIGHT","TOPRIGHT",-5,-(BUFF_HANDLE_H+(i-1)*BUFF_ROW_H+5))
        f.badges[i]=bg
        local n=f:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
        n:ClearAllPoints()
        -- FRIZQT numerals paint high/left within a centered FontString.
        -- Image-checked optical glyph centering in the 27px orange tile.
        n:SetPoint("CENTER",bg,"CENTER",2,-3)
        styleOverviewNumber(n,BUFF_ICON)
        n:SetText(tostring(i))
        f.labels[i]=n
    end
    local line=f:CreateTexture(nil,"OVERLAY")
    line:SetColorTexture(0.72,0.74,0.78,0.75)
    line:SetSize(1,BUFF_ROW_H*5-10)
    f.divider=line
    -- The grip is INSIDE the frame, above row 1, never placed off-screen.
    -- No aura icon has a click region in this header strip.
    local grip=CreateFrame("Button",nil,f)
    grip:SetSize(113,18)
    grip:SetPoint("TOPRIGHT",f,"TOPRIGHT",-3,-2)
    grip:EnableMouse(true)
    grip:RegisterForDrag("LeftButton")
    local shade=grip:CreateTexture(nil,"BACKGROUND")
    shade:SetAllPoints()
    shade:SetColorTexture(0.14,0.30,0.48,0.95)
    local gripText=grip:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
    gripText:SetPoint("CENTER",grip,"CENTER",0,0)
    gripText:SetText("MOVE BUFFS")
    gripText:SetTextColor(1,0.93,0.72)
    local moving=false
    grip:SetScript("OnDragStart",function()
        if InCombatLockdown and InCombatLockdown() then return end
        moving=true
        f:StartMoving()
    end)
    grip:SetScript("OnDragStop",function()
        if not moving then return end
        moving=false
        f:StopMovingOrSizing()
        local x=(f:GetRight() or 0)-(UIParent:GetRight() or 0)
        local y=(f:GetTop() or 0)-(UIParent:GetTop() or 0)
        x,y=f.ClampPosition(x,y)
        if HB.db then HB.db.buffOverviewPos={x,y} end
        f:ClearAllPoints()
        f:SetPoint("TOPRIGHT",UIParent,"TOPRIGHT",x,y)
    end)
    grip:SetScript("OnEnter",function(self)
        if not GameTooltip then return end
        GameTooltip:SetOwner(self,"ANCHOR_BOTTOM")
        GameTooltip:SetText("Move Buff Overview",1,0.82,0.4)
        GameTooltip:AddLine("Drag to reposition. Lock in UI Layout.",1,1,1,true)
        GameTooltip:Show()
    end)
    grip:SetScript("OnLeave",function() if GameTooltip then GameTooltip:Hide() end end)
    f.grip=grip
    grip:SetShown(HB.db and HB.db.buffOverviewUnlocked or false)
    buffOverview=f
    f:Hide()
    return f
end
function HB.SetBuffOverviewUnlocked(value)
    if InCombatLockdown and InCombatLockdown() then return false end
    if HB.db then HB.db.buffOverviewUnlocked=value and true or false end
    if buffOverview then buffOverview.grip:SetShown(value and true or false) end
    return true
end
function HB.ResetBuffOverviewPosition()
    if InCombatLockdown and InCombatLockdown() then return false end
    if HB.db then HB.db.buffOverviewPos=nil end
    if buffOverview then
        buffOverview:StopMovingOrSizing()
        buffOverview:ClearAllPoints()
        local x,y=buffOverview.ClampPosition(-205,-68)
        buffOverview:SetPoint("TOPRIGHT",UIParent,"TOPRIGHT",x,y)
        -- The map alignment is a default ONLY after an intentional reset.
        if HB.PositionDefaultBuffOverview then HB.PositionDefaultBuffOverview() end
    end
    return true
end
function HB.AttachBuffOverviewRow(r)
    local f=ensureBuffOverview()
    -- Parent only these ordinary display frames, not a SecureUnitButton or aura
    -- scanning state. Native C-side Buff button stays a child of buffArea.
    r.buffArea:SetParent(f)
    r.externalBuffArea:SetParent(f)
    r.missingArea:SetParent(f)
    f.rows[#f.rows+1]=r
    r.buffOverviewIndex=#f.rows
    r.buffShownCount=0
    r.externalBuffShownCount=0
    r.buffArea:Hide();r.externalBuffArea:Hide();r.missingArea:Hide()
end
function HB.AlignBuffOverview()
    if not buffOverview then return end
    if InCombatLockdown and InCombatLockdown() then return end
    local f=buffOverview
    local maxOwn,maxExternal=0,0
    for _,r in ipairs(f.rows) do
        if r.buffOverviewVisible then
            maxOwn=math.max(maxOwn,r.buffShownCount or 0)
            maxExternal=math.max(maxExternal,r.externalBuffShownCount or 0)
        end
    end
    -- Right to left: party-sustainable, then other active (external),
    -- then the missing warnings. All five rows share the SAME boundaries.
    local hasExternal=maxExternal>0
    local ownRight=BUFF_NUM_W
    local externalRight=ownRight+maxOwn*BUFF_STEP+(hasExternal and BUFF_GROUP_GAP or 0)
    local missingRight=externalRight+(hasExternal and maxExternal*BUFF_STEP or 0)+BUFF_MISSING_GAP
    f.divider:ClearAllPoints()
    f.divider:SetPoint("TOPRIGHT",f,"TOPRIGHT",-missingRight,-(BUFF_HANDLE_H+4))
    f.divider:SetShown(hasExternal or maxOwn>0)
    if not f.externalDivider then
        f.externalDivider=f:CreateTexture(nil,"OVERLAY")
        f.externalDivider:SetColorTexture(0.72,0.74,0.78,0.75)
        f.externalDivider:SetSize(1,BUFF_ROW_H*5-10)
    end
    f.externalDivider:ClearAllPoints()
    f.externalDivider:SetPoint("TOPRIGHT",f,"TOPRIGHT",-(ownRight+maxOwn*BUFF_STEP+4),-(BUFF_HANDLE_H+4))
    f.externalDivider:SetShown(hasExternal)
    for _,r in ipairs(f.rows) do
        local top=BUFF_HANDLE_H+(r.buffOverviewIndex-1)*BUFF_ROW_H+5
        r.buffArea:ClearAllPoints()
        r.buffArea:SetPoint("TOPRIGHT",f,"TOPRIGHT",-ownRight,-top)
        r.externalBuffArea:ClearAllPoints()
        r.externalBuffArea:SetPoint("TOPRIGHT",f,"TOPRIGHT",-externalRight,-top)
        r.missingArea:ClearAllPoints()
        r.missingArea:SetPoint("TOPRIGHT",f,"TOPRIGHT",-(missingRight+BUFF_MISSING_NUDGE),-top)
    end
end
function HB.LayoutBuffOverview(active,rows)
    if not buffOverview then return end
    if InCombatLockdown and InCombatLockdown() then return end
    local f=buffOverview
    -- Two independent menu toggles, neither changes any aura scanner.
    active=active and (not HB.db or HB.db.buffOverviewEnabled~=false)
    f:SetShown(active and true or false)
    for i,r in ipairs(f.rows) do
        local visible=active and rows and rows[i] == r and r:IsShown()
        r.buffOverviewVisible=visible and true or false
        r.buffArea:SetShown(r.buffOverviewVisible)
        r.externalBuffArea:SetShown(r.buffOverviewVisible and (r.externalBuffShownCount or 0)>0)
        r.missingArea:SetShown(r.buffOverviewVisible)
        f.labels[i]:SetShown(r.buffOverviewVisible)
        f.badges[i]:SetShown(r.buffOverviewVisible)
        if r.buffOverviewVisible then HB.SetAuraBadgeClassColor(f.badges[i],r) end
    end
    HB.AlignBuffOverview()
end

-- HF12 DEB-01: retired the entire separate buff-style Debuff Overview.
-- Debuffs now live within each secure Party Frame's visual rail, underneath
-- its follower tile and vertically aligned with its HoT column.
local function classColorForAuraRow(r)
    local file
    if r and r.unit and UnitClass then
        local ok,_,v=pcall(UnitClass,r.unit)
        if ok and safe(v) and type(v)=="string" then file=v end
    end
    local cc=file and (CUSTOM_CLASS_COLORS or RAID_CLASS_COLORS or {})[file]
    if cc then return cc.r,cc.g,cc.b end
    if file=="DRUID" or not file then return 1.0,0.49,0.04 end
    return 0.72,0.72,0.72
end
function HB.SetAuraBadgeClassColor(badge,r)
    if not badge then return end
    badge:SetVertexColor(classColorForAuraRow(r))
end
-- No floating frame is allocated, regardless of old SavedVariables.
function HB.LayoutDebuffOverview(active,visibleRows)
    if InCombatLockdown and InCombatLockdown() then return end
    for _,r in ipairs(visibleRows or {}) do
        if r.debuffArea then r.debuffArea:SetShown(not not (active and r:IsShown())) end
    end
end
function HB.AlignDebuffOverview() end -- archived API compatibility
function HB.SetDebuffOverviewUnlocked() return false end
function HB.ResetDebuffOverviewPosition() return false end
function HB.SetOverviewEnabled(kind,enabled)
    if not HB.db or (InCombatLockdown and InCombatLockdown()) then return false end
    local field=kind=="buff" and "buffOverviewEnabled" -- old debuff panel removed in HF12
    if not field then return false end
    HB.db[field]=not not enabled
    if HB.LayoutPartyFrame then HB.LayoutPartyFrame() end
    if HB.ApplyBlizzardAuraVisibility then HB.ApplyBlizzardAuraVisibility() end
    if HB.RefreshControls then HB.RefreshControls() end
    return true
end
-- Default Blizzard bars are replaced only while their JCDRbox alternative
-- is genuinely displayed. NEVER reparent/alter secure Blizzard frames in combat.
local savedBlizzard={}
local pendingBlizzard=false
local function ancestorOf(a,b)
    local node=b and b.GetParent and b:GetParent()
    while node do
        if node==a then return true end
        node=node.GetParent and node:GetParent()
    end
end
local function disableDefaultAuraMouse(record,frame,depth)
    if depth>5 or not frame then return end
    if record.mouse[frame]==nil and frame.IsMouseEnabled then
        local ok,enabled=pcall(frame.IsMouseEnabled,frame)
        if ok then record.mouse[frame]=not not enabled end
    end
    if frame.EnableMouse then pcall(frame.EnableMouse,frame,false) end
    if frame.GetChildren then
        local ok,children=pcall(function() return {frame:GetChildren()} end)
        if ok and children then
            for _,child in ipairs(children) do disableDefaultAuraMouse(record,child,depth+1) end
        end
    end
end
local function setDefaultAuraVisible(frame,wantHidden)
    if not frame then return end
    if InCombatLockdown and InCombatLockdown() then pendingBlizzard=true return end
    local record=savedBlizzard[frame]
    if wantHidden then
        if not record then
            local alpha=frame.GetAlpha and frame:GetAlpha() or 1
            record={alpha=alpha,mouse={}}
            savedBlizzard[frame]=record
        end
        -- Keep engine-side aura updates alive. Hide pixels AND mouse hitboxes;
        -- changing Blizzard secure frame properties in combat is forbidden.
        pcall(frame.SetAlpha,frame,0)
        disableDefaultAuraMouse(record,frame,0)
    elseif record then
        pcall(frame.SetAlpha,frame,record.alpha or 1)
        for object,enabled in pairs(record.mouse) do
            if object and object.EnableMouse then pcall(object.EnableMouse,object,enabled) end
        end
        savedBlizzard[frame]=nil
    end
end
function HB.ApplyBlizzardAuraVisibility()
    if InCombatLockdown and InCombatLockdown() then pendingBlizzard=true return false end
    pendingBlizzard=false
    local b=_G.BuffFrame
    local d=_G.DebuffFrame
    local buffVisible=buffOverview and buffOverview:IsShown()
    -- HF23: the native player DebuffFrame must be invisible and inert when
    -- our UI is in use, without deleting its protected aura updates.
    -- Preserve a visible BuffFrame if it happens to parent DebuffFrame.
    setDefaultAuraVisible(b,buffVisible and not ancestorOf(b,d))
    setDefaultAuraVisible(d,not ancestorOf(d,b))
    return true
end
function HB.GetBuffOverviewFractions()
    local f=buffOverview
    local w,h=UIParent:GetWidth(),UIParent:GetHeight()
    if not f or not w or not h or w<=0 or h<=0 then return nil end
    local x,y=f:GetRight(),f:GetTop()
    if not (safe(x) and safe(y)) then return nil end
    return math.max(0,math.min(1,((UIParent:GetRight() or 0)-x)/w)),
           math.max(0,math.min(1,((UIParent:GetTop() or 0)-y)/h))
end
function HB.SetBuffOverviewFractions(x,y)
    if not buffOverview or not HB.db or (InCombatLockdown and InCombatLockdown()) then return false end
    if type(x)~="number" or type(y)~="number" or x<0 or x>1 or y<0 or y>1 then return false end
    local w,h=UIParent:GetWidth(),UIParent:GetHeight()
    if not w or not h then return false end
    local px,py=buffOverview.ClampPosition(-x*w,-y*h)
    buffOverview:ClearAllPoints()
    buffOverview:SetPoint("TOPRIGHT",UIParent,"TOPRIGHT",px,py)
    HB.db.buffOverviewPos={px,py}
    return true
end

-- Historic layout-sharing fields remain harmless no-ops; do not recreate
-- an old floating Debuff Overview through a legacy saved layout.
function HB.GetDebuffOverviewFractions() return nil end
function HB.SetDebuffOverviewFractions() return false end

local blizEvents=CreateFrame("Frame")
blizEvents:RegisterEvent("PLAYER_REGEN_ENABLED")
blizEvents:RegisterEvent("PLAYER_ENTERING_WORLD")
blizEvents:SetScript("OnEvent",function()
    if not (InCombatLockdown and InCombatLockdown()) and (pendingBlizzard or HB.db) then
        HB.ApplyBlizzardAuraVisibility()
    end
end)

function HB.CreateAuraWidgets(r)
    r.hots,r.debuffs,r.buffIcons,r.missingIcons={},{},{},{}
    r.auraArea=CreateFrame("Frame",nil,r)
    r.auraArea:EnableMouse(false)
    r.debuffArea=CreateFrame("Frame",nil,r)
    r.debuffArea:EnableMouse(false)
    -- HoT rail remains one row with its approved sixteen positions. Debuff
    -- widgets grow on demand with real aura count rather than a fixed slot cap.
    for i=1,16 do r.hots[i]=icon(r.auraArea) end
    for i=1,16 do r.debuffs[i]=icon(r.debuffArea) end
    r.buffArea=CreateFrame("Frame",nil,r)
    r.buffArea:EnableMouse(false)
    r.externalBuffArea=CreateFrame("Frame",nil,r)
    r.externalBuffArea:EnableMouse(false)
    r.externalBuffIcons={}
    -- Legacy textures allocate on demand during non-combat scans.
    -- The native C-side AuraContainers maintain their own live buttons.
    r.missingArea=CreateFrame("Frame",nil,r)
    r.missingArea:EnableMouse(false)
    for i=1,MAX_MISSING do r.missingIcons[i]=icon(r.missingArea) end
    setupNativeAuras(r)
    HB.AttachBuffOverviewRow(r)
    -- Debuff area stays parented to the Party unit row; never a separate window.
end
function HB.SizeAuraWidgets(r,areaX,headerH,W,H,manaH,square)
    if not r.auraArea then return end
    -- TB18.3: ALL HoT icons form ONE horizontal row. One icon fills the
    -- actual blue inner height of Focus, not the external golden border.
    local focusH=r.focusTile:GetHeight()
    local cell,railHeight=hotGeometry(focusH)
    local step=cell+3
    local columns=HOT_COLUMNS
    local railW=columns*step+3
    r.auraArea:EnableMouse(false)
    r.auraArea:ClearAllPoints()
    r.auraArea:SetPoint("TOPLEFT",r.focusTile,"TOPRIGHT",3,-HOT_BORDER_INSET)
    r.auraArea:SetSize(railW,railHeight)
    -- Clip to the blue height, and place every fallback texture in row 1.
    -- The rail is mouse transparent and never overlaps the Follow area.
    -- HF12 HoT countdown sits directly BELOW the icon; it must not be cut by
    -- the old focus-height clipping boundary.
    if r.auraArea.SetClipsChildren then r.auraArea:SetClipsChildren(false) end
    for i,o in ipairs(r.hots) do
        local col=i-1
        o.tex:ClearAllPoints()
        o.tex:SetPoint("TOPLEFT",r.auraArea,"TOPLEFT",col*step,0)
        setSize(o,cell)
        -- HTT-01: timer centered below the HoT, not over its artwork.
        o.time:ClearAllPoints()
        o.time:SetPoint("TOP",o.tex,"BOTTOM",0,-1)
        o.time:SetHeight(10)
        o.timerFontSize=math.max(8,math.min(10,math.floor(cell*0.30)))
        if STANDARD_TEXT_FONT then o.time:SetFont(STANDARD_TEXT_FONT,o.timerFontSize,"THICKOUTLINE") end
    end
    -- HF23: keep the HoT's X-column, but align the TOP of the debuff rail
    -- with the BOTTOM of the centered Flower/Follow glyph. This moves with
    -- party tile resizing; never hardcode a -13px vertical offset.
    r.debuffArea:ClearAllPoints()
    local flowerBottom=(r.box:GetHeight()+r.box.icon:GetHeight())/2
    r.debuffArea:SetPoint("TOPLEFT",r.box,"TOPRIGHT",3,-flowerBottom)
    local debuffStep=step
    local debuffRowH=cell+15
    local uiW=(UIParent and UIParent.GetWidth and UIParent:GetWidth()) or 1280
    local right=(r.box.GetRight and r.box:GetRight()) or (uiW*0.33)
    local ps=r.GetEffectiveScale and r:GetEffectiveScale() or 1
    local us=UIParent.GetEffectiveScale and UIParent:GetEffectiveScale() or 1
    local ratio=(type(ps)=="number" and type(us)=="number" and us>0) and ps/us or 1
    local available=math.max(140,(uiW-right-16)/math.max(0.5,ratio))
    r.debuffColumns=math.max(5,math.min(16,math.floor(available/debuffStep)))
    local cols=r.debuffColumns
    r.debuffStep=debuffStep
    r.debuffRowH=debuffRowH
    r.debuffCell=cell
    r.debuffArea:SetSize(cols*debuffStep,math.max(1,math.ceil(#r.debuffs/cols))*debuffRowH)
    for i,o in ipairs(r.debuffs) do
        o.tex:ClearAllPoints()
        o.tex:SetPoint("TOPLEFT",r.debuffArea,"TOPLEFT",((i-1)%cols)*debuffStep,-math.floor((i-1)/cols)*debuffRowH)
        setSize(o,cell)
        o.isNormalBuff=false -- identical HoT timer fitting, not 11pt buff font
        o.time:ClearAllPoints()
        o.time:SetPoint("TOP",o.tex,"BOTTOM",0,-1)
        o.time:SetHeight(10)
        o.timerFontSize=math.max(8,math.min(10,math.floor(cell*0.30)))
        if STANDARD_TEXT_FONT then o.time:SetFont(STANDARD_TEXT_FONT,o.timerFontSize,"THICKOUTLINE") end
    end
    -- TB15: same proven icon widgets, now in an independent top-right panel.
    -- Own, external and missing icons run RIGHT -> LEFT in five fixed rows.
    local buffSize=BUFF_ICON
    r.missingSize=buffSize
    r.missingStep=BUFF_STEP
    r.buffStep=BUFF_STEP
    r.maxBuffIcons=MAX_BUFFS
    r.buffArea:EnableMouse(false)
    r.buffArea:SetSize(math.max(1,#r.buffIcons*BUFF_STEP),buffSize+10)
    r.externalBuffArea:EnableMouse(false)
    r.externalBuffArea:SetSize(math.max(1,#r.externalBuffIcons*BUFF_STEP),buffSize+10)
    local function sizeNormal(o,area,i)
        o.isNormalBuff=true
        o.tex:ClearAllPoints()
        o.tex:SetPoint("TOPRIGHT",area,"TOPRIGHT",-(i-1)*BUFF_STEP,0)
        setSize(o,buffSize)
        -- Keep the current timers below icons, never over the icon artwork.
        o.time:ClearAllPoints()
        o.time:SetPoint("TOP",o.tex,"BOTTOM",0,-1)
        o.time:SetWidth(math.max(38,buffSize+12))
        o.time:SetHeight(12)
        -- HF22: the approved icon size stays 27px, but the timer uses
        -- an 11pt thick-outline face, rather than HF21's tiny 7.5pt.
        -- The row already reserves 14px below the 27px icon.
        o.time:SetHeight(13)
        o.timerFontSize=11
        if STANDARD_TEXT_FONT then o.time:SetFont(STANDARD_TEXT_FONT,11,"THICKOUTLINE") end
        o.time:SetJustifyV("TOP")
    end
    r.sizeBuffIcon=sizeNormal
    for i,o in ipairs(r.buffIcons) do sizeNormal(o,r.buffArea,i) end
    for i,o in ipairs(r.externalBuffIcons) do sizeNormal(o,r.externalBuffArea,i) end
    r.missingArea:EnableMouse(false)
    r.missingArea:SetSize(#r.missingIcons*BUFF_STEP,buffSize+10)
    for i,o in ipairs(r.missingIcons) do
        o.tex:ClearAllPoints()
        o.tex:SetPoint("TOPRIGHT",r.missingArea,"TOPRIGHT",-(i-1)*BUFF_STEP,0)
        setSize(o,buffSize)
    end
    if r.nativeAurasReady then
        r.nativeHots:ClearAllPoints()
        r.nativeHots:SetPoint("TOPLEFT",r.auraArea,"TOPLEFT",0,0)
        -- The single-row group was created at the exact native button size.
        -- If party rows are later resized OOC, scale its visual contents
        -- without rebuilding secure combat auras or re-reading aura data.
        local original=r.hotNativeCell or cell
        local scale=(original>0) and (cell/original) or 1
        r.nativeHots:SetScale(scale)
        r.nativeHots:SetSize(railW/scale,railHeight/scale)
        r.nativeDebuffs:ClearAllPoints()
        r.nativeDebuffs:SetPoint("TOPLEFT",r.debuffArea,"TOPLEFT",0,0)
        local dInitial=r.debuffNativeCell or cell
        local dScale=(dInitial>0) and (cell/dInitial) or 1
        r.nativeDebuffs:SetScale(dScale)
        r.nativeDebuffs:SetSize((cols*debuffStep)/dScale,(math.ceil(MAX_UNIT_AURA_INDEX/cols)*debuffRowH)/dScale)
    end
    HB.AlignBuffOverview()
end
-- Team composition affects which class buffs can be expected. Per-recipient
-- selection of Paladin Blessings remains configurable rather than fabricated.
local REQUIRED_CLASS={mark="DRUID",thorns="DRUID",intellect="MAGE",fortitude="PRIEST",blessing="PALADIN"}
local function buffAvailableInTeam(f)
    local wanted=REQUIRED_CLASS[f]
    if not wanted then return true end
    local function isClass(unit)
        if not UnitExists or not UnitExists(unit) then return false end
        local ok,_,cf=pcall(UnitClass,unit)
        return ok and safe(cf) and cf==wanted
    end
    if isClass("player") then return true end
    if not (IsInGroup and IsInGroup()) then return false end
    for i=1,4 do if isClass("party"..i) then return true end end
    return false
end
-- HF22 Gathering sync: node tracking is a character-local MINIMAP setting,
-- not a UnitAura. Every HaploBox client reports its own state via the existing
-- registered HaploBox party addon channel. No player can inspect another
-- character's tracking setting without a message from that client.
-- State code: '1' = on, '0' = off (missing), 'N' = profession absent,
-- '?' = cannot determine. Only '0' is eligible for a Missing warning.
local GATHER_MESSAGE_PREFIX = "G|"
local GATHER_FRESH_SECONDS = 65
local gatherStates = {} -- local/peer key => {minerals=code,herbs=code,updated=GetTime()}
HB.gatherStates = gatherStates

local function professionKnown(kind)
    local expected=kind=="minerals" and "mining" or "herbalism"
    if GetProfessions and GetProfessionInfo then
        local ok,a,b,c,d,e=pcall(GetProfessions)
        if ok then
            for _,id in ipairs({a,b,c,d,e}) do
                if id then
                    local got,name=pcall(GetProfessionInfo,id)
                    if got and cleanText(name)==expected then return true end
                end
            end
            return false
        end
    end
    -- Some Forever builds do not implement GetProfessions; only use the
    -- known tracking spell in that case. A missing spell is NOT proof that
    -- the character lacks the profession, so report unknown rather than N.
    local spell=kind=="minerals" and 2580 or 2383
    local known=IsPlayerSpell or IsSpellKnown
    if known then
        local ok,v=pcall(known,spell)
        if ok and safe(v) and v==true then return true end
    end
    return nil
end

local function localTrackingCode(kind)
    local learned=professionKnown(kind)
    if learned==false then return "N" end
    if learned~=true then return "?" end
    local wanted=kind=="minerals" and "find minerals" or "find herbs"
    local function entry(i)
        if C_Minimap and C_Minimap.GetTrackingInfo then
            local ok,t=pcall(C_Minimap.GetTrackingInfo,i)
            if ok and type(t)=="table" and safe(t.name) then
                local active=t.active
                if active==nil then active=t.isActive end
                return t.name,active
            end
        end
        if GetTrackingInfo then
            local ok,name,_,active=pcall(GetTrackingInfo,i)
            if ok and safe(name) then return name,active end
        end
    end
    local count
    if C_Minimap and C_Minimap.GetNumTrackingTypes then
        local ok,n=pcall(C_Minimap.GetNumTrackingTypes)
        if ok and type(n)=="number" then count=n end
    end
    if not count and GetNumTrackingTypes then
        local ok,n=pcall(GetNumTrackingTypes)
        if ok and type(n)=="number" then count=n end
    end
    if not count or count<1 or count>200 then return "?" end
    for i=1,count do
        local name,active=entry(i)
        if cleanText(name)==wanted then
            if active==true then return "1" end
            if active==false then return "0" end
            return "?"
        end
    end
    -- If this client cannot find the expected tracking entry, do not assume
    -- the character is missing a usable button.
    return "?"
end

local function groupPeer(sender)
    local key=HB.Norm and HB.Norm(sender)
    if not key or not IsInGroup or not IsInGroup() then return false end
    for i=1,4 do
        local unit="party"..i
        if UnitExists(unit) and HB.Norm(HB.UnitIdent(unit))==key then return true end
    end
    return false
end

local function syncLocalTracking(force)
    if not HB.Norm or not HB.UnitIdent then return end
    local key=HB.Norm(HB.UnitIdent("player"))
    if not key then return end
    local m,h=localTrackingCode("minerals"),localTrackingCode("herbs")
    local now=GetTime and GetTime() or 0
    local prior=gatherStates[key]
    local changed=not prior or prior.minerals~=m or prior.herbs~=h
    gatherStates[key]={minerals=m,herbs=h,updated=now}
    if not (IsInGroup and IsInGroup()) then return end
    if (changed or force) and HB.SendTeamMessage then
        -- Existing Core.lua has already registered the 'HaploBox' prefix.
        pcall(HB.SendTeamMessage,GATHER_MESSAGE_PREFIX..m.."|"..h)
    end
end

local function trackingMissingForPlayer(r,kind)
    local settings=HB.db and HB.db.requiredBuffs or {}
    if settings[kind]==false or not r.unit then return false end
    if not HB.Norm or not HB.UnitIdent then return false end
    local key=HB.Norm(HB.UnitIdent(r.unit))
    if not key then return false end
    -- The local character is always read directly; no stale network cache.
    if UnitIsUnit and UnitIsUnit(r.unit,"player") then
        return localTrackingCode(kind)=="0"
    end
    local state=gatherStates[key]
    local now=GetTime and GetTime() or 0
    return state~=nil and (now-(state.updated or -10000))<=GATHER_FRESH_SECONDS
        and state[kind]=="0" or false
end

-- Polling is an event fallback: some clients don't fire
-- MINIMAP_UPDATE_TRACKING when the tracking option changes. Only changed
-- reports or a low-rate 20-second heartbeat are sent to party members.
local gatherEvents=CreateFrame("Frame")
gatherEvents:SetScript("OnEvent",function(_,event,prefix,msg,_,sender)
    if event=="CHAT_MSG_ADDON" then
        if prefix~="HaploBox" or not safe(msg) or type(msg)~="string" or
            not safe(sender) or type(sender)~="string" or not groupPeer(sender) then return end
        if msg=="G|?" then syncLocalTracking(true);return end
        local m,h=msg:match("^G|([01N?])|([01N?])$")
        if not m then return end
        local key=HB.Norm(sender)
        gatherStates[key]={minerals=m,herbs=h,updated=GetTime and GetTime() or 0}
        return
    end
    if event=="PLAYER_ENTERING_WORLD" or event=="GROUP_ROSTER_UPDATE" then
        -- Do not reuse stale statuses for characters who left or changed group.
        for key in pairs(gatherStates) do
            if key~=HB.Norm(HB.UnitIdent("player")) then gatherStates[key]=nil end
        end
        if C_Timer and C_Timer.After then
            C_Timer.After(2,function()
                syncLocalTracking(true)
                if IsInGroup and IsInGroup() and HB.SendTeamMessage then
                    pcall(HB.SendTeamMessage,"G|?")
                end
            end)
        end
    else
        syncLocalTracking(false)
    end
end)
for _,ev in ipairs({"PLAYER_LOGIN","PLAYER_ENTERING_WORLD","GROUP_ROSTER_UPDATE",
    "SKILL_LINES_CHANGED","MINIMAP_UPDATE_TRACKING","CHAT_MSG_ADDON"}) do
    pcall(gatherEvents.RegisterEvent,gatherEvents,ev)
end
if C_Timer and C_Timer.NewTicker then
    local lastHeartbeat=0
    C_Timer.NewTicker(3,function()
        local now=GetTime and GetTime() or 0
        local force=now-lastHeartbeat>=20
        syncLocalTracking(force)
        if force then lastHeartbeat=now end
    end)
end
local function partyStandard(f)
    local cfg=HB.db and HB.db.requiredBuffs or {}
    return cfg[f]~=false and buffAvailableInTeam(f)
end
local function hideMissing(r)
    for _,o in ipairs(r.missingIcons or {}) do setIcon(o,nil) end
end
function HB.ResetAuraRow(r)
    r.auraGoodAt=nil
    r.lastMissingKey=nil
    r.missingStability=0
    r.lastHelpful,r.lastHots,r.lastHarmful=nil,nil,nil
    r.helpfulSeenAt,r.hotsSeenAt,r.harmfulSeenAt=nil,nil,nil
    for _,group in ipairs({r.hots or {},r.debuffs or {},r.buffIcons or {},r.externalBuffIcons or {}}) do
        for _,o in ipairs(group) do setIcon(o,nil) end
    end
    hideMissing(r)
end
local function updateMissing(r,helpful,hots)
    -- An intentionally unbuffed character still needs red Missing Buffs.
    -- Two consecutive matching noncombat snapshots (below) debounce brief
    -- empty UnitAura race conditions. Do NOT equate zero auras with bad data.
    local found={}
    local sleepingBagStacks=0
    for _,a in ipairs(helpful) do
        local f=family(a)
        if f=="xp" then
            -- applications is explicitly not just a yes/no aura presence flag.
            -- Unknown/secret stack values must never incorrectly clear missing.
            local c=a.count
            if safe(c) and type(c)=="number" then
                sleepingBagStacks=math.max(sleepingBagStacks,c)
                if c>=3 then found.xp=true end
            end
        elseif f then found[f]=true end
    end
    local key={}
    for _,f in ipairs(REQUIRED_ORDER) do key[#key+1]=found[f] and "1" or "0" end
    for _,f in ipairs(TRACKING_ORDER) do key[#key+1]=trackingMissingForPlayer(r,f) and "1" or "0" end
    key=table.concat(key)
    if key==r.lastMissingKey then r.missingStability=(r.missingStability or 0)+1
    else r.lastMissingKey=key;r.missingStability=1 end
    if r.missingStability<2 then hideMissing(r);return end
    local index=0
    for _,f in ipairs(REQUIRED_ORDER) do
        if partyStandard(f) and not found[f] then
            index=index+1
            local config=REQUIRED[f]
            local tex=config.icon
            if config.spell>0 then
                local fn=(C_Spell and C_Spell.GetSpellTexture) or GetSpellTexture
                if fn then local ok,v=pcall(fn,config.spell);if ok and safe(v) and v then tex=v end end
            end
            setIcon(r.missingIcons[index],{icon=tex or "Interface\\Icons\\INV_Misc_QuestionMark",
                count=(f=="xp" and sleepingBagStacks>0) and sleepingBagStacks or nil},true)
            r.missingIcons[index].time:SetText("")
        end
    end
    for _,kind in ipairs(TRACKING_ORDER) do
        if trackingMissingForPlayer(r,kind) then
            index=index+1
            local spell=kind=="minerals" and 2580 or 2383
            local iconPath=kind=="minerals" and "Interface\\Icons\\Spell_Nature_Earthquake" or "Interface\\Icons\\INV_Misc_Flower_02"
            local fn=(C_Spell and C_Spell.GetSpellTexture) or GetSpellTexture
            if fn then local ok,v=pcall(fn,spell);if ok and safe(v) then iconPath=v end end
            if r.missingIcons[index] then
                setIcon(r.missingIcons[index],{icon=iconPath},true)
                r.missingIcons[index].time:SetText("")
            end
        end
    end
    for i=index+1,#r.missingIcons do setIcon(r.missingIcons[i],nil) end
end
-- HF21: all active buffs from expected party families belong on the right,
-- regardless of which player or outsider cast them. Unknown auras are extra.
local function isPartySustainableAura(a)
    local f=family(a)
    return f and partyStandard(f) or false
end
local function isTrackingAura(a)
    local n=cleanText(a and a.name)
    return n=="find minerals" or n=="find herbs"
end
local function ensureLegacyBuffButtons(r,ownCount,externalCount)
    local function grow(list,area,wanted)
        while #list<wanted do
            local o=icon(area)
            list[#list+1]=o
            r.sizeBuffIcon(o,area,#list)
            -- The icon is the only clickable region; Missing Buffs stay inert.
            local button=CreateFrame("Button",nil,area)
            button:SetSize(BUFF_ICON,BUFF_ICON)
            button:SetPoint("TOPLEFT",o.tex,"TOPLEFT",0,0)
            button:RegisterForClicks("RightButtonUp")
            button:EnableMouse(true)
            o.click=button
            button:SetScript("OnEnter",function()
                if not o.aura or not GameTooltip then return end
                GameTooltip:SetOwner(button,"ANCHOR_BOTTOM")
                if GameTooltip.SetUnitAura and r.unit and o.aura.index then
                    pcall(GameTooltip.SetUnitAura,GameTooltip,r.unit,o.aura.index,"HELPFUL")
                end
                GameTooltip:Show()
            end)
            button:SetScript("OnLeave",function() if GameTooltip then GameTooltip:Hide() end end)
            button:SetScript("OnClick",function(_,which)
                if which~="RightButton" or InCombatLockdown and InCombatLockdown() then return end
                if not (r.unit and UnitIsUnit and UnitIsUnit(r.unit,"player")) then return end
                local a=o.aura
                if not a or not a.auraInstanceID then return end
                -- No insecure fallback to protected CancelUnitBuff or /cancelaura.
                local cancel=C_UnitAuras and C_UnitAuras.CancelAuraByInstanceID
                if cancel then pcall(cancel,a.auraInstanceID) end
            end)
        end
        area:SetWidth(math.max(1,#list*BUFF_STEP))
    end
    grow(r.buffIcons,r.buffArea,ownCount)
    grow(r.externalBuffIcons,r.externalBuffArea,externalCount)
end
function HB.UpdateAuraWidgets(r)
    if not r.hots then return end
    if not (r.unit and UnitExists(r.unit)) then HB.ResetAuraRow(r);return end
    local combat=InCombatLockdown and InCombatLockdown()
    if combat then
        -- Party classification depends on readable Lua aura data. Freeze
        -- the last safe buff snapshot during combat; native HoTs/debuffs
        -- continue refreshing in the client.
        return
    end
    local helpful,hots,harmful={},{},{}
    for i=1,MAX_UNIT_AURA_INDEX do
        local a=aura(r.unit,i,"HELPFUL")
        if not a then break end
        if isHot(a) then hots[#hots+1]=a else helpful[#helpful+1]=a end
    end
    for i=1,MAX_UNIT_AURA_INDEX do
        local a=aura(r.unit,i,"HARMFUL")
        if not a then break end
        harmful[#harmful+1]=a
    end
    local now=GetTime and GetTime() or 0
    -- In native mode, scans below serve Missing Buff evaluation OUT OF COMBAT
    -- only; the C-side engine owns all visible active aura widgets.
    -- Some Forever clients return an empty category while UNIT_AURA and the
    -- local party aura cache are catching up. Hold for a brief bounded grace,
    -- on modern clients. On a legacy client, retain only unexpired cached
    -- icons for the duration of protected combat: incomplete but readable.
    local function restore(group, previous, seenAt)
        if #group>0 then return group,true end
        if not previous or not seenAt or (not combat and now-seenAt>5.5) then
            return group,false
        end
        local retained={}
        for _,a in ipairs(previous) do
            local expire=a.expiration
            if not (safe(expire) and type(expire)=="number" and expire>0 and expire<=now) then
                retained[#retained+1]=a
            end
        end
        return retained,false
    end
    local freshHelpful,freshHots,freshHarmful
    helpful,freshHelpful=restore(helpful,r.lastHelpful,r.helpfulSeenAt)
    hots,freshHots=restore(hots,r.lastHots,r.hotsSeenAt)
    harmful,freshHarmful=restore(harmful,r.lastHarmful,r.harmfulSeenAt)
    if freshHelpful then r.lastHelpful=helpful;r.helpfulSeenAt=now end
    if freshHots then r.lastHots=hots;r.hotsSeenAt=now end
    if freshHarmful then r.lastHarmful=harmful;r.harmfulSeenAt=now end
    if #helpful+#hots+#harmful>0 then r.auraGoodAt=now end
    -- Keep native WoW buff order. Missing Buff icons already tell the user what
    -- the party lacks, so extra sorting only makes characters inconsistent.
    stableSort(hots,"hot")
    stableSort(harmful,"debuff")
    -- External buffs keep Blizzard's native slot order. Party-sustainable
    -- families use one deterministic cross-character order (RIGHT -> LEFT)
    -- matching REQUIRED_ORDER; Missing Buffs use that same family order.
    local ownBuffs,externalBuffs={},{}
    for _,buff in ipairs(helpful) do
        if not isTrackingAura(buff) then
            local group=isPartySustainableAura(buff) and ownBuffs or externalBuffs
            group[#group+1]=buff
        end
    end
    stableSort(ownBuffs,"buff")
    -- The only runtime layout inputs are readable noncombat aura counts.
    -- Native HoTs/debuffs remain live; classified buff snapshots freeze combat.
    r.buffShownCount=#ownBuffs
    r.externalBuffShownCount=#externalBuffs
    if not combat then ensureLegacyBuffButtons(r,#ownBuffs,#externalBuffs) end
    HB.AlignBuffOverview()
    do
        -- On legacy clients, retain known auras in combat until their
        -- *actual known expiry*. Do not blank the row after 5.5s of secrets.
        if not r.nativeAurasReady then for i,o in ipairs(r.hots) do setIcon(o,hots[i]);updateTime(o) end end
        -- Legacy clients: allocate only newly observed debuffs out of combat.
        -- Never create a 255-slot texture/FontString array on every login.
        if not r.nativeAurasReady and not combat and #harmful>#r.debuffs then
            local cols=r.debuffColumns or 16
            while #r.debuffs<#harmful do
                local i=#r.debuffs+1
                local o=icon(r.debuffArea)
                r.debuffs[i]=o
                local dStep=r.debuffStep or 27
                local dRowH=r.debuffRowH or 38
                local dCell=r.debuffCell or 24
                o.tex:SetPoint("TOPLEFT",r.debuffArea,"TOPLEFT",((i-1)%cols)*dStep,-math.floor((i-1)/cols)*dRowH)
                setSize(o,dCell)
                o.isNormalBuff=false
                o.time:ClearAllPoints()
                o.time:SetPoint("TOP",o.tex,"BOTTOM",0,-1)
                o.timerFontSize=math.max(8,math.min(10,math.floor(dCell*0.30)))
                if STANDARD_TEXT_FONT then o.time:SetFont(STANDARD_TEXT_FONT,o.timerFontSize,"THICKOUTLINE") end
            end
            r.debuffArea:SetHeight(math.ceil(#r.debuffs/cols)*(r.debuffRowH or 38))
        end
        if not r.nativeAurasReady then for i,o in ipairs(r.debuffs) do setIcon(o,harmful[i]);updateTime(o) end end
        for i,o in ipairs(r.buffIcons) do
            setIcon(o,ownBuffs[i]);updateTime(o)
            if o.click then o.click:SetShown(o.aura~=nil) end
        end
        for i,o in ipairs(r.externalBuffIcons) do
            setIcon(o,externalBuffs[i]);updateTime(o)
            if o.click then o.click:SetShown(o.aura~=nil) end
        end
        r.externalBuffArea:SetShown(r.buffOverviewVisible and #externalBuffs>0)
    end
    -- Missing Buff evaluation is only trustworthy with readable aura fields.
    -- Never clear or invent warnings from a secret/restricted combat snapshot.
    if not combat then updateMissing(r,helpful,hots) end
end
function HB.TickAuraTimers(r)
    if not r.hots then return end
    for _,group in ipairs(r.nativeAurasReady and {r.buffIcons,r.externalBuffIcons} or {r.hots,r.debuffs,r.buffIcons,r.externalBuffIcons}) do
        for _,o in ipairs(group) do updateTime(o) end
    end
end

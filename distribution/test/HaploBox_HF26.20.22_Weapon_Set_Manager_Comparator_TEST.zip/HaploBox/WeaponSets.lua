-- HF26.20.22: Player-managed, immutable-reference weapon sets.
-- An optional sidecar of the ORIGINAL Blizzard CharacterFrame. No equipment changes.
-- The two reference sets are chosen on the character that owns the items.
local HB=HaploBox
local WS={}
HB.WeaponSets=WS
local rows={}
local panel,openButton,choiceTitle,choices,prevPage,nextPage,notices,updateButton
local twoLabel,oneLabel,twoStatus,oneStatus,slotButtons,lockButtons
local chooserSlot,chooserPage,chooserItems=nil,1,{}
local suggestion=nil
local SLOT_TYPES={two={INVTYPE_2HWEAPON=true},main={INVTYPE_WEAPON=true,INVTYPE_WEAPONMAINHAND=true},off={INVTYPE_HOLDABLE=true}}
local function currentName()
    local raw=UnitName and UnitName("player") or ""
    return (raw and raw:match("^([^%s%-]+)")) or "unknown"
end
local function db()
    if not HB.db then return nil end
    HB.db.weaponSetLocks=HB.db.weaponSetLocks or {}
    local name=currentName()
    local c=HB.db.weaponSetLocks[name]
    if type(c)~="table" then c={two={},one={}};HB.db.weaponSetLocks[name]=c end
    if type(c.two)~="table" then c.two={} end
    if type(c.one)~="table" then c.one={} end
    return c
end
local function itemId(link)
    if type(link)~="string" then return nil end
    return tonumber(link:match("item:(%d+)"))
end
local function itemKey(link)
    if type(link)~="string" then return nil end
    -- Keep the entire item payload, including suffix / enchant / upgrade info.
    -- This is an item fingerprint, not a mutable bag slot number.
    return link:match("item:([%d:%-]+)")
end
local function itemInfo(link)
    if not link then return nil end
    local fn=(C_Item and C_Item.GetItemInfo) or GetItemInfo
    if type(fn)~="function" then return nil end
    local ok,name,full,_,_,level,_,_,_,inv,_,_,classID,subID=pcall(fn,link)
    if not ok then return nil end
    if (not inv or not classID or not subID) and C_Item and type(C_Item.GetItemInfoInstant)=="function" then
        local yes,_,_,_,instantInv,_,instantClass,instantSub=pcall(C_Item.GetItemInfoInstant,itemId(link))
        if yes then inv=inv or instantInv;classID=classID or instantClass;subID=subID or instantSub end
    end
    return name,full,tonumber(level) or 0,inv,classID,subID
end
local function legal(link,slot)
    if not itemId(link) then return false,"NOT ITEM" end
    local name,_,req,inv,classID,subID=itemInfo(link)
    if not name or not inv then
        local loader=C_Item and C_Item.RequestLoadItemDataByID
        if type(loader)=="function" then pcall(loader,itemId(link)) end
        return false,"ITEM NOT CACHED"
    end
    if not SLOT_TYPES[slot] or not SLOT_TYPES[slot][inv] then return false,"WRONG SLOT" end
    if slot=="off" then
        if classID~=4 then return false,"NOT AN OFF-HAND" end
    else
        if classID~=2 or not (subID==4 or subID==5 or subID==10 or subID==13 or subID==15) then
            return false,"NOT A DRUID WEAPON"
        end
    end
    if req>tonumber(UnitLevel and UnitLevel("player") or 0) then return false,"FUTURE LEVEL" end
    return true
end
local function carried()
    local list={}
    if type(GetInventoryItemLink)=="function" then
        for _,slot in ipairs({16,17}) do
            local link=GetInventoryItemLink("player",slot)
            if type(link)=="string" then list[#list+1]={link=link,where="EQUIPPED"} end
        end
    end
    local getCount=(C_Container and C_Container.GetContainerNumSlots) or GetContainerNumSlots
    local getLink=(C_Container and C_Container.GetContainerItemLink) or GetContainerItemLink
    if type(getCount)=="function" and type(getLink)=="function" then
        for bag=0,4 do
            local ok,count=pcall(getCount,bag)
            if ok and type(count)=="number" then
                for slot=1,count do
                    local yes,link=pcall(getLink,bag,slot)
                    if yes and type(link)=="string" then
                        list[#list+1]={link=link,where="BAG"}
                    end
                end
            end
        end
    end
    return list
end
local function find(link)
    local key=itemKey(link)
    if not key then return nil end
    for _,v in ipairs(carried()) do
        if itemKey(v.link)==key then return v.link,v.where end
    end
    return nil
end
local function available(slot)
    local found,seen={},{}
    for _,v in ipairs(carried()) do
        local key=itemKey(v.link)
        if key and not seen[key] and legal(v.link,slot) then
            seen[key]=true;found[#found+1]=v
        end
    end
    table.sort(found,function(a,b)
        if a.where~=b.where then return a.where=="EQUIPPED" end
        return tostring(a.link)<tostring(b.link)
    end)
    return found
end
local lastAvailability=nil
local lastPawnScale=nil
local function invalidate()
    lastAvailability=nil
    if type(HB.HaploLootWeaponSetChanged)=="function" then HB.HaploLootWeaponSetChanged() end
end
local function say(msg) print("|cffd9b66eHaplo Weapon Sets:|r "..tostring(msg)) end
local function select(slot,link)
    local d=db();if not d then return false,"DB NOT READY" end
    local set=slot=="two" and d.two or d.one
    if set.locked then return false,"UNLOCK FIRST" end
    local valid,why=legal(link,slot)
    if not valid then return false,why end
    local actual=find(link)
    if not actual then return false,"ITEM NOT IN BAGS/EQUIPPED" end
    if slot=="two" then d.two.link=actual
    elseif slot=="main" then d.one.main=actual
    elseif slot=="off" then d.one.off=actual end
    invalidate()
    return true
end
local function lock(which,locked)
    local d=db();if not d then return false,"DB NOT READY" end
    local set=which=="two" and d.two or d.one
    if not locked then
        if not set.locked then return true end
        set.locked=false;invalidate();return true
    end
    for _,slot in ipairs(which=="two" and {"two"} or {"main","off"}) do
        local link=slot=="two" and set.link or set[slot]
        if not link then return false,"SELECT "..string.upper(slot) end
        if not legal(link,slot) then return false,"INVALID "..string.upper(slot) end
        if not find(link) then return false,"MISSING "..string.upper(slot) end
    end
    if not set.locked then set.locked=true;invalidate() end
    return true
end
local function stateFor(which)
    local d=db();if not d then return "UNKNOWN" end
    local set=which=="two" and d.two or d.one
    if not set.locked then return "UNLOCKED" end
    for _,slot in ipairs(which=="two" and {"two"} or {"main","off"}) do
        local link=slot=="two" and set.link or set[slot]
        if not link or not legal(link,slot) or not find(link) then return "SET MISSING" end
    end
    return "READY"
end
-- A locked reference can disappear from bags without triggering the normal
-- equipment-change event. Only transition READY<->MISSING invalidates scans;
-- unrelated bag loot does not invalidate anything.
local function watchAvailability()
    local d=db();if not d then return end
    local signature=(d.two.locked and stateFor("two") or "UNLOCKED").."/"..
        (d.one.locked and stateFor("one") or "UNLOCKED")
    if lastAvailability and signature~=lastAvailability then
        invalidate()
    end
    lastAvailability=signature
end
local function watchPawnScale()
    local d=db()
    if not d or (not d.two.locked and not d.one.locked) then return end
    local fn=HB.HaploLootGetScale
    if type(fn)~="function" then return end
    local scale=fn()
    if lastPawnScale and lastPawnScale~=scale then
        invalidate() -- do not keep old scan comparisons after a scale switch
    end
    lastPawnScale=scale
end
local function pawnScore(link,scale)
    if type(PawnGetItemData)~="function" or type(PawnGetSingleValueFromItem)~="function" then return nil end
    local ok,item=pcall(PawnGetItemData,link)
    if not ok or type(item)~="table" or type(item.Stats)~="table" then return nil end
    local yes,val=pcall(PawnGetSingleValueFromItem,item,scale)
    if not yes or type(val)~="number" or val~=val or val<0 then return nil end
    return val
end
-- Only a COMPLETE, explicitly locked and still-carried pair is accepted.
-- Return the proposal's same-set ratio and the other set's complete value.
-- The parent scanner transmits these numbers calculated on the OWN character scale.
function WS.Compare(link,inv,raw,scale)
    local slot=inv=="INVTYPE_2HWEAPON" and "two" or
        ((inv=="INVTYPE_WEAPON" or inv=="INVTYPE_WEAPONMAINHAND") and "main" or
        (inv=="INVTYPE_HOLDABLE" and "off" or nil))
    if not slot then return nil end
    local d=db();if not d then return nil end
    if not d.two.locked and not d.one.locked then return nil end -- legacy until configured
    if stateFor("two")~="READY" or stateFor("one")~="READY" then
        return {ok=false,why="LOCK_MISSING"}
    end
    if not legal(link,slot) then return {ok=false,why="LOCK_INVALID"} end
    local twoLink=find(d.two.link)
    local mainLink=find(d.one.main)
    local offLink=find(d.one.off)
    if not twoLink or not mainLink or not offLink then return {ok=false,why="LOCK_MISSING"} end
    local tw,mn,of=pawnScore(twoLink,scale),pawnScore(mainLink,scale),pawnScore(offLink,scale)
    if not tw or not mn or not of or type(raw)~="number" or raw<0 then
        return {ok=false,why="LOCK_NOSCORE"}
    end
    local pair=mn+of
    local base,proposal,other,why
    if slot=="two" then
        base,proposal,other,why=tw,raw,pair,"LOCK_TWO"
    elseif slot=="main" then
        base,proposal,other,why=pair,raw+of,tw,"LOCK_ONE"
    else
        base,proposal,other,why=pair,mn+raw,tw,"LOCK_ONE"
    end
    if base<=0 or other<=0 then return {ok=false,why="LOCK_ZERO"} end
    return {ok=true,why=why,base=base,other=other,proposal=proposal,
        pct=(proposal-base)/base*100,overall=(proposal-other)/other*100}
end
-- Exposed solely for nonsecure unit testing and readonly UI diagnostics.
WS.State=stateFor
WS.Select=select
WS.Lock=lock
WS.Find=find
WS.Available=available
WS.Current=function()return db() end
local function makeText(parent,text,size,x,y)
    local fs=parent:CreateFontString(nil,"OVERLAY",size or "GameFontNormalSmall")
    fs:SetPoint("TOPLEFT",parent,"TOPLEFT",x,y);fs:SetText(text)
    return fs
end
local function button(parent,text,x,y,w,h,fn)
    local b=CreateFrame("Button",nil,parent,"UIPanelButtonTemplate")
    b:SetPoint("TOPLEFT",parent,"TOPLEFT",x,y);b:SetSize(w,h);b:SetText(text)
    b:SetScript("OnClick",fn);return b
end
local refresh,refreshChoices
local function invalidatePicker()
    suggestion=nil
    if refresh then refresh() end
end
local function choose(slot,link)
    local ok,why=select(slot,link)
    if not ok then say(why) else say("Selected "..slot.." reference. Lock the set when ready.") end
    invalidatePicker()
end
local function cursorPick(slot)
    if type(GetCursorInfo)~="function" then return end
    local kind,id,link=GetCursorInfo()
    if kind~="item" then return end
    if type(link)~="string" or not itemId(link) then
        local matches={}
        for _,v in ipairs(available(slot)) do if itemId(v.link)==tonumber(id) then matches[#matches+1]=v.link end end
        if #matches~=1 then say("Choose exact item from the list (duplicate/unknown variant).");return end
        link=matches[1]
    end
    choose(slot,link)
    if type(ClearCursor)=="function" then ClearCursor() end -- never equips the item
end
local function setChooser(slot)
    chooserSlot=slot;chooserPage=1
    refreshChoices()
end
refreshChoices=function()
    if not choices then return end
    chooserItems=chooserSlot and available(chooserSlot) or {}
    local pageCount=math.max(1,math.ceil(#chooserItems/5))
    chooserPage=math.max(1,math.min(chooserPage,pageCount))
    choiceTitle:SetText(chooserSlot and ("CHOOSE "..string.upper(chooserSlot).." · "..#chooserItems.." carried") or
        "Click a weapon slot or drag an item from your bags")
    for i,b in ipairs(choices) do
        local entry=chooserItems[(chooserPage-1)*5+i]
        if entry then
            b.link=entry.link;b.slot=chooserSlot
            local title=itemInfo(entry.link)
            b:SetText((entry.where=="EQUIPPED" and "[E] " or "[B] ")..(title or tostring(entry.link)):sub(1,32))
            b:Show()
        else b.link=nil;b:Hide() end
    end
    prevPage:SetText("<")
    nextPage:SetText("> "..chooserPage.."/"..pageCount)
end
local function maybeSuggestion()
    local d=db()
    if not d or stateFor("two")~="READY" or stateFor("one")~="READY" then return nil end
    local getScale=HB.HaploLootGetScale
    local scale=type(getScale)=="function" and getScale() or nil
    if not scale then return nil end
    local two=find(d.two.link)
    local main=find(d.one.main)
    local off=find(d.one.off)
    if not two or not main or not off then return nil end
    local tw,mn,of=pawnScore(two,scale),pawnScore(main,scale),pawnScore(off,scale)
    if not tw or not mn or not of then return nil end
    local best
    for _,slot in ipairs({"two","main","off"}) do
        local current=slot=="two" and tw or (slot=="main" and mn or of)
        for _,item in ipairs(available(slot)) do
            local val=pawnScore(item.link,scale)
            local ref=slot=="two" and d.two.link or d.one[slot]
            if val and val>current+0.01 and itemKey(item.link)~=itemKey(ref) then
                local gain=val-current
                if not best or gain>best.gain then
                    best={slot=slot,link=item.link,gain=gain,label=(itemInfo(item.link) or "Item")}
                end
            end
        end
    end
    return best
end
local function applySuggestion()
    local proposed=maybeSuggestion() -- recalculate, never accept an old or missing item
    if not proposed or not suggestion or proposed.slot~=suggestion.slot
            or itemKey(proposed.link)~=itemKey(suggestion.link) then
        say("Set upgrade changed. Review the available items again.")
        invalidatePicker();return
    end
    local d=db();if not d then return end
    local set=proposed.slot=="two" and d.two or d.one
    if not set.locked then return end
    if proposed.slot=="two" then d.two.link=proposed.link
    else d.one[proposed.slot]=proposed.link end
    invalidate();say("Locked reference updated to "..proposed.label..". Rescan for Pawn confidence.")
    invalidatePicker()
end
refresh=function()
    if not panel then return end
    local d=db();if not d then return end
    watchPawnScale()
    local state2,state1=stateFor("two"),stateFor("one")
    twoStatus:SetText("2H · "..state2)
    oneStatus:SetText("1H + OFF · "..state1)
    for slot,b in pairs(slotButtons) do
        local link=slot=="two" and d.two.link or d.one[slot]
        local name=link and itemInfo(link) or nil
        b:SetText((slot=="two" and "2H: " or (slot=="main" and "1H: " or "OFF: "))
            ..(name or "[Choose item]")..(link and (find(link) and "" or " [MISSING]") or ""))
    end
    lockButtons.two:SetText(d.two.locked and "UNLOCK 2H" or "LOCK 2H")
    lockButtons.one:SetText(d.one.locked and "UNLOCK 1H+OFF" or "LOCK 1H+OFF")
    suggestion=maybeSuggestion()
    if suggestion then
        updateButton:SetText("UPDATE "..string.upper(suggestion.slot).." SET")
        updateButton:Show()
        notices:SetText("UPDATE AVAILABLE: "..suggestion.label.." (Pawn stat gain)")
    else
        updateButton:Hide()
        notices:SetText("No verified higher-scoring carried replacement · Scores use this Druid's Pawn scale")
    end
    refreshChoices()
end
local function makeUI()
    if not CharacterFrame or panel then return end
    openButton=button(CharacterFrame,"HB SETS",375,-48,78,23,function()
        if panel:IsShown() then panel:Hide() else panel:Show();refresh() end
    end)
    openButton:SetFrameLevel((CharacterFrame:GetFrameLevel() or 1)+5)
    panel=CreateFrame("Frame","HaploBoxWeaponSetsHF26",CharacterFrame,"BackdropTemplate")
    panel:SetPoint("TOPLEFT",CharacterFrame,"TOPRIGHT",2,-30)
    panel:SetSize(340,590);panel:SetFrameStrata("DIALOG")
    panel:SetFrameLevel((CharacterFrame:GetFrameLevel() or 1)+7)
    if panel.SetBackdrop then
        panel:SetBackdrop({bgFile="Interface\\DialogFrame\\UI-DialogBox-Background",
            edgeFile="Interface\\DialogFrame\\UI-DialogBox-Border",edgeSize=18,
            insets={left=7,right=7,top=7,bottom=7}})
    end
    makeText(panel,"HAPLOBOX · WEAPON SETS","GameFontNormal",15,-18)
    button(panel,"X",307,-12,24,22,function()panel:Hide()end)
    makeText(panel,"Select from bags/equipped. Lock never equips.","GameFontHighlightSmall",15,-42)
    twoStatus=makeText(panel,"2H · UNLOCKED","GameFontNormalSmall",16,-70)
    slotButtons={}
    slotButtons.two=button(panel,"2H: [Choose item]",16,-91,306,32,function()setChooser("two")end)
    lockButtons={}
    lockButtons.two=button(panel,"LOCK 2H",16,-129,150,24,function()
        local d=db();if not d then return end
        local ok,msg=lock("two",not d.two.locked)
        if not ok then say(msg) end;invalidatePicker()
    end)
    oneStatus=makeText(panel,"1H + OFF · UNLOCKED","GameFontNormalSmall",16,-174)
    slotButtons.main=button(panel,"1H: [Choose item]",16,-195,306,32,function()setChooser("main")end)
    slotButtons.off=button(panel,"OFF: [Choose item]",16,-235,306,32,function()setChooser("off")end)
    lockButtons.one=button(panel,"LOCK 1H+OFF",16,-274,150,24,function()
        local d=db();if not d then return end
        local ok,msg=lock("one",not d.one.locked)
        if not ok then say(msg) end;invalidatePicker()
    end)
    choiceTitle=makeText(panel,"Click a slot to choose from your bags","GameFontHighlightSmall",16,-314)
    choices={}
    for i=1,5 do
        choices[i]=button(panel,"",16,-334-(i-1)*35,305,30,function(self)
            if self.slot and self.link then choose(self.slot,self.link) end
        end)
    end
    prevPage=button(panel,"<",16,-515,38,24,function()
        chooserPage=math.max(1,chooserPage-1);refreshChoices()
    end)
    nextPage=button(panel,">",58,-515,76,24,function()
        chooserPage=chooserPage+1;refreshChoices()
    end)
    updateButton=button(panel,"UPDATE SET",176,-515,146,24,applySuggestion)
    notices=makeText(panel,"","GameFontHighlightSmall",16,-550)
    for slot,b in pairs(slotButtons) do
        b:RegisterForDrag("LeftButton")
        b:SetScript("OnReceiveDrag",function()cursorPick(slot)end)
        b:SetScript("OnMouseUp",function(_,mouse)
            if mouse=="LeftButton" and GetCursorInfo and GetCursorInfo()=="item" then cursorPick(slot) end
        end)
    end
    panel:SetScript("OnShow",function()refresh()end)
    panel:Hide()
end
local events=CreateFrame("Frame")
for _,e in ipairs({"PLAYER_LOGIN","ADDON_LOADED","PLAYER_ENTERING_WORLD","BAG_UPDATE_DELAYED","PLAYER_EQUIPMENT_CHANGED","GET_ITEM_INFO_RECEIVED"}) do
    pcall(events.RegisterEvent,events,e)
end
events:SetScript("OnEvent",function(_,ev,arg)
    if ev=="PLAYER_LOGIN" or ev=="PLAYER_ENTERING_WORLD" or
        (ev=="ADDON_LOADED" and (arg=="Blizzard_CharacterUI" or arg=="HaploBox")) then
        makeUI();watchAvailability();watchPawnScale()
    elseif ev=="BAG_UPDATE_DELAYED" or ev=="PLAYER_EQUIPMENT_CHANGED" or ev=="GET_ITEM_INFO_RECEIVED" then
        watchAvailability();watchPawnScale()
        if panel and panel:IsShown() then refresh() end
    end
end)
-- CharacterFrame can already be loaded when a /reload occurs.
if CharacterFrame then makeUI() end

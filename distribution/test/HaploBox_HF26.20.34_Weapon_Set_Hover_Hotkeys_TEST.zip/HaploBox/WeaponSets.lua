-- HF26.20.34: hover weapon in Baganator + three native bindings; readonly bag/equipped status markers.
-- HF26.20.33: Baganator equipment-set corner badges + readonly Blizzard equipped markers; no CharacterFrame menu.
-- HF26.20.22: Player-managed, immutable-reference weapon sets.
-- Baganator is the ONLY selector UI; equipment slots show readonly matching labels. No equipment changes.
-- The two reference sets are chosen on the character that owns the items.
local HB=HaploBox
local WS={}
HB.WeaponSets=WS
local SLOT_TYPES={two={INVTYPE_2HWEAPON=true},main={INVTYPE_WEAPON=true,INVTYPE_WEAPONMAINHAND=true},off={INVTYPE_HOLDABLE=true}}
local function currentName()
    local raw=UnitName and UnitName("player") or ""
    return (raw and raw:match("^([^%s%-]+)")) or "unknown"
end
local function db()
    if not HB.db then return nil end
    HB.db.weaponSetLocks=HB.db.weaponSetLocks or {}
    local name=currentName()
    local c=HB.db.weaponSetLocks[name]
    if type(c)~="table" then c={two={},one={}};HB.db.weaponSetLocks[name]=c end
    if type(c.two)~="table" then c.two={} end
    if type(c.one)~="table" then c.one={} end
    return c
end
local function itemId(link)
    if type(link)~="string" then return nil end
    return tonumber(link:match("item:(%d+)"))
end
local function itemKey(link)
    if type(link)~="string" then return nil end
    -- Keep the entire item payload, including suffix / enchant / upgrade info.
    -- This is an item fingerprint, not a mutable bag slot number.
    return link:match("item:([%d:%-]+)")
end
local function itemInfo(link)
    if not link then return nil end
    local fn=(C_Item and C_Item.GetItemInfo) or GetItemInfo
    if type(fn)~="function" then return nil end
    local ok,name,full,_,_,level,_,_,_,inv,_,_,classID,subID=pcall(fn,link)
    if not ok then return nil end
    if (not inv or not classID or not subID) and C_Item and type(C_Item.GetItemInfoInstant)=="function" then
        local yes,_,_,_,instantInv,_,instantClass,instantSub=pcall(C_Item.GetItemInfoInstant,itemId(link))
        if yes then inv=inv or instantInv;classID=classID or instantClass;subID=subID or instantSub end
    end
    return name,full,tonumber(level) or 0,inv,classID,subID
end
local function legal(link,slot)
    if not itemId(link) then return false,"NOT ITEM" end
    local name,_,req,inv,classID,subID=itemInfo(link)
    if not name or not inv then
        local loader=C_Item and C_Item.RequestLoadItemDataByID
        if type(loader)=="function" then pcall(loader,itemId(link)) end
        return false,"ITEM NOT CACHED"
    end
    if not SLOT_TYPES[slot] or not SLOT_TYPES[slot][inv] then return false,"WRONG SLOT" end
    if slot=="off" then
        if classID~=4 then return false,"NOT AN OFF-HAND" end
    else
        if classID~=2 or not (subID==4 or subID==5 or subID==10 or subID==13 or subID==15) then
            return false,"NOT A DRUID WEAPON"
        end
    end
    if req>tonumber(UnitLevel and UnitLevel("player") or 0) then return false,"FUTURE LEVEL" end
    return true
end
local function carried()
    local list={}
    if type(GetInventoryItemLink)=="function" then
        for _,slot in ipairs({16,17}) do
            local link=GetInventoryItemLink("player",slot)
            if type(link)=="string" then list[#list+1]={link=link,where="EQUIPPED"} end
        end
    end
    local getCount=(C_Container and C_Container.GetContainerNumSlots) or GetContainerNumSlots
    local getLink=(C_Container and C_Container.GetContainerItemLink) or GetContainerItemLink
    if type(getCount)=="function" and type(getLink)=="function" then
        for bag=0,4 do
            local ok,count=pcall(getCount,bag)
            if ok and type(count)=="number" then
                for slot=1,count do
                    local yes,link=pcall(getLink,bag,slot)
                    if yes and type(link)=="string" then
                        list[#list+1]={link=link,where="BAG"}
                    end
                end
            end
        end
    end
    return list
end
local function find(link)
    local key=itemKey(link)
    if not key then return nil end
    for _,v in ipairs(carried()) do
        if itemKey(v.link)==key then return v.link,v.where end
    end
    return nil
end
local function available(slot)
    local found,seen={},{}
    for _,v in ipairs(carried()) do
        local key=itemKey(v.link)
        if key and not seen[key] and legal(v.link,slot) then
            seen[key]=true;found[#found+1]=v
        end
    end
    table.sort(found,function(a,b)
        if a.where~=b.where then return a.where=="EQUIPPED" end
        return tostring(a.link)<tostring(b.link)
    end)
    return found
end
local lastAvailability=nil
local lastPawnScale=nil
local function invalidate()
    lastAvailability=nil
    if type(HB.HaploLootWeaponSetChanged)=="function" then HB.HaploLootWeaponSetChanged() end
end
local function say(msg) print("|cffd9b66eHaplo Weapon Sets:|r "..tostring(msg)) end
local function select(slot,link)
    local d=db();if not d then return false,"DB NOT READY" end
    local set=slot=="two" and d.two or d.one
    if set.locked then return false,"UNLOCK FIRST" end
    local valid,why=legal(link,slot)
    if not valid then return false,why end
    local actual=find(link)
    if not actual then return false,"ITEM NOT IN BAGS/EQUIPPED" end
    if slot=="two" then d.two.link=actual
    elseif slot=="main" then d.one.main=actual
    elseif slot=="off" then d.one.off=actual end
    invalidate()
    return true
end
local function lock(which,locked)
    local d=db();if not d then return false,"DB NOT READY" end
    local set=which=="two" and d.two or d.one
    if not locked then
        if not set.locked then return true end
        set.locked=false;invalidate();return true
    end
    for _,slot in ipairs(which=="two" and {"two"} or {"main","off"}) do
        local link=slot=="two" and set.link or set[slot]
        if not link then return false,"SELECT "..string.upper(slot) end
        if not legal(link,slot) then return false,"INVALID "..string.upper(slot) end
        if not find(link) then return false,"MISSING "..string.upper(slot) end
    end
    if not set.locked then set.locked=true;invalidate() end
    return true
end
local function stateFor(which)
    local d=db();if not d then return "UNKNOWN" end
    local set=which=="two" and d.two or d.one
    if not set.locked then return "UNLOCKED" end
    for _,slot in ipairs(which=="two" and {"two"} or {"main","off"}) do
        local link=slot=="two" and set.link or set[slot]
        if not link or not legal(link,slot) or not find(link) then return "SET MISSING" end
    end
    return "READY"
end
-- A locked reference can disappear from bags without triggering the normal
-- equipment-change event. Only transition READY<->MISSING invalidates scans;
-- unrelated bag loot does not invalidate anything.
local function watchAvailability()
    local d=db();if not d then return end
    local signature=(d.two.locked and stateFor("two") or "UNLOCKED").."/"..
        (d.one.locked and stateFor("one") or "UNLOCKED")
    if lastAvailability and signature~=lastAvailability then
        invalidate()
    end
    lastAvailability=signature
end
local function watchPawnScale()
    local d=db()
    if not d or (not d.two.locked and not d.one.locked) then return end
    local fn=HB.HaploLootGetScale
    if type(fn)~="function" then return end
    local scale=fn()
    if lastPawnScale and lastPawnScale~=scale then
        invalidate() -- do not keep old scan comparisons after a scale switch
    end
    lastPawnScale=scale
end
local function pawnScore(link,scale)
    if type(PawnGetItemData)~="function" or type(PawnGetSingleValueFromItem)~="function" then return nil end
    local ok,item=pcall(PawnGetItemData,link)
    if not ok or type(item)~="table" or type(item.Stats)~="table" then return nil end
    local yes,val=pcall(PawnGetSingleValueFromItem,item,scale)
    if not yes or type(val)~="number" or val~=val or val<0 then return nil end
    return val
end
-- Only a COMPLETE, explicitly locked and still-carried pair is accepted.
-- Return the proposal's same-set ratio and the other set's complete value.
-- The parent scanner transmits these numbers calculated on the OWN character scale.
function WS.Compare(link,inv,raw,scale)
    local slot=inv=="INVTYPE_2HWEAPON" and "two" or
        ((inv=="INVTYPE_WEAPON" or inv=="INVTYPE_WEAPONMAINHAND") and "main" or
        (inv=="INVTYPE_HOLDABLE" and "off" or nil))
    if not slot then return nil end
    local d=db();if not d then return nil end
    if not d.two.locked and not d.one.locked then return nil end -- legacy until configured
    if stateFor("two")~="READY" or stateFor("one")~="READY" then
        return {ok=false,why="LOCK_MISSING"}
    end
    if not legal(link,slot) then return {ok=false,why="LOCK_INVALID"} end
    local twoLink=find(d.two.link)
    local mainLink=find(d.one.main)
    local offLink=find(d.one.off)
    if not twoLink or not mainLink or not offLink then return {ok=false,why="LOCK_MISSING"} end
    local tw,mn,of=pawnScore(twoLink,scale),pawnScore(mainLink,scale),pawnScore(offLink,scale)
    if not tw or not mn or not of or type(raw)~="number" or raw<0 then
        return {ok=false,why="LOCK_NOSCORE"}
    end
    local pair=mn+of
    local base,proposal,other,why
    if slot=="two" then
        base,proposal,other,why=tw,raw,pair,"LOCK_TWO"
    elseif slot=="main" then
        base,proposal,other,why=pair,raw+of,tw,"LOCK_ONE"
    else
        base,proposal,other,why=pair,mn+raw,tw,"LOCK_ONE"
    end
    if base<=0 or other<=0 then return {ok=false,why="LOCK_ZERO"} end
    return {ok=true,why=why,base=base,other=other,proposal=proposal,
        pct=(proposal-base)/base*100,overall=(proposal-other)/other*100}
end
-- Exposed solely for nonsecure unit testing and readonly UI diagnostics.
WS.State=stateFor
WS.Select=select
WS.Lock=lock
WS.Find=find
WS.Available=available
WS.Current=function()return db() end

-- The actual locks and Pawn full-set comparison above are unchanged; only
-- the way players choose their exact owned weapon references is different.
-- Baganator owns its pooled bag buttons and their tooltip hooks. Its own
-- corner-widget API is the only bag integration; no bag button scripts are
-- replaced or secure item clicks hijacked.
local badgePluginRegistered=false
local characterBadges={}
local knownBagButtons=setmetatable({}, {__mode="k"})
local knownBagCorners=setmetatable({}, {__mode="k"})
local function selectedSlot(slot,link)
    local d=db()
    if not d or not itemKey(link) then return false end
    local selected=slot=="two" and d.two.link or d.one[slot]
    return itemKey(selected)==itemKey(link)
end
local function slotFor(link)
    if not itemId(link) then return nil end
    for _,slot in ipairs({"two","main","off"}) do
        if legal(link,slot) then return slot end
    end
    return nil
end
local function slotName(slot)
    return slot=="two" and "2H" or (slot=="main" and "1H" or "OH")
end
local function announce(message)
    if type(print)=="function" then
        print("|cffd9b66eHaplo Weapon Sets:|r "..tostring(message))
    end
end
local updateEquipped,refreshBagIcons
-- Left-click Baganator's tiny corner badge = select the exact physical item.
-- A complete 2H reference locks immediately, a 1H reference locks as a pair
-- only once BOTH the mainhand and held offhand have been chosen.
-- Right-click the SAME selected badge to unlock/remove that set reference.
local function markItem(slot,link,clear)
    if InCombatLockdown and InCombatLockdown() then return false,"OUT OF COMBAT ONLY" end
    if not (slot=="two" or slot=="main" or slot=="off") then return false,"WRONG SLOT" end
    local d=db();if not d then return false,"DB NOT READY" end
    local isSelected=selectedSlot(slot,link)
    local which=slot=="two" and "two" or "one"
    local set=which=="two" and d.two or d.one
    if clear then
        if not isSelected then return false,"THIS ITEM IS NOT MARKED" end
        set.locked=false
        if slot=="two" then set.link=nil else set[slot]=nil end
        invalidate()
        if refreshBagIcons then refreshBagIcons() end
        if updateEquipped then updateEquipped() end
        return true,"UNMARKED "..slotName(slot).."; set unlocked"
    end
    local ok,why=legal(link,slot)
    if not ok then return false,why end
    local found=find(link)
    if not found then return false,"ITEM NOT IN YOUR BAGS/EQUIPMENT" end
    if set.locked and not isSelected then
        return false,"UNMARK THE CURRENT "..(which=="two" and "2H" or "1H/OH").." REFERENCE FIRST"
    end
    if isSelected and set.locked then return true,slotName(slot).." ALREADY LOCKED" end
    if set.locked then return false,"UNMARK THE CURRENT REFERENCE FIRST" end
    local yes,msg=select(slot,link)
    if not yes then return false,msg end
    if which=="two" then
        local locked,problem=lock("two",true)
        if not locked then return false,problem end
    elseif d.one.main and d.one.off then
        local locked,problem=lock("one",true)
        if not locked then
            announce("1H + OH selection saved, but pair cannot lock: "..tostring(problem))
        end
    end
    if refreshBagIcons then refreshBagIcons() end
    if updateEquipped then updateEquipped() end
    local label=slotName(slot)
    return true,(which=="two" or d.one.locked) and (label.." MARKED + LOCKED") or
        (label.." MARKED; choose the other 1H/OH item to lock the pair")
end
WS.MarkItem=markItem
WS.GetMarkedSlot=function(link)
    for _,slot in ipairs({"two","main","off"}) do
        if selectedSlot(slot,link) then return slot end
    end
end

-- Real player inventory only. Baganator also supports cached bank/offline
-- items: these must NEVER become weapon references for the current Druid.
local function liveBagLink(itemButton,details)
    if not itemButton or not details or type(details.itemLink)~="string" then return nil end
    local bag,slot
    if type(itemButton.GetBagID)=="function" then
        local ok,value=pcall(itemButton.GetBagID,itemButton)
        if ok then bag=tonumber(value) end
    end
    if (bag==nil or bag<0 or bag>4) and itemButton.BGR then
        bag=tonumber(itemButton.BGR.bagID)
    end
    if type(itemButton.GetID)=="function" then
        local ok,value=pcall(itemButton.GetID,itemButton)
        if ok then slot=tonumber(value) end
    end
    -- Baganator exposes the physical slot explicitly on some versions.
    -- Its pooled/cached buttons may lack a normal GetBagID/GetID pair.
    if (bag==nil or slot==nil) and type(itemButton.GetSlotAndBagID)=="function" then
        local ok,realSlot,realBag=pcall(itemButton.GetSlotAndBagID,itemButton)
        if ok then
            bag=bag or tonumber(realBag)
            slot=slot or tonumber(realSlot)
        end
    end
    if bag==nil or not slot or bag<0 or bag>4 or slot<1 then return nil end
    local getLink=(C_Container and C_Container.GetContainerItemLink) or GetContainerItemLink
    if type(getLink)~="function" then return nil end
    local ok,current=pcall(getLink,bag,slot)
    if not ok or not current or itemKey(current)~=itemKey(details.itemLink) then return nil end
    return current
end
-- A corner status indicator is visual only. Baganator keeps its normal item
-- mouse-click/drag semantics; the user's keybinding performs assignment.
local function createCorner(itemButton)
    local badge=CreateFrame("Frame",nil,itemButton)
    badge:SetSize(23,15)
    if badge.EnableMouse then badge:EnableMouse(false) end
    badge.hbOwner=itemButton
    knownBagButtons[itemButton]=true
    knownBagCorners[itemButton]=badge
    local backing=badge:CreateTexture(nil,"BACKGROUND")
    backing:SetAllPoints(badge)
    backing:SetColorTexture(.09,.10,.12,.90)
    badge.hbBacking=backing
    local text=badge:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
    text:SetPoint("CENTER",badge,"CENTER",0,0)
    text:SetTextColor(1,.69,.23)
    badge.hbText=text
    return badge
end
local function updateCorner(button,details)
    button.hbSlot=nil;button.hbLink=nil
    local link=liveBagLink(button.hbOwner,details)
    if not link then return false end
    knownBagButtons[button.hbOwner]=true
    local slot=slotFor(link)
    if not slot then return false end
    button.hbSlot=slot;button.hbLink=link
    local marked=selectedSlot(slot,link)
    local d=db()
    local locked=d and ((slot=="two" and d.two.locked) or (slot~="two" and d.one.locked))
    button.hbText:SetText(marked and slotName(slot) or "")
    if marked then
        button.hbText:SetTextColor(locked and 1 or .46,locked and .70 or .86,locked and .18 or 1)
        button.hbBacking:SetColorTexture(.16,.11,.06,.94)
    else
        button.hbText:SetTextColor(.72,.72,.72)
        button.hbBacking:SetColorTexture(.10,.10,.10,0)
    end
    return marked -- only the 2H/1H/OH status occupies a Baganator corner

end
local function registerBaganatorCorner()
    if badgePluginRegistered then return end
    local api=Baganator and Baganator.API
    if not api or type(api.RegisterCornerWidget)~="function" then return end
    local ok,err=pcall(api.RegisterCornerWidget,"HaploBox Weapon Set","haplobox_weapon_set",
        updateCorner,createCorner,{corner="bottom_right",priority=1})
    if ok then badgePluginRegistered=true
    else announce("Baganator widget unavailable: "..tostring(err)) end
end
refreshBagIcons=function()
    local api=Baganator and Baganator.API
    if not api or type(api.RequestItemButtonsRefresh)~="function" then return end
    local reason=Baganator.Constants and Baganator.Constants.RefreshReason and
        Baganator.Constants.RefreshReason.ItemWidgets
    if reason then pcall(api.RequestItemButtonsRefresh,{reason})
    else pcall(api.RequestItemButtonsRefresh) end
end
-- Keybinding callbacks must use the ACTUAL hovered live Baganator button.
-- Never use tooltip item links, stored bag positions, bank data or cached
-- alt items to decide which weapon to mark. Baganator can recycle icon frames.
local function hoveredLiveWeapon()
    local foci={}
    if type(GetMouseFoci)=="function" then
        local ok,v=pcall(GetMouseFoci)
        if ok and type(v)=="table" then foci=v end
    end
    if #foci==0 and type(GetMouseFocus)=="function" then
        local ok,v=pcall(GetMouseFocus)
        if ok and v then foci[1]=v end
    end
    for _,focus in ipairs(foci) do
        local button=focus
        for _=1,12 do
            if not button then break end
            if knownBagButtons[button] then
                local bag,slot
                if type(button.GetBagID)=="function" then
                    local ok,v=pcall(button.GetBagID,button)
                    if ok then bag=tonumber(v) end
                end
                if bag==nil and button.BGR then bag=tonumber(button.BGR.bagID) end
                if type(button.GetID)=="function" then
                    local ok,v=pcall(button.GetID,button)
                    if ok then slot=tonumber(v) end
                end
                if (bag==nil or slot==nil) and type(button.GetSlotAndBagID)=="function" then
                    local ok,a,b=pcall(button.GetSlotAndBagID,button)
                    if ok then bag=bag or tonumber(b);slot=slot or tonumber(a) end
                end
                if bag~=nil and bag>=0 and bag<=4 and slot and slot>=1 then
                    local getLink=(C_Container and C_Container.GetContainerItemLink) or GetContainerItemLink
                    if type(getLink)=="function" then
                        local ok,link=pcall(getLink,bag,slot)
                        if ok and type(link)=="string" then
                            local badge=knownBagCorners[button]
                            -- Confirm the visible button was refreshed with the
                            -- same exact item fingerprint after a sort/move.
                            if badge and badge.hbLink and itemKey(link)==itemKey(badge.hbLink) then
                                return link
                            end
                        end
                    end
                end
                return nil
            end
            if type(button.GetParent)~="function" then break end
            local ok,parent=pcall(button.GetParent,button)
            if not ok or parent==button then break end
            button=parent
        end
    end
end
WS.HoveredLiveWeapon=hoveredLiveWeapon
function WS.MarkHovered(slot)
    if slot~="two" and slot~="main" and slot~="off" then return false end
    -- Fail before unlocking any previously saved set reference.
    if InCombatLockdown and InCombatLockdown() then
        announce("OUT OF COMBAT ONLY")
        return false
    end
    local link=hoveredLiveWeapon()
    if not link then
        announce("Hover a LIVE weapon in Baganator first (not bank, alt or tooltip).")
        return false
    end
    local legalItem,reason=legal(link,slot)
    if not legalItem then
        announce("Cannot mark "..slotName(slot)..": "..tostring(reason))
        return false
    end
    -- Same key on the same item toggles its status off. Assigning a new
    -- physical item replaces only the explicitly chosen slot in its set.
    if selectedSlot(slot,link) then
        local ok,msg=markItem(slot,link,true)
        announce(msg);return ok
    end
    local d=db()
    if not d then return false end
    local which=slot=="two" and "two" or "one"
    if (which=="two" and d.two.locked) or (which=="one" and d.one.locked) then
        lock(which,false)
    end
    local ok,msg=markItem(slot,link,false)
    announce(msg);return ok
end

-- Three actual Blizzard binding actions, configured in a small Quick Menu
-- submenu. Capturing keys never runs a macro or changes equipment.
local actionBySlot={two="HAPLOBOX_WEAPON_TWO",main="HAPLOBOX_WEAPON_MAIN",off="HAPLOBOX_WEAPON_OFF"}
local bindingFrame,bindRows,bindingNotice,captureSlot,pendingConflict
local slotOrder={"two","main","off"}
local bindTitles={two="2-Handed Weapon",main="1-Handed Weapon",off="Off-Hand"}
local function currentKey(slot)
    if type(GetBindingKey)~="function" then return nil end
    local ok,a=pcall(GetBindingKey,actionBySlot[slot])
    return ok and a or nil
end
local function bindingMessage(s)
    if bindingNotice then bindingNotice:SetText(s) end
end
local function refreshBindings()
    if not bindRows then return end
    for _,slot in ipairs(slotOrder) do
        local b=bindRows[slot]
        if b then b:SetText(currentKey(slot) or "Set key") end
    end
end
local function setBindingKey(slot,key,overwrite)
    if InCombatLockdown and InCombatLockdown() then return false,"Change keybindings after combat." end
    if type(GetBindingAction)~="function" or type(SetBinding)~="function" or
        type(SaveBindings)~="function" or type(GetCurrentBindingSet)~="function" then
        return false,"Blizzard keybinding API unavailable."
    end
    local action=actionBySlot[slot]
    if not action then return false,"Unknown weapon action" end
    if key and key~="" then
        local used=GetBindingAction(key)
        if used and used~="" and used~=action and not overwrite then
            return false,"KEY IN USE: "..key.." ("..used.."). Click Set key, press the SAME key again to confirm replacement."
        end
    end
    local old=currentKey(slot)
    if key and key~="" then
        local ok,result=pcall(SetBinding,key,action)
        if not ok or result==false then return false,"Could not bind "..key end
        if old and old~=key and GetBindingAction(old)==action then pcall(SetBinding,old) end
    elseif old then
        local ok,result=pcall(SetBinding,old)
        if not ok or result==false then return false,"Could not clear "..old end
    end
    local ok,result=pcall(SaveBindings,GetCurrentBindingSet())
    if not ok or result==false then return false,"Could not save the binding" end
    return true,key and key~="" and (bindTitles[slot].." = "..key) or (bindTitles[slot].." unbound")
end
local function startCapture(slot)
    if not bindingFrame then return end
    if InCombatLockdown and InCombatLockdown() then bindingMessage("Change bindings after combat.") return end
    captureSlot=slot
    bindingFrame:EnableKeyboard(true)
    bindingMessage("Press a key for "..bindTitles[slot]..". ESC cancels, Backspace clears.")
end
local function stopCapture()
    captureSlot=nil
    if bindingFrame then bindingFrame:EnableKeyboard(false) end
end
local function createWeaponBindingMenu()
    if bindingFrame then return end
    local f=CreateFrame("Frame","HaploBoxWeaponSetKeybindings",UIParent)
    bindingFrame=f;f.hbMenuName="WeaponSetKeybindings"
    f:SetSize(410,216);f:SetFrameStrata("DIALOG")
    f:SetClampedToScreen(true);f:SetMovable(true);f:EnableMouse(true)
    if HB.MenuStyle then HB.MenuStyle.Window(f,26) end
    local bg=f:CreateTexture(nil,"BACKGROUND")
    bg:SetAllPoints();bg:SetColorTexture(.095,.11,.14,.98)
    local title=f:CreateFontString(nil,"OVERLAY","GameFontNormal")
    title:SetPoint("TOPLEFT",f,"TOPLEFT",14,-12)
    title:SetText("Weapon Sets | Hover + Hotkey")
    title:SetTextColor(1,.80,.32)
    local close=CreateFrame("Button",nil,f,"UIPanelButtonTemplate")
    close:SetSize(24,22);close:SetPoint("TOPRIGHT",f,"TOPRIGHT",-7,-7)
    close:SetText("X");close:SetScript("OnClick",function()f:Hide()end)
    bindRows={}
    for i,slot in ipairs(slotOrder) do
        local y=-47-(i-1)*40
        local line=f:CreateTexture(nil,"BACKGROUND")
        line:SetPoint("TOPLEFT",f,"TOPLEFT",8,y+3);line:SetSize(394,36)
        line:SetColorTexture(.12,.16,.20,.94)
        local label=f:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
        label:SetPoint("TOPLEFT",f,"TOPLEFT",16,y-7)
        label:SetText(bindTitles[slot])
        local key=CreateFrame("Button",nil,f,"UIPanelButtonTemplate")
        key:SetSize(128,25);key:SetPoint("TOPRIGHT",f,"TOPRIGHT",-50,y+2)
        key:SetScript("OnClick",function()
            if captureSlot==slot then stopCapture();bindingMessage("Cancelled.")
            else stopCapture();startCapture(slot) end
        end)
        bindRows[slot]=key
        local clear=CreateFrame("Button",nil,f,"UIPanelButtonTemplate")
        clear:SetSize(28,25);clear:SetPoint("TOPRIGHT",f,"TOPRIGHT",-13,y+2)
        clear:SetText("X")
        clear:SetScript("OnClick",function()
            stopCapture();pendingConflict=nil
            local ok,msg=setBindingKey(slot,"")
            bindingMessage(msg);refreshBindings()
        end)
    end
    bindingNotice=f:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
    bindingNotice:SetPoint("TOPLEFT",f,"TOPLEFT",14,-174)
    bindingNotice:SetSize(382,35);bindingNotice:SetJustifyH("LEFT")
    bindingNotice:SetWordWrap(true)
    bindingNotice:SetTextColor(.93,.80,.56)
    f:SetScript("OnKeyDown",function(self,key)
        local slot=captureSlot
        if not slot then return end
        stopCapture()
        if key=="ESCAPE" then bindingMessage("Cancelled.");return end
        if key=="LSHIFT" or key=="RSHIFT" or key=="LCTRL" or key=="RCTRL" or
            key=="LALT" or key=="RALT" then
            bindingMessage("Choose a full key or key combination.");return
        end
        local value=key
        if key=="BACKSPACE" or key=="DELETE" then value=""
        else
            if IsControlKeyDown and IsControlKeyDown() then value="CTRL-"..value end
            if IsAltKeyDown and IsAltKeyDown() then value="ALT-"..value end
            if IsShiftKeyDown and IsShiftKeyDown() then value="SHIFT-"..value end
        end
        local confirmed=pendingConflict and pendingConflict.slot==slot and pendingConflict.key==value
        local ok,msg=setBindingKey(slot,value,confirmed)
        if not ok and msg and msg:find("KEY IN USE",1,true) then
            pendingConflict={slot=slot,key=value}
        else pendingConflict=nil end
        bindingMessage(msg);refreshBindings()
    end)
    f:SetScript("OnHide",function() stopCapture();pendingConflict=nil end)
    f:EnableKeyboard(false);f:Hide()
end
function HB.OpenWeaponSetKeybindings()
    createWeaponBindingMenu()
    refreshBindings()
    bindingMessage("Hover a LIVE Baganator weapon, then press its assigned hotkey. Press again to unmark.")
    if HB.OpenQuickSubmenu then HB.OpenQuickSubmenu(bindingFrame)
    else bindingFrame:Show() end
end
local function makeEquippedBadge(frame)
    if not frame then return nil end
    local badge=CreateFrame("Frame",nil,frame)
    badge:SetSize(24,15)
    badge:SetPoint("TOPRIGHT",frame,"TOPRIGHT",-1,-1)
    badge:SetFrameLevel((frame:GetFrameLevel() or 1)+1)
    local backing=badge:CreateTexture(nil,"BACKGROUND")
    backing:SetAllPoints(badge)
    backing:SetColorTexture(.15,.10,.05,.94)
    badge.text=badge:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
    badge.text:SetPoint("CENTER",badge,"CENTER",0,0)
    badge.text:SetTextColor(1,.70,.22)
    badge:Hide()
    return badge
end
updateEquipped=function()
    local d=db()
    if not d then return end
    local main=_G.CharacterMainHandSlot
    local off=_G.CharacterSecondaryHandSlot
    if main and not characterBadges.main then characterBadges.main=makeEquippedBadge(main) end
    if off and not characterBadges.off then characterBadges.off=makeEquippedBadge(off) end
    local links={main=GetInventoryItemLink and GetInventoryItemLink("player",16),
        off=GetInventoryItemLink and GetInventoryItemLink("player",17)}
    for position,badge in pairs(characterBadges) do
        if badge then
            local link=links[position]
            local name
            if link then
                if position=="main" and selectedSlot("two",link) then name="2H"
                elseif position=="main" and selectedSlot("main",link) then name="1H"
                elseif position=="off" and selectedSlot("off",link) then name="OH" end
            end
            if name then
                badge.text:SetText(name)
                badge:Show()
            else badge:Hide() end
        end
    end
end
local events=CreateFrame("Frame")
for _,event in ipairs({"PLAYER_LOGIN","PLAYER_ENTERING_WORLD","ADDON_LOADED",
        "PLAYER_EQUIPMENT_CHANGED","BAG_UPDATE_DELAYED","GET_ITEM_INFO_RECEIVED"}) do
    pcall(events.RegisterEvent,events,event)
end
events:SetScript("OnEvent",function(_,event,arg)
    if event=="PLAYER_LOGIN" or event=="PLAYER_ENTERING_WORLD" or
        (event=="ADDON_LOADED" and (arg=="Baganator" or arg=="Blizzard_CharacterUI" or arg=="HaploBox")) then
        registerBaganatorCorner()
        watchAvailability();watchPawnScale();updateEquipped()
    elseif event=="PLAYER_EQUIPMENT_CHANGED" or event=="BAG_UPDATE_DELAYED" then
        watchAvailability();watchPawnScale();updateEquipped()
    elseif event=="GET_ITEM_INFO_RECEIVED" then
        -- Baganator refreshes its own item cache; never force tooltip resets.
        watchAvailability();updateEquipped()
    end
end)
-- Blizzard CharacterUI might already be available before PLAYER_LOGIN.
if CharacterFrame then updateEquipped() end
-- Intentionally NO HB SETS button or external menu in CharacterFrame.
-- /hbsets is a text-only fallback/diagnostic, not a second picker UI.
SLASH_HAPLOBOXWEAPONSET1="/hbsets"
SlashCmdList.HAPLOBOXWEAPONSET=function()
    local a,b=stateFor("two"),stateFor("one")
    announce("2H: "..a.." | 1H + Off-hand: "..b)
    announce("Open Quick Menu > Weapon Sets to assign 2H / 1H / OH hotkeys.")
    announce("Hover a LIVE Baganator item and press its key to mark/unmark; C shows equipped labels.")
    if not badgePluginRegistered then
        announce("Baganator's corner-widget API not detected: bag markers unavailable.")
    end
end

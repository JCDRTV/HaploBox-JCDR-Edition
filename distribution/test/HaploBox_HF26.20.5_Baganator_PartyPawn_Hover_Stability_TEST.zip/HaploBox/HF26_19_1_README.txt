HaploBox HF26.19.1 HOTFIX TEST — 21 Nov 2026

1. Party Frames: 1..5 numbers replaced with live current / maximum HP on left of health bar; existing percent remains right. Client 12.x secret HP while in combat shows HP ? to avoid protected Lua formatting errors.
2. Buff Overview: orange numeral boxes removed; each 27px buff remains same size, timers use 8pt font in a narrower bottom cell; stacks move to inside bottom-right. Dense 39px row grid. Move Buffs drag anchor is lower-left of the visually populated buffs. No 22px blank band above top row. Existing saved position remains unchanged; unlock in UI Layout then drag to right/top.
3. Original WoW/BAGANATOR item tooltip: on ALT down, re-check and reattach current Party Pawn lines after 0.06s and 0.20s, including tooltip OnHide/OnShow caused by Baganator rebuild. Does not touch approved five-client tooltip columns.

OFFLINE PASS is not INGAME approval. Recommended tests: full/half/zero HP; combat/out-of-combat /reload; five Buff rows and different buffs/missing; unlocked grip visible bottom-left and persistent position; Baganator ALT-hover shows five rows; Blizzard bags and AtlasLoot continue working. All prior ZIP backups kept.

HF26.20.2 - F1 CAMERA ONLY (NO CAMERA IN MINI UI) - TEST

Mini UI now changes ONLY the UI. Switching Main/Mini will NOT adjust zoom, camera pitch or tracking. The old camera automation and compensating reverse tilt are removed; any saved legacy Mini camera snapshot only has its original cameraSmoothTrackingStyle preference restored once (if present).

The already approved Smart Follow behavior is untouched: F1 continues to issue exactly the same /follow party1/partyX (Direct/Dungeon routes), and then recalls an explicitly calibrated follower-only Blizzard camera view 5 via HaploBox.SmartFollowCamera(). No additional keybinding or automatic /follow. Mael's camera stays under manual control.

SETUP: after update and /reload, each follower can set desired view manually and use /hb followcam save confirm to save it. WARNING: overwrites native Blizzard saved camera slot 5 on that follower. F1 then recalls the angle and zoom. Existing saved views from HF26.20.1 remain valid; do NOT need to save again if already calibrated.

Test: toggle Main/Mini several times WITHOUT F1, confirm camera unchanged. Then press F1 in Direct and Dungeon and confirm follow target AND camera view. In combat, any failed SetView retry occurs only after combat. /hb followcam off turns off F1 camera recall but leaves the working Smart Follow macro unchanged. Observe walking camera tracking after SetView; Blizzard saved camera views may change native tracking behavior.

Base HF26.20.1. Only MiniCamera.lua, MiniHeal.lua, TOC and version history altered; README added. No unrelated modules. Syntax/mocks checked offline; NOT YET APPROVED INGAME.

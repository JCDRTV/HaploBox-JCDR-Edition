HF15 CAM-01 — Follower Camera | OFFLINE TEST, not Live OK
Base: exact HF14_BUFF_OVERVIEW_UPGRADE_REBASED_TEST (all prior code retained).
In Mini UI, ONLY follower client: save current zoom/auto-adjust, zoom out to at least 20, set cameraSmoothTrackingStyle 4 (move auto-follow), nudge pitch down briefly.
On Main UI: restore captured camera zoom/tracking and reverse the relative pitch nudge. Never overwrites Blizzard SaveView slots 2-5 or Group Leader camera.
Combat: existing MiniHeal SetMiniHealMode defers protected UI switching until PLAYER_REGEN_ENABLED.
Reload/login: the transient snapshot is persisted; reconciliation after entry.
Limitations: camera pitch cannot be measured exactly by supported APIs. Its reversal is approximate, particularly if user manually changes pitch while Mini UI is active, or camera collisions occur. Ingame verification required. The view is never restored via permanent saved-camera slots.
Suggested QA: on follower with custom zoom + angle + camera-follow OFF, switch MINI -> MAIN, /reload in MINI, combat mode toggle, solo/leader, manually adjust camera in MINI, ensure no stuck camera pitch motion.
Old HF14 ZIP, HF10 live rollback and all prior backups remain unchanged.

HAPLOBOX JCDR EDITION - HF26.0 HAPLO LOOT (ALPHA / INGAME TEST REQUIRED)
20 November 2026

SOURCE
- Built cumulatively from the user's HF25.1 ITEMINFO hotfix ZIP (not an older source copy).
- The original LootAdvisor.lua is RETAINED unchanged for bridge testing.
- All existing Follow, Box Mode, macros, partyframes, buff/HoT monitors, Gathering Map and Trade Lua files are byte-identical to HF25.1.

NEW: SHARED WISHLIST / DUNGEON FARM PLANNER
- /hb loot or /hb haploloot opens HAPLO LOOT on Mael.
- Quick Menu > MENUS > Haplo Loot opens the same view.
- JCDR Edition style uses the existing HaploBox MenuStyle (dark neutral/gold, identical button styling), not a separate legacy skin.
- AtlasLoot provides dungeon list, boss order and actual loot ID lists (no hard-coded item catalog).
- Select dungeon > boss to browse concise drops; manually pin an item for any of the five Druids.
- Click SCAN DUNGEON to request live Pawn evaluations from the party, paced at 1 item every 0.3s.
- Mael stores shared pins in HaploBoxDB.lootPlanner.pins; other clients do not need their own pins.
- Item minimum required level is a hard gate; above-level upgrades display FUTURE, never as current upgrades.
- Uses AtlasLoot LevelRange[1] (documented minEnter) to gate current dungeon farmability for ALL five characters.
- When the same non-weapon/non-ring/non-trinket slot has a better candidate in ANOTHER FULLY SCANNED, currently accessible dungeon, the weaker automated wish is marked REPLACED.
- Only the currently scanned/validated dungeon set participates in comparisons; unscanned dungeons show [?], not zero.
- No fabricated Pawn percentage: NO SCALE, missing stats, empty slots, uncertain weapon pair or uncached gear remain unknown/flagged.
- Full 2H vs equipped MH+OH is handled. A 1H vs currently equipped 2H remains NEEDPAIR until a valid MH+OH combination is assessed.
- Pawn's CanEquip flag and conservative druid equipment filters prevent obviously unusable items from ranking.
- On-demand scanning only; no permanent player-equipment sync or polling.

HOW TO TEST
1. Save previous HF25.1 ZIP. Install this ZIP's HaploBox folder on ALL FIVE druids; /reload each client.
2. Install/enable Pawn and AtlasLoot Forever (including AtlasLootClassic_DungeonsAndRaids).
3. On Mael open Quick Menu > Menus > HAPLO LOOT (or /hb loot).
4. Select Deadmines, confirm boss order; choose a boss, confirm item names.
5. Press SCAN DUNGEON with all five in the same party and clients online.
6. Check that all five character checks return and the scan says COMPLETE; missing results are INCOMPLETE and cannot be used for ranking.
7. Choose an item and pin/unpin Mael, Lyra, Elya, Nyra, Ayla; close/reopen and verify pins persist.
8. Test at levels below/above a specific item's requirement: it must not count until usable.
9. Scan a second accessible dungeon to check REPLACED logic for the same equipment slot.
10. Check Quick Menu, follow, Box Mode, macros, partyframes, Lyra Gathering Map and HoT features for regressions.
11. The older HF25.1 test browser is available via /hb lootdebug or /hb atlasloot, including ALT+Hover checks.

KNOWN LIMITATIONS / NEXT ITERATIONS
- Not ingame validated. Percentages/party bridge need five-client testing before use for real decisions.
- Native AtlasLoot window ALT+Hover is NOT YET integrated; HF25 bridge ALT+Hover is still limited to /hb lootdebug.
- AtlasLoot's own per-character favorites have not yet been imported; this version uses HaploBox manual pins on Mael.
- Dungeon accessibility uses documented minEnter level; actual navigation/party viability is not proven.
- Ranking only includes fully scanned accessible dungeons, not every dungeon automatically at login.
- No automatic background rescans; changing gear or level invalidates scores, use SCAN DUNGEON again. This avoids stale percentages.
- Two rings/trinkets and MH+OH optimization are deliberately NOT collapsed into one auto-wish without complete set comparison.
- Unknown/new empty-slot upgrade has no percentage and does not enter the numeric gear ranking.
- Class-specific tooltips/Forever Feral weapon-DPS value should be verified ingame with Pawn before approving the ranking.
- No Dungeon Run Tracker yet.

CHANGED FILES VS HF25.1
- HaploBox/HaploBox.toc: add LootPlanner.lua and bump HF version.
- HaploBox/Core.lua: /hb loot -> planner, preserve /hb lootdebug bridge.
- HaploBox/ControlBar.lua: add Haplo Loot to MENUS section; grow dynamic menu by one row.
- HaploBox/LootPlanner.lua: isolated new planner engine and styled UI.
- HaploBox/HF26_0_README.txt: this file.

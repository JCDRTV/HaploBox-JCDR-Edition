HAPLOBOX JCDR — HF22 TRACKING SYNC + READABLE TIMERS — TESTBUILD
Base: HF21 ZIP (which itself was built strictly on HF20).
Status: offline reviewed; needs in-game validation on all five accounts.

1. Buff Overview active buffs: raised own/external timers from 7.5pt OUTLINE
   to 11pt THICKOUTLINE. Icons remain 27px; 41px row gap unchanged.
   HoT and Debuff rows and the approved Mini UI remain untouched.

2. Gathering Find Herbs/Find Minerals: remote characters now report their
   own profession/tracking states over the EXISTING HaploBox addon channel.
   Codes: on=1 (never shown); off=0 (show red missing icon); profession
   absent=N (never shown); unknown=? (do not invent missing).
   Only party members can supply/receive these updates. Only the receiving
   player's local minimap API can read their own tracking state.
   Tracks both MINIMAP_UPDATE_TRACKING and SKILL_LINES_CHANGED plus a
   3-second local poll, with 20-second party heartbeat and roster queries.
   Remote statuses are dropped after 65 seconds without a refresh.
   All characters must run HF22 for cross-client tracking display to work.

TEST:
- Install HF22 on Mael AND Lyra (ideally all five), /reload on each.
- On Lyra, learn Herbalism and turn Find Herbs OFF. On Mael confirm
  missing Find Herbs icon in LYRA row (not Mael's row).
- Switch Find Herbs ON; icon must disappear on Mael within a few seconds.
- Check buff durations at 11pt are readable and do not overlap other icons.
- Check the three buff columns and Mini UI still behave as in HF21.

NOT SOLVED OR CLAIMED:
- Detailed Camp Benefits / Leatherworking tent semantics still need live
  verification; code is unchanged.
- Party buff family classification remains snapshot-based during combat.
- Remote tracking with a character still on HF21 cannot be shown.

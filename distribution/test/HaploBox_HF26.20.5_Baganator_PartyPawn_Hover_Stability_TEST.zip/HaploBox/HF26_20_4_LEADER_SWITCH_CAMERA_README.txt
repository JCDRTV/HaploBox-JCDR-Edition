HaploBox HF26.20.4 - Leader-switch camera calibration TEST

PROBLEM: HF26.20.3 blocked /hb followcam save confirm on the active group
leader. Changing Mael to follower later would leave his camera unsaved.

FIX: EVERY group member, including Mael as leader (or while solo), may SAVE
Blizzard camera view 5 locally with explicit /hb followcam save confirm.
This overwrites native view 5 for the current character/account.

The original Smart Follow F1 macro is unchanged. The view is ONLY recalled
if this client is currently a follower in a party with BOX ON. When leader,
F1 never changes the camera, even if view 5 is saved. Leadership switch is
read from live WoW group leader state and the macro follows roster updates.
No change to F1 follow target rules, role mapping, or Mini UI camera.

TEST: Save camera view on Mael while Mael is leader. /hb followcam status
should show ON but inactive on current leader. F1 must not change Mael's
camera. Make Lyra leader (outside combat), ensure BOX ON and the existing
Smart Follow macro is refreshed after roster changes. Mael now follower:
F1 should follow its configured target and restore view 5. Switch Mael back
to leader: F1 does not change camera. View may be saved while solo too.

Use /hb followcam off on any character to disable only the camera reset.
HF26.20.3 Mini Buff fix and all prior features remain unchanged.

OFFLINE TESTED ONLY - user must validate inside WoW Forever.

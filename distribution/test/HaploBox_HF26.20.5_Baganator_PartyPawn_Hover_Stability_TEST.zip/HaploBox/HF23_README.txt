HAPLOBOX – JCDR EDITION | HF23 TESTBUILD
Base: HF22_GATHER_SYNC_TIMER_READABILITY_TEST.zip (cumulative).
Build state: OFFLINE LUA PARSE + MOCK NATIVE HOT GROUP CHECK PASSED.
Not yet ingame validated. HF22/HF21/HF20 remain untouched.

1) Missing Buffs: red warning icons in the left area move FOUR PIXELS left
   of the group separator. No other buff panel geometry changes.

2) Blizzard player DebuffFrame: hidden outside combat via the existing safe
   alpha/mouse record-and-restore infrastructure. Child/parent guard avoids
   making normal Blizzard BuffFrame disappear when using a shared parent.
   Party-frame native debuffs remain enabled and visible in HaploBox.

3) Party-frame debuffs: X starts with the HoT rail (right of Follow tile);
   Y matches the BOTTOM of the centered Flower/Follow status glyph instead
   of a fixed -13px offset. Icon dimensions and countdown styling now derive
   from the SAME live Focus/HoT cell height. Native and legacy fallback both
   use the matched geometry, resizing outside combat only.

4) Mael Mini HoT Monitor:
   - local Mael Ashgrove only, enabled by default, no names/background.
   - Rejuvenation row max 5 active icons, Regrowth row max 5 active icons.
   - Timer is INSIDE each icon. Empty auras never create a visible tile.
   - Entire monitor is mouse-pass-through, including active icons.
   - Native Blizzard AuraContainer receives exact spell-ID filters and owns
     secure-combat aura changes/duration numbers, like existing party HoTs.
   - Fallback for older clients can read normal local UnitBuff when safe;
     secret protected auras need the native renderer for live combat updates.
   - MOVE HOTS drag handle appears only when UNLOCKED; saved position,
     lock/reset/on/off commands and UI Layout buttons. Default lower-right.
   - /hb hotpanel unlock|lock|reset|on|off (use outside combat).

5) Mini UI: no global frame scans. Previously captured *non-protected*
   Blizzard chat/cast/swing optional windows now gain bounded OnShow hooks,
   which immediately re-mute alpha when they reappear while Mini UI is on.
   Protected frames are NEVER manipulated in combat; layering flash of a
   protected Blizzard frame remains a live-test question, not a guarantee.

6) Party Sustainable Buffs: same fixed family order on every unit, matching
   REQUIRED_ORDER (RIGHT to LEFT: Sleeping Bag XP, Food, Camp, Mark, Thorns,
   Intellect, Fortitude, Blessing). MISSING uses the same family order;
   external buffs preserve scanned Blizzard order. Tracking stays missing-only.
   Family sorting freezes during restricted combat as in HF22.

ACCEPTANCE TEST: load HF23 on all five characters, /reload each.
- Mael: /hb hotpanel unlock; drag to wanted place; /hb hotpanel lock.
- Apply 1, 2, ... up to 5 Rejuvenations and Regrowths from different Druids
  on Mael; verify dynamic compact rows and visible in-icon countdowns DURING
  COMBAT. On expiration, each icon disappears without a leftover hitbox.
- Click the game world through the monitor with HoTs ACTIVE and EMPTY.
- Check revised Blizzard debuff visibility (not missing partyframe debuffs),
  red Missing warnings not touching divider and stable right-side buff order.
- Poison/curse on party member: debuff begins aligned to glyph bottom,
  icon+timer same scale/face as HoTs on same party row.
- Combat: observe chat, cast and swing windows for one-frame flashing,
  especially protected frames / third-party windows not in HUD_NAMES.

Do NOT call HF23 ingame approved until the user tests it.
Camp Benefits / Leatherworking Tent semantics remain live-validation TODO.

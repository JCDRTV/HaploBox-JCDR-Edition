-- HF24: Lyra-only native Blizzard Minimap in her OWN Mini UI.
-- Find Herbs dots come directly from Lyra's real minimap tracking, not
-- from Mael, an addon message, a guessed node database or a separate map.
-- All mutations happen outside combat. Snapshot and restore native layout.
local HB=HaploBox
local snapshot=nil
local unavailableReported=false
local function locked() return InCombatLockdown and InCombatLockdown() end
local function valid(v) return type(v)=="number" and not (issecretvalue and issecretvalue(v)) end
function HB.IsLyraGatheringMapClient()
    local name=HB.UnitIdent and HB.UnitIdent("player")
    local norm=name and HB.Norm and HB.Norm(name)
    return norm=="lyra" or norm=="lyra ashgrove"
end
function HB.WantsGatheringMiniMap()
    return HB.db and HB.db.miniHealMode and HB.db.gatheringMapEnabled~=false
        and HB.IsLyraGatheringMapClient()
end
local function frameReady()
    local m=_G.Minimap
    if not (m and m.SetParent and m.SetPoint and m.ClearAllPoints and m.SetSize and m.GetParent) then
        return nil
    end
    if m.IsForbidden then
        local ok,forbidden=pcall(m.IsForbidden,m)
        if not ok or forbidden then return nil end
    end
    return m
end
local function capture(m)
    if snapshot then return snapshot end
    local s={frame=m,parent=m:GetParent(),width=m:GetWidth(),height=m:GetHeight(),
        scale=m:GetScale(),alpha=m:GetAlpha(),shown=m:IsShown(),
        strata=m:GetFrameStrata(),level=m:GetFrameLevel(),
        mouse=m.IsMouseEnabled and m:IsMouseEnabled(),points={}}
    for i=1,(m:GetNumPoints() or 0) do
        local point,relative,relativePoint,x,y=m:GetPoint(i)
        s.points[#s.points+1]={point,relative,relativePoint,x,y}
    end
    if #s.points==0 then return nil end
    snapshot=s
    return s
end
local function restore()
    if not snapshot or locked() then return false end
    local s=snapshot
    local m=s.frame
    local success=pcall(function()
        m:SetParent(s.parent)
        m:ClearAllPoints()
        m:SetScale(s.scale)
        m:SetSize(s.width,s.height)
        for _,p in ipairs(s.points) do m:SetPoint(p[1],p[2],p[3],p[4],p[5]) end
        m:SetFrameStrata(s.strata)
        m:SetFrameLevel(s.level)
        m:SetAlpha(s.alpha)
        if s.mouse~=nil then m:EnableMouse(s.mouse) end
        if s.shown then m:Show() else m:Hide() end
    end)
    if success then snapshot=nil end
    return success
end
function HB.RestoreGatheringMiniMap() return restore() end
function HB.ApplyGatheringMiniMap()
    if locked() then return false end
    if not HB.WantsGatheringMiniMap() then return restore() end
    local m=frameReady()
    if not m then
        if not unavailableReported and HB.print then
            HB.print("Gathering Map: native minimap unavailable on this client.")
            unavailableReported=true
        end
        return false
    end
    local s=capture(m)
    if not s then return false end
    local sw,sh=UIParent:GetWidth(),UIParent:GetHeight()
    if not (valid(sw) and valid(sh) and sw>100 and sh>100) then return false end
    -- Red marked top-left panel is approximately half the mini viewport high.
    -- Keep it square: native minimap projection remains correct for tracking.
    local size=math.floor(math.min(430,sh*0.50,sw*0.255))
    if size<90 then return false end
    local ok=pcall(function()
        -- Moving the SAME Blizzard Minimap outside its faded native Cluster
        -- avoids showing default Blizzard chrome, and prevents changing
        -- the original map placement on Mael or any other client.
        m:SetParent(UIParent)
        m:SetScale(1)
        m:SetSize(size,size)
        m:ClearAllPoints()
        m:SetPoint("TOPLEFT",UIParent,"TOPLEFT",8,-8)
        m:SetFrameStrata("LOW")
        m:SetFrameLevel(35)
        m:SetAlpha(1)
        m:EnableMouse(false) -- don't intercept clicks in the follower Mini UI
        m:Show()
    end)
    if not ok then
        restore()
        if not unavailableReported and HB.print then
            HB.print("Gathering Map could not reposition Blizzard Minimap. Check minimap addons.")
            unavailableReported=true
        end
        return false
    end
    return true
end
function HB.SetGatheringMapEnabled(on)
    if locked() or not HB.db or not HB.IsLyraGatheringMapClient() then return false end
    HB.db.gatheringMapEnabled=not not on
    if HB.UpdateMiniHealLayout then HB.UpdateMiniHealLayout() end
    -- Explicitly re-apply in case layout was already current.  In the normal
    -- Mini UI this is idempotent; on OFF it restores the original map now.
    if HB.ApplyGatheringMiniMap then HB.ApplyGatheringMiniMap() end
    if HB.RefreshControls then HB.RefreshControls() end
    return true
end

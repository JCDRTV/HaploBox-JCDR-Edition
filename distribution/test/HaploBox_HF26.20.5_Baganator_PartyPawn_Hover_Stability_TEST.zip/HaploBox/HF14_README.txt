HaploBox — HF14 / Buff Overview Upgrade (TESTBUILD)
19 November 2026 | Parent: HF13 Menu Layout & Restyle
STATUS: OFFLINE TEST PASS / INGAME TEST OPEN. NOT LIVE APPROVED.

APPROVED SCOPE
- Retain five-player buff overview, Missing Buffs LEFT, player-cast buffs RIGHT.
- Insert other-caster EXTERNAL buffs between them using Blizzard's native
  HELPFUL|PLAYER versus HELPFUL|!PLAYER filters (12.1 client), with no custom
  aura-time or spell-ID sorting. External section/discriminator disappears at zero.
- Match external/own icon dimensions, spacing, and duration text below icons.
- All sections grow LEFT in one row; never wrap, auto-scale, or hide buffs to fit.
- New visible MOVE BUFFS drag handle INSIDE frame top when UI Layout unlocks;
  hidden when locked. The complete group moves and position persists after
  /reload; clamp handle position on drag and UI scale/resolution changes.
- Native AuraButton mouseover tooltip and secure SetCancelAuraButtons("RightButton")
  for allowed self buffs; HoTs/debuffs remain mouse-transparent. On legacy
  clients, expose tooltip with safe, instance-ID cancellation where available.
- Preserve original HoT/debuff/camp/required-buff detection and party security.
- No old separate Debuff Overview is created; HF13 menus remain unchanged.

SOURCE FILES MODIFIED: Auras.lua; HaploBox.toc; HF_VERSION_HISTORY.txt.
ADDED: HF14_README.txt. No other modules or media changed.

IMPORTANT CLIENT LIMITATIONS / LIVE TESTS
- Restricted combat aura details remain engine-owned. Dynamic section widths
  are based on the last safe, out-of-combat count; auras gained during combat
  may need an out-of-combat refresh before spacing catches up.
- Canceling only works when the client permits it; never bypass WoW secure
  protections. Hover/cancel must be verified inside the 12.1 WoW client.
- Test 0/1/many EXTERNAL buffs; 5 rows; mixed player/other source; timer
  positioning; Blizzard order; on-combat updates; right-click on self versus
  another character; tooltip; move/lock/reload/reset/UI scale and Sync Layout.
- Legacy WoW clients may have limited cancellation; do not claim Live OK.
- Separate open issues BUF-03 (Camp Benefits presentation) and BUF-06
  (Mining/Herbalism missing-only rules) were NOT changed in this build;
  they require their own accurate source/ingame checks.


Base for packaging verified again against later HF13 quick-menu-style ZIP, which differs from earlier HF13 only in its READMEs/history (no Lua, TOC or media changes).

ROLLBACK: HF13 ZIP preserved separately, HF10 remains last in-game
validated rollback until newer versions pass user tests.

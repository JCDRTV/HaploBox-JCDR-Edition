HF26.2 — Party Communication Diagnostics Hotfix (JCDR Edition)
Base: HF26.1 cumulative build. No changes to existing Core, partyframes, macros, Follow Indicators or Box Mode.

Changes:
- Automatic diagnostic ping at each SCAN DUNGEON start: Mael broadcasts P|token, each druid returns A|token|HF26.2.
- Party channel chosen like stable HaploBox core: PARTY, RAID or INSTANCE_CHAT as applicable.
- Prefix registration checked for success and retried on send if missing.
- Send errors and false-return sends tracked; missing replies are NEVER interpreted as 0% upgrades.
- New standalone /hblootnet command to inspect local network state on each client. On Mael, /hblootnet ping also sends an ad-hoc probe.
- At the end of incomplete scan, status shows which Druids returned PING OK versus NO PING.
- The title status displays party handshake count (0/4 ... 4/4).

TEST: Install on all five; /reload; group the five Druids. On Mael open /hb loot and SCAN DUNGEON.
Read the status line and chat. If no replies, run /hblootnet on Mael and Lyra, copy both outputs.
To send a new ping without another scan use /hblootnet ping on Mael, then /hblootnet on Lyra.

Do not treat this build as a verified repair until tested ingame. The diagnostic will identify routing issues.
AtlasLoot ALT-hover direct integration and automatic rankings remain separate work.

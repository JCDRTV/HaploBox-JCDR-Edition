HF18 - MINI UI HUD CLEANUP - TEST BUILD
=====================================
Status: OFFLINE TEST BUILD. Ingame NOT verified.
Base: Complete HF17 Mini UI HUD/Spy/Player Names ZIP; cumulative build.

Observed in the HF17 ingame screenshot:
- Standard Blizzard bars and Spy Nearby are no longer visible.
- 'Damage Done' meter (likely Skada) remains bottom right.
- 'Main Hand' swing timer remains near screen center/bottom.
- Green character/NPC overhead names remain inside the world scene.
- The right-side tooltip is transient when hovering an NPC; left enabled to
  preserve normal tooltips/mouseover and avoid UI regressions.

Targeted changes only in MiniHeal.lua:
1) Hide known damage meter frames, especially named Skada:GetWindows
   instances (bounded list, 12 maximum).
2) Hide known swing timer frame/module references if available.
   The specific installed swing-timer addon was not supplied; this is
   best-effort. If still visible, use /fstack to identify the actual frame.
3) Save/mute/restore extra NPC-name CVars; 1s refresh while Mini can
   reapply after other addons change CVar settings.

No change to Mini UI orange HP geometry, camera, Spy, menus, buffs,
healing/party targeting, or any underlying gameplay logic.
No EnumerateFrames global scans or combat-protected Hide calls.
Test Main UI restoration, /reload, and DM combat before Live OK.

HF17 — Mini UI HUD / Spy / player name visibility fix — 19 November 2026

This is a cumulative test build on the full HF16 Quick Menu Crash Fix.
The six approved orange health frames, size, anchors, health functions,
Mini Camera, all Buff Overview and Quick Menu code are UNCHANGED.

Mini UI on followers now handles the three user-reported remaining elements:
- Blizzard action bars, micro menu, bags and other known native HUD parts,
  with alpha suppression for protected frames instead of combat-unsafe Hide;
- Spy addon Nearby (Spy.MainWindow / Spy_MainWindow) and known Spy panels;
- overhead friendly/enemy player names, pet/player guild names, nameplates.

Main UI and PLAYER_LOGOUT restore the previously captured visibility, alpha,
and CVar settings. No global EnumerateFrames scans or unsupported combat
operations. Strictly no forced Blizzard secure/hardware-action changes.

TEST in game on a follower: Mini -> check bars/bags/Spy/nameplates are
visually absent, press binding /hb view main -> see original HUD return;
/reload while Mini, then return Main. Entering combat or zone changes can
cause protected Blizzard HUD to be shown again by the client; a bounded
1-second refresh applies only while out of combat. If the installed Spy
version uses a different or anonymous main frame, its actual frame name
must be supplied for a precise follow-up.

OFFLINE TEST ONLY. WoW Live PASS / DM validation still open.

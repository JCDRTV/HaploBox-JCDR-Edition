HAPLOBOX HF25 – PAWN + ATLASLOOT BRIDGE / TEST BUILD
Base: HF24; all Follow, Box Mode, Trade and macro source files unchanged.

OPEN ON MAEL: /hb loot
Requires installed Pawn and AtlasLootClassic + AtlasLootClassic_DungeonsAndRaids.

- On-demand AtlasLoot module load and dungeon/boss/drop browsing.
- Select an item to query all four party clients ONCE. No polling or cached party results.
- Each client evaluates with its own Pawn scale and equipped gear.
- Pawn scale must match the spec; if ambiguous, Change Pawn Scale locally on EACH client.
- Full 2H vs current MH + OH combined; ring/trinket replaces weaker slot.
- Scores are potential main-spec item stat deltas, NOT boss drop odds.
- Some statless, uncached, proc-based or unequippable comparisons show an explicit status instead of fabricated %.
- In particular proc/special-effect scores depend on Pawn weights; NO 'accurate DPS' guarantee.

IN-GAME TEST PLAN:
1. Test /hb loot on Mael with all 5 and Pawn loaded. Check atlas module gets loaded.
2. Select Deadmines > a boss > an item. See five rows; if SET SCALE, open /hb loot on that client and choose correct Pawn profile.
3. Compare MH+OH to 2H; check no false huge upgrade.
4. Repeat same item after gear changes; each click sends a fresh query.
5. Confirm Quick Menu + Lyra minimap from HF24 still behave.

KNOWN LIMITATIONS: First bridge only. NO dungeon ranking, no drop probability model, no automated item exclusion, no run timer yet.
Do not assume it is production-stable until on-client tests pass.

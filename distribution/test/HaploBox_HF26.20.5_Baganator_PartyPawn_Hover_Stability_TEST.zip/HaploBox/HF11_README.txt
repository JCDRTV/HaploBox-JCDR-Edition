HaploBox – JCDR Edition | HF11 Mini UI Upgrade test build
Base: HF10 (native Blizzard minimap, no HaploBar)

MIN-02: Four bottom party HP blocks are reduced by 25% in height, fixed bottom, same width. Player/target blocks shift down by the identical removed height.
MIN-03/MIN-04: Additional known Blizzard, Questie, Zygor and damage meter frames are suppressed in Mini UI; original shown state restored in Main UI. Nameplate CVars saved and restored. No periodic global frame enumeration. Protected Blizzard frames are intentionally left to Blizzard's secure system.
MIN-05: Party and self orange current HP/dark red missing; target red current HP/dark grey missing.
Mini UI shows six HP blocks, without on-screen buttons. Return via the existing keybind Toggle Main / Mini UI or '/hb view main' (out of combat).

Important limitations: Optional third-party addon windows with unknown frame names may need a follow-up targeted frame-name fix. Protected HUD components cannot be forcibly hidden by insecure Lua in combat. Combat mode switching is queued until out of combat.
Test Main > Mini > Main, reload/zone, combat, five clients and addon-specific UI. HF10 remains rollback.

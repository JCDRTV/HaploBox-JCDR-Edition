HAPLOBOX – JCDR EDITION | HF26.18 DYNAMIC DUNGEON SCAN TEST
21 NOVEMBER 2026 | NOT AN INGAME-APPROVED RELEASE

CUMULATIVE BASE
- Exact HF26.17_DUNGEON_ADVISOR_V1_TEST ZIP (unchanged and preserved).
- Only LootPlanner.lua, HaploBox.toc, version history and this note differ.
- Keep unchanged: HF26.16 Party Pawn Need/Pawn arrow/percent columns, LootHover,
  BoxMode, Mini Heal, camera, follow, menus, Blizzard interactions, buffs,
  trades, macros, secure frames and WoW SavedVariables.

WHAT CHANGED
- SCAN ALL DUNGEONS processes all AtlasLoot dungeon datasets, not just
  current-level/lowest-party-level ones. Raids still excluded.
- All dungeon rows remain browsable. An optional NOW ONLY view filters the
  displayed list by the lowest present group's level (the SCAN always does ALL).
- An ALL BOSS LOOT mode displays every recognized boss item, including items
  that are not verified upgrades; UPGRADES ONLY returns to confirmed or
  explicit future upgrade rows. No manual PIN-based scan selection.
- Future boss items that Pawn can evaluate are shown with LV and asterisk as
  a hypothetical gain versus CURRENT equipment. These are NOT assured future
  best-in-slot or recommended Need rolls. They do not enter the current score;
  dungeons above a client's level show FUTURE and no fictitious rank.
- Solo Mael works without group. With partial/full Team A, one bounded
  addon-presence handshake identifies responsive Lyra/Elya/Nyra/Ayla.
  Unresponsive group members are reported and keep rankings INCOMPLETE/?,
  while verified responding members remain visible. No imaginary zero.
- Item scanning is paced at approx 0.18 sec per unique item (subject to
  client/FPS load). Replies are no longer awaited five times for EVERY item.
  One short grace period and a maximum 12 targeted retries PER DUNGEON bound
  a disconnected/nonresponding client. Cache per explicit scan avoids repeated
  per-client Pawn calculation for identical itemIDs. No background checks.
- It remains an on-click/manual scan, outside combat, and continues if its
  window is temporarily closed. No auto-equip/Need/Greed/casts/trades.

INTENTIONAL LIMITATIONS
- Character/scale/class evaluation remains safe Team A Druid profile only.
  Other classes are detected as unsupported and the group rank is INCOMPLETE.
  General multi-class scale routing requires later separate implementation.
- Pawn/AtlasLoot must actually provide usable item/stat/cache data. Any
  missing data or mixed/unknown item types remain ? / unknown; never 0%.
- A future +% is a Pawn comparison with gear worn TODAY, not a projection
  of equipment at the future dungeon level.
- Boss section filtering still deliberately excludes Trash, Quest, Vendor,
  Professions and Crafts; raids remain out of Dungeon Advisor scope.
- Time-to-complete depends on real client processing, addon-message rates,
  and item caching. Mock timing is NOT a real-world performance guarantee.

OFFLINE VERIFICATION
- 30/30 packaged Lua modules parse with texlua.
- Five simulated party scenarios: Mael solo, Mael+Lyra, all five Druids,
  Mael+unresponsive Lyra, Mael+unsupported class.
- Each mock scans all 34 sample dungeons, including a future dungeon,
  with no per-item timeout loops. Responses, FUTURE status and incomplete
  markers checked. UI mock: open, BOTH filters, loot/detail navigation PASS.
- ZIP integrity/CRC and cumulative unchanged-module diff PASS.
- These are simulations and source checks; NOT a live WoW validation.

INGAME TEST ON MAEL
1. Use manual GitHub updater after the HF26.18 TEST channel has been
   published; otherwise install the separate HF26.18 ZIP on all active clients.
2. Start on Mael solo, no party, no combat. Open Haplo Loot.
3. Click SCAN ALL DUNGEONS once. It must finish; verify 34 dungeons scanned
   (or the actual AtlasLoot dungeon count), 0 level-skipped, without timeouts.
4. Compare ALL LEVELS vs NOW ONLY. Click future dungeon and ALL BOSS LOOT;
   verify boss/item names, LV and future values not counted as current rank.
5. Group Mael+Lyra then all 5; verify actual responsive names and Pawn/Need
   priority, one row per character, existing 5-client ALT hover and alignment.
6. Test a teammate with addon disabled and a cached/missing item; expect ?
   not 0 or endless waiting. Re-scan after equipment swap and /reload.
7. Time at least one dungeon scan; compare to HF26.17 (>2 min per dungeon).
   Check FPS, Lua errors and addon-channel traffic. Record exact results.

ROLLBACK
- HF26.17 standalone test ZIP is preserved; previous approved visual
  HF26.16 remains untouched. Do not mark full regression/live OK by default.

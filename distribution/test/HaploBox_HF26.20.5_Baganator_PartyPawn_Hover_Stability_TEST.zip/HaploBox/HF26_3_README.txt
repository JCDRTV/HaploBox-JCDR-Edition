HF26.3 - HAPLO LOOT PARTY SENDER ROUTING HOTFIX (JCDR Edition)
Cumulative base: HF26.2. Preserves the existing JCDR Edition UI, Box Mode, Follow Indicators, macros and partyframes.

CAUSE FOUND:
HF26.2 matched incoming sender names only up to a hyphen. The Forever client reports names such as "Mael Ashgrove", so valid party messages were rejected by the name allowlist before the ping/scan handlers.

FIX:
- Canonicalize incoming sender identity: allow only Mael, Lyra, Elya, Nyra or Ayla; accept an exact first name or those first names followed by a SPACE or HYPHEN.
- Use the same canonical naming for self identification.
- Keep party/raid/instance channel allowlist and strict roster checks.
- /hblootnet now shows recognized/rejected/malformed counters and last rejected sender.
- Scan start still sends a PING; team replies are still only on explicit scan request; incomplete scans cannot rank.

TEST: Install on all five clients, /reload all. On Mael choose Deadmines > SCAN DUNGEON.
Expect handshake 4/4 and nonzero Lyra/Elya/Nyra/Ayla counts if communications work.
Run /hblootnet on Mael and Lyra after test; send outputs if <4/4 or item counts stay at zero.
NOTE: Pawn scale must be configured separately; SET SCALE means no reliable upgrade score.

Offline source check/ZIP integrity are not ingame verification. No native AtlasLoot hover integration yet.

HaploBox - JCDR Edition | HF13 Menu Layout & Uniform Styling TEST BUILD
19 November 2026 | Base HF12 preserved unchanged

HF13 changes:
- Quick Menu: 3 categories and 10 functions. PLAY MODES: Box Mode,
  Follow Mode (Direct / Dungeon). TEAM MANAGEMENT: Invite Party + Leave
  Party side-by-side, Loot Mode (Auto/Manual with current loot method),
  Quest Sharing and Auto Repair. MENUS: Macro Menu, HaploBox Keybindings,
  UI Layout. 3 Config controls in section headers remain available.
- Dark Blizzard/HaploBox skins, golden borders, consistent fonts/rows;
  captions left and state/action button right. Green ON, red OFF,
  yellow mode, blue action/OPEN. Existing lock letter L is now a lock
  icon (locked/unlocked); the title-bar Settings gear opens Options.
- Options is a standalone addon window, reached via /hb options or the
  titlebar gear. Existing two error-report settings and error-only
  REFRESH SYNC preserved. Options no longer lives in Blizzard Settings.
- Macro Menu (Smart Spells) and HaploBox Keybindings have distinct
  windows/positions/locks. Existing six binding rows and binding/cast
  behavior unchanged. A former shared menu location is migrated as a
  one-time fallback when a new per-menu position is not yet saved.
- Category Config and UI Layout menu panels share the visual style;
  layout actions retain their previous behaviors and combat guards.

EXCLUDED / UNCHANGED:
- Buff Overview visual/data layout and entire Auras.lua are untouched.
  Buff layout and Camp Benefits remain for a later version (HF14 scope
  to be reviewed before any build); the old Debuff Overview stays gone.
- All Party Frame, BOX/FOLLOW, Mini UI, healing, macro action and
  game state modules other than ControlBar, ConfigUI, Options and
  MacroLibrary remain identical to HF12.
- No heavy full-UI frame scans were introduced.

OFFLINE CHECKS (NOT LIVE ACCEPTANCE):
24/24 Lua syntax PASS (host Lua 5.4 parser), ZIP CRC PASS, cumulative
source diff PASS. Minimal mock WoW frame test PASS: Options toggles;
distinct Macro/Keybindings windows with six binding controls; UI Layout
open; Quick Menu open/lock/close. Mocking is not the live WoW client.

LIVE TEST REQUIRED:
1. One client: /hb options + Quick Menu settings gear (same Options),
   two error toggles persist, REFRESH SYNC disabled without ERROR.
2. Quick Menu 3 categories, ten entries: colors/status, Invite/Leave,
   current loot-method indicator; check the 3 Config heading actions.
3. Locked/unlocked padlock, moving independently of Party Frames,
   reopening/resetting, combat lockdown and /reload position persistence.
4. Macro Menu and Keybindings truly independent; all six existing keys,
   conflict prompts, custom bindings, Smart Spells and secure actions.
5. UI Layout, per-character Reset/Sync and original saved settings.
6. Full team: five Druids in Main/Mini, combat, mouseover heals, party
   join/leave, aura display, Blizzard right-click unit menus and buffs.
7. HF12 click-on-debuff dispel remains NOT implemented; HF11/HF12
   changes have not been marked live approved.

BACKUP POLICY: this ZIP is a new checkpoint; do not overwrite HF12.
Known ingame rollback: HF10. All visible text/tooltips in English.

HAPLOBOX JCDR – HF24 QUICK MENU + LYRA GATHERING MAP – TEST BUILD
Base: original HF23 ZIP, untouched. This is not an ingame-approved release.

A) QUICK MENU BUG
- Fixed menu scaling that treated Mael's relocated bottom-left minimap as a
  right-side boundary; no more automatic 35%-size quick menu from that cause.
- Compact readable rows (10 in 3 sections), repositioned to the right of the
  party frames; old saved quick-menu positions overlapping party HP bars ignored.
- Docked submenus prefer readable viewport placement over 35% micro-scaling.
- No partyframe/Follow/BoxMode/macro gameplay code changes.

B) LYRA GATHERING MAP
- Lyra Ashgrove ONLY, in her OWN Mini UI: enlarges the REAL Blizzard minimap
  to approx 50% of the Mini UI viewport height, top-left. No fake node dots.
- Her active Find Herbs tracking dots remain Blizzard's live tracking.
- Mael's relocated main minimap and all other clients remain unchanged.
- Quick Menu > Menus > 'Lyra Gathering Map' ON/OFF; default ON for Lyra.
- /hb gathermap on|off can control it locally if the Mini UI is hiding buttons.
- The existing Toggle Quick Menu keybind can open the menu in Mini UI;
  default placement is upper-right, away from Lyra's upper-left gathering map.
- On Main UI / OFF / logout, restores parent, size, points, scale, alpha,
  strata, mouse and shown state captured for the native Blizzard Minimap.
- Requires out-of-combat switching. May conflict with addons that constantly
  reparent or resize Minimap; this remains an INGAME test item.

C) HOT MONITOR
- HF23 already implements MOVE HOTS while unlocked, on/off, lock and saved
  position. HF24 adds a thin temporary outline while the monitor is unlocked,
  even with no active HoTs. It remains click-through apart from MOVE HOTS.
  Test /hb hotpanel unlock,
  drag MOVE HOTS, /hb hotpanel lock, /reload and verify placement persists.

D) F6 > HB Trade
- Binding issue on followers remains UNVERIFIED; no risky changes to macro
  or BoxMode code without the actual error. Existing bindings preserved.
- Test whether an HB Trade character-specific macro exists on each follower,
  then bind F6 from HaploBox Keybindings on one follower and note exact error.

OFFLINE TESTS: Lua 5.4 syntax parser, a Lyra native-minimap mock
(ON/OFF/repeated apply/restore/Mael unchanged), ZIP CRC, and static
layout/preservation checks. Final ingame behavior still unverified.
LIVE TESTS: Install on all five, verify legacy behavior, Mini Lyra gathering
map, Quick Menu at full readable scale, Main UI minimap restoration and
/reload. Do NOT deploy as stable without checking in game.

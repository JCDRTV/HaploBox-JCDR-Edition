HF26.20.3 MINI BUFF VISIBILITY HOTFIX - TEST

BUG: HF26.19.3 made Buff Overview independent of party frame visibility to
support solo gameplay, but also allowed it to be shown in Mini UI. User reported
buff icons no longer disappear in Mini UI after later buff patch.

FIX:
- Main UI: independent Buff Overview still works SOLO or with group members.
- Mini UI: Buff Overview is hidden, both solo and in party, when buff toggle ON.
- Buff Overview OFF: stays OFF in either mode.
- Combat: existing Main/Mini keybind attempts a VISUAL-ONLY Hide of the
  ordinary Buff Overview parent immediately; secure layouts wait for combat end.
  If return to Main midcombat with previously visible rails, parent can re-show.
  Otherwise full restoration occurs after combat.
- Blizzard native player buffs continue the existing Mini HUD suppression
  and existing HB Buff Overview ON/OFF policy; no changes to native frame code.
- F1 camera, Smart Follow target routes, Total UI Sync, Dungeon Advisor, Baganator,
  Buff 27px icons/8pt timers, bottom-left grip and other functions unchanged.

TEST CHECKLIST:
1. Solo Main UI, Buffs ON: one buff row visible.
2. Solo Mini UI: buff panel disappears. Toggle back to Main: row returns.
3. Five-man Main: five rows. Mini: none. Back to Main: all five rows.
4. Buffs OFF in Main/Mini: no HaploBox buff panel.
5. Native Blizzard buff frame remains suppressed in Mini; normal ON/OFF policy
   resumes in Main, without blocking mouse interactions.
6. Toggle Main/Mini in combat: buff parent hides immediately where WoW permits;
   protected changes occur after combat. Watch for taint / blocked actions.
7. F1 Smart Follow camera, HP frames, and Total UI Sync unchanged.

OFFLINE TESTED ONLY: needs WoW Forever ingame confirmation.

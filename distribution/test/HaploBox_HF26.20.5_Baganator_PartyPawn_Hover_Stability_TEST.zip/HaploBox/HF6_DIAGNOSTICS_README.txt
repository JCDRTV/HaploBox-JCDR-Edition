HAPLOBOX HF6 - PERFORMANCE & COMBAT DIAGNOSTICS (from HF5)

This is a DIAGNOSTIC test build, not a lag/combat fix.

Installation: Back up existing Interface/AddOns/HaploBox; replace the ENTIRE folder, keep WTF/SavedVariables, restart WoW.

Solo test: /hbdiag reset, stay out of combat 30-60s until a few hitches, /hbdiag report, screenshot chat.
Combat test: enter combat without pressing extra keys. The diagnostic listener records ADDON_ACTION_BLOCKED/FORBIDDEN when WoW emits them. /hbdiag report after combat and screenshot all output.
/ hbdiag on|off (without space after /) enables/disables function timing. /hbdiag reset clears counters.

Measurements: total/max wall time in named HB callbacks, number of slow frame gaps >=100ms and blocked actions. These are *not* full CPU profiling: if the costly callback is not instrumented, it will not appear among top functions. A Lua error inside a wrapped callback propagates unchanged and may prevent that invocation from being measured.

No automatic casts, protected UI edits, saved variable rewrites, or sync protocol changes are introduced.

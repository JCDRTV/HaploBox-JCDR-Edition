HF26.19.4 — Combat Main / Mini UI Toggle TEST (2026-11-21)
BASE: HF26.19.3 (solo buffs + compact icons + hide native Blizzard BuffFrame).

WHAT CHANGED
- Existing Toggle Main / Mini UI binding and /hb view main|mini|toggle
  respond even in combat. NO extra keybind or emergency button.
- From Mini -> Main while fighting: restore native Blizzard bars, party/target,
  chat and other previously captured HUD frames immediately where supported.
  Original per-frame alpha/shown states are preserved. Nameplate CVar and all
  secure layout/visibility/unit attribute changes still wait for regen.
- Main -> Mini during combat keeps Main native controls visible until secure
  Mini Heal frames can be shown OOC. We avoid an invisible unusable interface.
- Secure bottom Mini Heal tiles may remain visible and clickable during
  combat because WoW prevents insecure Hide()/Show() on protected unit frames.
- Multiple presses: last requested mode wins; apply only final secure state
  at PLAYER_REGEN_ENABLED. No automatic switch on Mael dying.

TEST
1. On a follower: enter Mini UI before combat. Let Mael die while followers
   are still fighting. Press the EXISTING Main/Mini toggle once.
2. Native action bars/target/party should visually return immediately even if
   secure Mini HP tiles remain until combat ends. Try regular spell keybinds.
3. Press toggle twice in combat and verify last requested state wins afterwards.
4. From Main request Mini in combat; Main controls must not disappear until
   the secure Mini UI can actually appear after combat.
5. After fight, check full layout, Blizzard buffs visibility ON/OFF, camera,
   UI controls and /reload. Repeat on multiple followers.

STATUS: OFFLINE PASS; WoW Forever ingame acceptance required. This is not
full in-combat secure frame re-layout and does not circumvent Blizzard combat
restrictions. All previous module features preserved.

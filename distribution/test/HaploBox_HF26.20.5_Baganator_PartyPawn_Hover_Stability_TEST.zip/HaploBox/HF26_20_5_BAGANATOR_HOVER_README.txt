HaploBox HF26.20.5 – BAGANATOR PARTY PAWN HOVER STABILITY TEST
21 Nov 2026 | OFFLINE PASS / INGAME TEST OPEN

Why: User reports ALT hovering items in Baganator flickers back and forth.
Root in prior code: each Pawn reply called GameTooltip:Show(), and ALT+OnHide
scheduled two new timers indefinitely while the tooltip rebuilt.

Fix: Existing tooltip receives the five approved Party Pawn rows once; later
replies update values/icons IN PLACE without re-showing. OnHide no longer
queues timer callbacks. If Baganator rebuilds while ALT remains pressed,
previous item results/sequence are retained and the same rows reattach at
OnShow. ALT-down allows ONLY two bounded checks, 0.06s and 0.20s; releasing
ALT invalidates both. Baganator item-button ItemID does not hijack AtlasLoot.

Guaranteed source preservation: original Pawn scores and 5-row fixed dice/
arrow/% layout are unchanged; no modifications to Pawn/Baganator files. Other
HaploBox modules are byte-identical to HF26.20.4.

Test: Run existing desktop HaploBox UPDATE and verify STATUS.cmd HF26.20.5.
WoW /reload. Open Baganator, hold ALT and move mouse over a bagged item for
10-15 seconds. Confirm original item tooltip remains steady, all five Pawn
rows fill in and stay put. Release ALT and re-hover a different item. Check
Blizzard default bags and AtlasLoot too. If still flickering, provide a short
video and the /hbhoverdiag output taken while ALT is held.

INGAME validation not performed here. ZIP keeps all previous backup builds.

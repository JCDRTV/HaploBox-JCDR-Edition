HF16 — Quick Menu Crash Fix — 19 November 2026

Source: HF15 Follower Camera (unmodified source ZIP retained).
User-reported WoW errors: MenuStyle.lua:47 SetNormalTexture(nil) usage;
ControlBar.lua:647 attempted indexing nil CONFIG button.

Fixed: replace invalid SetNormalTexture(nil) / SetPushedTexture(nil) with
SetAlpha(0) on existing widget art; harden refresh while AttachControlBar
is still building the menu and bail out if a future CONFIG button is absent.
Full Quick Menu feature set remains 3 categories / 10 functional rows,
with config actions on category headers, Options gear, padlock and close.

HF15 camera and HF14 buffs unchanged; all previous ZIPs retained.
OFFLINE TEST ONLY. In WoW, /reload after installing; check startup is clean
and both settings and CONFIG buttons render. Real five-character smoke tests
and combat validation remain pending.

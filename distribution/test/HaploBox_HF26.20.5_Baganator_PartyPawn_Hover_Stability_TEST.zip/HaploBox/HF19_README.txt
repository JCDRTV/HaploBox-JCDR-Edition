HF19 — BLIZZARD SWING TIMER MAIN HAND MINI UI FIX
================================================
Status: OFFLINE PASS; INGAME TEST OPEN — NOT LIVE OK.
Base: HF18 MINI UI HUD CLEANUP, cumulative with unchanged previous code.

User supplied a zoomed Blizzard /fstack screenshot naming the actual window:
  SwingTimerMainHandFrame
  Source: Interface/AddOns/Blizzard_SwingTimer/Blizzard_SwingTimer.xml:21
  Children include SwingTimerMainHandFrame.Background and .Border.

HF18 guessed other swing-timer module names and could not find this one.
HF19 adds this EXACT global parent frame to the existing finite HUD_NAMES
list in MiniHeal.lua. The existing hide/restore mechanism applies to it.
No global frame enumeration. Suppress only on a follower in Mini UI,
outside combat; restore original visibility/opacity when Main UI returns.
If the frame is created after entering Mini, the existing bounded HUD
refresh may pick it up once it exists.

All HP blocks, geometry, camera, buffs, party, macros, Box/Follow, UI layout,
Spy, Skada and CVar logic remain byte-identical to HF18.

Ingame test: on one follower switch to Mini and verify Main Hand disappears.
Return to Main and confirm it reappears as before; test /reload.
Damage Done / overhead names may remain separate outstanding HUD problems.

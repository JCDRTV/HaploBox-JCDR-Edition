HAPLOBOX JCDR — HF21 PARTY BUFF LOGIC + TIMERS — TESTBUILD
Based strictly on HF20 ZIP: 11dOXOg4VGBjiOjRRa75s4ulLJiwIiEVf
Status: OFFLINE CODE REVIEW; NOT INGAME APPROVED.

RIGHT: active standard party-sustainable buff families. They are classified
by expected party composition, not who cast the aura. Current rules include
Mark of the Wild, Thorns, Arcane Intellect, Fortitude and general blessings
(when respective class present); Food, Camp Benefits and Sleeping Bag XP.
MIDDLE: all other active buffs, in Blizzard scanned slot order.
LEFT: missing enabled standard buffs.

MINING / HERBALISM: missing-only tracking indicators, never active icons.
Tracking state can only be read for LOCAL PLAYER and only where that
character knows the corresponding gathering profession. There is no reliable
API to inspect each remote party member's minimap-tracking selection.
On Classic clients that allow only one tracking type at a time, separate
tracking warnings are limited to the relevant learned professions.

TIMERS: widened below icons, with unit intact (5m instead of '5...' or '5').
Native HoTs/debuffs retained; party-classified buff icon snapshots freeze
inside protected combat because combat-safe filtering by dynamic party-family
is not provided by standard native AuraContainer filters. They refresh OOC.
Tooltips/secure buff cancelling in legacy custom buttons need ingame testing.

KNOWN OPEN / INGAME VALIDATION:
- Camp Benefits family remains matched against genuine 'Camp Benefits' aura,
  rather than precursor Campfire Nearby; per-benefit and LW Tent nuances
  are NOT validated and need live-client evidence before claiming completion.
- Existing saved /hb buffs camp off setting stays off; use
  '/hb buffs camp on' to enable. Fresh installs default camp to ON.
- Sleeping Bag XP still requires stack count >= 3 as in HF20.
- Tracking API availability is client-dependent, and remote tracking cannot
  be determined from the party unit aura feed.
- Do not claim live combat refresh of custom categorized buff icons.
- The old native local-player-versus-external secure buff presentation was
  deliberately replaced; validate mouseover and right-click in-game.

CHANGED: Auras.lua, Core.lua (buff settings), HaploBox.toc,
HF_VERSION_HISTORY.txt; ADDED: HF21_README.txt.
NO OTHER ADDON/MEDIA/MINI UI MODULES CHANGED.

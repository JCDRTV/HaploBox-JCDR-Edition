HAPLOBOX JCDR EDITION – HF26.1 SCAN FEEDBACK HOTFIX (ALPHA)
20 November 2026

BASE: cumulative HF26.0 built from user HF25.1 hotfix.
PURPOSE: Fix "SCAN DUNGEON does nothing" apparent no-feedback problem.

CHANGES
- Top-of-dungeon progress shows SCAN RUNNING 0/N, updating each request.
- Button visibly changes to SCANNING X/N and becomes disabled during scan.
- Mael's chat prints started/completed/incomplete scan status.
- Selected first boss is opened automatically so item list is visible.
- Incomplete scans show per-character response counters and never receive a numerical dungeon ranking.
- Missing Pawn scale / item cache / incomplete weapon set are shown as explicit diagnostic status instead of silent blank items.
- Zero-drop AtlasLoot failures shown prominently and via chat (no false COMPLETE message).
- Complete but unresolved Pawn, item-cache, equipment or level-gate scans are explicitly marked SCORES UNKNOWN / LEVEL LOCK and excluded from numerical dungeon priority.
- Existing JCDR MenuStyle preserved, no changes to Follow/Box Mode/macros/party frames.

TEST
1. Install on all five clients (save HF25.1 and HF26.0 ZIP backups), /reload.
2. Mael: /hb loot, choose Deadmines, click SCAN DUNGEON.
3. Verify: chat line "Scan started"; scan button SCANNING X/N; header SCAN RUNNING with member reply counters.
4. Scan completes only after every item requested. If any character lacks results, header says INCOMPLETE and left-bottom status identifies missing reply counts.
5. If items show SET SCALE, configure Pawn per character and rescan. Items waiting on cache show CACHE ? and should be rescanned when loaded.
6. Select boss / scroll items to see per-Druid candidate tags. All five responding is needed before ranking.

This is a test build; no ingame verification yet.

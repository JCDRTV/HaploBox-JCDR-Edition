HF10 - Remove HaploBar and custom minimap; restore native Blizzard minimap
Based on HF9 (confirmed five-client test).
- Remove HaploBar.lua from package and TOC: no square mask, overlays, minimap reparenting, toolbar or external coordinate scans.
- Remove HaploBar UI Layout switch and obsolete defaults.
- Quick Menu popup now uses native MinimapCluster as horizontal boundary.
- Party Controls default location no longer reserves 42px for former HaploBar.
- Preserve Mini UI existing ability to suppress native HUD, including Blizzard MinimapCluster, and restore it in MAIN.
- No changes to BOX MODE logic, healing, protected combat visibility guard, macros or keybindings.
- HF9 is the rollback build.
TEST: restart WoW completely, confirm round Blizzard minimap and normal native buttons, Quick Menu placement,
MAIN/MINI toggle, combat entry, BOX SYNC and five clients.

HF26.20.1 Smart Follow F1 Camera View Recall | TEST / INGAME OPEN

User confirms current F1 Smart Follow route/target logic is perfect. This build does NOT change the follow target, follow mode, or keybind. When the HB-owned Smart Follow secure macro is updated out of combat, a harmless non-secure camera callback is added AFTER its unchanged /follow partyX line.

ONE-TIME SETUP ON EACH FOLLOWER:
1. Join a group with Mael and put follower camera at the desired exact zoom and oblique angle.
2. Type /hb followcam save to see caution; /hb followcam save confirm to save Blizzard camera view slot 5 on THIS character. THIS OVERWRITES an existing native view 5, so only do it when you consent.
3. Ensure BOX ON; out of combat /reload or re-evaluate Smart Follow macro if needed. No rebinding: existing F1 continues to work.
4. F1 still performs the original /follow party1|partyX; after follow it invokes HaploBox.SmartFollowCamera() which calls SetView(5), for followers only. Works in both Direct and Dungeon follow routes.

/hb followcam status: current local state. /hb followcam reset: manually recall saved view (for testing). /hb followcam off: disables recall but does not delete Blizzard's saved view 5. No new hotkeys, no camera changes on Mael, no automatic follow, no SavedVariables/profile copy.

IMPORTANT WoW limitation: using a custom saved camera view can affect the game's automatic camera-follow style even with CVar tracking configured. Validate camera recentering while walking in actual WoW Forever; if this causes problems use /hb followcam off to restore previous F1 camera behavior (macro still has safe callback but becomes no-op). This is a TEST, NOT INGAME APPROVED.

Preserved from HF26.20: Total UI Sync foundation, Windows companion separate, HF26.19.4 combat toggle, HF26.19.3 buffs, Dungeon Advisor, original 5 druid Party Pawn tooltip, original F1 follow target/mode. No unrelated Lua changes.

-- HF6: Passive, in-memory diagnostics; no gameplay, macros or protected frame edits.
local HB = HaploBox
HB.Diag = HB.Diag or {}
local D = HB.Diag
local stats, blocks = {}, {}
local frameSpikes, maxFrame = 0, 0
local active = true
local function stamp() return GetTime and GetTime() or 0 end
local function clock() return debugprofilestop and debugprofilestop() end
local function sample(label, ms)
    local x = stats[label]
    if not x then x={count=0,total=0,max=0,slow=0}; stats[label]=x end
    x.count=x.count+1
    x.total=x.total+ms
    if ms>x.max then x.max=ms end
    if ms>=5 then x.slow=x.slow+1 end
end
-- HF7: Section-level timing only, held in memory until /hbdiag report.
-- No chat messages inside OnUpdate; retain HF6 counters and combat events.
function D.Section(label, startMS)
    if not active or not startMS or not debugprofilestop then return end
    local ms=debugprofilestop()-startMS
    if ms>=0 then sample("HaploBar/"..label,ms) end
end
function D.Wrap(label, fn)
    return function(...)
        if not active or not debugprofilestop then return fn(...) end
        local before=clock()
        -- Preserve direct error propagation, protected WoW behavior, and return values.
        -- Callback sites sampled here are event/ticker callbacks (no returns expected).
        fn(...)
        local elapsed=clock()-before
        if elapsed>=0 then sample(label,elapsed) end
    end
end
function D.WrapEvent(label, fn)
    return function(_,event,...)
        if not active or not debugprofilestop then return fn(_,event,...) end
        local before=clock()
        fn(_,event,...)
        local ms=clock()-before
        if ms>=0 then sample(label..":"..tostring(event),ms) end
    end
end
local f=CreateFrame("Frame")
f:RegisterEvent("ADDON_ACTION_BLOCKED")
f:RegisterEvent("ADDON_ACTION_FORBIDDEN")
f:RegisterEvent("PLAYER_REGEN_DISABLED")
f:RegisterEvent("PLAYER_REGEN_ENABLED")
f:SetScript("OnEvent",function(_, event, addon, action)
    if event=="ADDON_ACTION_BLOCKED" or event=="ADDON_ACTION_FORBIDDEN" then
        local str=string.format("%.1fs %s addon=%s action=%s",stamp(),event,tostring(addon),tostring(action))
        blocks[#blocks+1]=str
        if #blocks>12 then table.remove(blocks,1) end
        if DEFAULT_CHAT_FRAME then DEFAULT_CHAT_FRAME:AddMessage("|cffffaa33HB DIAG|r "..str) end
    else
        blocks[#blocks+1]=string.format("%.1fs %s",stamp(),event)
        if #blocks>12 then table.remove(blocks,1) end
    end
end)
local monitor=CreateFrame("Frame")
monitor:SetScript("OnUpdate",function(_,elapsed)
    if elapsed and elapsed>=0.10 then
        frameSpikes=frameSpikes+1
        if elapsed>maxFrame then maxFrame=elapsed end
    end
end)
local function say(s)
    if DEFAULT_CHAT_FRAME then DEFAULT_CHAT_FRAME:AddMessage("|cff88ccffHB DIAG|r "..s) end
end
SLASH_HAPLODIAG1="/hbdiag"
SlashCmdList.HAPLODIAG=function(cmd)
    cmd=(cmd or ""):lower():match("^%s*(.-)%s*$")
    if cmd=="reset" then
        stats,blocks={},{}
        frameSpikes,maxFrame=0,0
        say("Counters reset. Stand solo for 30 seconds, then /hbdiag report.")
    elseif cmd=="off" then active=false; say("Profiler OFF (frame monitor still counts slow frames).")
    elseif cmd=="on" then active=true; say("Profiler ON.")
    else
        local top={}
        for k,v in pairs(stats) do top[#top+1]={key=k,v=v} end
        table.sort(top,function(a,b) return a.v.total>b.v.total end)
        say(string.format("Samples=%d | frames >=100ms: %d | worst %.0fms",#top,frameSpikes,maxFrame*1000))
        for i=1,math.min(#top,12) do
            local item=top[i];local v=item.v
            say(string.format("%s: total %.1fms, max %.2fms, %d calls, %d >=5ms",item.key,v.total,v.max,v.count,v.slow))
        end
        if #top==0 then say("No samples yet (wait 30 seconds after /reload).") end
        for _,s in ipairs(blocks) do say(s) end
    end
end

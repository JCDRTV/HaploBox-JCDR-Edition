HF26.19.3 — Solo Buff Overview + Compact Layout TEST (2026-11-21)
BASE HF26.19.2. Auras.lua inherits HF26.19.1 compact style with independent solo visibility.
Party.lua now maintains invisible aura data carriers even when secure Party Frames
are hidden. Auras use the same engine and continue to refresh every second.
No orange number badges. Icon 27px; timer 8pt centered BELOW icon.
When HaploBox Buff Overview is ON, hide Blizzard default player buffs,
with exact alpha/mouse restoration when toggled OFF; protected combat changes
are deferred until leaving combat.
Unlock via UI Layout to see MOVE BUFFS beneath last visible row, lower-left.
If saved position is off-screen, use Reset Buff Position in UI Layout.
IMPORTANT: This does NOT fix the Main/Mini combat toggle yet.
Offline tests only; verify solo, team, party frame hidden, /reload, and combat.

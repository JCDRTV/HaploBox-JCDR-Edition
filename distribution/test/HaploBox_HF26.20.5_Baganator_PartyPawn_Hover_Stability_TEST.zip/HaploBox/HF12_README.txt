HaploBox - JCDR Edition | HF12 Party Frames test build
Base: HF11 Mini UI upgrade, preserved unchanged as rollback checkpoint.

NEW / CHANGED:
- Native Blizzard assigned role icons + secure right-click unit menus.
- Party Controls default flush to top, with left margin next to Blizzard party snapper.
  Existing saved per-client positions honored; use Reset Layout for the new default.
- Debuffs moved into each Party Frame beside Follow, aligned below HoT rail.
  Old floating Debuff Overview removed; normal Buff Overview untouched.
- More than 16 debuffs supported (per-unit client aura API up to 255 index slots).
- Native combat aura engine used when available, legacy OOC icons grow on demand.
- Debuff timers under their icons, HoT timers below HoT icons in stronger font.
- Quick Menu independent of moving Party Frames after it opens; submenus unchanged.

IMPORTANT TEST LIMITATION:
Blizzard 12.1 native AuraContainer buttons cannot reliably be assigned dynamic
secure actions per aura while in combat. Direct click-to-dispel on a native
Debuff icon has NOT been implemented; use existing manual spells/keybinds.
This is open DEB-01 work, NOT a 'Live OK' feature. Do not claim all features
ingame ready before validation. Huge numbers of debuffs may exceed screen area.
Test user menu, role icons, position/Reset Layout, five-client aura displays,
HoT countdowns, original Blizzard buff panel, mouseover heals, combat taint,
party join/leave, minimap, Quick Menu and Mini UI restoration. HF10 stable
rollback, HF11 previous checkpoint. No background scanning introduced.

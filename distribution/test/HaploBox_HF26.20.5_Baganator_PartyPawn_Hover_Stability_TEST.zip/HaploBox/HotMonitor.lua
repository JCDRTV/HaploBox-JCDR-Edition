-- HF23: Mael-only, click-through 2x(0..5) live HoT monitor.
-- The native 12.1 AuraContainer owns combat auras and secret timers.  Two
-- distinct spell-id filters (Rejuvenation/Regrowth) mirror the existing
-- Party.lua/Auras.lua native HoT pipeline, without introducing secure clicks.
-- NO opaque backgrounds, unit buttons, permanent placeholder icons or names.
local HB=HaploBox
local ICON,STEP,ROW_GAP=28,31,6
local W,H=5*STEP-3,2*ICON+ROW_GAP
local REJUV={}
for _,id in ipairs({774,1058,1430,2090,2091,3627,8910,9839,9840,9841,25299,26982,48440,48441}) do REJUV[id]=true end
local REGROWTH={}
for _,id in ipairs({8936,8938,8939,8940,8941,9750,9856,9857,9858,26980,48438}) do REGROWTH[id]=true end
local frame
local function inCombat() return InCombatLockdown and InCombatLockdown() end
local function readable(v) return v~=nil and not (issecretvalue and issecretvalue(v)) end
local function localMael()
    local name=HB.UnitIdent and HB.UnitIdent("player")
    local norm=name and HB.Norm and HB.Norm(name)
    -- Full surname is available on Forever; plain Mael supports the older
    -- client fallback which hides surnames in the UnitName API.
    return norm=="mael ashgrove" or norm=="mael"
end
local function clamp(x,y)
    local ww=UIParent:GetWidth() or 1280
    local hh=UIParent:GetHeight() or 720
    x=type(x)=="number" and x or -65
    y=type(y)=="number" and y or 315
    return math.max(-(ww-W-6),math.min(-6,x)),math.max(12,math.min(hh-H-30,y))
end
local function position(x,y)
    if not frame then return end
    x,y=clamp(x,y)
    frame:ClearAllPoints()
    frame:SetPoint("BOTTOMRIGHT",UIParent,"BOTTOMRIGHT",x,y)
    if HB.db then HB.db.hotMonitorPos={x,y} end
end
local function applyVisibility()
    if not frame then return end
    frame:SetShown(HB.db and HB.db.hotMonitorEnabled~=false and true or false)
    local unlocked=HB.db and HB.db.hotMonitorEnabled~=false and HB.db.hotMonitorUnlocked==true
    frame.grip:SetShown(not not unlocked)
    -- HF24: the empty, transparent monitor needs a visual outline while
    -- unlocked.  These are textures only: they cannot block world clicks.
    for _,line in ipairs(frame.moveOutline or {}) do line:SetShown(not not unlocked) end
end
local function makeButton(button)
    button:SetSize(ICON,ICON)
    button:EnableMouse(false) -- even active aura pixels never steal world clicks
    local image=button:CreateTexture(nil,"ARTWORK")
    image:SetAllPoints(button)
    image:SetTexCoord(.08,.92,.08,.92)
    button:SetIcon(image)
    local countdown=button:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
    countdown:SetPoint("CENTER",button,"CENTER",0,0)
    countdown:SetSize(ICON+8,18)
    countdown:SetJustifyH("CENTER")
    countdown:SetJustifyV("MIDDLE")
    countdown:SetWordWrap(false)
    countdown:SetTextColor(1,1,1,1)
    countdown:SetShadowOffset(1,-1)
    if STANDARD_TEXT_FONT then countdown:SetFont(STANDARD_TEXT_FONT,10,"THICKOUTLINE") end
    if button.SetDurationText then button:SetDurationText(countdown) end
end
local function nativeGroup(root,ids,y)
    local ok,c=pcall(CreateFrame,"AuraContainer",nil,root,"CustomAuraContainerTemplate")
    if not ok or not c or not c.AddAuraGroup or not c.SetUnit then return nil end
    local setup=pcall(function()
        c:EnableMouse(false)
        c:SetSize(W,ICON)
        c:SetPoint("TOPLEFT",root,"TOPLEFT",0,y)
        if c.SetFlowLayoutAnchorPoint then c:SetFlowLayoutAnchorPoint("TOPLEFT") end
        if c.SetFlowLayoutGrowthDirection and AnchorUtil and AnchorUtil.FlowDirection then
            c:SetFlowLayoutGrowthDirection(AnchorUtil.FlowDirection.Right,AnchorUtil.FlowDirection.Down)
        end
        c:AddAuraGroup("hots","HELPFUL",{
            maxFrameCount=5,
            candidateFilters={includeSpellIDs=ids},
            layout={elementWidth=ICON,elementHeight=ICON,elementSpacing=3,lineSpacing=0},
            initializeFrame=makeButton,
        })
        c:SetUnit("player")
        c:Show()
    end)
    if not setup then pcall(c.Hide,c);return nil end
    return c
end
local function makeLegacyIcon(root,x,y)
    local tex=root:CreateTexture(nil,"ARTWORK")
    tex:SetPoint("TOPLEFT",root,"TOPLEFT",x,y)
    tex:SetSize(ICON,ICON)
    tex:SetTexCoord(.08,.92,.08,.92)
    tex:Hide()
    local font=root:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
    font:SetPoint("CENTER",tex,"CENTER",0,0)
    font:SetSize(ICON+8,18)
    font:SetJustifyH("CENTER");font:SetWordWrap(false)
    font:SetTextColor(1,1,1)
    if STANDARD_TEXT_FONT then font:SetFont(STANDARD_TEXT_FONT,10,"THICKOUTLINE") end
    font:SetText("")
    return {tex=tex,time=font,expiration=nil}
end
local function fallbackSnapshot()
    if not frame or frame.nativeReady or not frame:IsShown() then return end
    local entries={rejuv={},regrowth={}}
    local reliable=true
    for index=1,255 do
        local name,texture,count,dispel,duration,expiration,source,_,_,spell
        if C_UnitAuras and C_UnitAuras.GetBuffDataByIndex then
            local ok,a=pcall(C_UnitAuras.GetBuffDataByIndex,"player",index)
            if not ok then reliable=false;break end
            if not a then break end
            if not readable(a.name) or not readable(a.spellId) then reliable=false;break end
            name,texture,duration,expiration,spell=a.name,a.icon,a.duration,a.expirationTime,a.spellId
        elseif UnitBuff then
            local ok,n,t,c,d,dur,exp,src,_,_,id=pcall(UnitBuff,"player",index)
            if not ok then reliable=false;break end
            if not n then break end
            if not readable(n) or not readable(id) then reliable=false;break end
            name,texture,duration,expiration,source,spell=n,t,dur,exp,src,id
        else reliable=false;break end
        if readable(name) and type(name)=="string" then
            local id=readable(spell) and type(spell)=="number" and spell or nil
            local group=(id and REJUV[id]) or name:lower()=="rejuvenation"
            local dest=group and entries.rejuv or (((id and REGROWTH[id]) or name:lower()=="regrowth") and entries.regrowth)
            if dest and #dest<5 and readable(texture) and texture then
                dest[#dest+1]={texture=texture,expiration=readable(expiration) and expiration or nil}
            end
        end
    end
    -- In protected combat an empty/unreadable client feed cannot erase a
    -- known HoT snapshot: the 12.1 native engine is needed for new live auras.
    if not reliable then return end
    for _,kind in ipairs({"rejuv","regrowth"}) do
        for i,o in ipairs(frame.legacy[kind]) do
            local entry=entries[kind][i]
            if entry then
                o.tex:SetTexture(entry.texture);o.tex:Show();o.expiration=entry.expiration
            else o.tex:Hide();o.expiration=nil;o.time:SetText("") end
        end
    end
end
local function legacyTimers()
    if not frame or frame.nativeReady or not frame:IsShown() then return end
    local now=GetTime and GetTime() or 0
    for _,kind in ipairs({"rejuv","regrowth"}) do
        for _,o in ipairs(frame.legacy[kind]) do
            if o.tex:IsShown() then
                local left=(type(o.expiration)=="number" and readable(o.expiration)) and o.expiration-now or nil
                if left and left<=0 then o.tex:Hide();o.time:SetText("")
                elseif left then
                    local label=left>=60 and (tostring(math.ceil(left/60)).."m") or (tostring(math.max(1,math.floor(left))).."s")
                    o.time:SetText(label)
                else o.time:SetText("") end
            end
        end
    end
end
local function create()
    if frame or inCombat() or not localMael() then return end
    local f=CreateFrame("Frame","HaploBoxMaelHotMonitor",UIParent)
    frame=f
    f:SetSize(W,H);f:SetFrameStrata("MEDIUM")
    f:EnableMouse(false)
    f:SetMovable(true);f:SetClampedToScreen(true)
    local saved=HB.db and HB.db.hotMonitorPos
    position(type(saved)=="table" and saved[1],type(saved)=="table" and saved[2])
    local c1=nativeGroup(f,REJUV,0)
    local c2=nativeGroup(f,REGROWTH,-(ICON+ROW_GAP))
    if c1 and c2 then
        f.nativeReady=true
        f.native={c1,c2}
    else
        if c1 then c1:Hide() end
        if c2 then c2:Hide() end
        f.nativeReady=false
        f.legacy={rejuv={},regrowth={}}
        for _,pair in ipairs({{"rejuv",0},{"regrowth",-(ICON+ROW_GAP)}}) do
            for i=1,5 do
                f.legacy[pair[1]][i]=makeLegacyIcon(f,(i-1)*STEP,pair[2])
            end
        end
        -- Older clients can read UnitBuff; secure 12.1 client uses native.
        if C_Timer and C_Timer.NewTicker then
            C_Timer.NewTicker(0.2,function() fallbackSnapshot();legacyTimers() end)
        end
    end
    local grip=CreateFrame("Button",nil,f)
    f.grip=grip
    f.moveOutline={}
    for _,edge in ipairs({"TOP","BOTTOM","LEFT","RIGHT"}) do
        local line=f:CreateTexture(nil,"OVERLAY")
        line:SetColorTexture(0.23,0.67,0.92,0.87)
        if edge=="TOP" then
            line:SetPoint("TOPLEFT",f,"TOPLEFT");line:SetPoint("TOPRIGHT",f,"TOPRIGHT");line:SetHeight(1)
        elseif edge=="BOTTOM" then
            line:SetPoint("BOTTOMLEFT",f,"BOTTOMLEFT");line:SetPoint("BOTTOMRIGHT",f,"BOTTOMRIGHT");line:SetHeight(1)
        elseif edge=="LEFT" then
            line:SetPoint("TOPLEFT",f,"TOPLEFT");line:SetPoint("BOTTOMLEFT",f,"BOTTOMLEFT");line:SetWidth(1)
        else
            line:SetPoint("TOPRIGHT",f,"TOPRIGHT");line:SetPoint("BOTTOMRIGHT",f,"BOTTOMRIGHT");line:SetWidth(1)
        end
        f.moveOutline[#f.moveOutline+1]=line
    end
    grip:SetSize(112,19)
    grip:SetPoint("BOTTOM",f,"TOP",0,3)
    grip:EnableMouse(true)
    grip:RegisterForDrag("LeftButton")
    local bg=grip:CreateTexture(nil,"BACKGROUND")
    bg:SetAllPoints();bg:SetColorTexture(0.13,0.28,0.46,0.96)
    local label=grip:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
    label:SetPoint("CENTER")
    label:SetText("MOVE HOTS")
    label:SetTextColor(1,0.92,0.71)
    grip:SetScript("OnDragStart",function()
        if not inCombat() then f:StartMoving() end
    end)
    grip:SetScript("OnDragStop",function()
        f:StopMovingOrSizing()
        local x=(f:GetRight() or 0)-(UIParent:GetRight() or 0)
        local y=(f:GetBottom() or 0)-(UIParent:GetBottom() or 0)
        position(x,y)
    end)
    f:RegisterEvent("UI_SCALE_CHANGED")
    f:RegisterEvent("DISPLAY_SIZE_CHANGED")
    f:SetScript("OnEvent",function()
        if inCombat() then return end
        local current=HB.db and HB.db.hotMonitorPos
        position(type(current)=="table" and current[1],type(current)=="table" and current[2])
    end)
    applyVisibility()
end
function HB.SetHotMonitorUnlocked(on)
    if inCombat() or not localMael() then return false end
    if HB.db then HB.db.hotMonitorUnlocked=not not on end
    create();applyVisibility()
    return true
end
function HB.SetHotMonitorEnabled(on)
    if inCombat() or not localMael() then return false end
    if HB.db then HB.db.hotMonitorEnabled=not not on end
    create();applyVisibility()
    return true
end
function HB.ResetHotMonitorPosition()
    if inCombat() or not localMael() then return false end
    create();position(nil,nil)
    return true
end
local events=CreateFrame("Frame")
for _,event in ipairs({"PLAYER_LOGIN","PLAYER_ENTERING_WORLD","PLAYER_REGEN_ENABLED","UNIT_AURA"}) do
    pcall(events.RegisterEvent,events,event)
end
events:SetScript("OnEvent",function(_,event,unit)
    if event=="UNIT_AURA" then
        if unit=="player" and frame and not frame.nativeReady then fallbackSnapshot();legacyTimers() end
    else
        create()
        applyVisibility()
    end
end)

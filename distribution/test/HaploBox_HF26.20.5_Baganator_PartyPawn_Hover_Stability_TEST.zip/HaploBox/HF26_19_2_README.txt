HaploBox HF26.19.2 BUFF OVERVIEW RECOVERY TEST — 21 Nov 2026

URGENT RECOVERY: user reported Buff Overview completely disappeared with HF26.19.1.
Restore the previously shown HF26.19 Auras.lua exactly, including 27px buff icons,
old 11pt timers, orange 1–5 badges and top grip. This intentionally rolls back
HF26.19.1 buff visual polish ONLY until a WoW client reproduces the true cause.
Do not confuse this with a finished buff UI redesign.

KEPT: HF26.19.1 Party Frames current / max HP values, existing percent, original
Party Pawn ALT-hover Baganator reattach, complete HF26.19 Dungeon Advisor, and
all unrelated modules. No SavedVariables, inventory, CVars or other addons touched.

INSTALL: existing manual updater compatible with HF26.19.2 after separate updater
version-regex fix, or install the ZIP manually as the one HaploBox addon folder.
Then /reload after update finishes. If Buff Overview remains missing, check
UI Layout > Buff Overview is ON, reset Buff Overview position, and capture any
Lua error / screenshot before another change.

STATUS: OFFLINE PASS / INGAME TEST OPEN. Combat Main/Mini toggle fix is NOT part
of this recovery package; it remains to be built and tested separately.

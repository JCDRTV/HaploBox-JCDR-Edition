-- HF13: shared non-secure menu styling. This module never changes protected
-- unit buttons, macro actions, aura logic, or user-owned SavedVariables.
local HB=HaploBox
local Style={}
HB.MenuStyle=Style
Style.colors={
    bg={0.095,0.11,0.14,0.99},
    header={0.16,0.19,0.24,0.98},
    edge={0.68,0.51,0.24,0.94},
    blue={0.14,0.30,0.48,0.97},
    green={0.14,0.40,0.25,0.98},
    red={0.54,0.17,0.17,0.98},
    yellow={0.46,0.36,0.15,0.98},
    neutral={0.20,0.24,0.29,0.98},
    disabled={0.13,0.15,0.18,0.81},
}
local function paint(texture,c) texture:SetColorTexture(c[1],c[2],c[3],c[4]) end
function Style.Window(frame,headerHeight)
    if not frame or frame._hbStyleWindow then return end
    frame._hbStyleWindow=true
    local t=frame:CreateTexture(nil,'BACKGROUND',nil,1)
    t:SetAllPoints(frame);paint(t,Style.colors.bg)
    local head=frame:CreateTexture(nil,'BORDER')
    head:SetPoint('TOPLEFT',frame,'TOPLEFT',1,-1)
    head:SetPoint('TOPRIGHT',frame,'TOPRIGHT',-1,-1)
    head:SetHeight(headerHeight or 30);paint(head,Style.colors.header)
    for _,side in ipairs({'TOP','BOTTOM','LEFT','RIGHT'}) do
        local edge=frame:CreateTexture(nil,'OVERLAY')
        paint(edge,Style.colors.edge)
        if side=='TOP' then
            edge:SetPoint('TOPLEFT',frame,'TOPLEFT');edge:SetPoint('TOPRIGHT',frame,'TOPRIGHT');edge:SetHeight(1)
        elseif side=='BOTTOM' then
            edge:SetPoint('BOTTOMLEFT',frame,'BOTTOMLEFT');edge:SetPoint('BOTTOMRIGHT',frame,'BOTTOMRIGHT');edge:SetHeight(1)
        elseif side=='LEFT' then
            edge:SetPoint('TOPLEFT',frame,'TOPLEFT');edge:SetPoint('BOTTOMLEFT',frame,'BOTTOMLEFT');edge:SetWidth(1)
        else
            edge:SetPoint('TOPRIGHT',frame,'TOPRIGHT');edge:SetPoint('BOTTOMRIGHT',frame,'BOTTOMRIGHT');edge:SetWidth(1)
        end
    end
end
function Style.Button(b,state)
    if not b then return end
    if not b._hbStyleFace then
        local face=b:CreateTexture(nil,'BACKGROUND',nil,1)
        face:SetAllPoints(b)
        b._hbStyleFace=face
        -- HF16: WoW's Button:SetNormalTexture / SetPushedTexture now reject
        -- nil as an asset. Never use Set*Texture(nil) to clear a template.
        -- Hide only the existing template art, preserving our own background,
        -- active hover, click scripts and the button's UI state.
        for _,getter in ipairs({'GetNormalTexture','GetPushedTexture','GetDisabledTexture'}) do
            if b[getter] then
                local art=b[getter](b)
                if art and art.SetAlpha then art:SetAlpha(0) end
            end
        end
        -- UIPanelButtonTemplate also contains separate sliced art textures.
        for _,part in ipairs({'Left','Middle','Right'}) do
            local art=b[part]
            if art and art.SetAlpha then art:SetAlpha(0) end
        end
        if b.SetHighlightTexture then b:SetHighlightTexture('Interface\\Buttons\\UI-Listbox-Highlight2','ADD') end
        local text=b.GetFontString and b:GetFontString()
        if text then text:SetTextColor(0.98,0.96,0.92) end
    end
    local wanted=Style.colors[state or 'blue'] or Style.colors.blue
    if b.IsEnabled and not b:IsEnabled() then wanted=Style.colors.disabled end
    paint(b._hbStyleFace,wanted)
end
function Style.LockButton(button,locked)
    if not button then return end
    if not button._hbLockIcon then
        local t=button:CreateTexture(nil,'ARTWORK')
        t:SetSize(17,17);t:SetPoint('CENTER')
        button._hbLockIcon=t
    end
    if button.SetText then button:SetText('') end
    button._hbLockIcon:SetTexture(locked and
        'Interface\\Buttons\\LockButton-Locked-Up' or
        'Interface\\Buttons\\LockButton-Unlocked-Up')
    Style.Button(button,'neutral')
end
function Style.Tooltip(button,title,body)
    button:SetScript('OnEnter',function(self)
        if not GameTooltip then return end
        GameTooltip:SetOwner(self,'ANCHOR_RIGHT')
        GameTooltip:SetText(title,1,0.83,0.41)
        if body then GameTooltip:AddLine(body,0.83,0.84,0.85,true) end
        GameTooltip:Show()
    end)
    button:SetScript('OnLeave',function() if GameTooltip then GameTooltip:Hide() end end)
end

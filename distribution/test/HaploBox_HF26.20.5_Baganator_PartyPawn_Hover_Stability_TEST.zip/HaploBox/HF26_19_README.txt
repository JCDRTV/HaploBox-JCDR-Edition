HAPLOBOX – JCDR EDITION | HF26.19 SCAN CONTROLS + NEED PRIORITY TEST
21 NOVEMBER 2026 | OFFLINE PASS / INGAME VALIDATION OPEN

CUMULATIVE BASE
- Exact HF26.18 ZIP is retained as immutable rollback; HF26.17 and HF26.16 too.
- Only LootPlanner.lua, HaploBox.toc, and HF_VERSION_HISTORY.txt changed.
- This HF26_19_README.txt is new. All other files unchanged byte-for-byte.
- Does not change already approved HF26.16 ALT-hover Party Pawn UI, LootHover,
  Party Frames, BoxMode, Camera, Mini Heal, macros, menus or other modules.

EXPLICIT SCAN CONTROLS
- New SCAN header on TOP of left panel, with two scan ACTION buttons:
  AVAILABLE DUNGEONS = only AtlasLoot dungeons whose minimum level is at or
  below the LOWEST present group's level (including party members).
  ALL DUNGEONS = all AtlasLoot dungeons regardless of required level.
- Both buttons initiate their own scan; neither just hides scan results.
- Old bottom SCAN ALL and passive NOW ONLY/ALL LEVELS button removed.
- Scans remain manual, require Mael and out-of-combat, do not auto equip or roll.
- ALL BOSS LOOT / UPGRADES ONLY toggle on right remains available.

RANK AND LOOT SEMANTICS
- Strict HF26.18 quality validation incorrectly hid entire dungeon rank even
  where verified Pawn upgrades were available, because unrelated item data was
  unknown. Compute capped per-character/slot score from VERIFIED upgrades.
- If other entries/clients remain uncertain, display ~NN% as PROVISIONAL,
  relative only to currently confirmed and scored dungeons. If no comparable
  verified score exists, display ?, never invent a zero or 100%.
- Loot column now counts verified item NEEDS PER CHARACTER (future included),
  not merely distinct itemIDs. T / H / D role totals sum to LOOT.
- A repeated itemID across multiple boss lists counts ONCE per character for
  total loot needs and ranking. Distinct boss item count shown separately in
  selected-dungeon summary. Future needs labeled separately from NOW.
- Source data limits: Only actual indexed AtlasLoot boss drops (not trash,
  quests, professions, vendors, raids), all five fixed Team A Druids; no
  general class profile expansion or invented Pawn values.

BLIZZARD ROLES, ITEM TOOLTIP, NEED PRIORITY
- Dungeon headers use native Blizzard Party Frames role icon sprites for
  TANK/HEALER/DAMAGER; no repeated letter captions; numbers remain.
- Item tooltip appears ONLY over the 24px item icon and beside the CURSOR,
  not over the full loot row. The approved ALT + hover Pawn addon hook is
  preserved unchanged.
- Only one Need die per item when the highest eligible comparable Pawn +%
  uniquely wins. A missing winner is no longer silent: CACHE? (missing item
  info), PAIR? (weapon set), TIE? (equal best +%), CHECK? (not comparable),
  LV? (future level). Hover the STATUS itself for the diagnostic reason.
- The need priority/status is a planning hint, NOT a click to Need/Greed.
- On uncertain item-level results, diagnostic rows are visible even when
  not confirmed upgrades, but are NOT counted as loot needs or numeric gains.

OFFLINE TESTS (NOT A LIVE CLIENT)
- Parse all 30 Lua files with texlua: PASS.
- Mock 5 scenarios (solo, duo, five, no-ACK, unsupported class) each scanning
  34 in ALL and 14 in AVAILABLE: PASS.
- Mock CASTER/neutral ring with 5 Druids: one NEED winner; CACHE?, TIE?,
  CHECK? and LV? explanations; exact 11 item/character opportunities incl.
  one future; no duplicate count/score on repeated boss item: PASS.
- Mock UI: explicit buttons, native Blizzard role sprites, no T/H/D letters,
  item-icon-only cursor tooltip, old boss loot filter retained: PASS.
- ZIP CRC and unchanged-module comparison: PASS.

INGAME TEST (OPEN)
1. Use manual HaploBox UPDATE once HF26.19 TEST manifest published; STATUS.cmd
   should show HF26.19. Verify five clients or only Mael solo /reload.
2. Mael solo: AVAILABLE DUNGEONS must scan 14 on current AtlasLoot/level
   sample, or however many dungeons are min-level accessible right now.
3. ALL DUNGEONS must scan 34 on the current AtlasLoot sample, or the actual
   exposed total. Verify this is actual scan work, not just a visual filter.
4. Verify percentages reappear for dungeons with real Pawn values; provisional
   ranks start with '~', no unsupported percentage for unknown/none.
5. T/H/D icon graphics match Party Frames, NO repeated letters.
6. Hover loot row vs item icon. Only icon gets ORIGINAL WoW tooltip AT CURSOR;
   ALT+Hover Pawn layout/Need dice remains exactly as approved.
7. Test duplicate item and jewelry priority: exactly one dice per item where
   Pawn is reliably comparable; otherwise inspect CACHE?/PAIR?/TIE?/CHECK?
   diagnostic text. Verify boss items vs LOOT needs per character and T/H/D.
8. Re-scan after loot upgrade and with missing follower, compare rankings;
   check real scan time, no WoW Lua errors or UI regression.

ROLLBACK
- HF26.18 ZIP retained in the Drive folder and prior GitHub test paths.
- HF26.17, HF26.16 and earlier archives not replaced.
- Do NOT mark full Live OK before user's screenshots and gameplay feedback.

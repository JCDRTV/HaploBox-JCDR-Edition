HaploBox JCDR Edition — TB19.1t HF8 External Coordinate Scan Fix (TEST)
Base: HF7 HaploBar Section Diagnostic, not a release build.

Changed ONLY HaploBar.lua:
- Removed the periodic 2-second enumeration of up to 15,000 UI frames for
  suppressing an unidentified third-party coordinate FontString.
- Kept the HaploBar coordinate caption and all other timer/UI functions.
- Kept HF6/HF7 /hbdiag instrumentation and all other modules unchanged.
- This may allow duplicate coordinates from another addon to remain visible.
- Combat 'Interface action failed' is NOT fixed by this patch.

Install: back up current Interface/AddOns/HaploBox, replace the ENTIRE
HaploBox folder, keep WTF/SavedVariables, restart WoW.
Test solo/out of party, outside combat:
  /hbdiag reset
  stand 30-60 seconds, then /hbdiag report
Compare long frames and HaploBar OnUpdate vs HF7. Test combat separately.
Offline source/ZIP checks are not an in-game validation.

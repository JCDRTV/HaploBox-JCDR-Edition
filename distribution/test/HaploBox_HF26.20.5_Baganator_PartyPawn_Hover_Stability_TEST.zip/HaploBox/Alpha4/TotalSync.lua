-- HF26.20 TEST: guarded Blizzard CVar bridge for HaploBox's EXISTING A4 ShareUI.
-- Third-party SavedVariables cannot be generically and safely live-merged.
-- Unsupported addon settings are handled by the separate, offline Companion.
local H=HaploBoxA4
local HB=HaploBox
if not (H and HB) then return end

local KEYS={"statusTextDisplay","showTargetOfTarget","useUiScale","uiScale"}
local SUPPORTED={}
for _,k in ipairs(KEYS) do SUPPORTED[k]=true end
local pending=nil
local function valid(key,value)
    if type(value)~="string" or #value>28 or not SUPPORTED[key] then return false end
    if key=="uiScale" then
        local n=tonumber(value)
        return n and n==n and n>=0.5 and n<=1.5 and value:match("^%d?%.?%d+$")~=nil
    elseif key=="useUiScale" or key=="showTargetOfTarget" then
        return value=="0" or value=="1"
    elseif key=="statusTextDisplay" then
        return value:match("^[A-Z_]+$")~=nil
    end
    return false
end
local function get(key)
    if type(GetCVar)~="function" then return nil end
    local ok,v=pcall(GetCVar,key)
    if ok and type(v)=="string" and valid(key,v) then return v end
end
local function parse(msg)
    if type(msg)~="string" or #msg>225 or msg:sub(1,2)~="1;" then return nil end
    local values,seen={},{}
    local count=0
    for entry in msg:sub(3):gmatch("[^;]+") do
        local key,val=entry:match("^([%a]+)=([%w%.]+)$")
        if not key or seen[key] or not valid(key,val) then return nil end
        seen[key]=true;values[key]=val;count=count+1
    end
    if count<1 or count>#KEYS then return nil end
    return values
end
local function apply(payload, sender)
    local values=parse(payload)
    if not values then return "BAD" end
    if InCombatLockdown and InCombatLockdown() then pending={payload=payload,sender=sender} return "WAIT" end
    if type(SetCVar)~="function" then return "SKIP" end
    local backup={}
    local count=0
    for _,key in ipairs(KEYS) do
        if values[key] then
            local current=get(key)
            if current then
                backup[key]=current
                if current~=values[key] then
                    local ok=pcall(SetCVar,key,values[key])
                    if ok then count=count+1 end
                end
            end
        end
    end
    if count>0 then
        H.db.totalSyncCvarBackup=backup
        H.Print("Total UI Sync: "..count.." Blizzard UI settings received. Backup kept for local rollback.")
    end
    return "OK"
end
local function liveLeader(sender)
    if not (H.Trusted and H.Trusted(sender) and H.LeaderName and H.Norm) then return false end
    local leader=H.LeaderName()
    return leader and H.Norm(leader)==H.Norm(sender)
end
H.On("CHAT_MSG_ADDON",function(prefix,msg,channel,sender)
    if prefix~=H.PREFIX or channel~="WHISPER" or type(msg)~="string" then return end
    if H.Secret and (H.Secret(msg) or H.Secret(sender)) then return end
    if #msg>240 then return end
    local ver,kind,body=msg:match("^(%d+)|([A-Z]+)|(.+)$")
    if ver~="1" or not body then return end
    if kind=="CVR" then
        if not liveLeader(sender) then return end
        local status=apply(body,sender)
        H.SendTo(sender,"CVA",status)
    elseif kind=="CVA" and H.AmLeader and H.AmLeader() and H.Trusted(sender) then
        if body=="OK" or body=="WAIT" or body=="BAD" or body=="SKIP" then
            H.Print("Blizzard settings from "..tostring(sender)..": "..body)
        end
    end
end)
H.On("PLAYER_REGEN_ENABLED",function()
    if not pending then return end
    local job=pending;pending=nil
    if not liveLeader(job.sender) then return end
    local result=apply(job.payload,job.sender)
    if H.SendTo then H.SendTo(job.sender,"CVA",result) end
end)
function H.SendBlizzardCVars()
    if not (H.AmLeader and H.AmLeader()) then H.Print("Only the live party leader can send UI settings.") return 0 end
    local parts={}
    for _,key in ipairs(KEYS) do
        local v=get(key)
        if v then parts[#parts+1]=key.."="..v end
    end
    if #parts<1 then H.Print("No supported Blizzard UI CVars on this client; skipped safely.") return 0 end
    local payload="1;"..table.concat(parts,";")
    local sent=H.SendTeam("CVR",payload)
    H.Print("Blizzard UI: "..#parts.." common settings sent to "..sent.." trusted clients; original values backed up locally.")
    return sent
end
function H.TotalSyncPreview()
    if not (H.AmLeader and H.AmLeader()) then H.Print("Total UI Sync: open on Mael, as party leader.") return false end
    local n=0
    for _,u in ipairs(H.PartyUnits()) do
        if u~="player" and H.Trusted(H.UnitName(u)) then n=n+1 end
    end
    H.Print("Total UI Sync PREVIEW: "..n.." eligible followers; HaploBox shared settings + anchors via existing ACK/CRC sender.")
    H.Print("Optional Blizzard CVars: status text, target of target, UI scale if supported. Edit Mode & external addon SavedVariables not silently imported.")
    return true
end
function H.TotalSyncExecute(includeBlizzard)
    if not H.TotalSyncPreview() then return false end
    if InCombatLockdown and InCombatLockdown() then H.Print("Run Total UI Sync after combat.") return false end
    if not H.ShareUI then return false end
    H.ShareUI()
    if includeBlizzard==true then H.SendBlizzardCVars() end
    return true
end
function H.UndoTotalSyncCVars()
    if InCombatLockdown and InCombatLockdown() then H.Print("Undo CVar changes after combat.") return false end
    local backup=H.db and H.db.totalSyncCvarBackup
    if not backup or not SetCVar then H.Print("No Blizzard CVar backup on this client.") return false end
    local n=0
    for _,key in ipairs(KEYS) do
        if valid(key,backup[key]) then
            if pcall(SetCVar,key,backup[key]) then n=n+1 end
        end
    end
    H.db.totalSyncCvarBackup=nil
    H.Print("Restored "..n.." Blizzard CVars; HaploBox config unchanged.")
    return true
end

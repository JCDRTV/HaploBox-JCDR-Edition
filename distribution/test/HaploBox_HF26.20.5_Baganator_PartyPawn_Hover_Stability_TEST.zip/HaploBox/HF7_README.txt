HAPLOBOX JCDR EDITION - HF7 HAPLOBAR SECTION DIAGNOSTIC
Source: HF6 Performance & Combat Diagnostic. No gameplay or synchronization changes.
HF6 found HaploBar OnUpdate max 123.45ms, 9 slow calls and 9 frames >=100ms.
HF7 adds memory-only section measurements for: zone text (0.3s), map coordinates (0.3s), external coords scan (2s), clock style (0.5s), suppressed buttons (0.5s), placed buttons (0.5s).

INSTALL: Backup the current HaploBox folder; replace the complete Interface/AddOns/HaploBox folder from ZIP. Keep WTF/SavedVariables. Relaunch WoW.
TEST WITH 1 CHARACTER, SOLO, OUTSIDE COMBAT:
/hbdiag reset
Stand still 30-60 seconds while spikes occur.
/hbdiag report
Take screenshots of the entire report, especially HaploBar/ lines and HaploBar OnUpdate.
Optional: enter combat without pressing anything, then report again after combat.
HF7 is diagnostic only and does not claim to fix lag or combat interface warnings.

HAPLOBOX HF25.1 - ATLASLOOT + PAWN ITEMINFO HOTFIX (TEST)

Base: exactly HF25 test ZIP, not the older source folder. No edits to Follow, Box Mode, macros, Trade or other existing modules.

FIXED
- WoW Forever may not export legacy global GetItemInfo. LootAdvisor uses C_Item.GetItemInfo with safe fallback, including item names, links and equip types.
- Fix nil-call at original LootAdvisor.lua:244 when opening /hb loot or switching bosses.
- Parse separate Q|token|itemID and R|token|itemID|status|delta network messages. HF25 incorrectly used a single pattern.
- Requests only on ALT+hover instead of item clicks. No background sync; no stale results are reused.
- Uncached item text shows item:<ID>; C_Item may populate the name later. No invented Pawn scores.

IN GAME
1) Install on all 5 Druids and reload. Keep Pawn and AtlasLoot installed.
2) /hb loot on Mael. Select dungeon and boss; item names should show.
3) ALT+hover an item and keep ALT held over it to receive five current scores.
4) Release ALT and ensure results clear. Click alone must NOT send party requests.
5) If Pawn shows SET SCALE, configure the correct local scale for that character.
6) Verify Quick Menu, Lyra's Gathering Map, Follow, Box Mode and macros unchanged.

LIMITATIONS
- No automated dungeon ranking or Run Tracker yet.
- Network/GUI integration tested offline only; client tests required.
- 2H versus MH+OH uses Pawn item-stat weights, not proc-specific DPS modeling.
- Only the LootAdvisor Lua file, this README and TOC version label are different from HF25.

HF20 — BLIZZARD NATIVE DAMAGE METER MINI UI FIX
================================================
Status: OFFLINE PASS; INGAME TEST OPEN — NOT LIVE OK.
Base: HF19 ZIP, cumulative, previous versions preserved unchanged.

User supplied an exact Blizzard /fstack screenshot:
  DamageMeterSessionWindow1
  Source: Interface/AddOns/Blizzard_DamageMeter/DamageMeter.lua:285
  Children: DamageMeterSessionWindow1.Header and .MinimizeContainer.

HF18/HF19 supported Skada and other damage meters, but this is the
Blizzard native damage-meter window. HF20 adds exactly ONE global parent:
  DamageMeterSessionWindow1
into the existing bounded HUD_NAMES list in MiniHeal.lua.

When a follower enters Mini UI out of combat, the existing suppressFrame
captures its original visible/alpha state and hides (or fades for protected
frames) this parent. The existing Main UI path restores the snapshot. Any
window spawned after entering Mini is picked up by the existing bounded
refresh when it becomes available. Never run EnumerateFrames or unbounded
UI searches; never change protected visibility in combat.

All orange HP frames, sizes, anchors and colors, the follower camera,
SwingTimerMainHandFrame support, buffs, macros, party and other addon code
are byte-identical to HF19. This change does not purport to repair NPC
names or other remaining unrelated UI issues.

TEST INGAME:
  1. On one follower, enter Mini out of combat: Damage Done window 1 gone.
  2. Switch to Main: window 1 comes back if originally visible.
  3. /reload on all followers and check no Lua error and no HP changes.
  4. Check that Party Leader's normal UI is unchanged.

Not yet ingame validated. HF19 and all earlier archives preserved.

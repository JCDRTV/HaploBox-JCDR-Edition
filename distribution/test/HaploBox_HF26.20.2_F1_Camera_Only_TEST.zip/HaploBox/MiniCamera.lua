-- HF26.20.2 / CAM-F1-ONLY:
-- Main/Mini UI never controls a character's camera, zoom, pitch or tracking.
-- ONLY the existing hardware-activated Smart Follow F1 macro may recall a
-- follower's explicitly saved Blizzard camera view 5.
local HB=HaploBox
local SMART_FOLLOW_VIEW=5
local pendingFollowView=false
local function blocked()
    return InCombatLockdown and InCombatLockdown()
end
local function follower()
    return IsInGroup and IsInGroup() and HB.IAmLeader and not HB.IAmLeader()
end

-- One-time migration from old Mini UI camera behavior. A previous build may
-- have changed the camera tracking CVar and saved its original value in the
-- character database. Restore only that original tracking preference, then
-- retire the snapshot. Never alter zoom, pitch or the current saved view here.
local function retireLegacyMiniCamera()
    local snapshot=HB.db and HB.db.miniCameraSnapshot
    if not snapshot or blocked() then return end
    if type(snapshot)=="table" and snapshot.tracking~=nil then
        local setter=(C_CVar and C_CVar.SetCVar) or SetCVar
        if setter then pcall(setter,"cameraSmoothTrackingStyle",tostring(snapshot.tracking)) end
    end
    HB.db.miniCameraSnapshot=nil
end

local function recall()
    if not HB.db or not HB.db.smartFollowCameraSaved or not follower()
       or not HB.db.boxMode or not SetView then return false end
    local ok,result=pcall(SetView,SMART_FOLLOW_VIEW)
    if not ok or result==false then
        if blocked() then pendingFollowView=true end
        return false
    end
    pendingFollowView=false
    return true
end
function HB.SmartFollowCamera()
    -- Triggered only from the user's own HB Smart Follow F1 macro, after the
    -- existing Blizzard /follow partyX command. No automated follow or camera.
    return recall()
end
function HB.SaveSmartFollowCamera(confirm)
    if not follower() then
        if HB.print then HB.print("Follower camera: configure this on a follower in the party, not Mael.") end
        return false
    end
    if blocked() then
        if HB.print then HB.print("Save follower camera after combat.") end
        return false
    end
    if not confirm then
        if HB.print then HB.print("CAUTION: /hb followcam save confirm overwrites Blizzard camera view 5 on THIS follower only.") end
        return false
    end
    if not SaveView then
        if HB.print then HB.print("WoW SaveView API unavailable; nothing changed.") end
        return false
    end
    local ok,result=pcall(SaveView,SMART_FOLLOW_VIEW)
    if not ok or result==false then
        if HB.print then HB.print("Saving follower camera view 5 failed.") end
        return false
    end
    HB.db.smartFollowCameraSaved=true
    if HB.print then HB.print("Follower view 5 saved. F1 Smart Follow now restores this camera angle and zoom.") end
    return true
end
function HB.DisableSmartFollowCamera()
    if not HB.db then return false end
    HB.db.smartFollowCameraSaved=false
    pendingFollowView=false
    if HB.print then HB.print("F1 camera recall OFF. Smart Follow still works; saved Blizzard view 5 is intact.") end
    return true
end
function HB.SmartFollowCameraStatus()
    local enabled=HB.db and HB.db.smartFollowCameraSaved==true
    if HB.print then HB.print("Smart Follow F1 camera recall: "..(enabled and "ON (saved Blizzard view 5)" or "OFF; set desired view then /hb followcam save confirm")) end
    return enabled
end

local events=CreateFrame("Frame")
events:RegisterEvent("PLAYER_ENTERING_WORLD")
events:RegisterEvent("PLAYER_REGEN_ENABLED")
events:RegisterEvent("PLAYER_LOGOUT")
events:SetScript("OnEvent",function(_,event)
    if not HB.db or blocked() then return end
    retireLegacyMiniCamera()
    if event=="PLAYER_REGEN_ENABLED" and pendingFollowView then
        -- Retry only an explicit F1 recall that WoW refused during combat;
        -- changing Main/Mini mode never calls this callback.
        if C_Timer and C_Timer.After then
            C_Timer.After(0,function()
                if pendingFollowView and not blocked() then recall() end
            end)
        else recall() end
    end
end)

# HaploBox JCDR - single-installation TEST channel updater.
# Requires Windows PowerShell 5.1 or newer. Runs ONLY when the user clicks UPDATE.cmd.
param([switch]$Force, [switch]$Quiet)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
$Base = Join-Path $env:LOCALAPPDATA 'HaploBoxUpdater'
$ConfigPath = Join-Path $Base 'config.json'
$StatePath = Join-Path $Base 'state.json'
$LogPath = Join-Path $Base 'updater.log'
$LockPath = Join-Path $Base 'updater.lock'
New-Item -ItemType Directory -Force -Path $Base | Out-Null

function Log([string]$Message) {
    $line = '[{0}] {1}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Message
    Add-Content -LiteralPath $LogPath -Value $line -Encoding UTF8
    if (-not $Quiet) { Write-Host $line }
}
function Property([object]$Object, [string]$Name) {
    if ($null -eq $Object -or -not ($Object.PSObject.Properties.Name -contains $Name)) {
        throw "Manifest/config ontbreekt: $Name"
    }
    return [string]$Object.$Name
}
function Fail([string]$Message) { throw $Message }

$lock = $null
$temp = $null
$stage = $null
$rollback = $null
$target = $null
$swapped = $false
try {
    # Atomic exclusive lock. A second manual invocation exits quietly.
    try {
        $lock = [System.IO.File]::Open($LockPath,
            [System.IO.FileMode]::OpenOrCreate,
            [System.IO.FileAccess]::ReadWrite,
            [System.IO.FileShare]::None)
    } catch [System.IO.IOException] {
        exit 0
    }
    if (-not (Test-Path -LiteralPath $ConfigPath -PathType Leaf)) { Fail 'Updater nog niet ingericht: config.json ontbreekt. Start INSTALL.cmd.' }
    $cfg = Get-Content -LiteralPath $ConfigPath -Raw -Encoding UTF8 | ConvertFrom-Json
    $addonRoot = Property $cfg 'addons_path'
    $channel = Property $cfg 'channel'
    $manifestUrl = Property $cfg 'manifest_url'
    if ($channel -ne 'test') { Fail 'Deze eerste updater ondersteunt bewust uitsluitend kanaal test.' }
    if (-not (Test-Path -LiteralPath $addonRoot -PathType Container)) { Fail "AddOns-map niet gevonden: $addonRoot" }
    if ((Split-Path $addonRoot -Leaf) -ine 'AddOns') { Fail 'config.addons_path moet de map Interface\AddOns zijn.' }
    if (-not $manifestUrl.StartsWith('https://raw.githubusercontent.com/JCDRTV/HaploBox-JCDR-Edition/')) {
        Fail 'Ongeldige bron: updater accepteert alleen de officiële HaploBox-repository.'
    }
    $target = Join-Path $addonRoot 'HaploBox'

    # Cache-busting is deliberate: raw GitHub may cache an old manifest for minutes.
    $u = '{0}{1}ts={2}' -f $manifestUrl, $(if ($manifestUrl.Contains('?')) {'&'} else {'?'}), [DateTimeOffset]::UtcNow.ToUnixTimeSeconds()
    $manifest = Invoke-RestMethod -Uri $u -TimeoutSec 25
    if ((Property $manifest 'schema') -ne '1') { Fail 'Ongeldige manifestversie.' }
    if ((Property $manifest 'channel') -ne 'test') { Fail 'Manifest is geen TEST-release.' }
    if ((Property $manifest 'addon_folder') -ne 'HaploBox') { Fail 'Verkeerde addon in manifest.' }
    $version = Property $manifest 'version'
    $sha = (Property $manifest 'sha256').ToLowerInvariant()
    $zipUrl = Property $manifest 'zip_url'
    if ($version -notmatch '^HF[0-9]{2}\.[0-9]{1,3}(\.[0-9]{1,3})?$') { Fail 'Ongeldig releaseversienummer.' }
    if ($sha -notmatch '^[a-f0-9]{64}$') { Fail 'Ongeldige release SHA-256.' }
    if (-not $zipUrl.StartsWith('https://raw.githubusercontent.com/JCDRTV/HaploBox-JCDR-Edition/')) {
        Fail 'ZIP komt niet uit de officiële HaploBox-repository.'
    }
    if (-not $zipUrl.EndsWith('.zip')) { Fail 'Manifest-URL verwijst niet naar een ZIP.' }

    # Never skip an upgrade when the actual installed TOC disagrees with state.json.
    $toc = Join-Path $target 'HaploBox.toc'
    $already = $false
    if ((Test-Path -LiteralPath $StatePath -PathType Leaf) -and (Test-Path -LiteralPath $toc -PathType Leaf)) {
        try {
            $state = Get-Content -LiteralPath $StatePath -Raw -Encoding UTF8 | ConvertFrom-Json
            $tocData = Get-Content -LiteralPath $toc -Raw
            if (($state.version -eq $version) -and ($state.sha256 -eq $sha) -and ($tocData.Contains($version))) { $already = $true }
        } catch { $already = $false }
    }
    if ($already -and -not $Force) { Log "$version is al geinstalleerd. Geen wijzigingen nodig."; exit 0 }

    Log "Nieuw TEST-build beschikbaar: $version; downloaden en controleren..."
    $temp = Join-Path $Base ('work-' + [Guid]::NewGuid().ToString('N'))
    New-Item -ItemType Directory -Path $temp | Out-Null
    $zip = Join-Path $temp 'HaploBox.zip'
    Invoke-WebRequest -Uri $zipUrl -OutFile $zip -UseBasicParsing -TimeoutSec 120
    $actual = (Get-FileHash -LiteralPath $zip -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($actual -ne $sha) { Fail "Checksumfout. Verwacht $sha; ontvangen $actual. Installatie NIET gestart." }

    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $archive = [System.IO.Compression.ZipFile]::OpenRead($zip)
    try {
        $files = 0
        foreach ($entry in $archive.Entries) {
            $name = $entry.FullName.Replace('\', '/')
            if (-not $name.StartsWith('HaploBox/', [StringComparison]::Ordinal)) { Fail "ZIP heeft onverwacht pad: $name" }
            if ($name -match '(^/|/\.\.?(/|$)|[:*?"<>|])') { Fail "Onveilig ZIP-pad: $name" }
            if ($name.Length -gt 240) { Fail 'ZIP-pad is te lang voor veilige Windows-installatie.' }
            if (-not $name.EndsWith('/')) { $files++ }
        }
        if ($files -lt 15) { Fail "ZIP lijkt incompleet ($files bestanden)." }
    } finally { $archive.Dispose() }

    $extractRoot = Join-Path $temp 'unpacked'
    New-Item -ItemType Directory -Path $extractRoot | Out-Null
    [System.IO.Compression.ZipFile]::ExtractToDirectory($zip, $extractRoot)
    $source = Join-Path $extractRoot 'HaploBox'
    $newToc = Join-Path $source 'HaploBox.toc'
    if (-not (Test-Path -LiteralPath $newToc -PathType Leaf)) { Fail 'ZIP mist HaploBox.toc.' }
    if (-not (Get-Content -LiteralPath $newToc -Raw).Contains($version)) { Fail 'TOC versienummer komt niet overeen met manifest.' }

    $stage = Join-Path $addonRoot ('.HaploBox.stage-' + [Guid]::NewGuid().ToString('N'))
    Copy-Item -LiteralPath $source -Destination $stage -Recurse
    if (-not (Test-Path -LiteralPath (Join-Path $stage 'HaploBox.toc') -PathType Leaf)) { Fail 'Staging mislukt.' }

    # Save a full rollback copy OUTSIDE Interface\AddOns, never overwrite WTF/SavedVariables.
    if (Test-Path -LiteralPath $target -PathType Container) {
        $backupRoot = Join-Path $Base 'Backups'
        New-Item -ItemType Directory -Force -Path $backupRoot | Out-Null
        $backup = Join-Path $backupRoot ('HaploBox-' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '-' + [Guid]::NewGuid().ToString('N').Substring(0,6))
        Copy-Item -LiteralPath $target -Destination $backup -Recurse
        if (-not (Test-Path -LiteralPath (Join-Path $backup 'HaploBox.toc') -PathType Leaf)) { Fail 'Back-upcontrole mislukt. Installatie afgebroken.' }
    }

    $rollback = Join-Path $addonRoot ('.HaploBox.rollback-' + [Guid]::NewGuid().ToString('N'))
    if (Test-Path -LiteralPath $target -PathType Container) {
        Move-Item -LiteralPath $target -Destination $rollback
        $swapped = $true
    }
    try {
        Move-Item -LiteralPath $stage -Destination $target
        $stage = $null
    } catch {
        if ($swapped -and (Test-Path -LiteralPath $rollback -PathType Container) -and -not (Test-Path -LiteralPath $target)) {
            Move-Item -LiteralPath $rollback -Destination $target
            $swapped = $false
        }
        throw
    }
    if (Test-Path -LiteralPath $rollback -PathType Container) {
        Remove-Item -LiteralPath $rollback -Recurse -Force
        $swapped = $false
    }

    $newState = [ordered]@{
        version = $version
        channel = 'test'
        sha256 = $sha
        installed_at = (Get-Date).ToString('o')
        addons_path = $addonRoot
    }
    $newState | ConvertTo-Json | Set-Content -LiteralPath $StatePath -Encoding UTF8
    Log "$version succesvol in $target geinstalleerd. Doe /reload in de vijf WoW-clients."
} catch {
    try { Log ('FOUT: ' + $_.Exception.Message) } catch {}
    if ($swapped -and $null -ne $rollback -and (Test-Path -LiteralPath $rollback -PathType Container) -and ($null -eq $target -or -not (Test-Path -LiteralPath $target))) {
        try { Move-Item -LiteralPath $rollback -Destination $target } catch { try { Log ('HERSTEL MISLUKT: ' + $_.Exception.Message) } catch {} }
    }
    exit 1
} finally {
    if ($null -ne $temp -and (Test-Path -LiteralPath $temp)) { Remove-Item -LiteralPath $temp -Recurse -Force -ErrorAction SilentlyContinue }
    if ($null -ne $stage -and (Test-Path -LiteralPath $stage)) { Remove-Item -LiteralPath $stage -Recurse -Force -ErrorAction SilentlyContinue }
    if ($null -ne $lock) { $lock.Dispose() }
}

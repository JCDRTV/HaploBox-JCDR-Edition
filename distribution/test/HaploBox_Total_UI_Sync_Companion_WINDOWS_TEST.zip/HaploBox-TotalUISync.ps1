# HaploBox Total UI Sync Companion v0.1 TEST — standalone Windows PowerShell 5.1.
# OFFLINE only; explicit selection, preview, backups, one-click restore.
# No background jobs, no scheduled tasks, no web/network, no WOW process manipulation.
Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()

$script:ProgramDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$script:Characters = @{}
$script:FileChoices = @{}
$script:LastPreviewSignature = $null
$script:LastPreviewPlan = @()

function Require-ClosedWoW {
    $running = @(Get-Process -ErrorAction SilentlyContinue | Where-Object {
        $_.ProcessName -match '^(wow|wowclassic|wowclassicera|wowforever|worldofwarcraft)([0-9a-z_-]*)$'
    })
    if ($running.Count -gt 0) {
        [System.Windows.Forms.MessageBox]::Show('WoW is running. Close EVERY client before copying SavedVariables, or WoW may overwrite the changes.', 'HaploBox - clients open', 'OK', 'Warning') | Out-Null
        return $false
    }
    return $true
}
function Get-WtfRoot {
    $root = $txtRoot.Text.Trim().Trim('"')
    if (-not (Test-Path -LiteralPath $root -PathType Container)) { throw "WoW folder not found: $root" }
    $wtf = Join-Path $root 'WTF'
    $accounts = Join-Path $wtf 'Account'
    if (-not (Test-Path -LiteralPath $accounts -PathType Container)) { throw "Expected WTF\Account folder is missing: $accounts" }
    return $wtf
}
function Short-Character([string]$name) {
    if ($name -match '^(Mael|Lyra|Elya|Nyra|Ayla)(\s|$)') { return $matches[1] }
    return $null
}
function Scan-Characters([string]$wtf) {
    $found = @()
    $accRoot = Join-Path $wtf 'Account'
    foreach ($acct in @(Get-ChildItem -LiteralPath $accRoot -Directory -ErrorAction SilentlyContinue)) {
        foreach ($realm in @(Get-ChildItem -LiteralPath $acct.FullName -Directory -ErrorAction SilentlyContinue)) {
            if ($realm.Name -in @('SavedVariables', 'Backups')) { continue }
            foreach ($char in @(Get-ChildItem -LiteralPath $realm.FullName -Directory -ErrorAction SilentlyContinue)) {
                $short=Short-Character $char.Name
                if (-not $short) { continue }
                $found += [pscustomobject]@{
                    Label = "$short | $($char.Name) | $($realm.Name) | $($acct.Name)"
                    Short = $short
                    Account = $acct.FullName
                    CharDir = $char.FullName
                    Realm = $realm.Name
                    Character = $char.Name
                }
            }
        }
    }
    return @($found | Sort-Object Short, Label)
}
function Append-Log([string]$msg) {
    $txtLog.AppendText($msg + [Environment]::NewLine)
}
function Set-Status([string]$msg) { $lblStatus.Text = $msg }
function Load-AddonChoices {
    $listAddons.Items.Clear()
    $script:FileChoices = @{}
    $script:LastPreviewSignature = $null
    if ($comboMaster.SelectedIndex -lt 0) { return }
    $source = $script:Characters[[string]$comboMaster.SelectedItem]
    $locations = @(
      @{ Scope = 'ACCOUNT'; Folder = (Join-Path $source.Account 'SavedVariables') },
      @{ Scope = 'CHARACTER'; Folder = (Join-Path $source.CharDir 'SavedVariables') }
    )
    foreach ($item in $locations) {
        if (-not (Test-Path -LiteralPath $item.Folder -PathType Container)) { continue }
        foreach ($file in @(Get-ChildItem -LiteralPath $item.Folder -Filter '*.lua' -File -ErrorAction SilentlyContinue | Sort-Object Name)) {
            # HaploBox is synced safely in-game; Blizzard data requires its own adapter.
            # Never copy those files blindly or character roles may be overwritten.
            if ($file.Name -match '^(HaploBox|Blizzard_).*\.lua$') { continue }
            if ($file.Length -gt 5242880) { continue } # per-file 5 MiB safety cap
            $label="[$($item.Scope)] $($file.Name)"
            $script:FileChoices[$label]=[pscustomobject]@{ Scope=$item.Scope; Source=$file.FullName; Name=$file.Name; Size=$file.Length }
            [void]$listAddons.Items.Add($label)
        }
    }
    Append-Log ("Found " + $listAddons.Items.Count + " selectable addon settings files; NO files are selected by default.")
}
function Reload-Inventory {
    $comboMaster.Items.Clear();$listTargets.Items.Clear();$listAddons.Items.Clear()
    $script:Characters = @{};$script:LastPreviewSignature=$null
    $wtf=Get-WtfRoot
    $chars=Scan-Characters $wtf
    foreach ($c in $chars) {
        $script:Characters[$c.Label]=$c
        if ($c.Short -eq 'Mael') { [void]$comboMaster.Items.Add($c.Label) }
        else {
            $idx=$listTargets.Items.Add($c.Label)
            $listTargets.SetItemChecked($idx,$true)
        }
    }
    if ($comboMaster.Items.Count -gt 0) { $comboMaster.SelectedIndex=0 }
    Load-AddonChoices
    Set-Status ("Detected " + $chars.Count + " Team A character folders. Check source, realm and recipients.")
    if ($comboMaster.Items.Count -lt 1) { Append-Log 'No Mael character folder found. Check game folder and character naming.' }
}
function New-Plan {
    if ($comboMaster.SelectedIndex -lt 0) { throw 'Select the Mael master first.' }
    $master=$script:Characters[[string]$comboMaster.SelectedItem]
    $targets=@()
    foreach ($label in @($listTargets.CheckedItems)) { $targets+= $script:Characters[[string]$label] }
    if ($targets.Count -lt 1) { throw 'Select at least one target character.' }
    $addon=@()
    foreach ($label in @($listAddons.CheckedItems)) { $addon+= $script:FileChoices[[string]$label] }
    if ($addon.Count -lt 1) { throw 'Select at least one addon file. Nothing is selected automatically.' }
    $plan=@();$dedupe=@{}
    foreach ($target in $targets) {
        foreach ($file in $addon) {
            if ($file.Scope -eq 'ACCOUNT') { $destDir=Join-Path $target.Account 'SavedVariables' }
            else { $destDir=Join-Path $target.CharDir 'SavedVariables' }
            $destination=Join-Path $destDir $file.Name
            if ([string]::Equals($file.Source,$destination,[StringComparison]::OrdinalIgnoreCase)) { continue }
            if ($dedupe.ContainsKey($destination.ToLowerInvariant())) { continue }
            $dedupe[$destination.ToLowerInvariant()]=$true
            $plan+= [pscustomobject]@{ Source=$file.Source; Destination=$destination; Scope=$file.Scope;
                Target=$target.Short; Addon=$file.Name; Exists=(Test-Path -LiteralPath $destination -PathType Leaf) }
        }
    }
    if ($plan.Count -lt 1) { throw 'No files need copying; master/target may share the same account.' }
    return @($plan)
}
function Plan-Signature($plan) {
    return (($plan | Sort-Object Destination | ForEach-Object { $_.Source + ' -> ' + $_.Destination }) -join [Environment]::NewLine)
}
function Show-Preview {
    $plan=New-Plan
    $script:LastPreviewPlan=$plan
    $script:LastPreviewSignature=Plan-Signature $plan
    $new=@($plan | Where-Object { -not $_.Exists }).Count
    $replace=@($plan | Where-Object { $_.Exists }).Count
    $txtLog.Clear()
    Append-Log 'DRY RUN — NOTHING HAS BEEN CHANGED.'
    Append-Log ("Files: " + $plan.Count + " | Replace: " + $replace + " | Create: " + $new)
    Append-Log 'Account files are copied once per destination account; character files to the matching follower character.'
    Append-Log 'CAUTION: some addons store character identity, inventory caches or named profiles inside .lua files.'
    Append-Log "A file copy cannot guarantee that a target addon switches to Mael's profile automatically."
    Append-Log ''
    foreach ($file in $plan) {
        $operation=if($file.Exists){'REPLACE'}else{'CREATE'}
        Append-Log ("$operation [$($file.Scope)] $($file.Addon) -> $($file.Target): $($file.Destination)")
    }
    Set-Status 'Preview ready. Recheck selected addon files; press SYNC only after closing ALL WoW clients.'
}
function Ensure-SafeDestination([string]$path,[string]$wtf) {
    $canon=[IO.Path]::GetFullPath($path)
    $prefix=[IO.Path]::GetFullPath($wtf).TrimEnd('\')+'\'
    if (-not $canon.StartsWith($prefix,[StringComparison]::OrdinalIgnoreCase)) {
        throw "Refusing file outside WTF: $path"
    }
}
function Restore-Records($records) {
    foreach ($record in @($records | Sort-Object -Property Destination -Descending)) {
        if ($record.Existed -eq 'True') {
            if (Test-Path -LiteralPath $record.Backup -PathType Leaf) {
                $dir=Split-Path -Parent $record.Destination
                if (-not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
                Copy-Item -LiteralPath $record.Backup -Destination $record.Destination -Force
            }
        } elseif (Test-Path -LiteralPath $record.Destination -PathType Leaf) {
            Remove-Item -LiteralPath $record.Destination -Force
        }
    }
}
function Execute-Sync {
    $plan=New-Plan
    if ($script:LastPreviewSignature -ne (Plan-Signature $plan)) {
        throw 'Selections changed since Preview. Click PREVIEW first.'
    }
    if (-not (Require-ClosedWoW)) { return }
    $ok=[System.Windows.Forms.MessageBox]::Show(
        "Overwrite $($plan.Count) selected SavedVariables files?`nEach existing file gets its own backup.`nAll five WoW clients must be CLOSED.",
        'HaploBox Total UI Sync - Confirm','YesNo','Warning')
    if ($ok -ne 'Yes') { return }
    $wtf=Get-WtfRoot
    $stamp=Get-Date -Format 'yyyyMMdd_HHmmss_fff'
    $backupRoot=Join-Path $script:ProgramDir ("Backups\$stamp")
    $records=New-Object System.Collections.ArrayList
    New-Item -ItemType Directory -Path $backupRoot -Force | Out-Null
    try {
        foreach ($item in $plan) {
            Ensure-SafeDestination $item.Source $wtf
            Ensure-SafeDestination $item.Destination $wtf
            if (-not (Test-Path -LiteralPath $item.Source -PathType Leaf)) { throw "Source vanished: $($item.Source)" }
            $targetDir=Split-Path -Parent $item.Destination
            if (-not (Test-Path -LiteralPath $targetDir)) { New-Item -ItemType Directory -Path $targetDir -Force | Out-Null }
            $relative=$item.Destination.Substring($wtf.Length).TrimStart('\')
            $backup=Join-Path (Join-Path $backupRoot 'files') $relative
            $exists=Test-Path -LiteralPath $item.Destination -PathType Leaf
            if ($exists) {
                New-Item -ItemType Directory -Path (Split-Path -Parent $backup) -Force | Out-Null
                Copy-Item -LiteralPath $item.Destination -Destination $backup -Force
            }
            [void]$records.Add([pscustomobject]@{ Source=$item.Source; Destination=$item.Destination;
                Backup=$backup; Existed=[string]$exists; Addon=$item.Addon; Scope=$item.Scope; Target=$item.Target })
            Copy-Item -LiteralPath $item.Source -Destination $item.Destination -Force
            if ((Get-FileHash -Algorithm SHA256 -LiteralPath $item.Source).Hash -ne
                (Get-FileHash -Algorithm SHA256 -LiteralPath $item.Destination).Hash) {
                throw "SHA256 check failed for $($item.Destination)"
            }
        }
        $records | Export-Csv -LiteralPath (Join-Path $backupRoot 'manifest.csv') -NoTypeInformation -Encoding UTF8
        [IO.File]::WriteAllText((Join-Path $script:ProgramDir 'LAST_SUCCESSFUL_BACKUP.txt'),$backupRoot)
        Append-Log ("SUCCESS — " + $records.Count + " files copied, verified SHA256 and backed up to " + $backupRoot)
        Set-Status "Sync completed ($($records.Count) files). Now start WoW; check addon profiles on each follower."
        $script:LastPreviewSignature=$null
    } catch {
        try { Restore-Records @($records.ToArray()) } catch { Append-Log "ROLLBACK ERROR: $_" }
        throw "Sync failed. Automatic rollback attempted. Error: $_"
    }
}
function Restore-Last {
    if (-not (Require-ClosedWoW)) { return }
    $flag=Join-Path $script:ProgramDir 'LAST_SUCCESSFUL_BACKUP.txt'
    if (-not (Test-Path -LiteralPath $flag -PathType Leaf)) { throw 'No successful backup record yet.' }
    $folder=[IO.File]::ReadAllText($flag).Trim()
    $manifest=Join-Path $folder 'manifest.csv'
    if (-not (Test-Path -LiteralPath $manifest -PathType Leaf)) { throw 'Backup manifest missing.' }
    $records=@(Import-Csv -LiteralPath $manifest)
    $ok=[System.Windows.Forms.MessageBox]::Show(
        "Restore $($records.Count) files from: $folder?`nWoW must be CLOSED. This overwrites any settings changed since the sync.",
        'Restore previous settings','YesNo','Warning')
    if ($ok -ne 'Yes') { return }
    Restore-Records $records
    Append-Log ("RESTORED " + $records.Count + " files from " + $folder)
    Remove-Item -LiteralPath $flag -Force
    Set-Status 'Last sync restored. Launch WoW to check the settings.'
}

$form=New-Object System.Windows.Forms.Form
$form.Text='HaploBox - Total UI Sync Companion (TEST)'
$form.Size=New-Object System.Drawing.Size(970,730)
$form.StartPosition='CenterScreen';$form.MinimumSize=New-Object System.Drawing.Size(920,650)
$form.BackColor=[Drawing.Color]::FromArgb(27,33,42)
$form.ForeColor=[Drawing.Color]::White
$form.Font=New-Object System.Drawing.Font('Segoe UI',9)

function Add-Label([string]$text,[int]$x,[int]$y,[int]$w,[int]$h) {
    $l=New-Object System.Windows.Forms.Label
    $l.Text=$text;$l.SetBounds($x,$y,$w,$h);$l.ForeColor=[Drawing.Color]::Gainsboro
    $form.Controls.Add($l);return $l
}
function Add-Button([string]$text,[int]$x,[int]$y,[int]$w,[int]$h,[scriptblock]$handler) {
    $b=New-Object System.Windows.Forms.Button
    $b.Text=$text;$b.SetBounds($x,$y,$w,$h)
    $b.BackColor=[Drawing.Color]::FromArgb(49,69,91)
    $b.ForeColor=[Drawing.Color]::White;$b.FlatStyle='Flat'
    $b.Add_Click({try{& $handler}catch{[System.Windows.Forms.MessageBox]::Show([string]$_,'HaploBox Error','OK','Error')|Out-Null; Append-Log ("ERROR: " + $_)}}.GetNewClosure())
    $form.Controls.Add($b);return $b
}
Add-Label 'WoW Forever folder' 18 16 200 21 | Out-Null
$txtRoot=New-Object System.Windows.Forms.TextBox
$txtRoot.SetBounds(18,41,750,27);$txtRoot.Text='D:\World of Warcraft\_forever_'
$form.Controls.Add($txtRoot)
Add-Button 'SCAN' 790 39 150 30 {Reload-Inventory}|Out-Null
Add-Label 'MASTER (MAEL)' 18 84 300 24 | Out-Null
$comboMaster=New-Object System.Windows.Forms.ComboBox
$comboMaster.DropDownStyle='DropDownList';$comboMaster.SetBounds(18,110,440,26)
$comboMaster.Add_SelectedIndexChanged({Load-AddonChoices})
$form.Controls.Add($comboMaster)
Add-Label 'TARGETS (FOLLOWERS)' 484 84 330 24 | Out-Null
$listTargets=New-Object System.Windows.Forms.CheckedListBox
$listTargets.SetBounds(484,110,457,144);$listTargets.CheckOnClick=$true
$form.Controls.Add($listTargets)
Add-Label 'ADDON SETTINGS FILES — CHECK ONLY WHAT YOU WANT TO COPY' 18 155 462 25 | Out-Null
$listAddons=New-Object System.Windows.Forms.CheckedListBox
$listAddons.SetBounds(18,180,440,230);$listAddons.CheckOnClick=$true
$form.Controls.Add($listAddons)
Add-Button 'SELECT ACCOUNT FILES' 484 275 222 32 {
    for($i=0;$i -lt $listAddons.Items.Count;$i++) {
        $label=[string]$listAddons.Items[$i]
        if($label.StartsWith('[ACCOUNT] ')) {$listAddons.SetItemChecked($i,$true)}
    }
    $script:LastPreviewSignature=$null
} |Out-Null
Add-Button 'CLEAR FILE SELECTION' 719 275 222 32 {
    for($i=0;$i -lt $listAddons.Items.Count;$i++) {$listAddons.SetItemChecked($i,$false)}
    $script:LastPreviewSignature=$null
}|Out-Null
Add-Label 'ACCOUNT = shared addon configs; CHARACTER = can include toon data.' 484 325 460 25|Out-Null
Add-Label 'HaploBox and Blizzard_* are excluded. Never copied automatically.' 484 350 460 34|Out-Null
Add-Label 'All WoW clients must be CLOSED for Companion Sync.' 484 389 455 25|Out-Null
Add-Button '1. PREVIEW CHANGES' 18 422 295 40 {Show-Preview}|Out-Null
Add-Button '2. SYNC SELECTED' 328 422 296 40 {Execute-Sync}|Out-Null
Add-Button 'RESTORE LAST SYNC' 639 422 302 40 {Restore-Last}|Out-Null
$txtLog=New-Object System.Windows.Forms.TextBox
$txtLog.Multiline=$true;$txtLog.ReadOnly=$true;$txtLog.ScrollBars='Vertical'
$txtLog.SetBounds(18,474,923,159)
$txtLog.BackColor=[Drawing.Color]::FromArgb(18,24,31)
$txtLog.ForeColor=[Drawing.Color]::Gainsboro
$txtLog.Font=New-Object Drawing.Font('Consolas',8)
$form.Controls.Add($txtLog)
$lblStatus=Add-Label 'Offline test version. Inspect Preview before applying.' 18 643 920 32
$form.Add_Shown({try{Reload-Inventory}catch{Append-Log("Scan: " + $_)}})
[void]$form.ShowDialog()

HaploBox TOTAL UI SYNC COMPANION — WINDOWS TEST v0.1

PURPOSE
Synchronize explicitly selected WoW addon SavedVariables files from Mael to Lyra,
Elya, Nyra and Ayla when a live, safe in-game adapter is not available.

HOW TO USE
1. First log out or exit EVERY WoW Forever client completely. /reload is NOT enough.
2. Extract this ZIP to a permanent folder (NOT inside Interface/AddOns).
3. Run "HaploBox Total UI Sync.cmd" on the Windows desktop.
4. Scan the correct WoW Forever folder (default D:\World of Warcraft\_forever_).
5. Verify Mael's source account/realm and check the intended follower target folders.
6. Select only the addon .lua settings files you want to share. None selected initially.
   - [ACCOUNT] = source account SavedVariables, applied once per destination account.
   - [CHARACTER] = source Mael's toon SavedVariables, applied to each selected follower.
7. Click PREVIEW and inspect EVERY destination file.
8. Click SYNC SELECTED. Every existing file gets a timestamped backup; SHA256 is
   checked. Restore Last Sync reverses the last successful run while WoW is closed.
9. Start WoW. Check profiles and UI position in each addon manually; some addons
   key settings to individual character names and will NOT use copied profile
   data without an addon-specific adapter or in-game profile import.

IMPORTANT SAFETY
- No scheduled/background task; no network communication; no Windows services.
- Never run while WoW is open; the program checks for WoW processes.
- HaploBox and Blizzard_* .lua are NOT copied (character roles, bars and Edit Mode
  require specific handling). Ingame HaploBox Total UI Sync handles shared HaploBox
  settings and optional safe Blizzard CVars; Blizzard Edit Mode is pending validation.
- SavedVariables may contain bags, inventory databases, alt information or addon
  character identity! Select files knowingly; character-scope copying is risky.
- Only .lua files up to 5 MiB are listed. Settings contained in other formats are not
  supported by this first test version. No blanket WTF folder copy.
- Backups are stored in the Companion folder under Backups\YYYYMMDD_HHMMSS_mmm.
- Windows PowerShell 5.1/WinForms required; native Windows run not yet verified.

STATUS: OFFLINE REVIEWED / WINDOWS TEST OPEN. Do not assume full addon compatibility.

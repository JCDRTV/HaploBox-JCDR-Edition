@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -STA -File "%~dp0HaploBox-TotalUISync.ps1"
if errorlevel 1 pause

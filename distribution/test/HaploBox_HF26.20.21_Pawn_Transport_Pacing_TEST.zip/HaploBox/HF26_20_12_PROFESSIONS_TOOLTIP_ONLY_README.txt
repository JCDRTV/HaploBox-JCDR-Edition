HF26.20.12 TEST - ORIGINAL BLIZZARD PROFESSIONS ITEM TOOLTIPS ONLY

User correction: no standalone Party Pawn profession panel; no Mini UI edits.

Changes confined to LootHover.lua (Party Pawn) and addon version/readme:
* Removed HF26.20.11 polling observer and addon-owned recipe panel.
* When a REAL item tooltip originates inside Blizzard ProfessionsFrame,
  TradeSkillFrame or CraftFrame, show the existing five-client Party Pawn
  evaluation INSIDE that very same GameTooltip, under Blizzard item stats.
* Keep bag/AtlasLoot ALT-hover behavior unchanged; profession hovers can
  show without ALT. Reagent item tooltip uses its own item ID, not the
  selected recipe result. A selected-recipe fallback is restricted to the
  actual output-icon widget, never arbitrary profession buttons.
* OnShow, Item TooltipDataProcessor and secure native tooltip setter hooks
  support variants of WoW Forever/Classic profession windows.
* No new frame, no background polling, no new network protocol.
* MiniHeal.lua, MiniCamera.lua, Smart Follow, visibility gates and every
  other Lua module byte-for-byte preserved from HF26.20.11.

TEST IN GAME:
1. /reload, open Blizzard Leatherworking (not Haplo Loot).
2. Hover the crafted item's ICON / its tooltip. The five Party Pawn rows
   should be INSIDE the original Blizzard tooltip, not beside the window.
3. Hover reagents; when item evaluation is possible, score the hovered
   reagent itself. Switch recipes and move away; no floating leftover panel.
4. Check normal ALT+bag and AtlasLoot tooltip still work.
5. /hbprofdiag while hovering if no Party Pawn rows show.
6. Confirm Mini UI behaves as before. The Mini UI was not touched.

Offline-only tests are NOT ingame verification.

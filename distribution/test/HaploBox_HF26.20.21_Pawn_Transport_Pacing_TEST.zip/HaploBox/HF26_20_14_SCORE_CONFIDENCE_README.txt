HaploBox HF26.20.14 - Run Guide Score Confidence (TEST)

This patch does NOT modify Mini UI, Smart Follow, Party Pawn tooltip adapters or the large Loot Planner scoring rules. Changes are limited to the Run Guide display and shared scan invalidation safety in LootPlanner.lua.

Important interpretation:
- A boss marked "N upgrades OK" means every one of its AtlasLoot-listed item IDs has a usable score/restriction response from ALL FIVE named Team A Druids, with no mismatched level snapshot. It does not guarantee that AtlasLoot enumerates all actual Forever drops, or that Pawn's configured scale weights match your goals.
- A boss marked "N? CHECK" or "? CHECK" is NOT safe to use as the definitive list of upgrades or no-upgrades. Hover the boss row or type /hbrunaudit for an explanation. An incomplete scan can have independently checked bosses.
- Green percentage means complete boss-level Pawn coverage; amber percentage plus "?" is a candidate needing review.
- Future level items are still shown only when FUTURE ON, and are not NOW upgrades. New empty-slot comparisons without a % are not certified numeric upgrades.
- Gear/level changes during a scan or afterward require a new SCAN THIS DUNGEON; stale generations never turn green after their final packet.

Ingame reliability test: five connected Team A Druids; /hbrun > Wailing Caverns > SCAN THIS DUNGEON; verify 5/5, inspect Lady Anacondra scores vs Pawn tooltip on Mael/Elya/Nyra/Ayla; gear swap DURING a scan should mark STALE; try one follower offline (no boss OK), restore follower and rescan; /hbrunaudit explains which data is missing. Boss [ ] completion flags remain manual.

Trust boundary: this improves confidence reporting and prevents false green results. It cannot certify server-side drop tables or Pawn scale quality without in-game checks.

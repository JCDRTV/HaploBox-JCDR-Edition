HaploBox HF26.20.13 - Dungeon Run Guide V1 (TEST ONLY)

1. On Mael, click Haplo Loot > RUN GUIDE, or type /hbrun.
2. Click CHANGE and choose Wailing Caverns or another dungeon.
3. Click SCAN THIS DUNGEON once while out of combat, with AtlasLoot + Pawn on the five clients. Party responders are checked using existing HBLP26 protocol.
4. The compact window lists every boss. Click a boss row to expand current *confirmed* Pawn upgrades; click its [ ] button to manually mark complete. Boss checks persist per dungeon across reloads. RESET RUN unchecks the selected dungeon.
5. Item icons show the normal Blizzard GameTooltip; existing Party Pawn ALT hover applies. V1 button toggles including *future* level upgrades (clearly marked).
6. WC has an approximate commonly used route order (Anacondra, Cobrahn, Kresh, optional Faerie Dragon, Pythas, Skum, Serpentis, Verdan, Mutanus), not an exact automated navigation path. Other dungeons follow AtlasLoot encounter database order, which may differ from shortest walk route.
7. This is a read-only loot *possibility* guide, NOT a record of actual loot dropped. Actual boss kills are never automatically detected; checkmarks are manual. Missing responses and stale gear do not become fake 0%. Only normal boss tables; trash/quests/vendor/professions excluded. Mixed classes not yet supported.
8. Mini UI and Smart Follow are unchanged byte-for-byte. Existing large Loot Planner, Party Pawn, tooltip and combat behavior are unchanged outside LootPlanner.lua.

Test: /hbrun > WC > SCAN THIS DUNGEON; check all five scores; check bosses, mark/expand, close/reopen, /reload, gear swap -> STALE and rescan; ensure Main/Mini, Smart Follow and other item hovers still work. Offline syntax/ZIP checks are not an ingame approval.

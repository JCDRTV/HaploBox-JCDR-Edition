HF26.20.10 STRICT MINI TOOLTIP LEAVE TRANSITION TEST

Observation ingame: mob tooltip is hidden during hover, but appears when mouse leaves mob. This points to native fade-out transition; alpha gating HF26.20.9 insufficient. In Mini ONLY, close the three native GameTooltip/ShoppingTooltip frames with Hide on OnShow/OnUpdate and after native FadeOut, guarded against recursion. In Main, no Hide/Show calls; normal Baganator Pawn ALT-hover is preserved. An existing 20.9 alpha fallback remains for protected frames refusing Hide. Native clicked ItemRefTooltip is not touched.

Steps: update through existing manual HaploBox updater; STATUS.cmd HF26.20.10; /reload. Enter Mini; hover mob then leave mob, tooltip should never reappear. Try second mob/item and Mini to Main; Main tooltip/Party Pawn should work. /hbtooltipdiag in Mini now prints hides and fadeEvents. If still visible attach diagnostic and screenshot to identify third-party tooltip.

Status: offline tested, ingame open.

HaploBox HF26.20.6 — MINI UI PLAYER CASTBAR VISIBLE (TEST)
21 November 2026 | OFFLINE CHECKS / INGAME TEST OPEN

Request: while using Mini UI, the player's native Blizzard castbar should
still be visible, but Main/Mini mode must retain every other prior behavior.

Change: remove CastingBarFrame and PlayerCastingBarFrame from the finite
MiniHeal HUD suppression list. Keep TargetFrameSpellBar and all other frames
hidden as before. This is an exemption, NOT a forced Show: the native bar
appears when WoW actually casts/channels, retains the player's layout and
works with the normal Blizzard cast lifecycle. Do not alter the Blizzard
castbar's parent, secure attributes, size, position, UI settings or CVar.

Test in WoW Forever:
1. Click the existing desktop HaploBox UPDATE shortcut; STATUS.cmd -> HF26.20.6.
2. /reload. On Lyra activate Mini UI, cast a heal or channel spell.
3. The own castbar should display and progress while casting, disappear when
   completed. Target castbar stays hidden. Main UI should remain unchanged.
4. Repeat combat and Mini/Main switch, and verify F1 follow/camera, 5 Party
   Pawn tooltip, buffs and sync unchanged.
5. If the native player castbar is still missing, check whether another addon
   has replaced it or it is parented to a hidden PlayerFrame on this client.
   Send /fstack of the actual castbar. No forced Show or reparenting was added.

This test build is NOT yet confirmed working ingame.

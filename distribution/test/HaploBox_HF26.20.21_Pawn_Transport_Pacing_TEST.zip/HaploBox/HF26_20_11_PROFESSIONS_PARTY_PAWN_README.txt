HF26.20.11 TEST - PARTY PAWN IN PROFESSIONS

Select a craftable item in Professions / TradeSkill / Craft window. An addon-owned
compact five-character Party Pawn panel appears next to the profession frame.
Uses the approved live HBHV15 request/reply, Pawn score/equipment checks and
aligned percentage/arrow/Need-dice renderer; no new broadcast protocol.

Main UI: existing ALT item hover remains unchanged. When ALT item-hover takes
focus, the selected-recipe panel yields; after ALT release it comes back.
Mini UI: Blizzard GameTooltip, ShoppingTooltip1/2 remain strictly hidden.
The new addon-owned profession panel is ONLY shown while a profession window
has a selected item output; no mob tooltip exclusion is introduced.
Non-item recipes (enchant/gather etc) have no Party Pawn item score.
Smart Follow, F1 camera, Baganator hooks and tooltip fade code unchanged.

TEST: /reload; open Leatherworking; select a crafted armor item and verify five
Party Pawn rows. Select another recipe; verify it updates and doesn't duplicate.
ALT-hover the profession output in Main, release ALT, verify the panel recovers.
Switch to Mini; select recipe, then hover a mob and leave: no native tooltip.
Close professions: panel disappears. /hbprofdiag for recipe-output diagnostics.
Offline syntax and regression tests only; ingame verification required.

HaploBox HF26.20.16 - Smart Spell macro target/pickup hotfix (TEST)

Only MacroLibrary.lua, BoxMode.lua, version metadata/history and this README were changed relative to HF26.20.14. Unshipped HF26.20.15 prototype is NOT used as base.

Cause: An already-existing HB Starfire (or similar named Smart Spell) whose body is a valid generated BOX OFF macro but whose saved ownership entry is missing cannot be adopted, so it remains /cast Starfire without /assist party1 even with follower BOX ON. Earlier HF26.20.15 pickup-only prototype was insufficient; DO NOT SHIP it.

HF26.20.16 behavior:
- User CLICK in Macro Menu explicitly checks whether an existing spell macro's entire body exactly matches a generated OFF / ON / LEADER profile.
- If and only if exact, recovers registry entry and synchronizes to this character's current BOX mode: follower ON includes /assist party1, OFF & leader do not. Unrelated or manually edited bodies are never overwritten.
- Click puts the verified macro on the cursor using Blizzard PickupMacro. Player manually places it in an action-bar slot.
- Fresh spells are created directly in the correct current profile rather than the default OFF form.
- Existing F1 follow, UI, macros of other name, stored bindings, Party Pawn, Loot Planner and run guide are not changed. No automated casts or prohibited input broadcasting.

INGAME: Install using HaploBox UPDATE; /reload all five toons. Outside combat, on Ayla verify BOX ON and Mael leader with /hb box status. Open Macro Menu > Smart Spells; click Starfire; inspect HB Starfire via /macro: /assist party1 should be directly before /cast Starfire. Place on bar and manually press on a target selected by Mael. Verify BOX OFF removes assist on follower and BOX ON restores it; never test in combat. Confirm custom user macros survive unchanged. F1 and Mini UI smoke-check. If nonstandard HB macro is rejected, inspect manually in /macro; never delete personal macros automatically.

Offline tests are separate from ingame acceptance.

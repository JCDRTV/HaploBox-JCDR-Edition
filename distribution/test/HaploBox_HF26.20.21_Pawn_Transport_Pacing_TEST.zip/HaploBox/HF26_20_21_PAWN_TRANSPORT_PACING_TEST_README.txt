HF26.20.21 — Pawn Transport Pacing TEST (2026-11-22)
BASE: HF26.20.20. Manual HaploBox UPDATE only.

INGAME OBSERVATION: After Mael sent 120 first-wave addressed requests plus 142 retry attempts, all four followers retained 19/30 scores each. Lyra's own /hblootnet diag showed addressed=19, ignored-other-target=57, repliesSent=19, sendFailed=0, and thus only 76 of 120 initial Q messages reached her client at all. Mael had applied=76, duplicate=0, oldScan=0, unexpected=0. SendAddonMessage's accepted return is not a delivery receipt. A shared request delivery/transport bottleneck is strongly suggested; channel-rate limiting is a hypothesis, not proven.

CHANGE: Strictly local to LootPlanner.lua: REQUEST SPACING on the existing addressed PARTY Q wire protocol is 0.90 seconds, instead of 0.24 seconds. This covers initial and targeted retries. Diagnostic /hblootnet diag on Mael prints the configured spacing. Existing finite two retry rounds, UI, item scoring, CHECKs for genuine NO_REPLY, weapon pairs, code transport and all unrelated features unchanged. Only LootPlanner.lua, version metadata/history and new README modified.

EXPECTATION: A 30-item, 4-follower Wailing Caverns scan has ~120 first-wave addressed Q, so initial request wave can take roughly two minutes, plus any retries. This slower pace is intentional for a controlled reliability test and is not an optimized long-term default.

VALIDATION: All 31 Lua source files must compile. Repeat network regression covering targeted Q, recoverable missing requests, permanent missing remains CHECK, correct high Pawn score handling; timer regression remains pass. ZIP CRC, manifest/hash and byte-for-byte unchanged protected files. Ingame acceptance OPEN; offline success cannot certify server delivery.

INGAME TEST (all five online, no gear changes during scan):
1) Update HF26.20.21 on all five, /reload, /hbrun on Mael and SCAN THIS DUNGEON for Wailing Caverns; allow the scan to actually finish.
2) On Mael: /hbrunaudit and /hblootnet diag; record Pawn replies, no reply count and retries.
3) On Lyra: /hblootnet diag; record addressed, ignored-other-target and repliesSent. A healthy first wave should show about 30 addressed and 90 ignored-other-target if no Q packets were lost, plus extra traffic if retries occurred. Counts are cumulative since /reload.
4) If 19/30 repeats, the issue is not resolved by request spacing; investigate server/client addon channel delivery or queues, do NOT suppress CHECK.

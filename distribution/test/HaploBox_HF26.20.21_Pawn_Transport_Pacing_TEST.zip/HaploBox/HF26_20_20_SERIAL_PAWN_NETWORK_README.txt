HF26.20.20 — Serialized Pawn scan requests TEST (2026-11-22)
BASE: HF26.20.19; manual HaploBox UPDATE only, no background checks.

OBSERVATION: On HF26.20.19 Mael accepted 89 replies, retry sent=98, 31 NO_REPLY remained. Lyra locally received 25 requests/25 replies sent, Elya 24/24, no sendFailed. This suggests but does NOT prove that initial group request/reply bursts can lose packets.

CHANGES:
- Each unique loot item is evaluated once locally on Mael. Remote item requests are staggered, sent as already-supported Q|scan|itemID|follower messages, ONE follower per 0.24 sec tick instead of one broadcast Q triggering four simultaneous replies. Targeted requests continue to use PARTY and the existing HBLP26 wire protocol; no new background networking or automatic actions.
- Existing two bounded retry rounds for still-missing item/follower results continue unchanged. No fabricated 'NOUP' and no falsely verified 'OK' on missing or invalid scores.
- /hblootnet diag on Mael: per-selected-scan initial addressed send counts, success/fail/skip, unique item count and accepted reply coverage for all five members, plus existing targeted retry stats and accepted/ignored reply counters.
- /hblootnet diag on followers: number of addressed requests processed, legacy broadcast requests, and packets addressed to another follower and skipped. Counts are cumulative since /reload, whereas scan coverage is for the selected scan.
- Pawn scale calculations, VERIFY WEAPON PAIR, SAFE score confidence, UI and persistent run timer untouched.

OFFLINE VALIDATION: Syntax compilation on all Lua files, behavior tests with simulated bursts and missing-pair retries, Run Guide timer regression, archive CRC, byte-for-byte changed-file comparison. Ingame acceptance OPEN.

INGAME TEST:
1. Update ALL five Druids, /reload, open /hbrun on Mael.
2. Wailing Caverns: SCAN THIS DUNGEON. The first wave will take longer (one addressed item/follower per 0.24 sec; ~30 items x 4 followers).
3. At end run /hbrunaudit then /hblootnet diag. Record NO_REPLY, first wave sent, targeted retries, five-member coverage.
4. Run /hblootnet diag separately on Lyra and Elya; compare addressed and ignored-other-target counts.
5. Scores still get CHECK for true missing replies; manual 1H/2H comparison remains CHECK.

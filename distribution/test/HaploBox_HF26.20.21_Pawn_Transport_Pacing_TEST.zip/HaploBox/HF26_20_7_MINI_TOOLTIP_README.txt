HaploBox HF26.20.7 — MINI MOUSEOVER TOOLTIP HIDDEN (TEST)
21 November 2026 | OFFLINE TEST PASS / INGAME OPEN

Change on HF26.20.6:
- Mini UI: standard GameTooltip for mouseover items/units and Blizzard
  ShoppingTooltip1/2 item comparisons rendered invisible (SetAlpha(0)).
- Main UI: each exact native tooltip alpha restored from first Mini entry.
- OnShow hook silently reasserts invisibility if Blizzard/Baganator reopens a
  tooltip while Mini; no forced Hide(), Show(), re-anchor, tooltip content
  replacement, protected attribute edits, OnHide timers or frame scans.
- Clicked chat-item link windows (ItemRefTooltip) stay visible by design.
- Own player castbar still available in Mini (HF26.20.6), target bar and native
  HUD still hidden. Smart Follow F1 and optional follower camera, Buff Overview,
  and five-person Baganator ALT-hover Party Pawn logic unchanged.

Ingame acceptance:
1. Click desktop HaploBox UPDATE then STATUS.cmd should show HF26.20.7.
2. /reload, start in Main, ALT hover an item in Baganator: five Party Pawn
   rows should be stable and their original alignment intact.
3. Switch Mini. Hover world unit or bag item (including ALT): no native
   mouseover tooltip or item comparison window. Player castbar still shows
   while casting; Mini HP remains unchanged. Clicked item links remain usable.
4. Return Main. Hover the same item: tooltip and Party Pawn must reappear,
   without flicker. Repeat Main/Mini several times and in combat.
5. Report the exact tooltip and /fstack if any different custom addon tooltip
   remains visible; this fix targets only the native Blizzard tooltip family.

WARNING: WoW client test is required; this archive is not ingame approved.

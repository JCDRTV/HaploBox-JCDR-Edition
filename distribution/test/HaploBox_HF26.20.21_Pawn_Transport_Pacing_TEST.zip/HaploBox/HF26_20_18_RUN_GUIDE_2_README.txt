HaploBox HF26.20.18 — Dungeon Run Guide 2.0 TEST
Base: HF26.20.17 preserved. Changes restricted to LootPlanner.lua and version metadata.

- Dungeon Run Guide /hbrun width 344px (previous 444), can collapse to 32px titlebar, stays draggable and remembers existing position. First open docks near right screen edge.
- Header displays STEALTH/NORMAL + live ACTIVE time when started, includes PAUSE/RESUME even in collapsed mode, plus expand/close.
- Body START STEALTH / START NORMAL, PAUSE / RESUME, FINISH, CANCEL and RUNS history. START is always manual.
- Active time stops on PAUSE; total wall clock continues, both saved in HaploBoxDB. Runs are per dungeon/mode and list last 8; best active times computed per mode, per dungeon. FINISH saves; CANCEL discards; history retains latest 120.
- Uses GetServerTime/time; timer persists even if the guide is hidden or /reload is used. Only visible UI drives 0.45s redraw, no network activity or background worker.
- Cannot change dungeon while a timed run is active; manual boss reset never changes timer/history.
- Whole-% display matches Pawn tooltip rounding (+2011.5% -> +2012%). Pawn calculations, loot sources, confidence checks and actual percentages are NOT modified.
- Scan, boss route, loot rows, expanded items, item tooltip, per-boss completion and focused scan preserved.
- No Mini UI, Smart Follow, F1, MiniHeal, Party Pawn, original Professions tooltip, Macro Menu or bindings changed.

INGAME ACCEPTANCE (Mael): /hbrun, confirm right-side 344px, drag to Zygor slot, collapse to titlebar. Start STEALTH, collapse, confirm active time increases; use || in collapsed mode to PAUSE, confirm active time freezes; resume, FINISH, RUNS history. Start NORMAL, pause, /reload, resume, finish; verify per-mode history and best. Repeat with SCAN DUNGEON and check boss expansion, tooltips, CHECK/STALE and rounding. Close/reopen window while active and confirm elapsed correct. Confirm RESET BOSSES doesn't reset timer. All status remains TEST until real WoW verified.

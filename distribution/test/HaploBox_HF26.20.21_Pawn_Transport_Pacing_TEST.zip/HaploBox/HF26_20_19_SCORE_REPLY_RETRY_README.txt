HaploBox HF26.20.19 — Score Confidence & Reply Retry TEST
Base: HF26.20.18 Dungeon Run Guide 2.0. New separate TEST build; no auto-update.

TARGETED CHANGES
- Official PawnIsItemAnUpgrade percent values (source PAWN_UI) are no longer rejected solely for exceeding the conservative 300% manual weapon threshold in the per-boss audit. The finite true-empty-slot sentinel is already handled by the existing evaluator; invalid/untrusted values remain CHECK. Official high scores (such as +2012% or +4962%) may now pass IF every boss item / every Druid has valid data.
- The same source-aware guard is used for future gear recommendations, preventing a >300% official Pawn percentage from being silently filtered.
- First-wave request interval = 0.22s (previous 0.18s), final response grace = 1.8s (previous 1.25s).
- On-demand per-dungeon scan retries EVERY still-unanswered (itemID, follower) individually for up to TWO finite rounds; at the start of each round, only current missing pairs are queued, and already completed pairs are skipped. No fixed 12-pair cap, no unlimited retries, no background polling.
- Missing or delayed answers remain CHECK / INCOMPLETE. Local Mael is never sent a network retry; true VERIFY WEAPON PAIR remains strict and unchanged.
- /hblootnet diag on Mael now reports: applied/duplicate/old-scan/unexpected/late-cache replies, targeted retry totals, and per-selected-scan retry rounds/sent/failed/skipped/still-missing. Counts are cumulative per login except the selected scan figures.

NOT CHANGED
- Compact Run Guide layout/collapse state and Stealth/Normal timer, pause/resume, history, SavedVariables.
- Pawn scales and score math; Party Pawn, LootHover, Blizzard Professions tooltip; AtlasLoot drops.
- Mini UI, MiniHeal tooltip suppression, Smart Follow/F1, Macro Menu, Quick Menu and bindings.

INGAME VALIDATION
- Install via existing manual HaploBox UPDATE, /reload on all five Team A Druids.
- On Mael open /hbrun, select Wailing Caverns, SCAN THIS DUNGEON; after it finishes, /hbrunaudit and /hblootnet diag.
- Lady Anacondra high official Pawn scores should not by themselves force VERIFY SCORE; other incomplete items may still produce CHECK.
- Compare Mutanus Slime-encrusted Pads #6461 on Lyra (NOUP) and Nyra (+4962% official Pawn) and ensure unmatched responses are not silently certified.
- Confirm weapon-pair review (Pythas/Skum) remains CHECK unless proven.
- Confirm compact collapse, timer start/pause/resume/finish, /reload persistence and unchanged macro/UI behavior.

OFFLINE VALIDATION DOES NOT CERTIFY INGAME ACCEPTANCE.

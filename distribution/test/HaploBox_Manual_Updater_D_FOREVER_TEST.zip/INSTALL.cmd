@echo off
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -STA -File "%~dp0HaploBox-Install-Updater.ps1"
if errorlevel 1 (
    echo.
    echo Installatie niet volledig gelukt. Lees de melding hierboven.
    pause
    exit /b 1
)
echo.
echo Klaar. Klik vanaf nu op HaploBox UPDATE op je bureaublad.
pause

# HaploBox TEST updater, explicit user-driven updates only (NO polling or background task).
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
$Base = Join-Path $env:LOCALAPPDATA 'HaploBoxUpdater'
$UpSrc = Join-Path $PSScriptRoot 'HaploBox-Updater.ps1'
$CmdSrc = Join-Path $PSScriptRoot 'UPDATE.cmd'
$UpDest = Join-Path $Base 'HaploBox-Updater.ps1'
$CmdDest = Join-Path $Base 'UPDATE.cmd'
$ConfigPath = Join-Path $Base 'config.json'
$ManifestUrl = 'https://raw.githubusercontent.com/JCDRTV/HaploBox-JCDR-Edition/main/distribution/test/manifest.json'
$PreferredAddons = 'D:\World of Warcraft\_forever_\Interface\AddOns'
$OldTaskName = 'HaploBox Auto Updater TEST'

try {
    if (-not (Test-Path -LiteralPath $UpSrc -PathType Leaf)) { throw 'Updaterbestand ontbreekt naast INSTALL.cmd.' }
    if (-not (Test-Path -LiteralPath $CmdSrc -PathType Leaf)) { throw 'UPDATE.cmd ontbreekt naast INSTALL.cmd.' }
    New-Item -ItemType Directory -Path $Base -Force | Out-Null
    $addons = $null
    if (Test-Path -LiteralPath $PreferredAddons -PathType Container) {
        $addons = $PreferredAddons
        Write-Host "Geconfigureerde WoW-map gevonden: $addons" -ForegroundColor Green
    }
    if (-not $addons -and (Test-Path -LiteralPath $ConfigPath -PathType Leaf)) {
        try {
            $previous = Get-Content -LiteralPath $ConfigPath -Raw | ConvertFrom-Json
            if ((Test-Path -LiteralPath $previous.addons_path -PathType Container) -and ((Split-Path $previous.addons_path -Leaf) -ieq 'AddOns')) {
                $addons = [string]$previous.addons_path
                Write-Host "Bestaande WoW-map hergebruiken: $addons"
            }
        } catch { $addons = $null }
    }
    if (-not $addons) {
        Add-Type -AssemblyName System.Windows.Forms
        $dialog = New-Object System.Windows.Forms.FolderBrowserDialog
        $dialog.Description = 'Kies jouw ENIGE WoW-map Interface\AddOns (niet HaploBox).'
        $dialog.ShowNewFolderButton = $false
        $result = $dialog.ShowDialog()
        if ($result -ne [System.Windows.Forms.DialogResult]::OK) { throw 'Geen map gekozen. Er is niets gewijzigd.' }
        $selected = $dialog.SelectedPath
        if ((Split-Path $selected -Leaf) -ieq 'AddOns') {
            $addons = $selected
        } else {
            $found = @()
            foreach ($rel in @('Interface\AddOns','_classic_era_\Interface\AddOns','_classic_\Interface\AddOns','_retail_\Interface\AddOns')) {
                $p = Join-Path $selected $rel
                if (Test-Path -LiteralPath $p -PathType Container) { $found += $p }
            }
            if ($found.Count -eq 1) { $addons = $found[0] }
            else { throw 'Selecteer de exacte Interface\AddOns-map.' }
        }
    }
    $addons = (Resolve-Path -LiteralPath $addons).ProviderPath
    if ((Split-Path $addons -Leaf) -ine 'AddOns') { throw 'Geen geldige Interface\AddOns-map.' }

    # If an older auto-check version was ever installed, disable it completely.
    $existingTask = $false
    try {
        & schtasks.exe /Query /TN $OldTaskName 2>$null | Out-Null
        $existingTask = ($LASTEXITCODE -eq 0)
    } catch { $existingTask = $false }
    if ($existingTask) {
        & schtasks.exe /Delete /F /TN $OldTaskName | Out-Null
        if ($LASTEXITCODE -ne 0) { throw 'Oude geplande taak kon niet worden verwijderd. Verwijder eerst HaploBox Auto Updater TEST uit Taakplanner.' }
        Write-Host 'Oude automatische controle uit Windows Taakplanner verwijderd.' -ForegroundColor Yellow
    }

    Copy-Item -LiteralPath $UpSrc -Destination $UpDest -Force
    Copy-Item -LiteralPath $CmdSrc -Destination $CmdDest -Force
    [ordered]@{ addons_path=$addons; channel='test'; manifest_url=$ManifestUrl } |
        ConvertTo-Json | Set-Content -LiteralPath $ConfigPath -Encoding UTF8

    # Desktop shortcut is just a link to the manual UPDATE button; it runs nothing itself.
    $desktop = [Environment]::GetFolderPath('Desktop')
    if (-not [string]::IsNullOrWhiteSpace($desktop) -and (Test-Path -LiteralPath $desktop -PathType Container)) {
        $shortcutPath = Join-Path $desktop 'HaploBox UPDATE.lnk'
        $shell = New-Object -ComObject WScript.Shell
        $shortcut = $shell.CreateShortcut($shortcutPath)
        $shortcut.TargetPath = $CmdDest
        $shortcut.WorkingDirectory = $Base
        $shortcut.Description = 'Klik om de nieuwste HaploBox TEST build van GitHub te installeren'
        $shortcut.Save()
        Write-Host "Snelkoppeling op bureaublad: $shortcutPath"
    } else {
        Write-Host "Geen bureaublad gevonden. Gebruik: $CmdDest"
    }
    Write-Host ''
    Write-Host 'KLAAR: Geen achtergrondproces, geen automatische controles.' -ForegroundColor Green
    Write-Host 'Klik zelf op HaploBox UPDATE of UPDATE.cmd om GitHub te controleren en eventueel bij te werken.'
    Write-Host 'Bij een update op alle vijf clients /reload (zo nodig WoW opnieuw starten).'
    Write-Host ('AddOns-map: ' + $addons)
    Write-Host ('Log/backups: ' + $Base)
} catch {
    Write-Host ('INSTALLATIEFOUT: ' + $_.Exception.Message) -ForegroundColor Red
    Write-Host ('Details: ' + (Join-Path $Base 'updater.log'))
    exit 1
}

HAPLOBOX - HANDMATIGE UPDATER - TEST
===================================
Een WoW-installatie met vijf clients. GEEN automatische controle.

GitHub: https://github.com/JCDRTV/HaploBox-JCDR-Edition
Doel: D:\World of Warcraft\_forever_\Interface\AddOns\HaploBox

EENMALIG INSTALLEREN:
1. Pak de volledige ZIP uit naar een gewone Windows-map.
2. Dubbelklik INSTALL.cmd.
3. De installer kiest je bestaande D:\...\Interface\AddOns-map.
   Alleen als die niet bestaat vraagt hij om een map.
4. Op je bureaublad komt de snelkoppeling 'HaploBox UPDATE'.
5. De installer downloadt NIETS en installeert nog GEEN nieuwe addon.
   Ook worden er GEEN geplande taken of achtergrondprocessen gemaakt.
   Een eventuele oude taak 'HaploBox Auto Updater TEST' wordt verwijderd.

ELKE VOLGENDE VERSIE (OOK DE EERSTE HF26.17):
1. Wij bouwen een TEST-ZIP en publiceren een nieuw manifest op GitHub.
2. Jij dubbelklikt op 'HaploBox UPDATE' op je bureaublad.
   Of start UPDATE.cmd in de uitgepakte updatermap.
3. Pas op dat moment controleert de updater GitHub op de nieuwste TEST-versie.
4. Als nodig downloadt en verifieert hij de ZIP (SHA-256), maakt een
   volledige backup van HaploBox en vervangt die in je ene AddOns-map.
5. Daarna doe je in alle vijf WoW-clients /reload.
   Bij sommige TOC/structuurwijzigingen kan een WoW-herstart nodig zijn.

VEILIGHEID:
- Alleen de HaploBox-addonfolder wordt vervangen; WTF/SavedVariables blijven.
- Backups in %%LOCALAPPDATA%%\HaploBoxUpdater\Backups.
- Update voert geen eindeloze achtergrondmonitor of autoscans uit.
- Alleen TEST; STABLE wordt nooit automatisch gepromoveerd.
- STATUS.cmd toont de huidige versie en recente log.
- Sluit WoW voor de allereerste update; daarna kan /reload meestal volstaan.
- Echte Windows-installatie is nog niet getest: meld eventuele foutmelding.

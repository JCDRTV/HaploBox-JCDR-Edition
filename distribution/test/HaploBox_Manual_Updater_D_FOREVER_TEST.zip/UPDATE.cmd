@echo off
set "SCRIPT=%LOCALAPPDATA%\HaploBoxUpdater\HaploBox-Updater.ps1"
if not exist "%SCRIPT%" (
    echo HaploBox Updater is nog niet ingericht. Start eerst INSTALL.cmd.
    pause
    exit /b 1
)
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT%"
if errorlevel 1 (
    echo.
    echo Update mislukt. Log: %%LOCALAPPDATA%%\HaploBoxUpdater\updater.log
    pause
    exit /b 1
)
echo.
echo Klaar. Als er nieuwe addonbestanden zijn: /reload op alle vijf clients.
pause

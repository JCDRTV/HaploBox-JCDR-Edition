HF26.20.40 TEST — Proportional scrollbar + icon headers

Exact base: HF26.20.39 Clean Dungeon UI TEST.

All 4 existing scrollbars now display native up/down arrow buttons, one visible row per click, and a proportional thumb that becomes taller when a larger fraction of the list is in view. Keep wheel scrolling and direct dragging. No scrollbar when content fully fits. Thumb adapts to window resizing; arrows remain within the scrollbar bounds.

Dungeon Advisor columns: replace UNI and Score text headers with diamond/priority-star icons aligned to numerical columns. Keep Dungeon heading, Tank/Healer/DPS role icons, all values, and RUN buttons. Remove provisional question-mark suffix from numerical scores; provisional numbers remain amber and diagnostics retain full status.

No priority calculation, Pawn Forever scale, data acquisition, network batching, manual/automatic update behavior, weapon-set hotkeys, macros, Quick Menu, Dungeon Run boss logic, or other modules changed.

Offline verified and awaiting user ingame PASS. Manual HaploBox UPDATE only.

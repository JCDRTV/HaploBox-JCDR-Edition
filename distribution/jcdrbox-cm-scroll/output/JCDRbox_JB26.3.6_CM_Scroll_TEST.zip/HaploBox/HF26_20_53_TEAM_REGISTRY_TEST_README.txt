HF26.20.53 TEST - TEAM-01
Central GUID character registry; current party signature independent of leader; own and trusted team specialization announcements; read-only API and /hb registry diagnostic. Existing UI unchanged. Unknown specs remain unknown. Ingame acceptance OPEN. Lua runtime verification pending.

-- HF25: HaploBox AtlasLoot + Pawn bridge, isolated from Follow/BoxMode/Macros.
-- This is an EXPLICIT /hb loot UI. No continuous scans or gear broadcasts.
local HB = HaploBox
local PREFIX = "HBLoot25"
local names = {"Mael", "Lyra", "Elya", "Nyra", "Ayla"}
local roster = {Mael=true, Lyra=true, Elya=true, Nyra=true, Ayla=true}
local wanted = {Mael="feral", Lyra="restoration", Elya="balance", Nyra="balance", Ayla="balance"}
local module = "AtlasLootClassic_DungeonsAndRaids"
local view, dungeonRows, bossRows, lootRows, partyRows = nil, {}, {}, {}, {}
local dungeons, bosses, drops = {}, {}, {}
local di, bi, ii, dp, bp, ip = nil, nil, nil, 1, 1, 1
local requestSeq = 0
local hoveredItem, hoverActive = nil, false
local result = {}
local selectedID = nil
local statusLabel, scaleLabel, selectedLabel, pageLabel
local btns = {}

local function who(s) return (type(s)=="string" and s:match("^[^-]+") or "") end
local function me() return who(UnitName("player")) end
local function out(s) print("|cff77c7ffHaploBox Loot:|r "..tostring(s)) end
local function short(s,n) s=tostring(s or ""); if #s>n then return s:sub(1,n-3).."..." end; return s end
local function addonReady()
    return type(PawnGetItemData)=="function" and type(PawnGetSingleValueFromItem)=="function"
        and type(PawnCommon)=="table" and type(PawnCommon.Scales)=="table"
end
local function scales()
    if not addonReady() then return {} end
    local t={}
    for k,v in pairs(PawnCommon.Scales) do
        if type(k)=="string" and type(v)=="table" and type(v.Values)=="table" then t[#t+1]=k end
    end
    table.sort(t)
    return t
end
local function scale()
    if not addonReady() then return nil end
    local db=HB.db
    if db and db.lootAdvisorScale and PawnCommon.Scales[db.lootAdvisorScale] then return db.lootAdvisorScale end
    local goal=wanted[me()]
    if not goal then return nil end
    local matches={}
    for _,s in ipairs(scales()) do
        local l=s:lower()
        if l:find("druid",1,true) and l:find(goal,1,true) then matches[#matches+1]=s end
    end
    if #matches==1 then return matches[1] end
    return nil -- ambiguous or absent: NEVER silently choose a wrong scale
end
-- Forever's client has C_Item.GetItemInfo, but may have no global GetItemInfo.
-- Pawn itself uses C_Item.GetItemInfo.  Avoid invoking a nil legacy global.
local function itemInfo(key)
    local fn = C_Item and C_Item.GetItemInfo
    if type(fn) ~= "function" then fn = _G.GetItemInfo end
    if type(fn) ~= "function" then return nil end
    local ok, a,b,c,d,e,f,g,h,i = pcall(fn,key)
    if ok then return a,b,c,d,e,f,g,h,i end
    return nil
end
local function equipLoc(key)
    local typ=select(9,itemInfo(key))
    if typ and typ~="" then return typ end
    local fn=C_Item and C_Item.GetItemInfoInstant
    if type(fn)=="function" then
        local ok,_,_,_,location=pcall(fn,key)
        if ok then return location end
    end
    return nil
end
local function itemLink(id)
    if not id or not tonumber(id) then return nil end
    local _,link=itemInfo(tonumber(id))
    if link then return link end
    -- Request cache hydration once on selection/hover; never invent a Pawn score.
    local loader=C_Item and C_Item.RequestLoadItemDataByID
    if type(loader)=="function" then pcall(loader,tonumber(id)) end
    return nil
end
local function pawnValue(link,scaleName)
    if not link then return nil end
    local ok, item=pcall(PawnGetItemData,link)
    if not ok or not item or not item.Stats then return nil end
    local yes,val=pcall(PawnGetSingleValueFromItem,item,scaleName)
    if not yes or type(val)~="number" then return nil end
    return val,item
end
local function pawnEquipped(slot,s)
    local link=GetInventoryItemLink("player",slot)
    if not link then return 0 end
    local v=pawnValue(link,s)
    return v -- nil means uncached equipped item, NOT a zero score
end
local function evaluate(id)
    if not addonReady() then return "NO PAWN" end
    local s=scale()
    if not s then return "SET SCALE" end
    local link=itemLink(id)
    if not link then return "UNCACHED" end
    local new,item=pawnValue(link,s)
    if not new then return "NO STATS" end
    local inv=item.InvType or equipLoc(link)
    if not inv then return "NO SLOT" end
    local slots={INVTYPE_HEAD={1},INVTYPE_NECK={2},INVTYPE_SHOULDER={3},INVTYPE_BODY={4},
        INVTYPE_CHEST={5},INVTYPE_ROBE={5},INVTYPE_WAIST={6},INVTYPE_LEGS={7},
        INVTYPE_FEET={8},INVTYPE_WRIST={9},INVTYPE_HAND={10},INVTYPE_FINGER={11,12},
        INVTYPE_TRINKET={13,14},INVTYPE_CLOAK={15},INVTYPE_2HWEAPON={16},
        INVTYPE_WEAPONMAINHAND={16},INVTYPE_WEAPON={16},INVTYPE_HOLDABLE={17},
        INVTYPE_SHIELD={17},INVTYPE_WEAPONOFFHAND={17},INVTYPE_RANGED={18},
        INVTYPE_RANGEDRIGHT={18},INVTYPE_RELIC={18},INVTYPE_THROWN={18}}
    local ss=slots[inv]; if not ss then return "SKIP SLOT" end
    local base
    if inv=="INVTYPE_2HWEAPON" then
        local mh,oh=pawnEquipped(16,s),pawnEquipped(17,s)
        if mh==nil or oh==nil then return "UNCACHED GEAR" end
        base=mh+oh -- correctly compare the COMPLETE current weapon set
    elseif inv=="INVTYPE_HOLDABLE" or inv=="INVTYPE_SHIELD" or inv=="INVTYPE_WEAPONOFFHAND" then
        local mhlink=GetInventoryItemLink("player",16)
        local mhType=mhlink and equipLoc(mhlink)
        if mhType=="INVTYPE_2HWEAPON" then return "NEEDS 1H" end
        base=pawnEquipped(17,s)
    elseif inv=="INVTYPE_WEAPONMAINHAND" or inv=="INVTYPE_WEAPON" then
        -- If currently wearing a 2H, a new 1H must beat the 2H alone;
        -- never invent an offhand that this character does not own.
        local mhlink=GetInventoryItemLink("player",16)
        local mhType=mhlink and equipLoc(mhlink)
        if mhType=="INVTYPE_2HWEAPON" then
            local mh,oh=pawnEquipped(16,s),pawnEquipped(17,s)
            if mh==nil or oh==nil then return "UNCACHED GEAR" end
            base=mh+oh
        else base=pawnEquipped(16,s) end
    elseif #ss==2 then
        local x,y=pawnEquipped(ss[1],s),pawnEquipped(ss[2],s)
        if x==nil or y==nil then return "UNCACHED GEAR" end
        base=math.min(x,y) -- replace weaker equipped ring or trinket
    else base=pawnEquipped(ss[1],s) end
    if base==nil then return "UNCACHED GEAR" end
    if new<=base then return "NO UPGRADE",0 end
    if base<=0 then return "NEW SLOT" end
    return "UPGRADE",(new-base)/base*100
end

local function initAtlas()
    if not _G.AtlasLoot or not AtlasLoot.ItemDB then return false,"AtlasLoot core not loaded" end
    local db=AtlasLoot.ItemDB
    if not db:Get(module) then
        if InCombatLockdown and InCombatLockdown() then return false,"Open outside combat" end
        local loader=C_AddOns and C_AddOns.LoadAddOn or _G.LoadAddOn
        if type(loader)=="function" then pcall(loader,module) end
    end
    if not db:Get(module) then return false,"AtlasLoot dungeon module unavailable" end
    return true
end
local function scanDungeons()
    wipe(dungeons)
    local ok,msg=initAtlas()
    if not ok then return false,msg end
    local db=AtlasLoot.ItemDB:Get(module)
    for key,d in pairs(db) do
        if type(key)=="string" and type(d)=="table" and type(d.items)=="table"
            and type(d.LevelRange)=="table" and #d.LevelRange>=2
            and not d.ExtraList then
            dungeons[#dungeons+1]={id=key,name=d.name or key,ref=d,range=d.LevelRange}
        end
    end
    table.sort(dungeons,function(a,b)
        local aa=tonumber(a.range[2]) or tonumber(a.range[1]) or 0
        local bb=tonumber(b.range[2]) or tonumber(b.range[1]) or 0
        if aa==bb then return a.id<b.id end
        return aa<bb
    end)
    return true
end
local function scanBosses()
    wipe(bosses)
    if not dungeons[di] then return end
    local d=dungeons[di].ref
    for idx,b in ipairs(d.items) do
        if type(b)=="table" and not b.link then
            bosses[#bosses+1]={idx=idx,name=b.name or ("Boss "..idx),ref=b}
        end
    end
end
local function scanDrops()
    wipe(drops)
    if not (dungeons[di] and bosses[bi]) then return end
    local db=AtlasLoot.ItemDB
    local d=dungeons[di].ref
    local diff=d.LoadDifficulty or 1
    local success,rows=pcall(db.GetItemTable,db,module,dungeons[di].id,bosses[bi].idx,diff)
    if not success or type(rows)~="table" then
        rows=bosses[bi].ref[diff]
    end
    if type(rows)~="table" then return end
    local seen={}
    for _,row in ipairs(rows) do
        local id=type(row)=="table" and tonumber(row[2])
        if id and id>0 and not seen[id] then
            drops[#drops+1]={id=id};seen[id]=true
        end
    end
end
local function present(status,delta)
    if status=="UPGRADE" and type(delta)=="number" then return string.format("+%.1f%%",delta) end
    if status=="NO UPGRADE" then return "0%" end
    return status or "..."
end
local function updateParty()
    if not view then return end
    for i,name in ipairs(names) do
        local r=result[name]
        partyRows[i]:SetText(name.."   "..(r and present(r[1],r[2]) or "not checked"))
    end
end
local function setStatus(s) if statusLabel then statusLabel:SetText(short(s,115)) end end
local function refreshSelection()
    if not view then return end
    local d=drops[ii]
    local item=d and d.id or nil
    selectedID=item
    local name=item and (itemInfo(item) or ("item:"..item)) or "Select an item"
    selectedLabel:SetText(short(name,46))
    local s=scale()
    scaleLabel:SetText(short(s or (addonReady() and "CHOOSE PAWN SCALE" or "PAWN MISSING"),50))
    updateParty()
end
local function sendCheck(id)
    if not id then return end
    requestSeq=requestSeq+1
    selectedID=id
    wipe(result)
    result[me()]={evaluate(id)}
    updateParty()
    if me()~="Mael" then setStatus("Party checks are requested from Mael's window") return end
    if not (IsInGroup and IsInGroup()) then setStatus("Solo: local Pawn score only") return end
    if not C_ChatInfo or not C_ChatInfo.SendAddonMessage then setStatus("Addon messages unavailable") return end
    local msg=string.format("Q|%d|%d",requestSeq,id)
    local ok,err=pcall(C_ChatInfo.SendAddonMessage,PREFIX,msg,"PARTY")
    if not ok then setStatus("Addon send failed: "..tostring(err));return end
    setStatus("Request #"..requestSeq.." sent; no polling or result cache")
end
-- Only ALT+hover sends a network request. A click selects locally.
local function beginHover(id)
    if me()~="Mael" or type(IsAltKeyDown)~="function" or not IsAltKeyDown() then return end
    if hoverActive and hoveredItem==id then return end
    hoveredItem,hoverActive=id,true
    sendCheck(id)
end
local function endHover()
    hoveredItem,hoverActive=nil,false
    wipe(result)
    updateParty()
end
local function mkText(parent,label,x,y,w,size)
    local t=parent:CreateFontString(nil,"OVERLAY",size or "GameFontNormalSmall")
    t:SetPoint("TOPLEFT",parent,"TOPLEFT",x,y);t:SetWidth(w);t:SetJustifyH("LEFT");t:SetText(label)
    return t
end
local function mkButton(parent,label,x,y,w,h,cb)
    local b=CreateFrame("Button",nil,parent,"UIPanelButtonTemplate")
    b:SetSize(w,h);b:SetPoint("TOPLEFT",parent,"TOPLEFT",x,y);b:SetText(label)
    b:SetScript("OnClick",cb);return b
end
local function refresh()
    if not view then return end
    for n,b in ipairs(dungeonRows) do
        local d=dungeons[dp+n-1]
        b:Show()
        if d then
            local rng=d.range
            local nm=short(d.name,29)
            b:SetText(nm.." ["..tostring(rng[1] or "?").."-"..tostring(rng[3] or rng[2] or "?").."]")
            b:SetEnabled(true)
        else b:SetText("");b:SetEnabled(false) end
    end
    for n,b in ipairs(bossRows) do
        local bo=bosses[bp+n-1]
        b:Show();b:SetEnabled(not not bo);b:SetText(bo and short(bo.name,26) or "")
    end
    for n,b in ipairs(lootRows) do
        local entry=drops[ip+n-1]
        b:Show();b:SetEnabled(not not entry)
        local nm=entry and (itemInfo(entry.id) or "item:"..entry.id) or ""
        b:SetText(short(nm,37))
        b.HBLootID=entry and entry.id or nil
        if entry then
            b:SetScript("OnEnter",function(self)
                if GameTooltip then
                    GameTooltip:SetOwner(self,"ANCHOR_RIGHT")
                    pcall(GameTooltip.SetHyperlink,GameTooltip,"item:"..entry.id)
                    GameTooltip:Show()
                end
                beginHover(entry.id)
            end)
        else b:SetScript("OnEnter",nil) end
        b:SetScript("OnLeave",function()
            if GameTooltip then GameTooltip:Hide() end
            endHover()
        end)
    end
    pageLabel:SetText(string.format("Dungeon %d / %d    Boss %d / %d    Item %d / %d",
        math.min(dp,#dungeons),#dungeons,math.min(bp,#bosses),#bosses,math.min(ip,#drops),#drops))
    refreshSelection()
end
local function chooseDungeon(index)
    di=index;bi=nil;ii=nil;bp=1;ip=1;wipe(result);scanBosses();scanDrops();refresh()
end
local function chooseBoss(index)
    bi=index;ii=nil;ip=1;wipe(result);scanDrops();refresh()
end
local function chooseItem(index)
    ii=index;wipe(result);refresh() -- Select only; ALT+hover requests live party scores
end
local function makeUI()
    view=CreateFrame("Frame","HaploBoxLootAdvisorHF25",UIParent,"BackdropTemplate")
    view:SetSize(880,524);view:SetPoint("CENTER",UIParent,"CENTER",0,0)
    view:SetFrameStrata("DIALOG");view:EnableMouse(true);view:SetMovable(true);view:RegisterForDrag("LeftButton")
    view:SetScript("OnDragStart",function(self) self:StartMoving() end)
    view:SetScript("OnDragStop",function(self) self:StopMovingOrSizing() end)
    view:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",edgeFile="Interface\\Tooltips\\UI-Tooltip-Border",edgeSize=13,insets={left=4,right=4,top=4,bottom=4}})
    view:SetBackdropColor(0.024,0.051,0.082,.97)
    mkText(view,"HAPLOBOX ATLASLOOT   |cff9ac8ffHF25 BRIDGE TEST|r",15,-13,700,"GameFontNormalLarge")
    mkButton(view,"X",842,-10,25,22,function() endHover();view:Hide() end)
    mkText(view,"DUNGEONS",16,-52,265)
    mkText(view,"BOSSES",313,-52,250)
    mkText(view,"DROPS",602,-52,255)
    for n=1,11 do
        dungeonRows[n]=mkButton(view,"",12,-70-(n-1)*32,277,28,function() if dungeons[dp+n-1] then chooseDungeon(dp+n-1) end end)
        bossRows[n]=mkButton(view,"",305,-70-(n-1)*32,275,28,function() if bosses[bp+n-1] then chooseBoss(bp+n-1) end end)
        lootRows[n]=mkButton(view,"",595,-70-(n-1)*32,274,28,function() if drops[ip+n-1] then chooseItem(ip+n-1) end end)
    end
    mkButton(view,"<",14,-424,32,24,function() dp=math.max(1,dp-11);refresh() end)
    mkButton(view,">",53,-424,32,24,function() dp=math.min(math.max(1,#dungeons-10),dp+11);refresh() end)
    mkButton(view,"<",305,-424,32,24,function() bp=math.max(1,bp-11);refresh() end)
    mkButton(view,">",344,-424,32,24,function() bp=math.min(math.max(1,#bosses-10),bp+11);refresh() end)
    mkButton(view,"<",595,-424,32,24,function() ip=math.max(1,ip-11);refresh() end)
    mkButton(view,">",634,-424,32,24,function() ip=math.min(math.max(1,#drops-10),ip+11);refresh() end)
    pageLabel=mkText(view,"",16,-457,550)
    statusLabel=mkText(view,"",16,-482,850)
    -- Scores are shown in a small independent window to avoid making dropdown lists microscopic.
    local side=CreateFrame("Frame","HaploBoxLootPawnHF25",view,"BackdropTemplate")
    side:SetSize(272,221);side:SetPoint("TOPLEFT",view,"TOPRIGHT",5,-48)
    side:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",edgeFile="Interface\\Tooltips\\UI-Tooltip-Border",edgeSize=12,insets={left=3,right=3,top=3,bottom=3}})
    side:SetBackdropColor(0.063,0.137,0.196,.97)
    mkText(side,"PAWN PARTY CHECK",12,-12,250,"GameFontNormal")
    selectedLabel=mkText(side,"Select item",12,-33,248)
    for i=1,5 do partyRows[i]=mkText(side,names[i].."  -",12,-54-(i-1)*21,248) end
    scaleLabel=mkText(side,"CHOOSE PAWN SCALE",12,-164,248)
    mkButton(side,"Change Pawn Scale",10,-184,245,27,function()
        if not HB.db then return end
        local all=scales()
        if #all==0 then out("Pawn not loaded") return end
        local current=scale();local idx=0
        for i,s in ipairs(all) do if s==current then idx=i end end
        HB.db.lootAdvisorScale=all[idx%#all+1]
        wipe(result);refreshSelection();out("Pawn scale: "..HB.db.lootAdvisorScale)
    end)
    view.side=side
    view:SetScript("OnShow",function()
        local ok,msg=scanDungeons()
        if not ok then setStatus(msg);wipe(bosses);wipe(drops) else setStatus("ALT + hover on an item: compare party gear on demand") end
        dp=1;bp=1;ip=1;di=nil;bi=nil;ii=nil;wipe(result);refresh()
    end)
    view:Hide()
end
function HB.ToggleLootAdvisor()
    if not view then makeUI() end
    if view:IsShown() then endHover();view:Hide() else view:Show() end
end
local event=CreateFrame("Frame")
event:RegisterEvent("PLAYER_LOGIN")
event:RegisterEvent("CHAT_MSG_ADDON")
event:RegisterEvent("MODIFIER_STATE_CHANGED")
event:RegisterEvent("GET_ITEM_INFO_RECEIVED")
event:SetScript("OnEvent",function(_,e,prefix,msg,channel,sender)
    if e=="MODIFIER_STATE_CHANGED" then
        local key,down=prefix,msg
        if key=="LALT" or key=="RALT" then
            if down==0 and type(IsAltKeyDown)=="function" and not IsAltKeyDown() then
                endHover()
                if view and view:IsShown() then setStatus("ALT released; results hidden") end
            elseif down==1 and view and view:IsShown() then
                local focus
                if type(GetMouseFocus)=="function" then focus=GetMouseFocus() end
                if not focus and type(GetMouseFoci)=="function" then
                    local frames=GetMouseFoci()
                    focus=type(frames)=="table" and frames[1] or nil
                end
                if focus and focus.HBLootID then beginHover(focus.HBLootID) end
            end
        end
        return
    end
    if e=="GET_ITEM_INFO_RECEIVED" then
        if view and view:IsShown() then refresh() end -- Item names may populate asynchronously.
        return
    end
    if e=="PLAYER_LOGIN" then
        if C_ChatInfo and C_ChatInfo.RegisterAddonMessagePrefix then
            C_ChatInfo.RegisterAddonMessagePrefix(PREFIX)
        end
        return
    end
    if prefix~=PREFIX or channel~="PARTY" or type(msg)~="string" then return end
    if not IsInGroup or not IsInGroup() then return end
    local from=who(sender)
    if not roster[from] or not roster[me()] then return end
    local kind=msg:sub(1,2)
    if kind=="Q|" and from=="Mael" and me()~="Mael" then
        local seq,id=msg:match("^Q|(%d+)|(%d+)$")
        local qid=tonumber(id);local token=tonumber(seq)
        if not qid or not token or qid<1 or qid>2000000 then return end
        local st,v=evaluate(qid)
        local reply=string.format("R|%d|%d|%s|%.3f",token,qid,st or "ERROR",tonumber(v) or 0)
        if C_ChatInfo and C_ChatInfo.SendAddonMessage then C_ChatInfo.SendAddonMessage(PREFIX,reply,"PARTY") end
    elseif kind=="R|" and me()=="Mael" and view and view:IsShown() and from~="Mael" then
        local seq,id,status,delta=msg:match("^R|(%d+)|(%d+)|([%w%s]+)|([%d%.%-]+)$")
        if seq and tonumber(seq)==requestSeq and tonumber(id)==selectedID
            and hoverActive and type(IsAltKeyDown)=="function" and IsAltKeyDown() then
            result[from]={status,tonumber(delta)}
            updateParty()
        end
    end
end)

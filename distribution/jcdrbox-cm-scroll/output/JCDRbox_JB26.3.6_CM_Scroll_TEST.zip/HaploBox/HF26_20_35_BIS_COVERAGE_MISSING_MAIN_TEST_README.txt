HF26.20.35 TEST — BiS Coverage + Lyra Missing Main-Hand

Built from unmodified HF26.20.34 TEST distribution, not an unverified feature branch.

Fix: locking a 2H no longer marks all 1H/Off-Hand dungeon candidates LOCK_MISSING merely because the other optional 1H+OH set was never selected. Scoring of such candidates requires a usable carried partner or a verified complete 1H+OH pair from the same dungeon; individual 1H is never equated to a 2H.
Fix: when both sets exist, proposed full weapon sets compare against the STRONGER existing locked set.
Fix: the Dungeon BiS shortlist can include a verified same-dungeon 1H+OH pair as two linked farm targets, each labeled [PAIR], with explicit tooltip context. No auto-equips.
Fix: allow Forever Druid polearm subclass 6, with minimum level 20 prefilter/evaluation and hotkey guard. Pawn still controls item equip eligibility and score.
Diagnostic: /hbbiscoverage Lyra (or omit name for all five) prints counts for 2H, 1H, Off-Hand and rings, including UP/NOUP/NEEDPAIR/VERIFY/OWNED/UNCACHED and other statuses. Counts are only sent-to-Pawn items from completed dungeons; NOT an assertion that every world drop is covered. No new scan/network traffic.
Remaining known limitation: second independent ring/trinket target is not certified as a simultaneous upgrade by existing per-item Pawn replies. This build does NOT pretend two speculative ring upgrades are confirmed. Full pairwise ring/unique group optimization remains separate. 1H+OH pairs requiring two drops from DIFFERENT dungeons are not currently certified; coverage will reveal NEEDPAIR.

Protected: HF26.20.29 16-item batch and existing pacing; ALT-hover Party Pawn, Mini UI, Smart Follow, macros, Baganator marker and hotkeys, Quick Menu, Unique-Equipped OWNED guard, run timer and UI.

Offline: 32/32 Lua syntax PASS (texlua); 7 WeaponSets mock assertions PASS; 3 LootPlanner evaluation cases PASS; 2 same-dungeon pair cases PASS; 3 BiS target-builder cases PASS. ZIP CRC and byte-level unchanged-file checks PASS. INGAME ACCEPTANCE OPEN.
Manual UPDATE only. No automatic updates.

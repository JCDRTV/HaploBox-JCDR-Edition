HF26.20.31 COMPACT DUNGEON RUN TEST

Change: minimum Dungeon Run width from 470px to 350px. Drag lower-right resize grip; default 548px. Saved width persists after /reload. Responsive narrow header with S/N timer mode; all loot rows keep icon, truncated item, orange name, Pawn arrow and right aligned percent with no overlap. Boss check status and [x] remain visible. Dungeon Advisor minimum unchanged (820px).

SAFE: Does NOT alter batch scan protocol, Pawn calculations, boss filter, run timer mechanics, following, macros, Weapon Sets or Quick Menu.

INGAME ACCEPTANCE: Resize Run window to 350, 400, 548; check boss header and full-character loot rows, high percentages and active timer; reload and check saved width; change selected dungeon; Advisor still resizes independently.

HF26.20.41 — UI Polish TEST (built exclusively from HF26.20.40)

ADVISOR DUNGEON HEADERS
UNI: compact original popularity-style starburst; Score: upward rank arrow. Both are bundled WoW-compatible transparent TGA assets, visually echoing the user-selected Wowpedia mini icons; no dependency on remote media. Role headers, scoring and numeric columns unchanged.

SCROLLBARS
All 4 scrollable areas share a narrower 14px track with 10px proportional thumb and compact arrow buttons (one line/click), wheel and drag still enabled. Track and arrow images share the dark UI palette; no empty-scrollbar display.

VISIBLE RATINGS ONLY
Verified positive pawn scores: green +NN%. Empty equipment slot: yellow EMPTY (previously NEW). Known special-effects-only: yellow SPECIAL. Insufficient scan, stale/comparison ambiguity, unverified percentages: red UNVERIFIED with NO green candidate score or suffixed '?'. Boss verification labels also use UNVERIFIED instead of '?' codes. In-game diagnostics/chat commands retain the original low-level reasons including CACHE/NEEDPAIR/NOSTATS and all precise raw percentages, with no changes to data or score calculations. Future-level gear still shows its level restriction (never pretends to be a verified present upgrade).

Preserved: role-weighted unique item priority, standard Pawn Forever scales, HF26.20.29 batched scanner/pacing, network, Weapon Set hotkeys, Baganator, UI layout and navigation, run timer/history, macros, Quick Menu.

Offline verified; ingame PASS not granted. Only manual HaploBox UPDATE.

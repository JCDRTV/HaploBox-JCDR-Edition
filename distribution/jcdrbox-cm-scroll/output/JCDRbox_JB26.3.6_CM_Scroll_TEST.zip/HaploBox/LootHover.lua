-- HF26.20.12: Add Party Pawn inside Blizzard Professions item tooltips, no panel.
-- HF26.20.8: Modern WoW Forever TooltipDataProcessor + Baganator BGR bag-item detection.
-- HF26.20.5: Stop Baganator ALT hover flicker (no per-reply Show / OnHide resync loop).
-- HF26.16: Fixed UI columns: Need slot, five aligned Pawn arrows, percent right edge.
-- HF26.15: Stream-readable Pawn arrow / Need order; five-client inline hover.
-- HF26.14: Cache retry after item loading, bag weapon-pair results, inline Need dice.
-- HF26.13: Native-Pawn-look party rows, live level tags and conservative loot priority.
-- HF26.12: Party Pawn values are appended INSIDE the original item tooltip.
-- Every current Team A client can request five live results in original item tooltips.
-- Separate addon prefix keeps the stable dungeon scan and Box Mode protocols unchanged.
-- No passive equipment synchronization, no score caching between hover actions.
local HB=HaploBox
local PREFIX="HBHV15"
local ALL={"Mael","Lyra","Elya","Nyra","Ayla"}
local TEAM={Mael=true,Lyra=true,Elya=true,Nyra=true,Ayla=true}
local registered=false
local atlasHooked=false
local gameHooked=false
local modernHooked=false
local classicHooked=false
local showHooked=false
local tooltipLastDetection="NONE"
local INLINE_TITLE="HAPLO LOOT  |  PARTY PAWN"
-- Use the actual Pawn upgrade-arrow art instead of a tiny orange Blizzard
-- scrollbar button. Both textures are rendered at readable inline sizes.
-- Pawn is already required for all party evaluations; no new art is bundled.
-- Keep icons as real Tooltip textures: inline texture escapes move when the
-- adjacent percentage changes length. Five fixed arrow slots do not move.
local PAWN_ARROW_PATH="Interface\\AddOns\\Pawn\\Textures\\UpgradeArrow"
local NEED_DICE_PATH="Interface\\Buttons\\UI-GroupLoot-Dice-Up"
local ICON_SIZE=16
local PERCENT_WIDTH=70
local STATUS_WIDTH=120
local ICON_GAP=3
-- Reuse 5 pairs per tooltip. Repeated ALT hovers must not leak textures.
local iconPool=setmetatable({}, {__mode="k"})
local GREEN="|cff4de878"
local GREY="|cffabb5bf"
local RESET="|r"
local function round(x) return math.floor(x+0.5) end
local function tagColor(diff)
    if diff<=2 then return "|cffffff00" end
    if diff<=4 then return "|cffff8818" end
    return "|cffff5050"
end

local tooltipErrors=0
local serial=0
local session=nil
local pending={} -- retry requests keyed by requester + seq, one active per requester
local counters={sent=0,received=0,request=0,replied=0,failed=0,malformed=0}
local function who(raw)
    if type(raw)~="string" then return nil end
    local name=raw:match("^%s*(.-)%s*$")
    for _,first in ipairs(ALL) do
        if name==first or name:match("^"..first.."[%s%-]") then return first end
    end
end
local function me() return who(UnitName("player")) end
local function alt() return type(IsAltKeyDown)=="function" and IsAltKeyDown() end
local function tell(s) print("|cffd9b66eHaplo Loot Hover:|r "..tostring(s)) end
local function channel()
    if not (IsInGroup and IsInGroup()) then return nil end
    if type(LE_PARTY_CATEGORY_INSTANCE)=="number" and IsInGroup(LE_PARTY_CATEGORY_INSTANCE) then return "INSTANCE_CHAT" end
    if IsInRaid and IsInRaid() then return "RAID" end
    return "PARTY"
end
local function register()
    local f=C_ChatInfo and C_ChatInfo.RegisterAddonMessagePrefix
    if type(f)~="function" then return false end
    local ok,value=pcall(f,PREFIX)
    registered=ok and value~=false
    return registered
end
local function send(payload)
    local ch=channel()
    local f=C_ChatInfo and C_ChatInfo.SendAddonMessage
    if not ch or type(f)~="function" then counters.failed=counters.failed+1;return false end
    if not registered then register() end
    if not registered then counters.failed=counters.failed+1;return false end
    local ok,value=pcall(f,PREFIX,payload,ch)
    if not ok or value==false then counters.failed=counters.failed+1;return false end
    counters.sent=counters.sent+1
    return true
end
local function exactItemString(link,id)
    if type(link)=="string" then
        local v=link:match("(item:%d+[:%d%-]*)")
        if v and #v<=150 then return v end
    end
    return "item:"..tostring(id)
end
local function itemIDFromLink(link)
    if type(link)~="string" then return nil end
    local id=tonumber(link:match("item:(%d+)"))
    if id and id>0 and id<=3000000 then return id end
end
-- On-demand ownership check. Never search the bank or sync inventory in the
-- background; every client checks only its equipped slots and carried bags.
local function ownership(id)
    id=tonumber(id)
    if not id then return "-" end
    for slot=1,19 do
        local link=type(GetInventoryItemLink)=="function" and GetInventoryItemLink("player",slot)
        if type(link)=="string" and tonumber(link:match("item:(%d+)"))==id then return "E" end
    end
    local getCount=(C_Container and C_Container.GetContainerNumSlots) or _G.GetContainerNumSlots
    local getID=(C_Container and C_Container.GetContainerItemID) or _G.GetContainerItemID
    if type(getCount)=="function" and type(getID)=="function" then
        for bag=0,4 do
            local ok,n=pcall(getCount,bag)
            if ok and type(n)=="number" then
                for slot=1,n do
                    local yes,item=pcall(getID,bag,slot)
                    if yes and tonumber(item)==id then return "B" end
                end
            end
        end
    end
    return "-"
end
local function eval(id,exactLink)
    local method=HB.HaploLootEvaluateHoverItem or HB.HaploLootEvaluateItem
    if type(method)~="function" then return "VERIFY",-1,0,0,"NO_EVALUATOR",ownership(id) end
    local ok,code,pct,_,req,lvl,_,_,why=pcall(method,id,exactLink)
    if not ok then return "VERIFY",-1,0,0,"EVALUATE_ERROR",ownership(id) end
    if type(code)~="string" or not code:match("^[A-Z]+$") then
        return "VERIFY",-1,0,0,"INVALID_RESULT",ownership(id)
    end
    return code,tonumber(pct) or -1,tonumber(req) or 0,tonumber(lvl) or 0,why or "NONE",ownership(id)
end
-- The value column contains NO icons or suffixes. It ends at the identical
-- right edge for all five rows. Extra info goes with the name on the left.
-- Shared presentation vocabulary with Dungeon Advisor/Run.
-- A separate scan's provisional state never rewrites an individually verified
-- percentage; unchecked results never produce green percentages or dice.
local function pretty(entry,itemID)
    local code,pct,req,lvl,why,owned=entry.code,entry.pct,entry.req,entry.lvl,entry.why,entry.owned
    local value,note,upgrade
    local YELLOW="|cffffc459"
    local RED="|cffff595c"
    local special=(tonumber(itemID)==273820 and code=="NOSTATS"
        and (why=="NO_ITEM" or why=="NO_STATS" or why=="NO_SCORE"))
    if code=="UP" and type(pct)=="number" and pct>0 and pct<10000 then
        value=GREEN.."+"..tostring(round(pct)).."%"..RESET
        upgrade=true
        if why=="BAG_PAIR" then note=GREY.."(bag pair)"..RESET
        elseif why~="PAWN_UI" then note=GREY.."(weapon set)"..RESET end
    elseif code=="NEW" or (code=="UP" and type(pct)=="number" and pct>=10000) then
        value=YELLOW.."EMPTY"..RESET
    elseif special then value=YELLOW.."SPECIAL"..RESET
    elseif code=="NOUP" then value=GREY.."NO UPGRADE"..RESET
    elseif code=="UNUSABLE" then value=GREY.."CANNOT EQUIP"..RESET
    elseif code=="FUTURE" then value=GREY.."LV"..tostring(req or "?")..RESET
    else value=RED.."UNVERIFIED"..RESET end
    if req and req>0 and lvl and lvl>0 and req>lvl then
        note=(note and (note.." ") or "")..tagColor(req-lvl).."(Lv"..req..")"..RESET
    elseif req and req>0 and (not lvl or lvl<=0) then
        note=(note and (note.." ") or "")..GREY.."(Lv"..req..")"..RESET
    end
    if owned=="E" then note=(note and (note.." ") or "")..GREY.."(Equipped)"..RESET
    elseif owned=="B" then note=(note and (note.." ") or "")..GREY.."(In Bag)"..RESET end
    return value,note,upgrade
end
-- Return one confirmed recipient (or nil). The Need dice is shown INSIDE
-- that character row, never as a separate priority line or wishlist marker.
-- A missing/unscored result for a competing same-role Druid prevents advice.
-- Same role priority as the Dungeon Planner: Tank, Healer, then highest
-- Pawn increase among DPS; a DPS tie goes to Elya, then Nyra, then Ayla.
-- No speculative dice for missing replies, empty slots, or SPECIAL items.
local function priorityRecipient(s)
    local best,bestPct
    for _,name in ipairs(ALL) do
        local r=s.results[name]
        local code=r and r.code
        local valid=(code=="UP" and type(r.pct)=="number"
            and r.pct>0 and r.pct<10000 and r.lvl and r.lvl>0
            and r.req and r.req<=r.lvl
            and r.owned~="E" and r.owned~="B")
        if valid then
            if name=="Mael" or name=="Lyra" then return name end
            if not bestPct or r.pct>bestPct+0.000001 then best,bestPct=name,r.pct end
        elseif code~="NOUP" and code~="UNUSABLE" and code~="FUTURE"
            and code~="OWNED" then
            -- An earlier higher-priority candidate may actually need it.
            return nil
        end
    end
    return best
end
-- Preserve the original Blizzard/AtlasLoot/Pawn tooltip and append at its foot.
-- Lines are added once per actual hover; subsequent party replies modify their
-- FontStrings in place (never ClearLines/SetHyperlink/rebuild an addon tooltip).
local function textFont(tip, side, number, exact)
    local n=type(tip.GetName)=="function" and tip:GetName()
    if type(n)=="string" and n~="" then
        local named=_G[n.."Text"..side..tostring(number)]
        if named and named.SetText then return named end
    end
    if not exact or type(tip.GetRegions)~="function" then return nil end
    -- Fallback for anonymous tooltips: find the uniquely labelled new region.
    for _,region in ipairs({tip:GetRegions()}) do
        if region and region.GetObjectType and region:GetObjectType()=="FontString"
            and region.GetText and region:GetText()==exact then return region end
    end
    return nil
end
-- Per-tooltip texture pool anchored to the fixed-width percent FontString.
-- Dice is one reserved slot LEFT of the arrow; arrows share an X coordinate.
local function hideIcons(tip)
    local cache=tip and iconPool[tip]
    if cache then
        for _,pair in ipairs(cache) do
            pair.arrow:Hide()
            pair.dice:Hide()
        end
    end
end
local function rowIcons(tip,index,right)
    if not (right and right.SetWidth and tip.CreateTexture) then return nil end
    local cache=iconPool[tip]
    if not cache then cache={};iconPool[tip]=cache end
    local pair=cache[index]
    if not pair then
        local arrow=tip:CreateTexture(nil,"OVERLAY")
        arrow:SetTexture(PAWN_ARROW_PATH)
        arrow:SetSize(ICON_SIZE,ICON_SIZE)
        local dice=tip:CreateTexture(nil,"OVERLAY")
        dice:SetTexture(NEED_DICE_PATH)
        dice:SetSize(ICON_SIZE,ICON_SIZE)
        pair={arrow=arrow,dice=dice}
        cache[index]=pair
    end
    pair.arrow:ClearAllPoints()
    pair.arrow:SetPoint("RIGHT",right,"LEFT",-ICON_GAP,0)
    pair.dice:ClearAllPoints()
    pair.dice:SetPoint("RIGHT",pair.arrow,"LEFT",-ICON_GAP,0)
    pair.arrow:Hide()
    pair.dice:Hide()
    return pair
end
local function appendLines(s)
    local tip=s.anchor
    if not (tip and type(tip.AddLine)=="function" and type(tip.AddDoubleLine)=="function"
        and type(tip.NumLines)=="function") then return false end
    tip:AddLine(" ")
    tip:AddLine(INLINE_TITLE,0.85,0.68,0.35)
    local h=tip:NumLines()
    s.headerFont=textFont(tip,"Left",h,INLINE_TITLE)
    hideIcons(tip)
    s.rows={}
    for i,name in ipairs(ALL) do
        local waiting="WAITING "..name
        tip:AddDoubleLine(name,waiting,1.00,0.49,0.04,0.63,0.68,0.75)
        local row=tip:NumLines()
        local left=textFont(tip,"Left",row,name)
        local right=textFont(tip,"Right",row,waiting)
        if right and right.SetWidth then
            right:SetWidth(PERCENT_WIDTH)
            if right.SetJustifyH then right:SetJustifyH("RIGHT") end
        end
        s.rows[name]={left=left,right=right,icons=rowIcons(tip,i,right)}
    end
    tip:AddLine("Awaiting party Pawn results",0.63,0.68,0.75)
    local last=tip:NumLines()
    s.footerFont=textFont(tip,"Left",last,"Awaiting party Pawn results")
    s.endLine=last
    s.added=true
    return true
end
local function stillAttached(s)
    if not (s.added and s.headerFont and s.headerFont.GetText) then return false end
    local t=s.anchor
    if not (t and type(t.NumLines)=="function" and t:NumLines()>=s.endLine) then return false end
    return s.headerFont:GetText()==INLINE_TITLE
end
local function redraw()
    local s=session
    if not s or s.drawing then return end
    local tip=s.anchor
    if not (tip and tip.IsShown and tip:IsShown()) then return end
    s.drawing=true
    local ok=pcall(function()
        local appended=false
        if not stillAttached(s) then
            s.added=nil;s.rows=nil;s.headerFont=nil;s.footerFont=nil
            if not appendLines(s) then return end
            appended=true
        end
        local done=0
        local resolved=0
        local recipient=priorityRecipient(s)
        for _,name in ipairs(ALL) do
            local entry=s.results[name]
            local value,note,upgrade
            if entry then
                done=done+1
                value,note,upgrade=pretty(entry,s.id)
                if entry.code~="UNCACHED" and entry.code~="NODATA" and entry.code~="NOSTATS"
                    and entry.code~="NOGEAR" and entry.code~="VERIFY" and entry.code~="NEEDPAIR"
                    and entry.code~="NOSCALE" then resolved=resolved+1 end
            else
                value=GREY.."WAITING"..RESET
            end
            local row=s.rows and s.rows[name]
            if row then
                if row.left then row.left:SetText(name..(note and ("  "..note) or "")) end
                if row.right then
                    -- Right edge stays fixed even for +84% versus +4674%.
                    row.right:SetWidth(upgrade and PERCENT_WIDTH or STATUS_WIDTH)
                    row.right:SetText(value)
                    if row.right.SetTextColor then row.right:SetTextColor(1,1,1) end
                end
                if row.icons then
                    if upgrade then row.icons.arrow:Show() else row.icons.arrow:Hide() end
                    if upgrade and name==recipient then row.icons.dice:Show()
                    else row.icons.dice:Hide() end
                end
            end
        end
        local footer
        if not s.grouped then
            footer="SOLO - other Druids unavailable"
        elseif s.sent==false then
            footer="PARTY REQUEST FAILED - /hbhoverdiag"
        elseif done==#ALL then
            if resolved==#ALL then footer="5/5 READY  |  ALT + hover"
            else footer="5/5 REPLIED  |  "..tostring(#ALL-resolved).." unresolved" end
        else
            footer=tostring(done).."/5 REPLIED  |  awaiting replies"
        end
        if s.footerFont then s.footerFont:SetText(footer) end
        -- Only refresh geometry when the five rows were first appended.
        -- In particular, never call GameTooltip:Show() for each incoming Pawn
        -- reply: Baganator can rebuild its tooltip from Show and cause a
        -- Hide/Show/SetItem loop while ALT remains down.
        if appended and not s.initialShowDone and type(tip.Show)=="function" then
            s.initialShowDone=true
            tip:Show()
        end
    end)
    s.drawing=false
    if not ok then tooltipErrors=tooltipErrors+1 end
end
local function stop()
    -- Original tooltip lines remain owned by AtlasLoot/Pawn. Reused overlay
    -- icons must disappear when ALT is released or the item changes.
    if session then hideIcons(session.anchor) end
    session=nil
end
local function begin(id,anchor,source,link)
    local myself=me()
    if not TEAM[myself] or (source~="PROFESSION" and not alt()) then return end
    id=tonumber(id)
    if not id or id<1 or id>3000000 then return end
    if not anchor or not anchor.IsShown or not anchor:IsShown() then return end
    local itemString=exactItemString(link,id)
    if session and session.id==id and session.itemString==itemString then
        -- AtlasLoot often fires both item-data and OnEnter for one hover.
        -- Share the request and only update lines within the active tooltip.
        if session.anchor~=anchor then
            hideIcons(session.anchor)
            session.anchor=anchor;session.added=nil;session.rows=nil
            session.headerFont=nil;session.footerFont=nil
        end
        session.source=source
        redraw();return
    end
    if session then hideIcons(session.anchor) end
    serial=serial+1
    local grouped=(channel()~=nil)
    session={id=id,itemString=itemString,seq=serial,source=source,anchor=anchor,results={},grouped=grouped}
    local code,pct,req,lvl,why,owned=eval(id,itemString)
    session.results[myself]={code=code,pct=pct,req=req,lvl=lvl,why=why,owned=owned}
    if grouped then
        session.sent=send("Q|"..serial.."|"..id.."|"..itemString)
    else session.sent=false end
    redraw()
end
-- Baganator uses pooled item buttons with a BGR table containing itemLink
-- and itemID. Its tooltip can temporarily have no GetItem() result, especially
-- with Forever's modern tooltip data processor and item-cache updates. Do not
-- enumerate frames; inspect only the tooltip owner and the current mouse focus.
local function safeItemLink(raw)
    if type(raw)~="string" then return nil end
    local ok,id=pcall(itemIDFromLink,raw)
    if ok and id then return id,raw end
end
local function fromBagButton(button)
    for depth=1,4 do
        if not button then break end
        local ok,bgr=pcall(function() return button.BGR end)
        if not ok then break end
        if type(bgr)=="table" then
            local id,link=safeItemLink(bgr.itemLink or bgr.itemString)
            if id then return id,link,"BAGANATOR" end
            id=tonumber(bgr.itemID)
            if id and id>0 and id<=3000000 then return id,"item:"..id,"BAGANATOR" end
        end
        -- Classic and modern Blizzard bag slots offer bag/slot methods.
        if type(button.GetSlotAndBagID)=="function" then
            local okSlot,slot,bag=pcall(button.GetSlotAndBagID,button)
            local getLink=(C_Container and C_Container.GetContainerItemLink) or _G.GetContainerItemLink
            if okSlot and type(getLink)=="function" and type(slot)=="number" and type(bag)=="number" then
                local okLink,link=pcall(getLink,bag,slot)
                if okLink then
                    local id,full=safeItemLink(link)
                    if id then return id,full,"BAG" end
                end
            end
        end
        if type(button.GetParent)~="function" then break end
        local okParent,parent=pcall(button.GetParent,button)
        if not okParent or parent==button then break end
        button=parent
    end
end
local function currentFocus()
    if type(GetMouseFoci)=="function" then
        local ok,foci=pcall(GetMouseFoci)
        if ok and type(foci)=="table" and foci[1] then return foci[1] end
    end
    if type(GetMouseFocus)=="function" then
        local ok,f=pcall(GetMouseFocus)
        if ok then return f end
    end
end
-- HF26.20.12: PROFESSION ITEM TOOLTIPS ONLY. We append Party Pawn to the
-- EXISTING Blizzard GameTooltip on a real item hover inside the native
-- profession window. No extra panel, no selected-recipe polling and, crucially,
-- NO changes to Mini UI / tooltip visibility / camera / Smart Follow.
-- Parent traversal is bounded and read-only; it never scans all UI frames.
local professionDetection="NONE"
local professionSettersHooked=false
local function safeCall(fn,...)
    if type(fn)~="function" then return nil end
    local ok,value=pcall(fn,...)
    if ok then return value end
end
local function isShown(frame)
    return frame and safeCall(frame.IsShown,frame)==true
end
local function underFrame(frame,root)
    if not frame or not root then return false end
    for _=1,24 do
        if frame==root then return true end
        local parent=safeCall(frame.GetParent,frame)
        if not parent or parent==frame then return false end
        frame=parent
    end
    return false
end
local function professionOrigin(tip)
    if not tip then return nil end
    local owner=safeCall(tip.GetOwner,tip)
    local focus=currentFocus()
    -- Never use ipairs here: the modern frame is nil on Classic clients,
    -- and ipairs would stop before inspecting TradeSkillFrame / CraftFrame.
    for i=1,3 do
        local frame=(i==1 and _G.ProfessionsFrame)
            or (i==2 and _G.TradeSkillFrame)
            or (i==3 and _G.CraftFrame)
        if isShown(frame) then
            if underFrame(owner,frame) then return frame,owner end
            if underFrame(focus,frame) then return frame,focus end
        end
    end
end
local function recipeResult(recipeID)
    recipeID=tonumber(recipeID)
    local trades=_G.C_TradeSkillUI
    if not recipeID or not trades then return nil end
    local data=safeCall(trades.GetRecipeOutputItemData,recipeID)
    local link=type(data)=="table" and (data.hyperlink or data.itemLink)
    local id=type(data)=="table" and tonumber(data.itemID)
    if not id then id=itemIDFromLink(link) end
    if not id then
        link=safeCall(trades.GetRecipeItemLink,recipeID)
        id=itemIDFromLink(link)
    end
    if not id then
        local schematic=safeCall(trades.GetRecipeSchematic,recipeID,false)
        id=type(schematic)=="table" and tonumber(schematic.outputItemID)
    end
    if id and id>0 and id<=3000000 then return id,link end
end
local function professionOutputFallback(root,hovered)
    -- ONLY use the selected recipe as a fallback when the hovered widget is
    -- its OUTPUT icon. Reagent tooltips must use their own actual item link,
    -- never accidentally get scored as the finished product.
    local modern=_G.ProfessionsFrame
    if root==modern then
        local page=modern.CraftingPage
        local form=page and page.SchematicForm
        local output=form and (form.OutputIcon or form.OutputItemIcon)
        local details=modern.DetailsFrame
        local contents=details and details.Contents
        local resultIcon=contents and contents.ResultIcon
        if not ((output and underFrame(hovered,output))
            or (resultIcon and underFrame(hovered,resultIcon))) then return nil end
        local info=form and safeCall(form.GetRecipeInfo,form)
        local recipeID=type(info)=="table" and tonumber(info.recipeID)
        if not recipeID then
            local list=page and page.RecipeList
            recipeID=list and tonumber(safeCall(list.GetSelectedRecipeID,list))
        end
        return recipeResult(recipeID)
    end
    if root==_G.TradeSkillFrame then
        local icon=_G.TradeSkillSkillIconButton or _G.TradeSkillSkillIcon
        if not icon or not underFrame(hovered,icon) then return nil end
        local index=tonumber(safeCall(_G.GetTradeSkillSelectionIndex))
        local link=index and safeCall(_G.GetTradeSkillItemLink,index)
        return itemIDFromLink(link),link
    end
    if root==_G.CraftFrame then
        local icon=_G.CraftIconButton or _G.CraftIcon
        if not icon or not underFrame(hovered,icon) then return nil end
        local index=tonumber(safeCall(_G.GetCraftSelectionIndex))
        local link=index and safeCall(_G.GetCraftItemLink,index)
        return itemIDFromLink(link),link
    end
end
local function fromTooltip(tooltip,hintLink,hintID)
    if not (tooltip and tooltip.IsShown and tooltip:IsShown()) then return false end
    local profRoot,profOwner=professionOrigin(tooltip)
    local inProfession=profRoot~=nil
    if inProfession then professionDetection="HOVER" end
    if not (alt() or inProfession) then return false end
    local source=inProfession and "PROFESSION" or nil
    -- A post-call's item data is authoritative for its own callback.
    local id,link=safeItemLink(hintLink)
    if not id then
        local num=tonumber(hintID)
        if num and num>0 and num<=3000000 then id=num;link="item:"..num end
    end
    if id then tooltipLastDetection=inProfession and "PROFESSION_DATA" or "MODERN_DATA";begin(id,tooltip,source or "MODERN_DATA",link);return true end
    if type(tooltip.GetItem)=="function" then
        local ok,_,itemLink=pcall(tooltip.GetItem,tooltip)
        if ok then id,link=safeItemLink(itemLink) end
        if id then tooltipLastDetection=inProfession and "PROFESSION_ITEM" or "GET_ITEM";begin(id,tooltip,source or "TOOLTIP",link);return true end
    end
    if type(tooltip.GetPrimaryTooltipData)=="function" then
        local ok,data=pcall(tooltip.GetPrimaryTooltipData,tooltip)
        if ok and type(data)=="table" then
            id,link=safeItemLink(data.hyperlink)
            local itemType=_G.Enum and Enum.TooltipDataType and Enum.TooltipDataType.Item
            if not id and itemType~=nil and data.type==itemType then
                local num=tonumber(data.id)
                if num and num>0 and num<=3000000 then id=num;link="item:"..num end
            end
            if id then tooltipLastDetection=inProfession and "PROFESSION_PRIMARY" or "PRIMARY_DATA";begin(id,tooltip,source or "PRIMARY_DATA",link);return true end
        end
    end
    if inProfession then
        id,link=professionOutputFallback(profRoot,profOwner)
        if id then
            professionDetection="OUTPUT_ICON"
            tooltipLastDetection="PROFESSION_OUTPUT"
            begin(id,tooltip,"PROFESSION",link)
            return true
        end
        professionDetection="NO_ITEM"
        -- For a profession tooltip with no item identity, don't guess from a
        -- bag button or unrelated focus elsewhere in the UI.
        return false
    end
    -- Tooltip owner is a more reliable item identity than an arbitrary mouse
    -- focus when Baganator has a search overlay or category scroll frame.
    if type(tooltip.GetOwner)=="function" then
        local ok,owner=pcall(tooltip.GetOwner,tooltip)
        if ok then
            id,link=fromBagButton(owner)
            if id then tooltipLastDetection="BAG_OWNER";begin(id,tooltip,"BAG_OWNER",link);return true end
        end
    end
    id,link=fromBagButton(currentFocus())
    if id then tooltipLastDetection="BAG_FOCUS";begin(id,tooltip,"BAG_FOCUS",link);return true end
    return false
end
local function atlasTip()
    local a=_G.AtlasLoot
    if a and a.Tooltip and type(a.Tooltip.GetTooltip)=="function" then
        local ok,t=pcall(a.Tooltip.GetTooltip)
        if ok and t then return t end
    end
    return GameTooltip
end
local function hookAtlas()
    if atlasHooked then return end
    local a=_G.AtlasLoot
    if not (a and a.Button and type(a.Button.GetType)=="function") then return end
    if type(hooksecurefunc)~="function" then return end
    local ok,t=pcall(a.Button.GetType,a.Button,"Item")
    if not ok or type(t)~="table" or type(t.OnEnter)~="function" then return end
    local hooked=pcall(hooksecurefunc,t,"OnEnter",function(button)
        if button and button.ItemID then
            begin(button.ItemID,atlasTip(),"ATLASLOOT",button.ItemString)
        end
    end)
    if not hooked then return end
    if type(t.OnLeave)=="function" then
        pcall(hooksecurefunc,t,"OnLeave",function()
            if session and session.source=="ATLASLOOT" then stop() end
        end)
    end
    atlasHooked=true
end
local altResyncToken=0
local function queueAltTooltipResync()
    -- Baganator may replace the item tooltip a moment AFTER ALT is pressed.
    -- These two one-shot checks are scheduled ONLY on the actual ALT keypress.
    -- Never schedule from OnHide: that created a self-perpetuating tooltip
    -- refresh loop when another addon repeatedly rebuilt GameTooltip.
    altResyncToken=altResyncToken+1
    local token=altResyncToken
    if not (C_Timer and type(C_Timer.After)=="function") then return end
    for _,delay in ipairs({0.06,0.20}) do
        C_Timer.After(delay,function()
            if token~=altResyncToken or not alt() then return end
            if GameTooltip and GameTooltip.IsShown and GameTooltip:IsShown() then
                fromTooltip(GameTooltip)
            end
        end)
    end
end
local function hookGameTooltip()
    if gameHooked or not GameTooltip then return end
    -- WoW Forever (Mainline-style API) does not support OnTooltipSetItem.
    -- Each hook is independent: one unsupported legacy script must NEVER
    -- prevent OnShow/OnHide or modern TooltipDataProcessor registration.
    if type(GameTooltip.HookScript)=="function" then
        local ok=pcall(GameTooltip.HookScript,GameTooltip,"OnTooltipSetItem",function(self)
            fromTooltip(self)
        end)
        classicHooked=ok
        local shown=pcall(GameTooltip.HookScript,GameTooltip,"OnShow",function(self)
            -- No per-reply GameTooltip:Show() and no OnHide timers.
            -- Profession item tooltips can be evaluated without holding ALT.
            if alt() or professionOrigin(self) then fromTooltip(self) end
        end)
        local hidden=pcall(GameTooltip.HookScript,GameTooltip,"OnHide",function(self)
            if session and session.anchor==self then
                hideIcons(self)
                if not alt() then stop() end
            end
        end)
        showHooked=shown and hidden
    end
    local processor=_G.TooltipDataProcessor
    local itemType=_G.Enum and Enum.TooltipDataType and Enum.TooltipDataType.Item
    if processor and type(processor.AddTooltipPostCall)=="function" and itemType~=nil then
        modernHooked=pcall(processor.AddTooltipPostCall,itemType,function(tip,data)
            if tip~=GameTooltip or (not alt() and not professionOrigin(tip)) then return end
            local link,id
            if type(data)=="table" then link=data.hyperlink;id=data.id end
            -- During SetBagItem a tooltip may not be visible yet. Its OnShow
            -- hook then resolves the freshly displayed item or BGR owner.
            if tip.IsShown and tip:IsShown() then fromTooltip(tip,link,id) end
        end)
    end
    -- Blizzard may set the crafted result AFTER OnShow (modern output icons
    -- update their tooltip with SetRecipeResultItem). A secure post-hook is
    -- used only to detect that item; it never changes Blizzard's method.
    if type(hooksecurefunc)=="function" then
        for _,name in ipairs({"SetRecipeResultItem","SetTradeSkillItem","SetCraftItem"}) do
            if type(GameTooltip[name])=="function" then
                local ok=pcall(hooksecurefunc,GameTooltip,name,function(self)
                    if not professionOrigin(self) or not isShown(self) then return end
                    if session and session.source=="PROFESSION" and session.anchor==self
                        and stillAttached(session) then return end
                    fromTooltip(self)
                end)
                if ok then professionSettersHooked=true end
            end
        end
    end
    gameHooked=classicHooked or modernHooked or showHooked
end

-- Ingame diagnostic for native profession tooltip detection. This does not
-- create a tooltip or alter UI visibility.
SLASH_HAPLOPROFDIAG1="/hbprofdiag"
SlashCmdList.HAPLOPROFDIAG=function()
    local root=GameTooltip and professionOrigin(GameTooltip)
    local name=root and (safeCall(root.GetName,root) or "profession") or "NONE"
    local link
    if GameTooltip and type(GameTooltip.GetItem)=="function" then
        local ok,_,itemLink=pcall(GameTooltip.GetItem,GameTooltip)
        if ok then link=itemLink end
    end
    tell("native profession owner="..tostring(name)
        .." item="..tostring(link)
        .." detection="..tostring(professionDetection)
        .." setterHooks="..tostring(professionSettersHooked)
        .." session="..tostring(session and session.source))
end

local function mouseItem()
    -- ALT pressed over an already visible Baganator item: modern TooltipData
    -- callbacks may have fired BEFORE ALT became held. Resolve immediately
    -- via tooltip and the BGR owner/focus fallback, without re-Show().
    if GameTooltip and fromTooltip(GameTooltip) then return end
    local focus=currentFocus()
    local tooltip=atlasTip()
    -- Only the explicitly AtlasLoot-style ItemID path uses AtlasLoot's
    -- separate tooltip. Never redirect a Baganator BGR button there.
    if focus and type(focus.ItemID)=="number" and not focus.BGR
        and tooltip~=GameTooltip and tooltip and tooltip.IsShown and tooltip:IsShown() then
        begin(focus.ItemID,tooltip,"ATLASLOOT",focus.ItemString)
    end
end
SLASH_HAPLOHOVERDIAG1="/hbhoverdiag"
SlashCmdList.HAPLOHOVERDIAG=function()
    tell("HF26.20.12 original professions tooltip + five-client Party Pawn | player="..tostring(me()).." | registered="..tostring(registered)
        .." | GameTooltip="..tostring(gameHooked).." | modern="..tostring(modernHooked)
        .." | classic="..tostring(classicHooked).." | OnShow="..tostring(showHooked)
        .." | Baganator/path="..tooltipLastDetection.." | AtlasLoot="..tostring(atlasHooked))
    tell("sent="..counters.sent.." recv="..counters.received.." requests="..counters.request
        .." replies="..counters.replied.." failed="..counters.failed.." malformed="..counters.malformed
        .." inlineErrors="..tooltipErrors)
    if session then
        tell("active="..tostring(session.id).." source="..tostring(session.source)
            .." group="..tostring(session.grouped).." sent="..tostring(session.sent)
            .." roleFit="..tostring(session.fit))
        -- Diagnostic only: shows Pawn's actual parsed stats when a role tag
        -- needs checking; never modifies scales or the existing item tooltip.
        local getter=(C_Item and C_Item.GetItemInfo) or _G.GetItemInfo
        if type(getter)=="function" and type(PawnGetItemData)=="function" then
            local ok,_,link=pcall(getter,session.itemString)
            if ok and link then
                local parsed,item=pcall(PawnGetItemData,link)
                if parsed and type(item)=="table" and type(item.Stats)=="table" then
                    local keys={}
                    for key,value in pairs(item.Stats) do
                        if type(value)=="number" and value>0 then
                            keys[#keys+1]=tostring(key).."="..tostring(value)
                        end
                    end
                    table.sort(keys)
                    tell("Pawn stat profile: "..table.concat(keys,", "))
                end
            end
        end
    else tell("no active hover") end
end
-- A member can reply UNCACHED while its item data is still loading. When
-- Blizzard finally delivers the data, send a corrected reply for the SAME hover
-- sequence; the requesting client updates its existing FontString in place.
-- No polling in idle.
local function retryable(code,why)
    return code=="UNCACHED" or (code=="NOGEAR" and why=="BAG_PENDING")
        or (code=="NOSTATS" and
        (why=="NO_ITEM" or why=="NO_STATS" or why=="NO_LINK"))
end
local function reply(target,seq,id,code,pct,req,lvl,why,owned)
    why=tostring(why or "NONE"):upper():gsub("[^A-Z_]","_")
    -- Party messages are broadcast, so address each reply explicitly. This
    -- prevents two clients hovering at once from mixing their sequence IDs.
    return send(string.format("R|%s|%d|%d|%s|%.2f|%d|%d|%s|%s",
        target,seq,id,code,pct,req,lvl,why,owned))
end
local retryDelay={0.40,1.00,2.00,3.00,4.00}
local function refreshPending(p,fromTimer)
    if pending[p.key]~=p then return end
    local code,pct,req,lvl,why,owned=eval(p.id,p.itemString)
    if not retryable(code,why) then
        pending[p.key]=nil
        reply(p.requester,p.seq,p.id,code,pct,req,lvl,why,owned)
        return
    end
    if fromTimer then
        p.step=p.step+1
        if p.step>#retryDelay then
            pending[p.key]=nil
            reply(p.requester,p.seq,p.id,"NODATA",-1,req,lvl,"CACHE_TIMEOUT",owned)
            return
        end
    end
    local loader=C_Item and C_Item.RequestLoadItemDataByID
    if type(loader)=="function" then pcall(loader,p.id) end
end
local function scheduleRetry(p)
    if not (C_Timer and type(C_Timer.After)=="function") then return end
    local delay=retryDelay[p.step]
    if not delay then return end
    C_Timer.After(delay,function()
        if pending[p.key]~=p then return end
        refreshPending(p,true)
        if pending[p.key]==p then scheduleRetry(p) end
    end)
end
local events=CreateFrame("Frame")
events:RegisterEvent("PLAYER_LOGIN")
events:RegisterEvent("ADDON_LOADED")
events:RegisterEvent("CHAT_MSG_ADDON")
events:RegisterEvent("MODIFIER_STATE_CHANGED")
pcall(events.RegisterEvent,events,"GET_ITEM_INFO_RECEIVED")
pcall(events.RegisterEvent,events,"ITEM_DATA_LOAD_RESULT")
events:SetScript("OnEvent",function(_,event,...)
    if event=="GET_ITEM_INFO_RECEIVED" or event=="ITEM_DATA_LOAD_RESULT" then
        local itemID=tonumber((...))
        if itemID then
            for _,p in pairs(pending) do
                if p.id==itemID then refreshPending(p,false) end
            end
            if TEAM[me()] and session and session.id==itemID then
                local old=session.results[me()]
                if old and retryable(old.code,old.why) then
                    local code,pct,req,lvl,why,owned=eval(itemID,session.itemString)
                    session.results[me()]={code=code,pct=pct,req=req,lvl=lvl,why=why,owned=owned}
                    redraw()
                end
            end
        end
        return
    end
    if event=="PLAYER_LOGIN" then
        register()
        if TEAM[me()] then hookGameTooltip();hookAtlas() end
        return
    elseif event=="ADDON_LOADED" then
        if TEAM[me()] then hookGameTooltip();hookAtlas() end
        return
    elseif event=="MODIFIER_STATE_CHANGED" then
        if not TEAM[me()] then return end
        local key,down=...
        if key~="LALT" and key~="RALT" then return end
        if not alt() then
            altResyncToken=altResyncToken+1 -- discard stale ALT-down callbacks
            if not session or session.source~="PROFESSION" then stop() end
        elseif down==1 then
            mouseItem()
            queueAltTooltipResync()
        end
        return
    end
    local prefix,msg,ch,sender=...
    if prefix~=PREFIX or type(msg)~="string" then return end
    if ch~="PARTY" and ch~="RAID" and ch~="INSTANCE_CHAT" then return end
    local from=who(sender)
    if not from or not TEAM[from] or not channel() then return end
    local kind=msg:sub(1,2)
    if kind=="Q|" and from~=me() then
        local seq,id,itemString=msg:match("^Q|(%d+)|(%d+)|(item:[%d:%-]+)$")
        seq,id=tonumber(seq),tonumber(id)
        if not seq or not id or id<1 or id>3000000 or not itemString
            or #itemString>150 or itemIDFromLink(itemString)~=id then
            counters.malformed=counters.malformed+1;return
        end
        counters.request=counters.request+1
        -- Cancel only this requester's previous hover. Other clients can
        -- inspect their own item independently in the same party session.
        for key,old in pairs(pending) do
            if old.requester==from then pending[key]=nil end
        end
        local code,pct,req,lvl,why,owned=eval(id,itemString)
        if reply(from,seq,id,code,pct,req,lvl,why,owned) then counters.replied=counters.replied+1 end
        if retryable(code,why) then
            local key=from..":"..seq
            local p={key=key,requester=from,seq=seq,id=id,itemString=itemString,step=1}
            pending[key]=p
            local loader=C_Item and C_Item.RequestLoadItemDataByID
            if type(loader)=="function" then pcall(loader,id) end
            scheduleRetry(p)
        end
    elseif kind=="R|" and from~=me() then
        local target,seq,id,code,pct,req,lvl,why,owned=msg:match(
            "^R|([A-Za-z]+)|(%d+)|(%d+)|([A-Z]+)|([%d%.%-]+)|(%d+)|(%d+)|([A-Z_]+)|([EB%-])$")
        if target~=me() then return end
        seq,id,pct,req,lvl=tonumber(seq),tonumber(id),tonumber(pct),tonumber(req),tonumber(lvl)
        if not (seq and id and pct and req and lvl and code and why and owned)
            or pct~=pct or pct>100000 or pct< -1 then
            counters.malformed=counters.malformed+1;return
        end
        counters.received=counters.received+1
        if session and session.seq==seq and session.id==id
            and (alt() or session.source=="PROFESSION") then
            session.results[from]={code=code,pct=pct,req=req,lvl=lvl,why=why,owned=owned}
            redraw()
        end
    end
end)

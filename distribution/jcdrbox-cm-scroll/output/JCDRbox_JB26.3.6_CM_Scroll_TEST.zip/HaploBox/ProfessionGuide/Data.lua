-- HaploBox Profession Guide – catalog of profession identities (not a leveling recipe DB).
-- SkillLine IDs are stable; skill values are read from the active game client.
HaploBoxProfessionGuide = HaploBoxProfessionGuide or {}
local PG = HaploBoxProfessionGuide

PG.VERSION = "HF26.PG.1-TEST"
PG.PREFIX = "HBPG1"
PG.ORDER = {"BS", "LW", "ENG", "TAIL", "ALCH", "ENCH", "MIN", "HERB", "SKIN"}
PG.PROFESSIONS = {
    BS   = { name = "Blacksmithing", id = 164, icon = "Interface\\Icons\\Trade_BlackSmithing" },
    LW   = { name = "Leatherworking", id = 165, icon = "Interface\\Icons\\Trade_LeatherWorking" },
    ENG  = { name = "Engineering", id = 202, icon = "Interface\\Icons\\Trade_Engineering" },
    TAIL = { name = "Tailoring", id = 197, icon = "Interface\\Icons\\Trade_Tailoring" },
    ALCH = { name = "Alchemy", id = 171, icon = "Interface\\Icons\\Trade_Alchemy" },
    ENCH = { name = "Enchanting", id = 333, icon = "Interface\\Icons\\Trade_Engraving" },
    MIN  = { name = "Mining", id = 186, icon = "Interface\\Icons\\Trade_Mining" },
    HERB = { name = "Herbalism", id = 182, icon = "Interface\\Icons\\Trade_Herbalism" },
    SKIN = { name = "Skinning", id = 393, icon = "Interface\\Icons\\INV_Misc_Pelt_Wolf_01" },
}
-- Localization-safe aliases can be extended without changing any saved records.
PG.BY_NAME = {
    ["blacksmithing"]="BS", ["leatherworking"]="LW", ["engineering"]="ENG",
    ["tailoring"]="TAIL", ["alchemy"]="ALCH", ["enchanting"]="ENCH",
    ["mining"]="MIN", ["herbalism"]="HERB", ["skinning"]="SKIN",
}
PG.BY_ID = {}
for code, item in pairs(PG.PROFESSIONS) do PG.BY_ID[item.id] = code end
PG.BANDS = {
    { startSkill=1, endSkill=75, name="Apprentice" },
    { startSkill=75, endSkill=150, name="Journeyman" },
    { startSkill=150, endSkill=225, name="Expert" },
    { startSkill=225, endSkill=300, name="Artisan" },
}

-- Real recipe steps are registered only after source and in-game validation.
-- Shape: { { from=1, to=30, name="...", spellID=123, reagents={{itemID=1,count=2}} } }
PG.GUIDES = {}
function PG.RegisterGuide(code, rows)
    if not PG.PROFESSIONS[code] or type(rows) ~= "table" then return false end
    for _, row in ipairs(rows) do
        if type(row.from) ~= "number" or type(row.to) ~= "number"
            or row.from < 1 or row.to > 300 or row.from >= row.to
            or type(row.name) ~= "string" then return false end
    end
    PG.GUIDES[code] = rows
    if PG.RefreshUI then PG.RefreshUI() end
    return true
end

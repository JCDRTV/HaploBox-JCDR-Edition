-- HaploBox Profession Guide – Phase 1: current-skill scan and party sync.
local PG = HaploBoxProfessionGuide
local function now()
    return type(GetServerTime) == "function" and GetServerTime() or (type(time) == "function" and time() or 0)
end
local function clock()
    return type(GetTime) == "function" and GetTime() or 0
end

function PG.ShortName(name)
    if type(name) ~= "string" then return nil end
    local n = name:match("^([^%-]+)")
    if not n or n == "" then return nil end
    return n
end
function PG.Me()
    return PG.ShortName(UnitName("player")) or "Player"
end

local function findCode(name, skillLineID)
    local code = PG.BY_ID[tonumber(skillLineID) or 0]
    if code then return code end
    if type(name) ~= "string" then return nil end
    local normalized = name:lower():gsub("^%s+", ""):gsub("%s+$", "")
    if PG.BY_NAME[normalized] then return PG.BY_NAME[normalized] end
    -- Classic/Forever may prefix a profession with a skill tier/expansion name.
    for professionName, match in pairs(PG.BY_NAME) do
        if normalized:match("%f[%a]" .. professionName .. "%f[%A]") then return match end
    end
end

function PG.ReadMySkills()
    local results = {}
    -- A modern API exists on Forever; the legacy fallback is useful on Classic Era.
    if type(GetProfessions) == "function" and type(GetProfessionInfo) == "function" then
        local indexes = { GetProfessions() }
        for _, index in pairs(indexes) do
            if type(index) == "number" then
                local ok, name, _, skill, maxSkill, _, _, skillLine = pcall(GetProfessionInfo, index)
                if ok then
                    local code = findCode(name, skillLine)
                    if code and type(skill) == "number" then
                        results[code] = {skill=math.max(0, math.floor(skill)), cap=math.max(0, math.floor(tonumber(maxSkill) or 0))}
                    end
                end
            end
        end
    end
    -- Forever's C_TradeSkillUI can report professions that GetProfessions omits.
    local trade = C_TradeSkillUI
    if trade and type(trade.GetProfessionInfoBySkillLineID) == "function" then
        for _, code in ipairs(PG.ORDER) do
            local id = PG.PROFESSIONS[code].id
            local ok, info = pcall(trade.GetProfessionInfoBySkillLineID, id)
            if ok and type(info) == "table" and type(info.skillLevel) == "number" and info.skillLevel > 0 then
                local newSkill = math.floor(info.skillLevel)
                local old = results[code]
                if not old or newSkill > old.skill then
                    results[code] = {skill=newSkill,cap=math.floor(tonumber(info.maxSkillLevel) or 0)}
                end
            end
        end
    end
    local numSkills = C_SkillInfo and C_SkillInfo.GetNumSkillLines or GetNumSkillLines
    local getSkill = C_SkillInfo and C_SkillInfo.GetSkillLineInfo or GetSkillLineInfo
    if type(numSkills) == "function" and type(getSkill) == "function" then
        local ok, total = pcall(numSkills)
        if ok and type(total) == "number" then
            for i=1,math.min(total,500) do
                local valid, first, isHeader, _, rank, _, _, maxRank = pcall(getSkill, i)
                local name
                if valid and type(first) == "table" then
                    name = first.name
                    isHeader = first.isHeader
                    rank = first.rank
                    maxRank = first.maxRank
                else
                    name = first
                end
                if valid and not isHeader and type(rank) == "number" then
                    local code = findCode(name)
                    if code and (not results[code] or rank > results[code].skill) then
                        results[code] = {skill=math.max(0,math.floor(rank)), cap=math.max(0,math.floor(tonumber(maxRank) or 0))}
                    end
                end
            end
        end
    end
    return results
end

function PG.GetRoster()
    local names, seen = {}, {}
    local function add(name)
        name = PG.ShortName(name)
        if name and not seen[name:lower()] then
            seen[name:lower()] = true
            names[#names+1] = name
        end
    end
    add(PG.Me())
    if type(IsInRaid) == "function" and IsInRaid() then
        local total = type(GetNumGroupMembers) == "function" and GetNumGroupMembers() or 0
        for i=1,math.min(total,40) do add(UnitName("raid" .. i)) end
    elseif type(IsInGroup) == "function" and IsInGroup() then
        local total = type(GetNumSubgroupMembers) == "function" and GetNumSubgroupMembers() or 4
        for i=1,math.min(total,4) do add(UnitName("party" .. i)) end
    elseif PG.db and PG.db.team then
        -- When alone, retain the last seen party so the overview remains useful.
        for name in pairs(PG.db.team) do add(name) end
    end
    return names
end

local function inCurrentParty(name)
    if not name then return false end
    for _, current in ipairs(PG.GetRoster()) do
        if name:lower() == current:lower() then return true end
    end
    return false
end

function PG.ScanMySkills()
    if not PG.db then return end
    local me = PG.Me()
    local data = PG.ReadMySkills()
    PG.db.team[me] = {skills=data, updated=now(), online=true}
    if PG.RefreshUI then PG.RefreshUI() end
end

local function transport()
    if type(IsInGroup) ~= "function" or not IsInGroup() then return nil end
    if type(IsInGroup) == "function" and type(LE_PARTY_CATEGORY_INSTANCE) == "number" and IsInGroup(LE_PARTY_CATEGORY_INSTANCE) then return "INSTANCE_CHAT" end
    if type(IsInRaid) == "function" and IsInRaid() then return "RAID" end
    return "PARTY"
end
local function send(message)
    local channel = transport()
    if not channel then return end
    if C_ChatInfo and type(C_ChatInfo.SendAddonMessage) == "function" then
        pcall(C_ChatInfo.SendAddonMessage, PG.PREFIX, message, channel)
    elseif type(SendAddonMessage) == "function" then
        pcall(SendAddonMessage, PG.PREFIX, message, channel)
    end
end
function PG.Broadcast(force)
    if not PG.db then return end
    if not force and clock() - (PG.lastSent or -100) < 1 then return end
    PG.lastSent = clock()
    local me = PG.db.team[PG.Me()]
    if not me then PG.ScanMySkills(); me = PG.db.team[PG.Me()] end
    if not me then return end
    local parts = {}
    for _, code in ipairs(PG.ORDER) do
        local s = me.skills[code]
        if s then parts[#parts+1] = code .. ":" .. s.skill .. ":" .. s.cap end
    end
    send("S|" .. table.concat(parts, ","))
end
local function readSnapshot(name, msg)
    local skills = {}
    local payload = msg:sub(3)
    if #payload > 250 then return end
    for code, skill, cap in payload:gmatch("([A-Z]+):(%d+):(%d+)") do
        if PG.PROFESSIONS[code] then
            local n, m = tonumber(skill), tonumber(cap)
            if n and m and n <= 10000 and m <= 10000 then
                skills[code] = {skill=n,cap=m}
            end
        end
    end
    PG.db.team[name] = {skills=skills,updated=now(),online=true}
    if PG.RefreshUI then PG.RefreshUI() end
end

local events = CreateFrame("Frame")
PG.events = events
events:RegisterEvent("PLAYER_LOGIN")
events:RegisterEvent("PLAYER_ENTERING_WORLD")
events:RegisterEvent("GROUP_ROSTER_UPDATE")
events:RegisterEvent("CHAT_MSG_ADDON")
events:RegisterEvent("SKILL_LINES_CHANGED")
events:RegisterEvent("TRADE_SKILL_SHOW")
events:RegisterEvent("TRADE_SKILL_CLOSE")
events:SetScript("OnEvent", function(_, event, ...)
    if event == "PLAYER_LOGIN" then
        HaploBoxProfessionDB = HaploBoxProfessionDB or {}
        PG.db = HaploBoxProfessionDB
        PG.db.team = type(PG.db.team) == "table" and PG.db.team or {}
        PG.db.selected = PG.PROFESSIONS[PG.db.selected] and PG.db.selected or "LW"
        if C_ChatInfo and type(C_ChatInfo.RegisterAddonMessagePrefix) == "function" then
            pcall(C_ChatInfo.RegisterAddonMessagePrefix, PG.PREFIX)
        elseif type(RegisterAddonMessagePrefix) == "function" then
            pcall(RegisterAddonMessagePrefix, PG.PREFIX)
        end
        PG.ScanMySkills()
        if PG.CreateUI then PG.CreateUI() end
        if C_Timer and type(C_Timer.After) == "function" then
            C_Timer.After(2, function() PG.ScanMySkills(); PG.Broadcast(true); send("R|") end)
        end
        -- A low-frequency heartbeat keeps the party's skill cache honest.
        if C_Timer and type(C_Timer.NewTicker) == "function" then
            PG.heartbeat = C_Timer.NewTicker(60, function()
                if PG.db then PG.ScanMySkills(); PG.Broadcast(true) end
            end)
        end
    elseif not PG.db then
        return
    elseif event == "CHAT_MSG_ADDON" then
        local prefix, msg, _, sender = ...
        if prefix ~= PG.PREFIX or type(msg) ~= "string" or #msg > 250 then return end
        local who = PG.ShortName(sender)
        if not who or who:lower() == PG.Me():lower() or not inCurrentParty(who) then return end
        if msg == "R|" then
            PG.Broadcast(true)
        elseif msg:sub(1,2) == "S|" then
            readSnapshot(who,msg)
        end
    elseif event == "GROUP_ROSTER_UPDATE" or event == "PLAYER_ENTERING_WORLD" then
        PG.ScanMySkills()
        PG.Broadcast(true)
        send("R|")
    else
        PG.ScanMySkills()
        PG.Broadcast(false)
    end
end)

HF26.20.38 TEST — Separate role icons, responsive Dungeon Advisor columns

Base: exact HF26.20.37 TEST. UI-only patch inside LootPlanner.lua. No BiS scoring, role weighting, Pawn/network/scanner, menu scroll, weapon set, or Dungeon Run changes.

Fix: Dungeon Advisor's farm-priority header now uses 3 Blizzard role icons (Tank, Healer, Damage) rather than "T/H/D" text. The rows show a separate numeric count for each role beneath its icon; UNI and Rank remain distinct.

Widths and offsets computed from the dynamically resized left farm panel. The final Rank column ends before the scrollbar gutter even at 820px minimum Advisor width. Name text compresses to the remaining space; columns never overflow into the right BiS list or window border.

Offline: 32 Lua syntax checks, mocked UI creation and resize, 3 icon/3 separate count column alignment at 820/1000/1200/1600/1920px, geometry overlap checks, four scrollbar regressions, ZIP CRC/SHA and unchanged-file binary comparisons.

INSTALL: Manual HaploBox UPDATE from GitHub TEST channel only. Ingame acceptance remains OPEN: check visible icons, non-overlapping counts + P-rank at minimum and large window widths, drag resize, mouse wheel, tooltips and five-character role counts. Do not mark PASS until user confirms ingame.

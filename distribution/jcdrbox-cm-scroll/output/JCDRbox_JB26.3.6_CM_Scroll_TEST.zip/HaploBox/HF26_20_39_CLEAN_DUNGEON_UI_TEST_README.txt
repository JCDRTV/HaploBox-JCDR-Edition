HF26.20.39 TEST — Clean Dungeon Advisor + Dungeon Run UI

Exact base: HF26.20.38 TEST. Small scoped UI-only change in LootPlanner.lua plus TOC version.

- Advisor dungeon row selects loot details; a separate RUN button opens that dungeon in the existing Run Planner without destroying timer, position, or size. Old header RUN GUIDE removed.
- Run Planner CHANGE button removed; choose runs via Advisor only. /hbrun and diagnostic commands preserved.
- Advisor and Run bosses expand/collapse on boss row click; COLLAPSE ALL / EXPAND ALL supported and state saved. Manual boss [ ] checkboxes and RESET BOSSES removed without deleting saved legacy run history.
- Scrollbars visually widened and highlighted. Old paging arrows and page counters hidden in every existing scrolling panel. Wheel and slider drag remain.
- Rank heading becomes Score. Display exact role-weighted UNIQUE item opportunity score (Tank x3, Healer x2, DPS x1; highest weight per unique item), with ? when coverage provisional. No priority math changes.
- Numeric positive Pawn upgrades green, qualitative NEW yellow; CHECK and SPECIAL remain visible.
- Technical coverage prose, UI-only explanatory tooltips, and redundant footnotes removed from display. Full detail remains available through /hbbiscoverage, /hblootnet diag / inspect, and /hbrunaudit. Native item tooltip remains on each item icon, with ALT-hover Party Pawn untouched.
- Scanner, Pawn Forever scales, role assignments, unique-equipped checks, specialized weapon scoring, networking, Macro/Quick Menu/Mini UI, saved window dimensions and timer remain unchanged.

All tests are offline mocks until ingame user acceptance. Manual HaploBox UPDATE only.

HF26.20.26 — LEVEL-RANGE DUNGEON BIS (TEST — 2026-11-22)
BASE: HF26.20.25 Offline Whisper Guard; includes HF26.20.23 UI styling + HF26.20.24 button reposition + HF26.20.25 offline whisper safety. Ingame acceptance OPEN.

USER GOAL:
Scan every AtlasLoot dungeon the five currently leveled Druids can enter/do; from
ONLY the scannable boss drops in these dungeons, show each Druid's highest-scoring
currently equippable upgrade PER GEAR SLOT. Not BiS for one dungeon, and not
absolute WoW BiS (quest, profession, world drops not scanned).

UI:
- Haplo Loot Dungeon Advisor defaults to DUNGEON BIS, an overview of the five
  team characters with the strongest candidate by slot from ALL completed,
  accessible dungeon scans. Each row shows target gear slot, item, dungeon,
  boss, and Pawn gain or NEW. Hover row for full source and uncertainty.
- BOSS DETAILS returns to the original per-dungeon boss/Need/priority details;
  selecting a dungeon on left also opens its boss details. DUNGEON BIS returns
  to the global cross-dungeon view. ALL BOSS LOOT remains a per-dungeon-only
  debug/verification toggle (disabled in BiS view).
- One best candidate per single-value slot. Two distinct candidates may appear
  for ring/trinket (two slots); the SECOND is marked CHECK PAIR, because the
  existing protocol only reports comparison against the weakest equipped ring
  or trinket. It does NOT certify equipping both candidates at once.
- Weapon targets are 2H, 1H main, and held off-hand individually; only use the
  correctly configured/ready LOCKED set comparator. Never sort 1H standalone
  Pawn raw score against a complete 2H. No fallback to another bag partner.
- Item ranking within each ordinary slot uses raw Pawn score from THAT character
  with its own scale (consistent with the upgrade eligibility check), not raw
  percentages pooled between slots/characters. Weapon ranking uses full proposed
  set value = locked reference * (1 + validated upgrade_pct/100).
- Higher level-required items and inaccessible dungeon levels are excluded;
  no future gear is presented as an available BiS target. Unusable druid gear,
  score-unknown results and outdated scans cannot become a verified winner.
- Scan coverage states exactly how many accessible dungeons were completed.
  An incomplete, stale, partial-team or unresolved scan makes BiS PROVISIONAL.
  BiS is never asserted beyond covered AtlasLoot dungeon drops.
- Any gear/level/weapon lock change makes scans STALE; must rescan to recalculate.
  No automatic background scanning or gear equipping.
- Preserve left dungeon ranking, older per-boss Need workflow, /hbrun, timer,
  Pawn inspect /hblootnet, manual HaploBox UPDATE and 0.90-second transport pacing.

FIRST INGAME TEST:
1. Install HF26.20.26 via existing manual HaploBox UPDATE on all 5 Druids.
2. On Mael open Dungeon Advisor. Start AVAILABLE DUNGEONS scan, with all 5 online.
   Network still deliberately paced at 0.90s/request, so let it finish.
3. DUNGEON BIS must show one best currently usable item per ordinary slot and
   Druid across ALL scanned accessible dungeons; source dungeon and boss shown.
4. Verify a weaker item for the same slot in another dungeon is not in BiS.
5. Click BOSS DETAILS to confirm original advisor remains accessible.
6. Equip a stronger item / accept a weapon lock change. All results become
   stale; rescan and verify older no-longer-better drops disappear.
7. Verify both rings/trinkets and 2H/1H sets: secondary jewelry shows CHECK PAIR;
   weapons only rank after both sets are READY and locked.
8. /hblootnet diag network coverage, timer, Mini UI, Smart Follow, Party Pawn
   original native Blizzard professions tooltip, macros, and bind settings.

OFFLINE TESTS:
- Lua parser compile, 32 Lua files, 200-local main-chunk cap.
- Candidate selection tests: cross-dungeon winner, future exclusion, stale
  exclusion, no longer an upgrade, tentative second ring, locked pair ranking,
  unknown legacy weapon exclusion, incomplete follower coverage.
- Only LootPlanner.lua, HaploBox.toc, HF_VERSION_HISTORY.txt and this README change versus HF26.20.25.
- No ingame claims: confirm visual placement and Blizzard client behavior live.

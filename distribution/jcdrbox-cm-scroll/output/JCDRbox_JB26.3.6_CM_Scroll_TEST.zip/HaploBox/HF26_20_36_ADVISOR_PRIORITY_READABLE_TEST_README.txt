HF26.20.36 TEST — Readable Dungeon Advisor Status + Team-Priority Ranking

Built strictly from HF26.20.35 TEST, preserves all existing scan/transport and Pawn Forever scales.

UI: Selected dungeon and complete scan coverage are separate short lines; full original coverage summary remains available on hover. The bottom note gets a compact variant on narrow windows. Dungeon list priority column shows P1/P2/... and adds ? while scan coverage remains provisional; every row has a tooltip explaining its rank. Minimized Advisor layouts are kept responsive.

Priority: replaces raw target-count-only sorting with an explainable deterministic score derived ONLY from the final actionable wishlist objectives: average bounded verified Pawn improvement, distinct Druids benefitting, and target count. Formula: avg(min(50,100*pct/(100+pct))) + 6*member_count + min(16,target_count). This rank is a heuristic for which dungeon to farm, not a new Pawn percentage; all item upgrade percentages are unchanged. NEW/unknown score remains an unquantified goal, not an invented 0% gain. Incomplete scans retain PROVISIONAL labels and may reorder after data arrives. Sorting is view-only; no scan requests and no equipment swapping.

Protected: HF26.20.29 fast 16-item batch and request/reply timing; HF26.20.35 weapon-set missing-main tests, Baganator hover keys, Unique-Equipped guard, Run Guide, ALT-hover, Mini UI, Quick Menu, Smart Follow and macros.

INGAME ACCEPTANCE OPEN. Manual HaploBox UPDATE only; user confirms before PASS.

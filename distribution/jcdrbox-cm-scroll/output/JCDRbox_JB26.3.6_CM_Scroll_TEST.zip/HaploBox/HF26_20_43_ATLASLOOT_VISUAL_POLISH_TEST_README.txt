HF26.20.43 AtlasLoot Visual Polish TEST — 23 November 2026
Base: HF26.20.42. UI-only refinements.
- AtlasLoot-style compact two-line item cells in Dungeon Advisor and Dungeon Run:
  native quality-colored WoW item name, small grey subtype/equip-type line;
  remove Head/Wrist/Chest etc prefixes from item names. All item icons keep
  their quality outline, original item tooltips and ALT-hover functionality.
- Cleaner, subdued dark matte scrollbar colors. Preserve slider height,
  arrows, mouse wheel, thumb drag, and resize behavior across all four lists.
- Replacement UNI and Rating/Score circular 15px icons with same dimensions,
  style and alignment as native Tank/Healer/DPS header badges.
- No scanner, Pawn weights, candidate selection, priority scoring, run timer,
  weapon-set, macro, Baganator or network changes.
- Offline tests PASS; ingame acceptance OPEN.
- Manual HaploBox UPDATE only.

HF26.20.34 TEST — Weapon Sets via Baganator Hover + Hotkey

Quick Menu -> Weapon Sets: three independent user keybinds (2H, 1H, OH).
Hover a LIVE Baganator bag item and press its bound key to mark it. Press again on the same item to unmark.
Different item in same slot: deliberate hotkey assignment replaces that reference after legality is checked.
2H locks immediately; 1H and OH lock together after both are marked.
The Baganator corner shows only 2H/1H/OH on selected items; no tiny plus/click selector.
CharacterFrame displays read-only labels on equipped, selected weapons.
Empty/bank/offline/cached/not weapon/wrong slot/high level/combat: do not change references.
Keybindings use native Bindings.xml; user action in binding menu saves them with SaveBindings. No default key assignment; no overwriting other bindings without a second explicit confirmation.
Old lock references and Pawn Compare preserved. No changes to scanner/batching, BiS, run timer, Mini UI, macros, Party Pawn.
Ingame acceptance open: test Baganator hover, /reload, switching weapon equipped/bag and no tooltip interference.

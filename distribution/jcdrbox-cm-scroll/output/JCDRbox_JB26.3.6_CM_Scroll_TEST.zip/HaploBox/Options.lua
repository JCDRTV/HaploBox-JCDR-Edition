-- HF13: standalone, visually unified Options. No Blizzard AddOns pane.
-- /hb options and the Quick Menu title-bar gear open exactly this frame.
local HB=HaploBox
local frame
local function fighting() return InCombatLockdown and InCombatLockdown() end
local function text(parent,value,x,y,width)
    local f=parent:CreateFontString(nil,'OVERLAY','GameFontHighlightSmall')
    f:SetPoint('TOPLEFT',parent,'TOPLEFT',x,y)
    f:SetWidth(width or 440);f:SetJustifyH('LEFT');f:SetText(value)
    return f
end
function HB.CreateOptions()
    if frame then return end
    frame=CreateFrame('Frame','HaploBoxOptionsWindow',UIParent)
    frame.hbMenuName='Options'
    frame:SetSize(510,244);frame:SetClampedToScreen(true)
    frame:SetMovable(true);frame:EnableMouse(true)
    frame:SetFrameStrata('DIALOG');frame:SetFrameLevel(180)
    if HB.MenuStyle then HB.MenuStyle.Window(frame,31) end
    frame:RegisterForDrag('LeftButton')
    frame:SetScript('OnDragStart',function(self) if not fighting() then self:StartMoving() end end)
    frame:SetScript('OnDragStop',function(self) self:StopMovingOrSizing() end)
    local title=text(frame,'HAPLOBOX OPTIONS',15,-9,405)
    title:SetTextColor(0.396,0.851,1)
    local close=CreateFrame('Button',nil,frame,'UIPanelButtonTemplate')
    close:SetSize(27,23);close:SetPoint('TOPRIGHT',frame,'TOPRIGHT',-7,-4)
    close:SetText('X');close:SetScript('OnClick',function() frame:Hide() end)
    if HB.MenuStyle then HB.MenuStyle.Button(close,'blue') end
    text(frame,'Local error reporting (both OFF by default for new characters).',17,-47,465)
    local toggles={
        {'relayErrors','Relay Cast Errors','Send follower cast errors to the leader.'},
        {'showRelayedErrors','Show Relayed Errors','Show follower cast errors in the leader chat.'},
    }
    local checks={}
    for i,t in ipairs(toggles) do
        local key,caption,detail=t[1],t[2],t[3]
        local y=-81-(i-1)*41
        local f=text(frame,caption,18,y,256)
        f:SetTextColor(0.95,0.9,0.77)
        text(frame,detail,18,y-15,345):SetTextColor(0.7,0.75,0.8)
        local b=CreateFrame('Button',nil,frame,'UIPanelButtonTemplate')
        b:SetSize(103,25);b:SetPoint('TOPRIGHT',frame,'TOPRIGHT',-17,y+5)
        b:SetScript('OnClick',function()
            if fighting() then HB.print('Change Options after combat.');return end
            if HB.db then HB.db[key]=not HB.db[key] end
            if HB.RefreshOptions then HB.RefreshOptions() end
        end)
        checks[#checks+1]={key=key,widget=b}
    end
    local syncLabel=text(frame,'BOX SYNC recovery',18,-176,260)
    syncLabel:SetTextColor(0.95,0.9,0.77)
    local sync=CreateFrame('Button',nil,frame,'UIPanelButtonTemplate')
    sync:SetSize(155,26);sync:SetPoint('TOPRIGHT',frame,'TOPRIGHT',-17,-168)
    sync:SetText('REFRESH SYNC')
    sync:SetScript('OnClick',function()
        if fighting() then HB.print('Refresh sync after combat.');return end
        if HB.boxSyncError and HB.RefreshBoxSync then HB.RefreshBoxSync() end
        sync:SetEnabled(not fighting() and not not HB.boxSyncError)
        if HB.MenuStyle then HB.MenuStyle.Button(sync,HB.boxSyncError and 'blue' or 'disabled') end
    end)
    local function refresh()
        for _,entry in ipairs(checks) do
            local on=HB.db and HB.db[entry.key] or false
            entry.widget:SetText(on and 'ON' or 'OFF')
            if HB.MenuStyle then HB.MenuStyle.Button(entry.widget,on and 'green' or 'red') end
        end
        sync:SetEnabled(not fighting() and not not HB.boxSyncError)
        if HB.MenuStyle then HB.MenuStyle.Button(sync,HB.boxSyncError and 'blue' or 'disabled') end
    end
    -- Lightweight monitoring only WHILE Options is displayed; no UI-frame scans.
    local elapsed=0
    frame:SetScript('OnUpdate',function(_,dt)
        elapsed=elapsed+dt
        if elapsed>=0.5 then elapsed=0;refresh() end
    end)
    frame:SetScript('OnShow',refresh)
    HB.RefreshOptions=refresh
    frame:ClearAllPoints();frame:SetPoint('CENTER',UIParent,'CENTER')
    frame:Hide()
    HB.OpenOptions=function()
        if not frame then return end
        if frame:IsShown() then frame:Hide();return end
        frame:Show();frame:Raise()
    end
end

HF26.20.27 PARTY BIS FARM/RUN GUIDE (TEST)

CURRENT TEAM: the existing verified Team A Druid party roster and Pawn roles.
The current scanner does not support arbitrary other classes/specs: future generalization required.

- Scan current accessible AtlasLoot dungeons with one SCAN PARTY BIS button.
- Per online/responding team member and slot: retain the one strongest currently wearable and still-usable dungeon boss item across completed, non-stale scans.
- One primary ring/trinket target pending validated 2-slot-combination scoring.
- Shortlist ONLY dungeons containing those targets. Rank by distinct target count, tie by minimum level then dungeon ID.
- Click dungeon to open Dungeon Run Guide for that dungeon; selector contains shortlisted dungeons only.
- Run Guide shows ONLY bosses with party BiS targets. Bosses expand by default to show target item, Druid class-orange name, native Pawn upgrade arrow, percent in aligned fixed right column.
- Run Guide back to wider 548px, retaining fold/collapse and Stealth/Normal run timer.
- Owner item tooltips and original strict Pawn confidence gates retained.
- Incomplete/provisional coverage cannot assert global BiS; scans cover only AtlasLoot boss loot.
- No automatic gear changes, no in-combat macro writes, no background updater changes.
- Protected modules remain identical to HF26.20.26.

Test status: OFFLINE STATIC+MOCK and integrity checks required; INGAME ACCEPTANCE OPEN.

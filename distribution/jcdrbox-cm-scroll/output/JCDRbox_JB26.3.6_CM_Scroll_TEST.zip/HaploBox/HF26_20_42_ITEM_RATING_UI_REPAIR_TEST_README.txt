HF26.20.42 — ITEM RATING / UI REPAIR TEST — 23 November 2026

Base: HF26.20.41.

- Fix global/dungeon PROVISIONAL leaking into all individual verified Pawn item labels.
- Verified positive Pawn percentages remain GREEN for the individual item even when another unrelated dungeon/drop is unresolved. Only unknown item scores are RED UNVERIFIED. Individual item rating does not certify global BiS completion; unresolved coverage continues in chat diagnostics.
- Preserve strict Pawn/level/role validation, best-slot selection and separate boss audit.
- Do not let unverified loot-need winner decision override a verified Pawn item score.
- UNI and rating pictograms use original circular medallions matching the native Tank/Healer/DPS circular badge style.
- Advisor and Dungeon Run item icons adopt a compact item-quality outline with Blizzard rarity colors, inspired by AtlasLoot item display, without altering existing item tooltips or behavior.
- All existing HF26.20.41 features and HF26.20.29 batched network scan remain unchanged.
- Ingame acceptance OPEN. Manual HaploBox UPDATE only.

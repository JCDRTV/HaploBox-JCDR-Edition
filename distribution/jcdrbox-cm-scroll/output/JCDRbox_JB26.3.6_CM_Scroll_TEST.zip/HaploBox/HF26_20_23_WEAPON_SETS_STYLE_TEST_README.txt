HaploBox HF26.20.23 TEST — Weapon Sets UI position and theme

Scope: Visual hotfix only, based on HF26.20.22.
- HB SETS tab placed outside the Blizzard CharacterFrame (not over stats, item slots or existing tabs).
- Weapon Set sidecar docks beneath the tab on the right; left-side fallback when character window is near the right edge.
- Existing shared MenuStyle.Window / MenuStyle.Button palette: charcoal and gold, blue action buttons, green locked state, consistent with Haplo Loot windows.
- Existing lock, bag/equipment selection, exact-item identity and Pawn comparator unchanged.
- /reload preserves locks; Blizzard CharacterFrame artwork and dimensions untouched.
- Offline syntax and behaviour/style regression only. Must validate visual fit in WoW after update.

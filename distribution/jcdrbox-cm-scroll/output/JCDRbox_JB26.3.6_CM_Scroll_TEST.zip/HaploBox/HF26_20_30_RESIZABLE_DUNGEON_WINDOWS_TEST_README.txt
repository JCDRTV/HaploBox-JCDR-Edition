HF26.20.30 – RESIZABLE DUNGEON WINDOWS (TEST)
Baseline: HF26.20.29 Batched Pawn Scan.

Run Guide (Dungeon Run):
- Bottom-right corner resize handle; resize width and height by dragging.
- Minimum 470x405; remembers width/height and top-left position when resizing.
- Keeps timer, collapsed title, Stealth/Normal runs, manual boss checkmarks, and existing boss filtering.
- Reflows fixed character/arrow/percent columns; page size adjusts with window height.
- Dungeon chooser rows also paginate to fit the resized window.

Dungeon Advisor / BiS:
- Separate bottom-right corner resize handle; resize width and height by dragging.
- Minimum 820x475; remembers independent width and height after /reload.
- Left farm-dungeon list and right BiS-loot list both adapt visible rows, pagination, label widths,
  and column anchors to available width. Bottom status and footer remain anchored.
- Does not modify atlas data, PvE recommendations or the Pawn scoring and scan protocol.

Install the full ZIP on all Team A Druids through the manually invoked HaploBox UPDATE.
Only the leader Mael opens these windows. No automatic background updater checks.

Offline validation:
- All 32 Lua files compile in Lua 5.4 check.
- WoW UI mocked runtime confirms both frames create and resize independently,
  dimensions persist in SavedVariables, and smaller frames use fewer list rows.
- ZIP integrity and baseline file comparison verified.

INGAME acceptance still OPEN: drag each window at bottom-right to min/large,
check Pawn % alignment, advisor pagination, /reload size persistence, Run collapse and timer.

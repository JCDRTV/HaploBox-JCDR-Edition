HF26.20.37 TEST — Unique role-weighted dungeon priority, mousewheel+drag scroll, SPECIAL-only handling

Base: HF26.20.36 TEST, preserving readable Advisor summary, hover breakdown, and rank labels. No network protocol or HF26.20.29 batched scanner changes.

Dungeon priority:
- One item ID counts ONCE per dungeon, even if it appears on several bosses or is wanted by multiple Druids.
- Roles preserved: Mael Tank, Lyra Healer, Elya/Nyra/Ayla DPS.
- Weight per unique item ID = 3 if at least one Tank needs it, otherwise 2 if any Healer needs it, otherwise 1 if DPS needs it.
- Role counters T/H/D each count distinct physical item IDs needed by that role; one item can appear in two role counters, but contributes only its highest weight once to the priority score.
- Individual per-Druid farm targets and actual Pawn % remain unchanged. PROVISIONAL scans may change the ranking after rescan.

Scrolling:
- Native mouse wheel and draggable vertical scrollbar available for Dungeon Advisor dungeon list and BiS details, Dungeon Run boss/loot and dungeon chooser; offset moves two rows per wheel event, no need to page-click.
- Existing page arrow buttons retained as fallback. Dynamic visible rows and window size remain supported.

Known special-effects-only item:
- Nightskulker Ring (273820) verified by user's AtlasLoot tooltip is separate SPECIAL when Pawn returns NO_ITEM/NO_STATS/NO_SCORE. No invented 0% or BiS conclusion.
- SPECIAL listed once as manual review at end of selected Dungeon Advisor detail list, and in coverage/diagnostic output. It does not contribute to loot rank or block a boss solely by its missing Pawn score.
- Unrecognized item IDs and other NOSTATS remain UNKNOWN; do not broaden exception without item-specific evidence.

Protections: Weapon Sets, Baganator hover + hotkeys, Unique-Equipped, Pawn Forever scales, fast scan/network timing, Dungeon Run timers, ALT-hover, Quick Menu, Mini UI, Smart Follow, macros untouched.

Manual UPDATE only. Ingame user acceptance OPEN.

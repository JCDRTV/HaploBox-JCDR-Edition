HF26.20.32 - UNIQUE OWNED GUARD TEST

BASE: HF26.20.31
STATUS: offline test; ingame test pending.

A Pawn-recommended Unique/Unique-Equipped item is excluded for a character who already owns a copy (equipped OR bags). The item receives status OWNED from that character, and the Party BiS planner filters it out; another Druid who does not own it may still have a goal. Non-unique rings remain eligible for a second slot. A worn ring whose uniqueness cannot be inspected remains VERIFY rather than a false BiS upgrade. A bag change that changes ownership of scanned candidates invalidates the affected local character scan until rescan. All 5 Druids need this protocol version; batch size and pacing are unchanged. No changes to UI, weapon sets, macro, timers or updater.

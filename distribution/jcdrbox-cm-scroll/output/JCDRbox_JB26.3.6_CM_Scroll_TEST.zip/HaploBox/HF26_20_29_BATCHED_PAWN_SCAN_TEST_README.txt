HF26.20.29 - BATCHED PAWN SCAN (TEST / INGAME ACCEPTANCE OPEN)

Base: HF26.20.28, with smart prefilter and within-scan cache.

- One B|scan|target|id1,id2,... packet for up to 16 item IDs (not 16 separate Q).
- Mael sends exactly one addressed B every >=0.90s, retaining successful request pacing.
- Follower evaluates its own Pawn scale and queues compact V|scan|... responses,
  split at <=224 bytes and sent at >=0.42s intervals (no simultaneous burst).
- Unknown/unsupported Pawn status/why uses full original R packet (no guessed scores).
- Cache data loaded later still emits original R with matching scan token.
- Exactly two bounded retry rounds of only missing follower/item pairs, grouped.
- Strict team sender/target identity, packet size, item bounds, unique IDs, numeric
  bounds, scan generation and original old-UNCACHED overwrite protections.
- PING version changed to HF26.29. Update ALL five clients before testing.
- No extra background scans. Existing 2H/1H locks, BiS, timer and Mini UI untouched.

INGAME: Update all five Druids via manual HaploBox UPDATE; reload all.
Use /hblootnet diag to inspect B packets, accepted rows, missing scores.
Compare total SCAN PARTY BIS time, per-dungeon status and NO_REPLY against HF26.20.28.
If any unexpected missing scores, do NOT silently trust BiS - share diag/screens.

HF26.20.24 — Weapon Sets CharacterFrame button placement TEST

User requested HB SETS in the red-marked unused space at the bottom-left of the native Blizzard Character panel.
- HB SETS is now anchored BOTTOMLEFT of CharacterFrame, 10px right and 12px up; button 92x24px.
- It remains part of original CharacterFrame, appears only with C, and follows window moves.
- Full Weapon Sets selection/lock UI remains the same optional sidecar, docked to the outside right; left fallback near screen edge.
- Shared dark/gold HaploBox styling, locked item references, manual updates, Pawn comparator, 0.90-second request pacing, Dungeon Run Guide and timer untouched.
- Only WeaponSets.lua + TOC + history + this README changed relative to HF26.20.23.
- Ingame acceptance OPEN: screenshot of C window and open Weapon Sets on Mael requested.

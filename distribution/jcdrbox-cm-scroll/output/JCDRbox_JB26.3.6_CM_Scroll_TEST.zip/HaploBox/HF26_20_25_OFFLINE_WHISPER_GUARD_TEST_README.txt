HF26.20.25 – OFFLINE WHISPER GUARD TEST (2026-11-22)

Observed in HF26.20.24: after Nyra/Ayla went offline, Blizzard chat repeatedly reported "No player named ... is currently playing", even after BOX OFF.

Root cause in code: Alpha4 periodic status telemetry still uses WHISPER and the party roster can contain offline names. The old sendRaw allowed them when UnitExists/PartyName was true; it did not check UnitIsConnected. BOX OFF switches targeting macros but does not disable all other party-status features.

Fix: Alpha4/Sync.lua uses a live party unit + UnitIsConnected before sending add-on WHISPER. Offline recipients and an unavailable/ambiguous connection API are skipped, with no auto retries. Legitimate online party recipients still receive telemetry; explicit UI sync remains available to online players. No changes to alpha4 trust model.

Files changed vs HF26.20.24: Alpha4/Sync.lua, HaploBox.toc, HF_VERSION_HISTORY.txt, this README. No other LUA changes.

Offline: Lua syntax, direct message routing tests (offline/online/no connection API/untrusted), 1:1 protected-file comparison and ZIP integrity. Ingame acceptance OPEN: turn BOX OFF with Nyra/Ayla offline, monitor chat >1 minute, verify online teammates still sync; then reconnect offline members and confirm normal syncing resumes.

No automatic updater / background update checks; distribution via existing HaploBox UPDATE.

HF26.20.28 SMART SCAN TEST (built on HF26.20.27)

Why: full 15-dungeon scan at 0.90 sec per addressed follower request took >10 minutes.
Changes are limited to LootPlanner.lua, TOC, HF_VERSION_HISTORY and this README.

1. Before emitting any Pawn query, evaluate AtlasLoot item/class/subclass/inventory type.
   Skip only DEFINITELY non-Druid gear, and items requiring higher level
   than ALL ONLINE party members. Missing item cache/type/required level
   => keep item and scan conservatively (do not silently lose BiS candidates).
2. Memoize completed per-item/per-character replies across dungeons WITHIN
   ONE manual scan only, only at identical observed character level.
   New explicit scan, gear/level changed or weapon lock change clears cache.
3. Do not burn additional 0.90s gaps for already-answered pairs. Preserve
   exactly ONE actual addon-message Q per 0.90s and the 2 retry rounds.
4. Print skipped entries and reused results at scan completion; show local
   dungeon skipped count during scan.

Not included: arbitrary class/spec support, simultaneous network fanout,
smaller send delay, persistent cross-scan Pawn cache, automatic background scan.

Acceptance: Ingame check measured end-to-end 15-dungeon time, number of
queries, follower replies, no silent missing BiS items; 5/5 completeness.
Do NOT assume a particular time improvement based on offline mock tests.

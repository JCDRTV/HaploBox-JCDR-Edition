HaploBox Profession Guide – HF26.PG.1 TEST (23 Nov 2026)
=========================================================
Phase 1: functioning main Advisor and compact Profession Run window.

SAFE TEST INSTALL
1) KEEP your existing HaploBox HF26.20.44 TEST installation unchanged.
2) Extract the folder HaploBoxProfessionGuide into the SAME AddOns directory
   where the existing HaploBox folder is installed.
3) Start/reload WoW. Make sure "HaploBox Profession Guide" is enabled.
4) /hbprof  or  /hbpg  opens the Profession Advisor.
   /hbpg run   opens the compact run window.
   /hbpg scan  refreshes and broadcasts your current profession skills.
   /hb professions  also works when the original /hb command is present.
5) Install this companion folder on EACH member of the party for shared skills.
   Test on Mael first, then Lyra, Elya, Nyra and Ayla.

CURRENTLY INCLUDED
- Nine profession tiles: BS, LW, ENG, TAIL, ALCH, ENCH, MIN, HERB, SKIN.
- Actual skill/skill-cap scan from the game API (modern and Classic fallback).
- Party sync over an isolated addon message prefix HBPG1 (online group only).
- Party characters, trained/not trained, last synchronized/cached indicators.
- Compact window with profession, chosen character, actual skill and skill band.
- No changes to the existing HaploBox addon's files, SavedVariables, macros,
  Weapon Sets, Baganator, Pawn, Dungeon Advisor or Dungeon Run.

NOT YET INCLUDED
- Detailed 1-300 recipe routes; material requirements; trainer/recipe locations.
- Party-wide bags/banks inventory and reservations.
- Item hover tags BS - LW - ENG - TAIL - ALCH - ENCH.
- Native Quick Menu button (requires verifying the packaged release's menu API).
These belong to later phases. We intentionally do NOT show false NEED/NOT NEEDED.

KNOWN TEST LIMITATIONS
- Actual Forever in-game API and UI validation is still required.
- Party data is received only while characters are grouped and online; cached
  data is marked after 3 minutes without a live update. There is no hidden
  access to another character's bank or bags in this phase.
- Non-English profession names may require additional name aliases on Classic
  if no profession skillLine ID is provided by its API.
- In a group larger than five, the main window only displays five character
  detail rows (the party-specific intended scope).

ROLLBACK
Delete the standalone HaploBoxProfessionGuide folder and reload WoW.
The existing HaploBox TEST build is completely untouched.

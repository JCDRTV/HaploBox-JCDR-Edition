-- JCDR Edition / TB19.1q SPELLBOOK UI: linked windows, direct pickup and
-- class spell cards. Blizzard actions always need explicit hardware input.
-- Existing personal macros and bindings are never overwritten silently.
local HB=HaploBox
local panel,bindingWindow,bindingNotice,notice,content,boxContent,spellContent,footer,tabButtons,rows,spellCards,bookHeading
local page="box"
local spellPage=1
local PER_PAGE=12  -- Two columns x six rows; preserves the existing icon size
local spellBook={};local scannedBook=false
local waiting,conflict=nil,nil
local BOX={
    {id="follow",name="HB Smart Follow",title="Smart Follow",kind="follow"},
    {id="assist",name="HB Assist",title="Assist",kind="boxassist"},
    {id="trade",name="HB Trade",title="Trade with Leader",kind="trade"},
    {id="role",name="HB Set Role",title="Set Role",kind="role"},
    {id="quickmenu",title="Quick Menu",kind="native",binding="HAPLOBOX_QUICK_TOGGLE"},
    {id="mainmini",title="Main / Mini UI",kind="native",binding="HAPLOBOX_HEAL_TOGGLE"},
}
-- Level 1-30 WoW Forever Druid active spell/ability presets. Class-quest,
-- trainer and talent actions can only be created if known by the character.
-- Passive skills are never listed or offered as a macro. More levels later.
-- kind: assist follows leader target only on follower BOX ON; heal uses
-- shift self > friendly mouseover > party1 on follower / self on leader.
-- cast never changes target; buff chooses friendly target/self; revive requires dead target.
local SMART={DRUID={
    {id="wrath",name="HB Wrath",title="Wrath",spell="Wrath",kind="assist",level=1,icon="Spell_Nature_AbolishMagic"},
    {id="moonfire",name="HB Moonfire",title="Moonfire",spell="Moonfire",kind="assist",level=4,icon="Spell_Nature_StarFall"},
    {id="starfire",name="HB Starfire",title="Starfire",spell="Starfire",kind="assist",level=20,icon="Spell_Arcane_StarFire"},
    {id="roots",name="HB Entangle",title="Entangling Roots",spell="Entangling Roots",kind="assist",level=8,icon="Spell_Nature_StrangleVines"},
    {id="hibernate",name="HB Hibernate",title="Hibernate",spell="Hibernate",kind="assist",level=18,icon="Spell_Nature_Sleep"},
    {id="faeriefire",name="HB Faerie Fire",title="Faerie Fire",spell="Faerie Fire",kind="assist",level=18,icon="Spell_Nature_FaerieFire"},
    {id="healingtouch",name="HB Healing Touch",title="Healing Touch",spell="Healing Touch",kind="heal",level=1,icon="Spell_Nature_HealingTouch"},
    {id="rejuvenation",name="HB Rejuvenation",title="Rejuvenation",spell="Rejuvenation",kind="heal",level=4,icon="Spell_Nature_Rejuvenation"},
    {id="regrowth",name="HB Regrowth",title="Regrowth",spell="Regrowth",kind="heal",level=12,icon="Spell_Nature_ResistNature"},
    {id="mark",name="HB Mark",title="Mark of the Wild",spell="Mark of the Wild",kind="buff",level=1,icon="Spell_Nature_Regeneration"},
    {id="thorns",name="HB Thorns",title="Thorns",spell="Thorns",kind="buff",level=6,icon="Spell_Nature_Thorns"},
    {id="curepoison",name="HB Cure Poison",title="Cure Poison",spell="Cure Poison",kind="buff",level=14,icon="Spell_Nature_NullifyPoison"},
    {id="revive",name="HB Revive",title="Revive",spell="Revive",kind="revive",level=12,icon="Spell_Nature_Resurrection"},
    {id="rebirth",name="HB Rebirth",title="Rebirth",spell="Rebirth",kind="revive",level=20,icon="Spell_Nature_Reincarnation"},
    {id="naturesgrasp",name="HB Nature Grasp",title="Nature's Grasp",spell="Nature's Grasp",kind="cast",level=10,icon="Spell_Nature_NaturesWrath"},
    {id="moonglade",name="HB Moonglade",title="Teleport: Moonglade",spell="Teleport: Moonglade",kind="cast",level=10,icon="Spell_Arcane_TeleportMoonglade"},
    {id="bear",name="HB Bear Form",title="Bear Form",spell="Bear Form",kind="cast",level=10,icon="Ability_Racial_BearForm"},
    {id="maul",name="HB Maul",title="Maul",spell="Maul",kind="assist",level=10,icon="Ability_Druid_Maul"},
    {id="growl",name="HB Growl",title="Growl",spell="Growl",kind="cast",level=10,icon="Ability_Physical_Taunt"},
    {id="demoroar",name="HB Demo Roar",title="Demoralizing Roar",spell="Demoralizing Roar",kind="cast",level=10,icon="Ability_Druid_DemoralizingRoar"},
    {id="enrage",name="HB Enrage",title="Enrage",spell="Enrage",kind="cast",level=12,icon="Ability_Druid_Enrage"},
    {id="bash",name="HB Bash",title="Bash",spell="Bash",kind="assist",level=14,icon="Ability_Druid_Bash"},
    {id="aquatic",name="HB Aquatic Form",title="Aquatic Form",spell="Aquatic Form",kind="cast",level=16,icon="Ability_Druid_AquaticForm"},
    {id="swipe",name="HB Swipe",title="Swipe",spell="Swipe",kind="cast",level=16,icon="INV_Misc_MonsterClaw_03"},
    {id="cat",name="HB Cat Form",title="Cat Form",spell="Cat Form",kind="cast",level=20,icon="Ability_Druid_CatForm"},
    {id="claw",name="HB Claw",title="Claw",spell="Claw",kind="assist",level=20,icon="Ability_Druid_Rake"},
    {id="rip",name="HB Rip",title="Rip",spell="Rip",kind="assist",level=20,icon="Ability_GhoulFrenzy"},
    {id="shred",name="HB Shred",title="Shred",spell="Shred",kind="assist",level=20,icon="Spell_Shadow_VampiricAura"},
    {id="prowl",name="HB Prowl",title="Prowl",spell="Prowl",kind="cast",level=20,icon="Ability_Ambush"},
    {id="omen",name="HB Omen",title="Omen of Clarity",spell="Omen of Clarity",kind="cast",level=20,icon="Spell_Nature_CrystalBall",passive=true},
    {id="feralcharge",name="HB Feral Charge",title="Feral Charge",spell="Feral Charge",kind="assist",level=20,icon="Ability_Hunter_Pet_Bear",optional=true},
    -- Forever 21-30: first-rank active spells only. Existing rank updates use
    -- the same macros, so never duplicate a spell just for a later rank.
    {id="sootheanimal",name="HB Soothe Animal",title="Soothe Animal",spell="Soothe Animal",kind="assist",level=22,icon="Ability_Hunter_BeastSoothe"},
    {id="rake",name="HB Rake",title="Rake",spell="Rake",kind="assist",level=24,icon="Ability_Druid_Disembowel"},
    {id="ferociousbite",name="HB Fero Bite",title="Ferocious Bite",spell="Ferocious Bite",kind="assist",level=24,icon="Ability_Druid_FerociousBite"},
    {id="removecurse",name="HB Remove Curse",title="Remove Curse",spell="Remove Curse",kind="buff",level=24,icon="Spell_Holy_RemoveCurse"},
    {id="tigersfury",name="HB Tiger Fury",title="Tiger's Fury",spell="Tiger's Fury",kind="cast",level=24,icon="Ability_Mount_JungleTiger"},
    {id="insectswarm",name="HB Insect Swarm",title="Insect Swarm",spell="Insect Swarm",kind="assist",level=25,icon="Spell_Nature_InsectSwarm",optional=true},
    {id="lacerate",name="HB Lacerate",title="Lacerate",spell="Lacerate",kind="assist",level=25,icon="Ability_Druid_Lacerate",optional=true},
    {id="abolishpoison",name="HB AbolishPois",title="Abolish Poison",spell="Abolish Poison",kind="buff",level=26,icon="Spell_Nature_NullifyPoison_02"},
    {id="dash",name="HB Dash",title="Dash",spell="Dash",kind="cast",level=26,icon="Ability_Druid_Dash"},
    {id="challengingroar",name="HB Chall Roar",title="Challenging Roar",spell="Challenging Roar",kind="cast",level=28,icon="Ability_Druid_ChallangingRoar"},
    {id="cower",name="HB Cower",title="Cower",spell="Cower",kind="cast",level=28,icon="Ability_Druid_Cower"},
    {id="travelform",name="HB Travel Form",title="Travel Form",spell="Travel Form",kind="cast",level=30,icon="Ability_Druid_TravelForm"},
    {id="tranquility",name="HB Tranquility",title="Tranquility",spell="Tranquility",kind="cast",level=30,icon="Spell_Nature_Tranquility"},
    {id="naturesswiftness",name="HB Nature Swift",title="Nature's Swiftness",spell="Nature's Swiftness",kind="cast",level=30,icon="Spell_Nature_RavenForm",optional=true},
}}
-- Forever client spell facts, source: https://wowguildhub.com/wow-forever/guide/spellbook/ (build 1.60.1.71091, 24 Nov 2026), supplemented by current client spellbook.
-- t talent, q quest/racial/other prerequisite, p passive, ? unknown level; no claims of live availability.
local FOREVER={
    WARRIOR={
        {"Arms","Battle Stance=1|Charge=4|Hamstring=8|Heroic Strike=1|Meathook=?|Mocking Blow=16|Mortal Strike=t40|Overpower=12|Rend=4|Retaliation=20|Spearing Strike=t25|Sweeping Strikes=t30|Tactical Mastery=p14|Thunder Clap=6|Victory Rush=20"},
        {"Fury","Battle Shout=1|Berserker Rage=30|Berserker Stance=q30|Bloodthirst=t40|Challenging Shout=26|Cleave=20|Death Wish=t30|Demoralizing Shout=14|Execute=24|Intercept=30|Intimidating Shout=22|Piercing Howl=t20|Pummel=38|Reckless Swings=t25|Recklessness=50|Slam=20|Whirlwind=36"},
        {"Protection","Bloodrage=10|Concussion Blow=t30|Defensive Stance=q10|Disarm=18|Last Stand=t20|Revenge=14|Shield Bash=12|Shield Block=16|Shield Slam=t40|Shield Wall=28|Sunder Armor=10|Taunt=10|Valor of Azeroth=?"},
    },
    PALADIN={
        {"Holy","Blessing of Wisdom=14|Cleanse=42|Consecration=20|Divine Favor=t20|Enhanced Blessings=p?|Exorcism=20|Flash of Light=20|Greater Blessing of Wisdom=54|Hammer of Wrath=44|Holy Light=1|Holy Shock=t30|Holy Wrath=50|Horn of Lordaeron=?|Judgement of Light=30|Judgement of Righteousness=1|Judgement of Wisdom=38|Lay on Hands=10|Light's Vigil=t40|Oath of Light=t25|Purify=8|Redemption=q?|Seal of Light=30|Seal of Righteousness=1|Seal of Wisdom=38|Sense Undead=?|Turn Undead=?"},
        {"Protection","Blessing of Freedom=18|Blessing of Kings=20|Blessing of Protection=10|Blessing of Sacrifice=46|Concentration Aura=22|Devotion Aura=1|Divine Intervention=30|Divine Protection=6|Divine Shield=34|Fire Resistance Aura=36|Frost Resistance Aura=32|Greater Blessing of Kings=60|Hammer of Justice=8|Hammer of the Righteous=40|Holy Shield=t30|Judgement of Fury=25|Judgement of Justice=22|Righteous Fury=10|Seal of Fury=10|Seal of Justice=22|Shadow Resistance Aura=28|Swift Judgement=t25|Templar's Bulwark=t20"},
        {"Retribution","Avenging Wrath=?|Blessing of Might=4|Divine Sacrifice=?|Exorcist=?|Greater Blessing of Might=52|Holy Strike=6|Judgement=4|Judgement of Martyrdom=?|Judgement of the Crusader=12|Repentance=t30|Retribution Aura=16|Righteous Judgement=1|Seal of Command=t20|Seal of Martyrdom=?|Seal of the Crusader=6|Summon Charger=q?|Summon Warhorse=q?"},
    },
    HUNTER={
        {"Beast Mastery","Aspect of the Beast=?|Aspect of the Cheetah=20|Aspect of the Falcon=?|Aspect of the Hawk=10|Aspect of the Monkey=4|Aspect of the Pack=40|Aspect of the Wild=46|Beast Lore=?|Bestial Wrath=t40|Call Pet=q?|Dismiss Pet=q?|Eagle Eye=?|Eyes of the Beast=14|Feed Pet=q?|Intimidation=t30|Kill Command=?|Mend Pet=12|Revive Pet=q10|Scare Beast=?|Summon Hawk=t25|Tame Beast=q?|Tranquilizing Shot=q60|Beast Training=q?"},
        {"Marksmanship","Arcane Shot=6|Auto Shot=1|Black Arrow=?|Chimera Shot - Scorpid=?|Chimera Shot - Serpent=?|Chimera Shot - Viper=?|Concussive Shot=8|Distracting Shot=12|Enchanted Flare=?|Flare=32|Hunter's Mark=6|Multi-Shot=18|Rapid Fire=26|Scatter Shot=t30|Scorpid Sting=22|Serpent Sting=4|Sniper Shot=t40|Trueshot Aura=t25|Viper Sting=36|Volley=40|Aimed Shot=?"},
        {"Survival","Counterattack=t30|Deterrence=t20|Disengage=20|Explosive Trap=34|Feign Death=30|Freezing Trap=20|Frost Trap=28|Heart of the Lion=?|Immolation Trap=16|Mongoose Bite=16|Raptor Strike=1|Readiness=?|Strider Kick=t30|Track Beasts=1|Track Demons=32|Track Dragonkin=50|Track Elementals=26|Track Giants=40|Track Hidden=24|Track Humanoids=10|Track Undead=18|Wing Clip=12"},
    },
    ROGUE={
        {"Assassination","Ambush=18|Cheap Shot=26|Cold Blood=t25|Eviscerate=1|Expose Armor=14|Garrote=14|Kidney Shot=30|Mutilate=t40|Rupture=20|Slice and Dice=10"},
        {"Combat","Adrenaline Rush=t40|Backstab=4|Blade Flurry=t30|Evasion=8|Feint=16|Gouge=6|Kick=12|Riposte=t20|Shank=?|Shiv=?|Sinister Strike=1|Sprint=10"},
        {"Subtlety","Blind=34|Death Mark=t40|Detect Traps=p?|Disarm Trap=30|Distract=22|Ghostly Strike=t25|Hemorrhage=t30|Pick Pocket=4|Poised=p?|Premeditation=t20|Preparation=t30|Redirect=?|Safe Fall=p?|Sap=10|Stealth=1|Vanish=22|Pick Lock=q?"},
        {"Poisons","Atrophic Poison=?|Blinding Powder=?|Crippling Poison=?|Crippling Poison II=?|Deadly Poison=?|Deadly Poison II=?|Deadly Poison III=?|Deadly Poison IV=?|Deadly Poison V=?|Instant Poison=?|Instant Poison II=?|Instant Poison III=?|Instant Poison IV=?|Instant Poison V=?|Instant Poison VI=?|Mind-numbing Poison=?|Mind-numbing Poison II=?|Mind-numbing Poison III=?|Numbing Poison=?|Occult Poison I=?|Occult Poison II=?|Poisons=q?|Sebacious Poison=?|Wound Poison=?|Wound Poison II=?|Wound Poison III=?|Wound Poison IV=?"},
    },
    PRIEST={
        {"Discipline","Confounding Flash=10|Contingency Plan=20|Dispel Magic=18|Divine Spirit=30|Elune's Grace=q20|Feedback=q20|Focused Casting=p?|Increased Fortitude=p?|Inner Fire=12|Inner Focus=t20|Levitate=34|Mana Burn=24|Penance=t30|Power Infusion=t40|Power Word: Fortitude=1|Power Word: Shield=6|Prayer of Fortitude=48|Prayer of Spirit=60|Shackle Undead=20|Starshards=q10"},
        {"Holy","Abolish Disease=32|Chastise=q20|Cure Disease=14|Desperate Prayer=q10|Divine Grace=q10|Fear Ward=20|Flash Heal=20|Greater Heal=40|Heal=16|Holy Fire=20|Holy Nova=t20|Lesser Heal=1|Lightwell=q40|Prayer of Healing=30|Prayer of Mending=t40|Renew=8|Resurrection=10|Smite=1"},
        {"Shadow","Dark Sacrifice=q20|Devouring Plague=q20|Fade=8|Hex of Weakness=q10|Mind Blast=10|Mind Control=30|Mind Flay=t20|Mind Soothe=20|Mind Vision=22|Prayer of Shadow Protection=56|Psychic Scream=14|Shadow Protection=30|Shadow Word: Pain=4|Shadowform=t40|Shadowguard=q20|Silence=t30|Touch of Weakness=q10|Vampiric Embrace=t30|Shadow Word: Death=?"},
    },
    SHAMAN={
        {"Elemental","Call of the Ancestors=30|Call of the Elements=20|Call of the Spirits=40|Chain Lightning=32|Earth Shock=4|Earthbind Totem=6|Fire Nova=12|Flame Shock=10|Frost Shock=20|Lightning Bolt=1|Lightning Mastery=t40|Magma Totem=26|Purge=12|Searing Totem=10|Stoneclaw Totem=8|Totemic Recall=20"},
        {"Enhancement","Astral Recall=?|Far Sight=?|Fire Resistance Totem=28|Flametongue Totem=28|Flametongue Weapon=?|Frost Resistance Totem=24|Frostbrand Weapon=?|Ghost Wolf=20|Grace of Air Totem=42|Grounding Totem=30|Lightning Shield=8|Nature Resistance Totem=30|Rage of the Farseer=t40|Rockbiter Weapon=?|Sentry Totem=34|Stoneskin Totem=4|Stormstrike=t40|Strength of Earth Totem=10|Totemic Call=22|Water Breathing=?|Water Walking=?|Windfury Totem=32|Windfury Weapon=30|Windwall Totem=36"},
        {"Restoration","Ancestral Fortitude=p?|Ancestral Spirit=12|Chain Heal=40|Cure Disease=22|Cure Poison=16|Disease Cleansing Totem=38|Healing Stream Totem=20|Healing Wave=1|Lesser Healing Wave=20|Mana Spring Totem=26|Mana Tide Totem=t25|Nature's Swiftness=t30|Poison Cleansing Totem=22|Reincarnation=30|Riptide=t40|Tremor Totem=18|Water Shield=t20"},
    },
    MAGE={
        {"Arcane","Amplify Magic=18|Arcane Blast=t20|Arcane Brilliance=56|Arcane Explosion=14|Arcane Intellect=1|Arcane Missiles=8|Arcane Power=t40|Arcane Wrath=t25|Blink=20|Conjure Food=6|Conjure Mana Agate=28|Conjure Mana Citrine=48|Conjure Mana Jade=38|Conjure Mana Ruby=58|Conjure Water=4|Counterspell=24|Dampen Magic=12|Expanded Intellect=p?|Mage Armor=34|Mana Shield=20|Polymorph=8|Polymorph: Cow=q60|Portal: Darnassus=50|Portal: Ironforge=40|Portal: Orgrimmar=40|Portal: Stormwind=40|Portal: Thunder Bluff=50|Portal: Undercity=40|Presence of Mind=t30|Remove Lesser Curse=18|Slow Fall=12|Teleport: Dalaran=50|Teleport: Darnassus=30|Teleport: Ironforge=20|Teleport: Orgrimmar=20|Teleport: Stormwind=20|Teleport: Thunder Bluff=30|Teleport: Undercity=20|Evocation=20"},
        {"Fire","Blast Wave=t30|Combustion=t40|Fire Blast=6|Fire Vulnerability=p?|Fire Ward=20|Fireball=1|Flamestrike=16|Frostfire Bolt=40|Pyroblast=t20|Scorch=22"},
        {"Frost","Blizzard=20|Cold Snap=t30|Cone of Cold=26|Frost Armor=1|Frost Nova=10|Frost Ward=22|Frostbolt=4|Ice Armor=30|Ice Barrier=t40|Ice Block=t25|Ice Lance=t20"},
    },
    WARLOCK={
        {"Affliction","Amplify Curse=t20|Bane of Agony=8|Bane of Doom=60|Corruption=4|Curse of Exhaustion=t25|Curse of Idiocy=?|Curse of Recklessness=14|Curse of Tongues=26|Curse of Weakness=4|Death Coil=42|Drain Life=14|Drain Mana=24|Drain Soul=10|Fear=8|Howl of Terror=40|Life Tap=6|Siphon Life=t30|Wrack=t40"},
        {"Demonology","Banish=28|Create Firestone=28|Create Healthstone=10|Create Soulstone=18|Create Spellstone=36|Demon Armor=20|Demon Skin=1|Demonic Sacrifice=t20|Detect Invisibility=?|Eye of Kilrogg=?|Fel Armor=?|Fel Domination=t25|Health Funnel=12|Inferno=q50|Portal of Summoning=60|Ritual of Doom=q60|Ritual of Summoning=20|Sense Demons=?|Shadow Ward=?|Soul Link=t30|Subjugate Demon=30|Summon Felhunter=q30|Summon Imp=q1|Summon Incubus=q20|Summon Succubus=q20|Summon Voidwalker=q10|Unending Breath=?|Summon Felsteed=q?|Summon Dreadsteed=q?"},
        {"Destruction","Bane of Havoc=t30|Conflagrate=t25|Hellfire=30|Immolate=1|Incinerate=t40|Rain of Fire=20|Searing Pain=18|Shadow Bolt=1|Shadowburn=t20|Soul Fire=48"},
    },
    DRUID={
        {"Balance","Barkskin=44|Entangling Roots=8|Faerie Fire=18|Hibernate=18|Hurricane=40|Insect Swarm=t25|Moonfire=4|Moonkin Aura=p40|Moonkin Form=t40|Nature's Grasp=10|Soothe Animal=22|Starfire=20|Teleport: Moonglade=10|Thorns=6|Wrath=1"},
        {"Feral Combat","Aquatic Form=q16|Bash=14|Bear Form=q10|Cat Form=20|Challenging Roar=28|Claw=20|Cower=28|Dash=?|Demoralizing Roar=10|Dire Bear Form=40|Enrage=12|Feline Grace=p?|Feral Charge=t20|Ferocious Bite=24|Frenzied Regeneration=36|Growl=10|Lacerate=t25|Maul=10|Poised=p?|Pounce=36|Primal Bite=t40|Prowl=20|Rake=24|Ravage=32|Rip=20|Shifting Power=t40|Shred=20|Swipe=16|Tiger's Fury=24|Track Humanoids=?|Travel Form=30"},
        {"Restoration","Abolish Poison=26|Cure Poison=14|Deeper Wilds=p?|Enhanced Restoration=p?|Gift of the Wild=50|Healing Touch=1|Mark of the Wild=1|Nature's Swiftness=t30|Rebirth=20|Regrowth=12|Rejuvenation=4|Remove Curse=24|Revive=12|Swiftmend=t25|Tranquility=30|Wild Growth=t40|Omen of Clarity=p?|Innervate=?"},
    },
}

local function me() return UnitClass and select(2,UnitClass("player")) end
-- HF26.20.54: learned active class spells, with stable IDs and safe defaults.
-- Existing Druid presets above remain authoritative, including macro names.
local scanSpellbook, knownByName
local scanMode="none"
local scanAttempted=false
local RULES={}
local function rules(class,kind,names)
    RULES[class]=RULES[class] or {}
    for name in names:gmatch("[^|]+") do RULES[class][name:lower()]=kind end
end
rules("WARRIOR","assist","Heroic Strike|Charge|Rend|Hamstring|Overpower|Sunder Armor|Revenge|Shield Bash|Taunt|Mocking Blow|Execute|Mortal Strike|Bloodthirst|Slam|Pummel|Intercept|Disarm|Shield Slam|Concussion Blow")
rules("WARRIOR","cast","Battle Stance|Defensive Stance|Berserker Stance|Battle Shout|Demoralizing Shout|Challenging Shout|Thunder Clap|Cleave|Whirlwind|Shield Block|Shield Wall|Retaliation|Recklessness|Bloodrage|Berserker Rage|Sweeping Strikes|Last Stand|Death Wish")
rules("PALADIN","heal","Holy Light|Flash of Light|Lay on Hands")
rules("PALADIN","dual","Holy Shock")
rules("PALADIN","buff","Blessing of Might|Blessing of Wisdom|Blessing of Protection|Blessing of Freedom|Blessing of Salvation|Blessing of Sanctuary|Blessing of Light|Blessing of Kings|Blessing of Sacrifice|Greater Blessing of Might|Greater Blessing of Wisdom|Greater Blessing of Kings|Greater Blessing of Salvation|Greater Blessing of Sanctuary|Greater Blessing of Light|Purify|Cleanse")
rules("PALADIN","revive","Redemption|Resurrection")
rules("PALADIN","assist","Judgement|Judgment|Exorcism|Hammer of Justice|Hammer of Wrath|Turn Undead|Repentance|Crusader Strike|Judgement of Light|Judgement of Wisdom|Judgement of Justice")
rules("PALADIN","cast","Devotion Aura|Retribution Aura|Concentration Aura|Shadow Resistance Aura|Frost Resistance Aura|Fire Resistance Aura|Sanctity Aura|Seal of Righteousness|Seal of the Crusader|Seal of Command|Seal of Justice|Seal of Light|Seal of Wisdom|Divine Shield|Divine Protection|Divine Favor|Holy Shield|Consecration|Righteous Fury|Holy Wrath|Summon Warhorse|Summon Charger")
rules("HUNTER","assist","Auto Shot|Arcane Shot|Serpent Sting|Concussive Shot|Multi-Shot|Aimed Shot|Scatter Shot|Wyvern Sting|Scorpid Sting|Viper Sting|Distracting Shot|Hunter's Mark|Wing Clip|Raptor Strike|Mongoose Bite|Counterattack|Tranquilizing Shot|Kill Command|Kill Shot|Steady Shot|Explosive Shot|Black Arrow|Intimidation|Flare")
rules("HUNTER","cast","Aspect of the Hawk|Aspect of the Monkey|Aspect of the Cheetah|Aspect of the Pack|Aspect of the Beast|Aspect of the Wild|Mend Pet|Revive Pet|Call Pet|Dismiss Pet|Feed Pet|Tame Beast|Eyes of the Beast|Beast Lore|Scare Beast|Feign Death|Disengage|Freezing Trap|Frost Trap|Immolation Trap|Explosive Trap|Rapid Fire|Bestial Wrath|Trueshot Aura|Volley|Eagle Eye")
rules("ROGUE","assist","Sinister Strike|Eviscerate|Gouge|Backstab|Ambush|Garrote|Rupture|Cheap Shot|Kidney Shot|Kick|Hemorrhage|Ghostly Strike|Riposte|Blind|Expose Armor|Sap|Pick Pocket|Shiv|Mutilate|Envenom")
rules("ROGUE","cast","Stealth|Vanish|Sprint|Evasion|Feint|Slice and Dice|Preparation|Cold Blood|Blade Flurry|Adrenaline Rush|Premeditation|Distract|Pick Lock|Detect Traps|Disarm Trap")
rules("PRIEST","heal","Lesser Heal|Heal|Greater Heal|Flash Heal|Renew|Power Word: Shield|Desperate Prayer|Penance")
rules("PRIEST","dual","Dispel Magic")
rules("PRIEST","buff","Power Word: Fortitude|Prayer of Fortitude|Divine Spirit|Prayer of Spirit|Shadow Protection|Prayer of Shadow Protection|Cure Disease|Abolish Disease|Fear Ward|Power Infusion")
rules("PRIEST","revive","Resurrection")
rules("PRIEST","assist","Smite|Holy Fire|Shadow Word: Pain|Mind Blast|Mind Flay|Mana Burn|Shackle Undead|Mind Control|Silence|Devouring Plague|Vampiric Touch|Shadow Word: Death")
rules("PRIEST","cast","Inner Fire|Fade|Psychic Scream|Prayer of Healing|Holy Nova|Shadowform|Vampiric Embrace|Inner Focus|Lightwell|Levitate|Mind Vision|Spirit of Redemption")
rules("SHAMAN","heal","Healing Wave|Lesser Healing Wave|Chain Heal|Riptide")
rules("SHAMAN","buff","Water Walking|Water Breathing|Cure Poison|Cure Disease|Cleanse Spirit|Earth Shield")
rules("SHAMAN","revive","Ancestral Spirit")
rules("SHAMAN","assist","Lightning Bolt|Chain Lightning|Earth Shock|Flame Shock|Frost Shock|Purge|Stormstrike|Lightning Lasso|Lava Burst|Lava Lash|Hex")
rules("SHAMAN","cast","Ghost Wolf|Lightning Shield|Water Shield|Rockbiter Weapon|Flametongue Weapon|Frostbrand Weapon|Windfury Weapon|Astral Recall|Far Sight|Reincarnation|Elemental Mastery|Nature's Swiftness|Call of the Elements|Call of the Ancestors|Call of the Spirits")
rules("MAGE","assist","Fireball|Frostbolt|Arcane Missiles|Fire Blast|Scorch|Pyroblast|Polymorph|Counterspell|Cone of Cold|Arcane Blast|Ice Lance|Living Bomb|Frostfire Bolt")
rules("MAGE","buff","Arcane Intellect|Arcane Brilliance|Dampen Magic|Amplify Magic|Remove Lesser Curse|Remove Curse|Slow Fall")
rules("MAGE","cast","Frost Nova|Arcane Explosion|Flamestrike|Blizzard|Blast Wave|Ice Block|Ice Barrier|Mana Shield|Fire Ward|Frost Ward|Mage Armor|Ice Armor|Frost Armor|Molten Armor|Blink|Evocation|Presence of Mind|Arcane Power|Combustion|Cold Snap|Summon Water Elemental")
rules("WARLOCK","assist","Shadow Bolt|Corruption|Immolate|Curse of Agony|Curse of Weakness|Curse of Recklessness|Curse of Tongues|Curse of Elements|Curse of Shadow|Curse of Doom|Fear|Banish|Drain Life|Drain Soul|Drain Mana|Searing Pain|Shadowburn|Conflagrate|Death Coil|Siphon Life|Unstable Affliction|Incinerate|Haunt")
rules("WARLOCK","buff","Unending Breath|Detect Lesser Invisibility|Detect Invisibility|Detect Greater Invisibility")
rules("WARLOCK","cast","Life Tap|Dark Pact|Demon Armor|Demon Skin|Fel Armor|Health Funnel|Sacrifice|Demonic Sacrifice|Soul Link|Summon Imp|Summon Voidwalker|Summon Succubus|Summon Felhunter|Summon Felguard|Summon Dreadsteed|Summon Felsteed|Enslave Demon|Ritual of Summoning|Ritual of Doom|Hellfire|Rain of Fire|Howl of Terror|Shadow Ward|Create Healthstone|Create Soulstone|Create Firestone|Create Spellstone|Soulstone Resurrection")
rules("DRUID","assist","Faerie Fire (Feral)|Feral Faerie Fire|Pounce|Ravage|Mangle|Mangle (Bear)|Mangle (Cat)|Cyclone|Hurricane|Moonfire|Wrath|Starfire")
rules("DRUID","heal","Swiftmend|Nourish|Lifebloom|Wild Growth")
rules("DRUID","buff","Gift of the Wild|Innervate|Remove Curse|Remove Corruption")
rules("DRUID","revive","Revive|Rebirth")
rules("DRUID","cast","Dire Bear Form|Moonkin Form|Tree of Life|Barkskin|Frenzied Regeneration|Frenzied Regeneration (Bear)|Nature's Swiftness|Tiger's Fury")
rules("WARRIOR","assist","Victory Rush|Spearing Strike")
rules("PALADIN","assist","Holy Strike|Hammer of the Righteous|Judgement of Righteousness|Judgement of Fury|Judgement of the Crusader")
rules("WARLOCK","assist","Bane of Agony|Bane of Doom|Bane of Havoc|Curse of Exhaustion|Soul Fire|Subjugate Demon|Wrack")
rules("HUNTER","assist","Sniper Shot|Strider Kick")
rules("PRIEST","heal","Divine Grace|Prayer of Mending")
rules("PRIEST","assist","Chastise|Dark Sacrifice|Shadow Word: Death")
rules("DRUID","assist","Primal Bite")
local function baseSpellKey(spell)
    return type(spell)=="string" and spell:lower():gsub("%s*%(rank%s+%d+%)%s*$",""):match("^%s*(.-)%s*$") or nil
end
function HB.GetExplicitMacroKind(spell)
    local class,key=me(),baseSpellKey(spell)
    if not key then return nil end
    for _,entry in ipairs(SMART[class] or {}) do
        if not entry.passive and baseSpellKey(entry.spell)==key then return entry.kind end
    end
    return RULES[class] and RULES[class][key]
end
local function kindFor(class,key)
    local rule=RULES[class] and RULES[class][baseSpellKey(key)]
    if rule then return rule end
    -- Stances, auras, seals, totems, traps, teleports and unknown/custom
    -- spells remain ordinary local casts. Never infer targeting from a name.
    return "cast"
end
local function spellHash(s)
    local h=0
    for i=1,#s do h=(h*131+s:byte(i))%4294967296 end
    return h
end
local function autoEntry(class,data,key,reserved)
    if not data.name or data.name:find("[%c|;%[%]]") then return nil end
    local h=spellHash(class..":"..key)
    local clean=data.name:gsub("[^%w ]",""):gsub("%s+"," "):match("^%s*(.-)%s*$")
    local name="HB "..clean
    if #clean==0 or clean~=data.name or #name>16 or reserved[name] then
        local prefix=clean:sub(1,7):gsub("%s+$","")
        if prefix=="" then prefix="Spell" end
        name="HB "..prefix.." "..string.format("%05X",h%1048576)
    end
    if reserved[name] then return nil end
    return {id="auto"..class..string.format("%08X",h),name=name,title=data.name,
        spell=data.name,kind=kindFor(class,key),auto=true}
end
-- Stable legacy presets plus live spellbook entries. No macro or binding
-- is created by a scan, and the general/profession tab is not imported.
local function catalogFor(class)
    local out={}
    for _,g in ipairs(FOREVER[class] or {}) do
        for line in g[2]:gmatch("[^|]+") do
            local name,code=line:match("^(.-)=(.+)$")
            local level=tonumber(code:match("%d+"))
            local mode=code:sub(1,1)
            local special=mode=="t" and "Talent" or mode=="q" and "Quest / requirement" or mode=="p" and "Passive" or not level and "Check source" or nil
            out[name:lower()]={name=name,level=level,category=g[1],special=special,passive=mode=="p"}
        end
    end
    return out
end
local selectedCategory="All Spells"
local function activeSpells()
    if not scanAttempted and scanSpellbook then scanSpellbook() end
    local class=me()
    local facts=catalogFor(class)
    local out,seen,reserved,ids={},{},{},{}
    for _,e in ipairs(BOX) do if e.name then reserved[e.name]=true end end
    for _,e in ipairs(SMART[class] or {}) do
        local key=e.spell:lower()
        local learned=spellBook[key]
        local fact=facts[key]
        -- Preserve existing IDs and macro names for matching legacy entries.
        if fact or learned then
            local entry={}
            for k,v in pairs(e) do entry[k]=v end
            if fact then
                entry.level=fact.level;entry.category=fact.category;entry.special=fact.special;entry.passive=fact.passive or (learned and learned.passive==true)
            else entry.category="Other";entry.special="Check source";entry.level=nil end
            seen[key]=true;reserved[entry.name]=true;ids[entry.id]=true
            out[#out+1]=entry
        end
    end
    local keys={}
    for k in pairs(facts) do if not seen[k] then keys[#keys+1]=k end end
    table.sort(keys)
    for _,k in ipairs(keys) do
        local fact=facts[k]
        local e=autoEntry(class,fact,k,reserved)
        if e and not ids[e.id] then
            e.level=fact.level;e.category=fact.category;e.special=fact.special
            e.passive=fact.passive or (spellBook[k] and spellBook[k].passive==true)
            -- Race/faction dependent portals must not be presented as trainable to the wrong side.
            local faction=UnitFactionGroup and UnitFactionGroup("player")
            local city=e.spell:match("^Teleport: (.+)$") or e.spell:match("^Portal: (.+)$")
            local side=city and ({Ironforge="Alliance",Stormwind="Alliance",Darnassus="Alliance",Orgrimmar="Horde",Undercity="Horde",["Thunder Bluff"]="Horde"})[city]
            if side and side~=faction then e.special=side.." only" end
            out[#out+1]=e;seen[k]=true;reserved[e.name]=true;ids[e.id]=true
        end
    end
    keys={}
    for k in pairs(spellBook) do keys[#keys+1]=k end
    table.sort(keys)
    for _,k in ipairs(keys) do
        local d=spellBook[k]
        local explicit=RULES[class] and RULES[class][k]
        if class and RULES[class] and not seen[k] and (d.tab>1 or explicit) then
            local e=autoEntry(class,d,k,reserved)
            if e and not ids[e.id] then
                e.category=d.category or "Other";e.passive=d.passive==true
                e.special="Client spellbook";out[#out+1]=e;reserved[e.name]=true;ids[e.id]=true
            end
        end
    end
    table.sort(out,function(a,b)
        local al,bl=a.level or 99,b.level or 99
        if al~=bl then return al<bl end
        return a.title<b.title
    end)
    return out
end
local function filteredSpells()
    local out={}
    for _,e in ipairs(activeSpells()) do
        if selectedCategory=="All Spells" or selectedCategory==e.category then out[#out+1]=e end
    end
    return out
end

local function locked() return InCombatLockdown and InCombatLockdown() end
local function say(message)
    if notice then notice:SetText(message) end
    if bindingNotice then bindingNotice:SetText(message) end
    if HB.print then HB.print(message) end
end
local function bindingAction(entry)
    return entry.binding or ("MACRO "..entry.name)
end
local function keyFor(entry)
    if not GetBindingKey then return nil,nil end
    local ok,a,b=pcall(GetBindingKey,bindingAction(entry))
    if ok then return a,b end
end
local function macroIndex(name)
    if not GetMacroIndexByName then return nil end
    local ok,idx=pcall(GetMacroIndexByName,name)
    if ok and type(idx)=="number" and idx>0 then return idx end
end
local function myRegistry()
    local key=HB.Norm and HB.UnitIdent and HB.Norm(HB.UnitIdent("player"))
    return key and HB.db and HB.db.boxMacros and HB.db.boxMacros[key]
end
local function owned(entry)
    -- A native key action is owned by HaploBox's Bindings.xml, not a macro.
    if entry.kind=="native" then return true,nil end
    local idx=macroIndex(entry.name)
    if not idx then return false,nil end
    if entry.id=="follow" then
        local key=HB.Norm and HB.UnitIdent and HB.Norm(HB.UnitIdent("player"))
        return (key and HB.db and HB.db.smartFollowOwners and HB.db.smartFollowOwners[key]) and true or false,idx
    end
    local reg=myRegistry()
    local item=reg and reg[entry.name]
    if not item or not GetMacroBody then return false,idx end
    local ok,body=pcall(GetMacroBody,idx)
    local match=HB.SameMacroBody or function(a,b) return a==b end
    local valid=ok and (match(body,item.offBody) or match(body,item.onBody) or
        match(body,item.leaderBody) or match(body,item.legacyBody))
    return not not valid,idx
end
local function allEntries()
    return page=="box" and BOX or activeSpells()
end
local function preset(id)
    for _,entry in ipairs(BOX) do if entry.id==id then return entry end end
    for _,entry in ipairs(activeSpells()) do if entry.id==id then return entry end end
end
function HB.MacroLibraryEntries(section)
    if section=="spells" then return activeSpells() end
    return BOX
end
-- Read the actual spellbook rather than depending on GetSpellInfo(name),
-- which is inconsistent on several 1.x/Forever clients. Do not claim a
-- quest spell has been learned just because the character is level 20.
-- HF26.20.55: accept both client spellbook API families. Do not equate
-- an unavailable spellbook API with an unlearned spell.
local function api(fn,...)
    if type(fn)~="function" then return nil end
    local ok,a,b,c,d,e,f,g=pcall(fn,...)
    if ok then return a,b,c,d,e,f,g end
end
local function flagValue(v)
    if v==true or v==1 then return true end
    if v==false or v==0 then return false end
    return nil
end
local function rememberSpell(name,rank,texture,slot,tab,passive,id)
    if type(name)~="string" or name=="" then return end
    local key=name:lower()
    local rn=tonumber(type(rank)=="string" and rank:match("%d+") or "") or 0
    local prev=spellBook[key]
    if not prev or rn>=(prev.rankNumber or 0) then
        if prev and passive==nil then passive=prev.passive end
        spellBook[key]={name=name,texture=texture or (prev and prev.texture),slot=slot,
            rank=rank,rankNumber=rn,tab=tab,passive=passive,id=id}
    end
end
local function lookupSpell(name)
    local sn,_,icon,_,_,_,id=api(GetSpellInfo,name)
    if type(sn)=="string" then return sn,icon,id end
    if C_Spell then
        local info=api(C_Spell.GetSpellInfo,name)
        if type(info)=="table" then return info.name,info.iconID,info.spellID end
    end
end
knownByName=function(name)
    local sn,icon,id=lookupSpell(name)
    if type(id)~="number" and C_Spell then id=api(C_Spell.GetSpellIDForSpellIdentifier,name) end
    if type(id)~="number" then return nil,sn,icon end
    local bank=Enum and Enum.SpellBookSpellBank and Enum.SpellBookSpellBank.Player
    local confirmed,checked=false,false
    local function check(fn,...)
        local result=flagValue(api(fn,...))
        if result~=nil then checked=true;if result then confirmed=true end end
    end
    check(IsSpellKnown,id)
    check(IsPlayerSpell,id)
    check(IsSpellKnownOrOverridesKnown,id)
    if C_SpellBook then
        check(C_SpellBook.IsSpellKnown,id)
        if bank~=nil then check(C_SpellBook.IsSpellInSpellBook,id,bank,true) end
    end
    if confirmed then return true,sn,icon,id end
    if checked then return false,sn,icon,id end
    return nil,sn,icon,id
end
scanSpellbook=function()
    spellBook={};scannedBook=false;scanMode="none";scanAttempted=true
    local bookType=BOOKTYPE_SPELL or "spell"
    local tabs=api(GetNumSpellTabs)
    if type(tabs)=="number" and tabs>0 then
        for tab=1,tabs do
            local _,__,offset,count=api(GetSpellTabInfo,tab)
            if type(offset)=="number" and type(count)=="number" then
                for slot=offset+1,offset+count do
                    local name,rank=api(GetSpellBookItemName,slot,bookType)
                    if type(name)~="string" or name=="" then name,rank=api(GetSpellName,slot,bookType) end
                    local itemType,id=api(GetSpellBookItemInfo,slot,bookType)
                    if itemType~="FUTURESPELL" and itemType~="FLYOUT" then
                        local passive
                        if type(IsPassiveSpell)=="function" then
                            local ok,result=pcall(IsPassiveSpell,slot,bookType)
                            if ok then passive=flagValue(result);if result==nil then passive=false end end
                        end
                        local texture=api(GetSpellBookItemTexture,slot,bookType) or api(GetSpellTexture,slot,bookType)
                        rememberSpell(name,rank,texture,slot,tab,passive,id)
                    end
                end
            end
        end
        if next(spellBook) then scanMode="legacy" end
    end
    local bank=Enum and Enum.SpellBookSpellBank and Enum.SpellBookSpellBank.Player
    if C_SpellBook and bank~=nil then
        local n=api(C_SpellBook.GetNumSpellBookSkillLines)
        local types=Enum and Enum.SpellBookItemType
        if type(n)=="number" and n>0 then
            local modern=0
            for tab=1,n do
                local line=api(C_SpellBook.GetSpellBookSkillLineInfo,tab)
                if type(line)=="table" and type(line.itemIndexOffset)=="number" and type(line.numSpellBookItems)=="number" then
                    for slot=line.itemIndexOffset+1,line.itemIndexOffset+line.numSpellBookItems do
                        local info=api(C_SpellBook.GetSpellBookItemInfo,slot,bank)
                        local itemType=type(info)=="table" and info.itemType
                        local future=(types and itemType~=nil and (itemType==types.FutureSpell or itemType==types.Flyout))
                        if not future then
                            local name,rank=api(C_SpellBook.GetSpellBookItemName,slot,bank)
                            local id=type(info)=="table" and (info.spellID or info.actionID)
                            if type(name)~="string" and type(info)=="table" then name=info.name end
                            if type(name)~="string" and type(id)=="number" then name=lookupSpell(id) end
                            local passive=flagValue(api(C_SpellBook.IsSpellBookItemPassive,slot,bank))
                            if passive==nil and type(info)=="table" then passive=flagValue(info.isPassive) end
                            local texture=api(C_SpellBook.GetSpellBookItemTexture,slot,bank)
                            if type(name)=="string" and name~="" then
                                rememberSpell(name,rank,texture,slot,tab,passive,id)
                                modern=modern+1
                            end
                        end
                    end
                end
            end
            if modern>0 then scanMode=scanMode=="legacy" and "legacy+modern" or "modern" end
        end
    end
    scannedBook=next(spellBook)~=nil
    -- Fill class presets missed by a partial scan only when a known-spell
    -- API explicitly confirms them; never use mere database existence here.
    local class=me()
    local candidates={}
    for _,entry in ipairs(SMART[class] or {}) do
        candidates[entry.spell:lower()]=entry.spell
    end
    for key in pairs(RULES[class] or {}) do
        if not candidates[key] then candidates[key]=key end
    end
    local verified=0
    for key,name in pairs(candidates) do
        if not spellBook[key] then
            local known,sn,icon,id=knownByName(name)
            if known==true and type(sn)=="string" and sn:lower()==key then
                local passive
                if C_Spell and type(id)=="number" then passive=flagValue(api(C_Spell.IsSpellPassive,id)) end
                rememberSpell(sn,nil,icon,nil,2,passive,id);verified=verified+1
            end
        end
    end
    if verified>0 then scanMode=scanMode=="none" and "known-api" or scanMode.."+known-api" end
    scannedBook=next(spellBook)~=nil
end
local function learnedState(entry)
    if not entry.spell then return true end
    if not scanAttempted then scanSpellbook() end
    local data=spellBook[entry.spell:lower()]
    if data then return true end
    local known=knownByName(entry.spell)
    return known
end
local function spellKnown(entry)
    return not entry.passive and learnedState(entry)==true
end
local function spellStatus(entry)
    local learned=learnedState(entry)
    if learned==true then return "Learned"..(entry.passive and " / Passive" or ""),.30,.90,.42 end
    local lv=UnitLevel and UnitLevel("player")
    if type(lv)=="number" and entry.level and lv<entry.level then
        return "Level "..entry.level.." required",.95,.32,.32
    end
    if entry.special or entry.passive then return entry.special or "Passive",.74,.56,.94 end
    if learned==false or scannedBook then
        if type(lv)=="number" and entry.level and lv>=entry.level then
            return "Level "..entry.level.." / Check trainer",1,.63,.24
        end
    end
    return "Not verified",.65,.69,.76
end
HB.MacroSpellStatus=spellStatus

function HB.MacroSpellbookStatus()
    scanSpellbook()
    local count=0
    for _ in pairs(spellBook) do count=count+1 end
    return "Class="..tostring(me()).." | API="..scanMode.." | entries="..count
end
function HB.EnsureMacroPreset(id)
    local entry=preset(id)
    if not entry then say("Preset not available in this menu.") return false end
    if locked() then say("Create macros after combat.") return false end
    -- Native UI actions are declared in Bindings.xml. They never occupy
    -- Blizzard macro slots or touch the managed spell registry.
    if entry.kind=="native" then return true end
    if entry.kind=="follow" then
        if not HB.PrepareSmartFollow or not HB.PrepareSmartFollow() then
            say("Could not prepare Smart Follow.") return false end
        say("Smart Follow ready. Bind a key in this menu.")
        return true
    end
    if entry.spell and (entry.passive or not spellKnown(entry)) then say("Spell not confirmed learned or passive: "..entry.title);return false end
    local exists,idx=owned(entry)
    if idx then
        if entry.spell then
            -- An explicit click can reconcile a standard old /cast-only macro
            -- to follower BOX ON, including when ownership data was lost.
            -- Never adopt or modify arbitrary macros with the same name.
            local good,reason=HB.EnsureKnownBoxSpell and
                HB.EnsureKnownBoxSpell(entry.name,entry.spell,entry.kind)
            if not good then say(reason or (entry.name.." cannot be safely synchronized.")) return false end
            say(entry.name.." ready for current BOX profile.")
            return true
        end
        if not exists then say(entry.name.." exists but is not an unchanged HB macro. Not overwritten.") return false end
        say(entry.name.." already exists.")
        return true
    end
    if entry.passive then say(entry.title.." is passive and needs no macro.") return false end
    if not spellKnown(entry) then say("Not learned yet (trainer, quest or talent): "..entry.title) return false end
    local ok
    if entry.spell then ok=HB.AddBoxSpell and HB.AddBoxSpell(entry.spell,entry.kind,entry.name)
    else ok=HB.AddBoxAction and HB.AddBoxAction(entry.id) end
    if not ok then say("Could not create "..entry.name) return false end
    say(entry.name.." created.")
    return true
end
-- Explicit repair only: adopt exact canonical existing macros, never create
-- missing presets, overwrite imports/custom bodies or change bindings.
function HB.RepairExistingMacroPresets()
    if locked() then say("Repair macros after combat.");return false end
    local n,failed=0,0
    for _,entry in ipairs(activeSpells()) do
        if entry.spell and macroIndex(entry.name) then
            local ok,reason=HB.EnsureKnownBoxSpell(entry.name,entry.spell,entry.kind)
            if ok then n=n+1 else failed=failed+1;say(reason or ("Skipped "..entry.name)) end
        end
    end
    say("Macro repair: "..n.." existing presets verified; "..failed.." protected/failed. No new macros.")
    return failed==0
end
function HB.PickupMacroPreset(id)
    if locked() then say("Pick up macros after combat.") return false end
    local entry=preset(id)
    if not entry then return false end
    local own,idx=owned(entry)
    if not idx then say("Create the HB macro first; personal macros are untouched.") return false end
    if entry.spell then
        -- Keep the selected action bar macro synchronized to the active mode.
        -- Failed verification must NOT put an unsafe /cast-only macro on cursor.
        if not HB.EnsureMacroPreset(id) then return false end
    elseif not own then
        say("Existing macro is not a verified HB macro. Not picked up.") return false
    end
    if not PickupMacro then say("Blizzard PickupMacro API unavailable.") return false end
    local ok,result=pcall(PickupMacro,idx)
    if not ok or result==false then say("Could not pick up macro.") return false end
    say("Macro on cursor. Place it on a Blizzard action bar.")
    return true
end

local function bindKey(entry,slot,key,confirm)
    if locked() then say("Change bindings after combat.") return false end
    if not SetBinding or not SaveBindings or not GetCurrentBindingSet or not GetBindingAction or
        (entry.kind~="native" and not SetBindingMacro) then
        say("Blizzard binding API unavailable.") return false end
    if not HB.EnsureMacroPreset(entry.id) then return false end
    local first,second=keyFor(entry)
    local old=(slot==1 and first or second)
    if key=="" then
        if not old then return true end
        if not SetBinding or not SetBinding(old) then say("Unable to clear binding.") return false end
        SaveBindings(GetCurrentBindingSet());return true
    end
    local action=GetBindingAction(key)
    if action and action~="" and action~=bindingAction(entry) and not confirm then
        conflict={id=entry.id,slot=slot,key=key}
        say(key.." is assigned to "..tostring(action)..". Click the same key box again to CONFIRM replacement.")
        return false
    end
    -- Preserve a secondary binding if the primary changes (and vice versa).
    local success
    if entry.kind=="native" then success=SetBinding(key,entry.binding)
    else success=SetBindingMacro(key,entry.name) end
    if not success then say("Cannot bind "..key) return false end
    if old and old~=key and SetBinding then SetBinding(old) end
    SaveBindings(GetCurrentBindingSet())
    conflict=nil
    say(entry.title.." bound to "..key.." on this client.")
    return true
end
local function namedButton(parent,text,x,y,w,h,handler)
    local b=CreateFrame("Button",nil,parent,"UIPanelButtonTemplate")
    b:SetSize(w,h);b:SetPoint("TOPLEFT",parent,"TOPLEFT",x,y)
    b:SetText(text)
    b:SetScript("OnClick",handler)
    if HB.MenuStyle then HB.MenuStyle.Button(b,"blue") end
    return b
end
local function label(parent,text,x,y,width)
    local f=parent:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
    f:SetPoint("TOPLEFT",parent,"TOPLEFT",x,y)
    f:SetWidth(width or 300);f:SetJustifyH("LEFT")
    f:SetText(text or "")
    return f
end
local function roundIcon(parent,x,y,size)
    local b=CreateFrame("Button",nil,parent)
    b:SetSize(size,size);b:SetPoint("TOPLEFT",parent,"TOPLEFT",x,y)
    b.tex=b:CreateTexture(nil,"ARTWORK")
    b.tex:SetAllPoints()
    b.tex:SetTexture("Interface\\Icons\\INV_Misc_QuestionMark")
    b:SetHighlightTexture("Interface\\Buttons\\ButtonHilight-Square","ADD")
    return b
end
local function setIcon(tex,entry)
    if not entry or not entry.spell then return end
    local data=spellBook[entry.spell:lower()]
    local texture=data and data.texture
    if not texture and GetSpellTexture then
        local ok,art=pcall(GetSpellTexture,entry.spell)
        if ok then texture=art end
    end
    if not texture and GetSpellInfo then
        local ok,_,__,art=pcall(GetSpellInfo,entry.spell)
        if ok then texture=art end
    end
    -- Concrete fallback icons prevent a wall of red question marks even if
    -- this client cannot resolve spell textures by name before learning them.
    if not texture and entry.icon then texture="Interface\\Icons\\"..entry.icon end
    tex:SetTexture(texture or "Interface\\Icons\\INV_Misc_QuestionMark")
end
-- TB19.1q: popup windows share one placement calculation in ControlBar.lua.
-- If Quick Menu is open the Macro Menu attaches immediately to its right.
local function resetPlacement()
    if not panel then return end
    if HB.PositionMacroMenu then HB.PositionMacroMenu(true)
    else
        panel:ClearAllPoints()
        local quick=_G.HaploBoxControlsFlyout
        local party=_G.HaploBoxControlsPanel
        local target=quick and quick:IsShown() and quick or party
        if target then panel:SetPoint("TOPLEFT",target,"TOPRIGHT",7,0)
        else panel:SetPoint("TOPLEFT",UIParent,"TOPLEFT",15,-45) end
    end
end
local function setPage(which)
    page=which;waiting=nil;conflict=nil
    if which=="spells" then selectedCategory="All Spells";spellPage=1 end
    if which=="spells" then scanSpellbook() end
    if HB.RefreshMacroMenu then HB.RefreshMacroMenu() end
end
local function makeKeyButton(parent,entry,slot,x,y)
    local b=namedButton(parent,"Not Bound",x,y,93,23,function(self)
        if conflict and conflict.id==entry.id and conflict.slot==slot then
            bindKey(entry,slot,conflict.key,true)
            conflict=nil
            if HB.RefreshMacroMenu then HB.RefreshMacroMenu() end
            return
        end
        conflict=nil
        if not bindingWindow then return end
        waiting={entry=entry,slot=slot}
        say("Press a key for "..entry.title.." (ESC cancels; BACKSPACE removes binding).")
        bindingWindow:EnableKeyboard(true)
        if bindingWindow.SetPropagateKeyboardInput then bindingWindow:SetPropagateKeyboardInput(false) end
        if bindingWindow.SetKeyboardFocus then bindingWindow:SetKeyboardFocus() end -- optional API
        self:SetText("Press key...")
    end)
    b.entry,b.slot=entry,slot
    return b
end
local function refreshKeyWidgets(row,entry)
    local first,second=keyFor(entry)
    row.key1:SetText(first or "Not Bound")
    if row.key2 then row.key2:SetText(second or "Not Bound") end
end
local function makePanel()
    if panel then return end
    panel=CreateFrame("Frame","HaploBoxMacroLibrary",UIParent)
    panel.hbMenuName="MacroMenu"
    panel:SetSize(680,525);panel:SetFrameStrata("DIALOG")
    if HB.MenuStyle then HB.MenuStyle.Window(panel,32) end
    panel:SetClampedToScreen(true);panel:SetMovable(true);panel:EnableMouse(true)
    panel:RegisterForDrag("LeftButton")
    panel:SetScript("OnDragStart",function(self)
        if HB.db and HB.db.submenuLocks and HB.db.submenuLocks.MacroMenu==false and
           not (InCombatLockdown and InCombatLockdown()) then self:StartMoving() end
    end)
    panel:SetScript("OnDragStop",function(self)
        self:StopMovingOrSizing()
        if not (HB.db and HB.db.submenuLocks and HB.db.submenuLocks.MacroMenu==false) then return end
        local w,h=UIParent:GetWidth(),UIParent:GetHeight()
        local l,t=self:GetLeft(),self:GetTop()
        if l and t and w and h and w>0 and h>0 then
            local scale=self:GetEffectiveScale()/(UIParent:GetEffectiveScale() or 1)
            HB.db.submenuPositions=HB.db.submenuPositions or {}
            HB.db.submenuPositions.MacroMenu={
                math.max(0,math.min(0.97,l*scale/w)),
                math.max(0,math.min(0.97,1-t*scale/h)),
            }
        end
    end)
    panel:SetScript("OnHide",function(self)
        self:EnableKeyboard(false)
        waiting=nil;conflict=nil
    end)
    local function captureKey(self,key)
        local w=waiting
        if not w then return end
        waiting=nil;self:EnableKeyboard(false)
        if key=="ESCAPE" then say("Keybinding cancelled.")
        else
            local value=key
            if key=="BACKSPACE" or key=="DELETE" then value=""
            elseif key=="LSHIFT" or key=="RSHIFT" or key=="LCTRL" or key=="RCTRL" or key=="LALT" or key=="RALT" then
                say("Modifier alone is not a keybinding. Try a combination.")
                HB.RefreshMacroMenu();return
            else
                if IsControlKeyDown and IsControlKeyDown() then value="CTRL-"..value end
                if IsAltKeyDown and IsAltKeyDown() then value="ALT-"..value end
                if IsShiftKeyDown and IsShiftKeyDown() then value="SHIFT-"..value end
            end
            bindKey(w.entry,w.slot,value,false)
        end
        HB.RefreshMacroMenu()
    end
    panel:SetScript("OnKeyDown",captureKey)
    panel:EnableKeyboard(false)
    local bg=panel:CreateTexture(nil,"BACKGROUND")
    -- TB19.1r: the spellbook is a LAYOUT, not a parchment skin.
    bg:SetAllPoints();bg:SetColorTexture(0.024,0.051,0.082,0.99)
    local goldTrim=panel:CreateTexture(nil,"OVERLAY")
    goldTrim:SetPoint("TOPLEFT",panel,"TOPLEFT",5,-31)
    goldTrim:SetPoint("TOPRIGHT",panel,"TOPRIGHT",-5,-31)
    goldTrim:SetHeight(2);goldTrim:SetColorTexture(0.157,0.376,0.502,0.94)
    local heading=label(panel,"JCDRbox | Macro Menu",16,-16,520)
    heading:SetTextColor(0.396,0.851,1)
    panel.heading=heading
    local close=namedButton(panel,"X",634,-7,30,22,function() panel:Hide() end)
    panel.closeButton=close
    local lock=namedButton(panel,"L",598,-7,30,22,function(self)
        if InCombatLockdown and InCombatLockdown() then say("Change menu lock after combat.") return end
        HB.db.submenuLocks=HB.db.submenuLocks or {}
        local wasLocked=HB.db.submenuLocks.MacroMenu~=false
        if not wasLocked then
            local dragstop=panel:GetScript("OnDragStop")
            if dragstop then dragstop(panel) end
        end
        HB.db.submenuLocks.MacroMenu=not wasLocked
        if HB.MenuStyle then HB.MenuStyle.LockButton(self,not wasLocked)
        else self:SetText(wasLocked and "U" or "L") end
    end)
    panel:HookScript("OnShow",function()
        local isLocked=not (HB.db.submenuLocks and HB.db.submenuLocks.MacroMenu==false)
        if HB.MenuStyle then HB.MenuStyle.LockButton(lock,isLocked)
        else lock:SetText(isLocked and "L" or "U") end
    end)
    -- HF13: separate binding window, backed by the *existing* keybind engine.
    -- No keybind data is copied/rewritten merely by opening this window.
    bindingWindow=CreateFrame("Frame","HaploBoxKeybindingsWindow",UIParent)
    bindingWindow.hbMenuName="HaploBoxKeybindings"
    bindingWindow:SetSize(680,382);bindingWindow:SetFrameStrata("DIALOG")
    bindingWindow:SetClampedToScreen(true);bindingWindow:SetMovable(true)
    bindingWindow:EnableMouse(true);bindingWindow:RegisterForDrag("LeftButton")
    if HB.MenuStyle then HB.MenuStyle.Window(bindingWindow,32) end
    local bindingHeading=label(bindingWindow,"HaploBox - JCDR Edition | Keybindings",16,-16,520)
    bindingHeading:SetTextColor(0.396,0.851,1)
    namedButton(bindingWindow,"X",634,-7,30,22,function() bindingWindow:Hide() end)
    -- Saved locations inherited from the original shared popup once.
    HB.db.submenuPositions=HB.db.submenuPositions or {}
    local old=HB.db.submenuPositions.MacroKeybindings
    if type(old)=="table" and not HB.db.submenuPositions.MacroMenu then
        HB.db.submenuPositions.MacroMenu={old[1],old[2]}
    end
    if type(old)=="table" and not HB.db.submenuPositions.HaploBoxKeybindings then
        HB.db.submenuPositions.HaploBoxKeybindings={old[1],old[2]}
    end
    local function saveBindingPosition(self)
        local w,h=UIParent:GetWidth(),UIParent:GetHeight()
        local l,t=self:GetLeft(),self:GetTop()
        if l and t and w and h and w>0 and h>0 then
            local scale=self:GetEffectiveScale()/(UIParent:GetEffectiveScale() or 1)
            HB.db.submenuPositions.HaploBoxKeybindings={
                math.max(0,math.min(0.97,l*scale/w)),
                math.max(0,math.min(0.97,1-t*scale/h))}
        end
    end
    local bindingLock=namedButton(bindingWindow,"L",598,-7,30,22,function(self)
        if InCombatLockdown and InCombatLockdown() then say("Change menu lock after combat.");return end
        HB.db.submenuLocks=HB.db.submenuLocks or {}
        local wasLocked=HB.db.submenuLocks.HaploBoxKeybindings~=false
        if not wasLocked then saveBindingPosition(bindingWindow) end
        HB.db.submenuLocks.HaploBoxKeybindings=not wasLocked
        if HB.MenuStyle then HB.MenuStyle.LockButton(self,not wasLocked)
        else self:SetText(wasLocked and "U" or "L") end
    end)
    bindingWindow:HookScript("OnShow",function()
        local isLocked=not (HB.db.submenuLocks and HB.db.submenuLocks.HaploBoxKeybindings==false)
        if HB.MenuStyle then HB.MenuStyle.LockButton(bindingLock,isLocked)
        else bindingLock:SetText(isLocked and "L" or "U") end
    end)
    bindingWindow:SetScript("OnDragStart",function(self)
        if HB.db.submenuLocks and HB.db.submenuLocks.HaploBoxKeybindings==false and
           not (InCombatLockdown and InCombatLockdown()) then self:StartMoving() end
    end)
    bindingWindow:SetScript("OnDragStop",function(self)
        self:StopMovingOrSizing()
        if HB.db.submenuLocks and HB.db.submenuLocks.HaploBoxKeybindings==false then
            saveBindingPosition(self)
        end
    end)
    bindingWindow:SetScript("OnHide",function(self)
        self:EnableKeyboard(false);waiting=nil;conflict=nil
    end)
    bindingWindow:SetScript("OnKeyDown",captureKey)
    bindingWindow:EnableKeyboard(false)
    tabButtons={}
    tabButtons.box=namedButton(panel,"Multibox",16,-48,130,25,function()setPage("box")end)
    tabButtons.spells=namedButton(panel,"Smart Spells",155,-48,140,25,function()setPage("spells")end)
    for _,tab in pairs(tabButtons) do
        tab.activeLine=tab:CreateTexture(nil,"OVERLAY")
        tab.activeLine:SetPoint("BOTTOMLEFT",tab,"BOTTOMLEFT",4,1)
        tab.activeLine:SetPoint("BOTTOMRIGHT",tab,"BOTTOMRIGHT",-4,1)
        tab.activeLine:SetHeight(3)
        tab.activeLine:SetColorTexture(0.396,0.851,1,1)
    end
    content=CreateFrame("Frame",nil,panel)
    content:SetPoint("TOPLEFT",panel,"TOPLEFT",12,-83)
    content:SetSize(654,375)
    boxContent=CreateFrame("Frame",nil,content)
    boxContent:SetAllPoints(content)
    spellContent=CreateFrame("Frame",nil,content)
    spellContent:SetAllPoints(content)
    spellContent:Hide()
    local categoryButtons={}
    panel.categoryButtons=categoryButtons
    for i=1,6 do
        local b=namedButton(panel,"",12+(i-1)*108,-48,105,25,function(self)
            selectedCategory=self.category or "All Spells";spellPage=1;HB.RefreshMacroMenu()
        end)
        categoryButtons[i]=b
    end
    rows={}
    label(boxContent,"FUNCTION",10,-3,200)
    label(boxContent,"KEYBINDING",337,-3,130)
    for i,entry in ipairs(BOX) do
        local y=-24-(i-1)*38
        local row=CreateFrame("Frame",nil,boxContent)
        row:SetSize(654,36);row:SetPoint("TOPLEFT",boxContent,"TOPLEFT",0,y)
        local fill=row:CreateTexture(nil,"BACKGROUND")
        fill:SetAllPoints();fill:SetColorTexture(0.063,0.137,0.196,0.93)
        row.title=label(row,entry.title,10,-12,240)
        row.key1=makeKeyButton(row,entry,1,333,-6)
        -- Secondary legacy Blizzard binding is preserved; only one key box is displayed.
        row.key2=false
        row.create=namedButton(row,"Create",440,-6,71,23,function()
            HB.EnsureMacroPreset(entry.id);HB.RefreshMacroMenu()
        end)
        row.pick=namedButton(row,"Pick Up",520,-6,78,23,function()
            HB.PickupMacroPreset(entry.id)
        end)
        row.create:Hide();row.pick:Hide()
        local tips={
            follow="Follows the correct party member when you press the key. Direct: Follow the Group Leader. Dungeon: Healer follows the Group Leader; DPS follows the Healer.",
            assist="Targets the same enemy as the Group Leader.",
            trade="Opens a trade window with the Group Leader.",
            role="Assigns your Blizzard party role using the current team setup. Other users must assign their roles manually for now. Custom team configurations are planned for a future update.",
            quickmenu="Opens or closes the HaploBox Quick Menu.",
            mainmini="Switches between the Main UI and Mini UI. If you switch during combat, the UI changes automatically after combat ends.",
        }
        row:EnableMouse(true)
        row:SetScript("OnEnter",function(self)
            if GameTooltip then
                GameTooltip:SetOwner(self,"ANCHOR_RIGHT")
                GameTooltip:SetText(entry.title,1,0.82,0.42)
                GameTooltip:AddLine(tips[entry.id] or "",0.88,0.88,0.88,true)
                GameTooltip:Show()
            end
        end)
        row:SetScript("OnLeave",function() if GameTooltip then GameTooltip:Hide() end end)
        row.key1:SetScript("OnEnter",row:GetScript("OnEnter"))
        row.key1:SetScript("OnLeave",row:GetScript("OnLeave"))
        rows[i]=row
    end
    -- Dedicated keybinding rows are parented to the separate Keybindings
    -- window. Macro Menu still owns only its Spellbook/Smart Spells page.
    boxContent:SetParent(bindingWindow)
    boxContent:ClearAllPoints()
    boxContent:SetPoint("TOPLEFT",bindingWindow,"TOPLEFT",12,-67)
    boxContent:SetSize(654,295)
    bindingNotice=label(bindingWindow,"",16,-355,646)
    bindingNotice:SetWordWrap(true);bindingNotice:SetTextColor(0.95,0.79,0.48)
    bindingWindow:Hide()
    -- Separate, explicit opt-in configuration sync. No key broadcasts.
    rows.sync=namedButton(spellContent,"Sync Team",335,-352,98,22,function()
        if HB.RequestMacroSync then HB.RequestMacroSync() end
    end)
    rows.syncOpt=namedButton(spellContent,"Allow Sync: OFF",437,-352,118,22,function()
        HB.db.allowMacroSync=not HB.db.allowMacroSync
        HB.RefreshMacroMenu()
    end)
    rows.reset=namedButton(spellContent,"Clean HB Macros",558,-352,95,22,function()
        if HB.ResetOwnedMacros then HB.ResetOwnedMacros(false) end
    end)
    -- Blizzard Spellbook presentation: two columns of icon / name / rank.
    -- Single hardware click creates (if needed) and picks up a managed macro.
    -- No selection state, Ready text or separate Create/Pick Up buttons.
    spellCards={}
    local ICON=51
    local rowHeight=56
    for i=1,PER_PAGE do
        local col=math.floor((i-1)/6)
        local row=(i-1)%6
        local tile=CreateFrame("Button",nil,spellContent)
        tile:RegisterForClicks("LeftButtonUp")
        tile:SetSize(314,rowHeight-2)
        tile:SetPoint("TOPLEFT",spellContent,"TOPLEFT",10+col*324,-7-row*rowHeight)
        tile.tex=tile:CreateTexture(nil,"ARTWORK")
        tile.tex:SetSize(ICON,ICON)
        tile.tex:SetPoint("LEFT",tile,"LEFT",2,0)
        tile.tex:SetTexture("Interface\\Icons\\INV_Misc_QuestionMark")
        tile.name=tile:CreateFontString(nil,"OVERLAY","GameFontNormal")
        tile.name:SetPoint("TOPLEFT",tile,"TOPLEFT",63,-7)
        tile.name:SetWidth(242)
        tile.name:SetJustifyH("LEFT")
        tile.name:SetWordWrap(false)
        tile.level=tile:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
        tile.level:SetPoint("TOPLEFT",tile,"TOPLEFT",63,-27)
        tile.level:SetWidth(242)
        tile.level:SetJustifyH("LEFT")
        tile:SetHighlightTexture("Interface\\Buttons\\UI-Listbox-Highlight2","ADD")
        local function pick(self)
            local entry=self.entry
            if not entry then return end
            if entry.passive then say(entry.title.." is passive; no macro required.") return end
            if not spellKnown(entry) then say("Not learned yet: "..entry.title) return end
            -- Always verify the current BOX profile on a deliberate click,
            -- even when a stale off-body still appears 'owned'.
            if not HB.EnsureMacroPreset(entry.id) then return end
            HB.PickupMacroPreset(entry.id)
        end
        tile:SetScript("OnClick",pick)
        tile:RegisterForDrag("LeftButton")
        tile:SetScript("OnDragStart",pick)
        tile:SetScript("OnEnter",function(self)
            local entry=self.entry
            if not entry or not GameTooltip then return end
            GameTooltip:SetOwner(self,"ANCHOR_RIGHT")
            GameTooltip:SetText(entry.title,1,0.85,0.37)
            local status,r,g,b=spellStatus(entry)
            GameTooltip:AddLine(status,r,g,b)
            GameTooltip:AddLine((entry.category or "Other").." | "..entry.kind,0.75,0.72,0.64)
            if entry.passive then
                GameTooltip:AddLine("Passive ability: no macro needed",0.95,0.61,0.41)
            elseif not spellKnown(entry) then
                GameTooltip:AddLine("Not learned yet",1,0.48,0.38)
            else
                local exists,idx=owned(entry)
                if idx and not exists then
                    GameTooltip:AddLine("Click to verify/sync standard HB macro",1,0.73,0.35)
                    GameTooltip:AddLine("Custom macro text is NEVER overwritten",1,0.54,0.40)
                else
                    GameTooltip:AddLine(exists and "Click to sync and pick up HB macro" or "Click to create and pick up HB macro",0.46,0.9,0.52)
                end
                local profile=HB.IAmLeader and HB.IAmLeader() and "Leader" or
                    (HB.db and HB.db.boxMode and "Follower BOX ON" or "BOX OFF")
                GameTooltip:AddLine("Macro profile: "..profile,0.94,0.79,0.40)
                local macro=HB.PreviewBoxSpell and HB.PreviewBoxSpell(entry.spell,entry.kind)
                if macro then
                    for line in (macro.."\n"):gmatch("(.-)\n") do
                        if line~="" then GameTooltip:AddLine(line,0.88,0.84,0.71) end
                    end
                end
            end
            GameTooltip:Show()
        end)
        tile:SetScript("OnLeave",function() if GameTooltip then GameTooltip:Hide() end end)
        spellCards[i]=tile
    end
    rows.spellPrev=namedButton(spellContent,"<",11,-352,34,22,function()
        spellPage=math.max(1,spellPage-1);HB.RefreshMacroMenu()
    end)
    rows.spellPage=label(spellContent,"",57,-356,205)
    rows.spellNext=namedButton(spellContent,">",245,-352,34,22,function()
        spellPage=math.min(math.max(1,math.ceil(#filteredSpells()/PER_PAGE)),spellPage+1)
        HB.RefreshMacroMenu()
    end)
    notice=label(panel,"",16,-470,651)
    notice:SetWordWrap(true);notice:SetTextColor(0.95,0.79,0.48)
    footer=label(panel,"Local actions require a key press. No auto-casting or input broadcast.",16,-508,651)
    footer:SetTextColor(0.63,0.70,0.77)
    panel:Hide()
end
function HB.RefreshMacroMenu()
    if not panel then return end
    -- Active tab has a gold underline; do NOT show the selected tab as
    -- disabled/grey (which made Multibox appear selected on the spell page).
    tabButtons.box:Hide()
    tabButtons.spells:Hide()
    tabButtons.box.activeLine:SetShown(page=="box")
    tabButtons.spells.activeLine:SetShown(page=="spells")
    if panel.heading then
        panel.heading:SetText("JCDRbox | "..tostring(me() or "").." | Macro Menu")
    end
    local showBox=page=="box"
    -- Hide *entire* tab containers. No headings, buttons or selection from
    -- the other tab may remain visible, regardless of button child state.
    boxContent:SetShown(showBox)
    spellContent:SetShown(not showBox)
    if showBox then
        for i,row in ipairs(rows) do
            local entry=BOX[i]
            refreshKeyWidgets(row,entry)
            -- One bind field per row; macro creation remains available via explicit binding.
        end
        return
    end
    rows.syncOpt:SetText("Allow Sync: "..(HB.db and HB.db.allowMacroSync and "ON" or "OFF"))
    local categories={"All Spells"}
    for _,g in ipairs(FOREVER[me()] or {}) do categories[#categories+1]=g[1] end
    categories[#categories+1]="Other"
    local present=false
    for i,b in ipairs(panel.categoryButtons) do
        b.category=categories[i];b:SetShown(categories[i]~=nil)
        if categories[i] then
            b:SetText(categories[i]);b:SetEnabled(categories[i]~=selectedCategory)
            if categories[i]==selectedCategory then present=true end
        end
    end
    if not present then selectedCategory="All Spells" end
    local entries=filteredSpells()
    local totalPages=math.max(1,math.ceil(#entries/PER_PAGE))
    spellPage=math.min(math.max(1,spellPage),totalPages)
    for i,c in ipairs(spellCards) do
        local entry=entries[(spellPage-1)*PER_PAGE+i]
        c.entry=entry
        c:SetShown(entry~=nil)
        if entry then
            c.name:SetText(entry.title)
            local status,r,g,b=spellStatus(entry)
            c.level:SetText(status)
            c.level:SetTextColor(r,g,b)
            setIcon(c.tex,entry)
            c.tex:SetVertexColor(1,1,1)
            c.name:SetTextColor(r,g,b)

        end
    end
    rows.spellPage:SetText("Page "..spellPage.." / "..totalPages.."   (Lv 1-60)")
    rows.spellPrev:SetEnabled(spellPage>1)
    rows.spellNext:SetEnabled(spellPage<totalPages)
end
local function openMacroPage(wantedPage)
    makePanel()
    local target=wantedPage=="box" and bindingWindow or panel
    if target:IsShown() then
        target:Hide();target:EnableKeyboard(false);waiting=nil;return
    end
    if HB.PrepareQuickSubmenu then HB.PrepareQuickSubmenu(target) end
    setPage(wantedPage)
    if wantedPage=="spells" then scanSpellbook() end
    target:Show()
    HB.RefreshMacroMenu()
    if HB.PositionQuickSettings then HB.PositionQuickSettings(true) end
    if HB.PositionDockedSubmenu then HB.PositionDockedSubmenu(target,true)
    elseif target==panel then resetPlacement()
    else target:SetPoint("CENTER",UIParent,"CENTER") end
end
function HB.OpenMacroMenu() openMacroPage("spells") end
function HB.OpenKeybindingsMenu() openMacroPage("box") end
function HB.RequestMacroSync()
    if not HB.IAmLeader or not HB.IAmLeader() or not (IsInGroup and IsInGroup()) then
        say("Only the party leader can sync macros.") return false
    end
    if not HB.SendTeamMessage then return false end
    HB.macroSyncStatus={sent=0,confirmed={}}
    local n=0
    local box=BOX
    local spells=activeSpells()
    for _,collection in ipairs({box,spells}) do
        for _,entry in ipairs(collection) do
            local yes=owned(entry)
            if yes then
                HB.SendTeamMessage("K|P|"..entry.id)
                local first,second=keyFor(entry)
                if first or second then
                    HB.SendTeamMessage("K|B|"..entry.id..":"..(first or "-")..":"..(second or "-"))
                end
                n=n+1
            end
        end
    end
    HB.macroSyncStatus={sent=n,confirmed={}}
    say("Requested "..n.." managed presets on opted-in followers; wait for ACKs.")
    return true
end
local function trustedLeader(sender)
    local t=HB.TeamManagement
    return t and t.GetReadySignature()~=nil and t.IsLeaderName(sender) or false
end
function HB.OnMacroSyncMessage(sender,code,arg)
    if code=="A" then
        if HB.IAmLeader and HB.IAmLeader() and HB.IsGroupMember and HB.IsGroupMember(sender) then
            HB.macroSyncStatus=HB.macroSyncStatus or {sent=0,confirmed={}}
            HB.macroSyncStatus.confirmed[HB.Norm(sender)..":"..tostring(arg)]=true
            say("Macro sync response from "..tostring(sender)..": "..tostring(arg))
            if arg and (arg:find(":error",1,true) or arg:find(":consent-needed",1,true)) then
                HB.boxSyncError=true
                say("Macro sync issue from "..tostring(sender)..": "..tostring(arg))
            end
        end
        return
    end
    if code~="P" and code~="B" then return end
    if not trustedLeader(sender) then return end
    if not HB.db.allowMacroSync then
        if HB.SendTeamMessage then HB.SendTeamMessage("K|A|"..tostring(arg)..":consent-needed") end
        return
    end
    if locked() then
        if HB.SendTeamMessage then HB.SendTeamMessage("K|A|"..tostring(arg)..":combat") end
        return
    end
    local id,two,three
    if code=="P" then id=arg else
        id,two,three=tostring(arg or ""):match("^([%w]+):([%w%-]+):([%w%-]+)$")
    end
    local entry=preset(id)
    if not entry then return end -- never accept remote arbitrary macros
    if code=="P" then
        local ok=HB.EnsureMacroPreset(id)
        if HB.SendTeamMessage then HB.SendTeamMessage("K|A|"..id..(ok and ":ok" or ":error")) end
    else
        local ok=true
        for slot,key in ipairs({two,three}) do
            if key and key~="-" then
                local used=GetBindingAction and GetBindingAction(key)
                if used and used~="" and used~=bindingAction(entry) then
                    ok=false -- avoid replacing follower's own bindings
                elseif not bindKey(entry,slot,key,false) then ok=false end
            end
        end
        if HB.SendTeamMessage then HB.SendTeamMessage("K|A|"..id..(ok and ":bindings-ok" or ":error")) end
    end
end
-- Explicitly accessible from the console in case a follower needs to opt in
-- while its normal UI is suppressed by Mini Heal.
function HB.SetMacroSyncAllowed(on)
    if not HB.db then return end
    HB.db.allowMacroSync=not not on
    if HB.RefreshMacroMenu then HB.RefreshMacroMenu() end
end

-- Refresh read-only spell cards when the client learns a spell or rank.
if CreateFrame then
    local watcher=CreateFrame("Frame")
    for _,event in ipairs({"PLAYER_ENTERING_WORLD","SPELLS_CHANGED","LEARNED_SPELL_IN_TAB","PLAYER_LEVEL_UP"}) do
        pcall(watcher.RegisterEvent,watcher,event)
    end
    watcher:SetScript("OnEvent",function()
        scanSpellbook()
        if panel and panel:IsShown() then HB.RefreshMacroMenu() end
    end)
end
